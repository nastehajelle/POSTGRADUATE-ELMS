<?php
session_start();
include_once 'config/init.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Features - Benadir University E-Learning Management System</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/landing.css">
    <?php echo FONT_AWESOME_CSS; ?>
    <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;500;600;700&family=Open+Sans:wght@400;500;600&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Header Section -->
    <header class="landing-header">
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-brand">
                    <img src="assets/images/ben.png" alt="Benadir University Logo" class="nav-logo">
                    <span class="nav-title">Benadir University LMS</span>
                </div>
                <div class="nav-menu">
                    <a href="landing.php" class="nav-link">Home</a>
                    <a href="features.php" class="nav-link">Features</a>
                    <a href="about.php" class="nav-link">About Us</a>
                    <a href="testimonials.php" class="nav-link">Testimonials</a>
                    <a href="contact.php" class="nav-link">Contact</a>
                    <a href="auth/login.php" class="btn btn-outline btn-sm">Sign In</a>
                    <a href="auth/register.php" class="btn btn-primary btn-sm">Get Started</a>
                </div>
            </div>
        </nav>
    </header>

    <!-- Features Section -->
    <section class="features-section" style="padding-top: 120px;">
        <div class="section-container">
            <div class="section-header">
                <h1 class="section-title">System Features</h1>
                <p class="section-subtitle">Comprehensive tools designed for modern postgraduate education</p>
            </div>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-user-check"></i>
                    </div>
                    <h3 class="feature-title">Attendance Tracking for Students</h3>
                    <p class="feature-description">Automated attendance tracking system that monitors student participation in live classes and online activities with real-time reporting.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-graduation-cap"></i>
                    </div>
                    <h3 class="feature-title">Postgraduate-Focused Curriculum</h3>
                    <p class="feature-description">Specialized curriculum designed for advanced learning with research-oriented content and academic rigor suitable for graduate studies.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-clipboard-check"></i>
                    </div>
                    <h3 class="feature-title">Comprehensive Assessments</h3>
                    <p class="feature-description">Advanced assessment tools including quizzes, assignments, and examinations with automated grading and detailed feedback systems.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-chart-bar"></i>
                    </div>
                    <h3 class="feature-title">Reports for Admin & Instructors</h3>
                    <p class="feature-description">Detailed analytics and reporting system for administrators and instructors to track student progress, performance, and engagement metrics.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-video"></i>
                    </div>
                    <h3 class="feature-title">Secure Live Classes with Whiteboard</h3>
                    <p class="feature-description">Interactive live classroom sessions with digital whiteboard functionality, screen sharing, and secure video conferencing capabilities.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <h3 class="feature-title">Mobile Responsive Design</h3>
                    <p class="feature-description">Access your courses on any device - desktop, tablet, or smartphone - with our fully responsive and optimized design.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="landing-footer">
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-section">
                    <div class="footer-brand">
                        <img src="assets/images/ben.png" alt="Benadir University Logo" class="footer-logo">
                        <h3>Benadir University</h3>
                        <p>Empowering minds through innovative education and technology.</p>
                    </div>
                </div>
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul class="footer-links">
                        <li><a href="landing.php">Home</a></li>
                        <li><a href="features.php">Features</a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="auth/register.php">Register</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Support</h4>
                    <ul class="footer-links">
                        <li><a href="#">Help Center</a></li>
                        <li><a href="contact.php">Contact Support</a></li>
                        <li><a href="#">Technical Support</a></li>
                        <li><a href="#">Student Resources</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Contact Info</h4>
                    <div class="contact-info">
                        <div class="contact-item">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>Mogadishu, Somalia</span>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-phone"></i>
                            <span>+252 1 234567</span>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-envelope"></i>
                            <span>info@benadir.edu.so</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="footer-bottom-content">
                    <p>&copy; 2024 Benadir University. All rights reserved.</p>
                    <div class="social-links">
                        <a href="#" class="social-link"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-linkedin"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
