<?php
session_start();
include_once 'config/init.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Benadir University E-Learning Management System</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/landing.css">
    <?php echo FONT_AWESOME_CSS; ?>
    <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;500;600;700&family=Open+Sans:wght@400;500;600&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Header Section -->
    <header class="landing-header">
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-brand">
                    <img src="assets/images/ben.png" alt="Benadir University Logo" class="nav-logo">
                    <span class="nav-title">Benadir University LMS</span>
                </div>
                <div class="nav-menu">
                    <a href="landing.php" class="nav-link">Home</a>
                    <a href="features.php" class="nav-link">Features</a>
                    <a href="about.php" class="nav-link">About Us</a>
                    <a href="testimonials.php" class="nav-link">Testimonials</a>
                    <a href="contact.php" class="nav-link">Contact</a>
                    <a href="auth/login.php" class="btn btn-outline btn-sm">Sign In</a>
                    <a href="auth/register.php" class="btn btn-primary btn-sm">Get Started</a>
                </div>
            </div>
        </nav>
    </header>

    <!-- Contact Section -->
    <section class="about-section" style="padding-top: 120px;">
        <div class="section-container">
            <div class="section-header">
                <h1 class="section-title">Contact Us</h1>
                <p class="section-subtitle">Get in touch with our support team</p>
            </div>
            <div class="about-content">
                <div class="about-text">
                    <h2 class="section-title">Get Support</h2>
                    <p class="about-description">
                        Need help with your account or have questions about our E-Learning Management System? 
                        Our dedicated support team is here to assist you with any inquiries or technical issues.
                    </p>
                    <div class="contact-info" style="margin-top: 2rem;">
                        <div class="contact-item" style="margin-bottom: 1rem; display: flex; align-items: center; gap: 1rem;">
                            <i class="fas fa-map-marker-alt" style="color: var(--primary-color); font-size: 1.25rem;"></i>
                            <div>
                                <strong>Address:</strong><br>
                                <span>Mogadishu, Somalia</span>
                            </div>
                        </div>
                        <div class="contact-item" style="margin-bottom: 1rem; display: flex; align-items: center; gap: 1rem;">
                            <i class="fas fa-phone" style="color: var(--primary-color); font-size: 1.25rem;"></i>
                            <div>
                                <strong>Phone:</strong><br>
                                <span>+252 1 234567</span>
                            </div>
                        </div>
                        <div class="contact-item" style="margin-bottom: 1rem; display: flex; align-items: center; gap: 1rem;">
                            <i class="fas fa-envelope" style="color: var(--primary-color); font-size: 1.25rem;"></i>
                            <div>
                                <strong>Email:</strong><br>
                                <span>info@benadir.edu.so</span>
                            </div>
                        </div>
                        <div class="contact-item" style="margin-bottom: 1rem; display: flex; align-items: center; gap: 1rem;">
                            <i class="fas fa-clock" style="color: var(--primary-color); font-size: 1.25rem;"></i>
                            <div>
                                <strong>Support Hours:</strong><br>
                                <span>Sunday - Thursday: 8:00 AM - 6:00 PM</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="about-image">
                    <div class="feature-card" style="height: 100%;">
                        <h3 class="feature-title">Quick Links</h3>
                        <div style="display: flex; flex-direction: column; gap: 1rem;">
                            <a href="auth/register.php" class="btn btn-primary">
                                <i class="fas fa-user-plus"></i>
                                Register Now
                            </a>
                            <a href="auth/login.php" class="btn btn-outline">
                                <i class="fas fa-sign-in-alt"></i>
                                Sign In
                            </a>
                            <a href="features.php" class="btn btn-outline">
                                <i class="fas fa-list"></i>
                                View Features
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="landing-footer">
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-section">
                    <div class="footer-brand">
                        <img src="assets/images/ben.png" alt="Benadir University Logo" class="footer-logo">
                        <h3>Benadir University</h3>
                        <p>Empowering minds through innovative education and technology.</p>
                    </div>
                </div>
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul class="footer-links">
                        <li><a href="landing.php">Home</a></li>
                        <li><a href="features.php">Features</a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="auth/register.php">Register</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Support</h4>
                    <ul class="footer-links">
                        <li><a href="#">Help Center</a></li>
                        <li><a href="contact.php">Contact Support</a></li>
                        <li><a href="#">Technical Support</a></li>
                        <li><a href="#">Student Resources</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Contact Info</h4>
                    <div class="contact-info">
                        <div class="contact-item">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>Mogadishu, Somalia</span>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-phone"></i>
                            <span>+252 1 234567</span>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-envelope"></i>
                            <span>info@benadir.edu.so</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="footer-bottom-content">
                    <p>&copy; 2024 Benadir University. All rights reserved.</p>
                    <div class="social-links">
                        <a href="#" class="social-link"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-linkedin"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
