<?php
session_start();
include_once '../config/init.php';

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$error = '';
$success = '';

// Get programs for dropdown
$programs_query = "SELECT id, name FROM departments";
$programs_stmt = $conn->prepare($programs_query);
$programs_stmt->execute();
$programs = $programs_stmt->fetchAll(PDO::FETCH_ASSOC);

// Process registration form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate input
    $full_name = sanitize_input($_POST['full_name']);
    $email = sanitize_input($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $program_id = sanitize_input($_POST['program_id']);
    $department_id = sanitize_input($_POST['department_id']);
    $gender = sanitize_input($_POST['gender']);
    $phone = sanitize_input($_POST['phone']);
    $address = sanitize_input($_POST['address']);
    
    // New fields
    $mother_name = sanitize_input($_POST['mother_name']);
    $date_of_birth = sanitize_input($_POST['date_of_birth']);
    $place_of_birth = sanitize_input($_POST['place_of_birth']);
    $nationality = sanitize_input($_POST['nationality']);
    $marital_status = sanitize_input($_POST['marital_status']);
    $bachelor_institution = sanitize_input($_POST['bachelor_institution']);
    $bachelor_specialization = sanitize_input($_POST['bachelor_specialization']);
    $bachelor_location = sanitize_input($_POST['bachelor_location']);
    $bachelor_year = sanitize_input($_POST['bachelor_year']);
    $application_type = sanitize_input($_POST['application_type']);
    $language_of_instruction = sanitize_input($_POST['language_of_instruction']);
    $emergency_contact_name = sanitize_input($_POST['emergency_contact_name']);
    $parent_associated_with_uni = isset($_POST['parent_associated_with_uni']) ? 1 : 0;
    $parent_name = sanitize_input($_POST['parent_name']);
    
    // Validate input
    if (empty($full_name) || empty($email) || empty($password) || empty($confirm_password) || 
        empty($program_id) || empty($department_id) || empty($gender) || empty($phone) || empty($address) ||
        empty($mother_name) || empty($date_of_birth) || empty($place_of_birth) || empty($nationality) ||
        empty($marital_status) || empty($bachelor_institution) || empty($bachelor_specialization) ||
        empty($bachelor_location) || empty($bachelor_year) || empty($application_type) ||
        empty($language_of_instruction) || empty($emergency_contact_name)) {
        $error = "Please fill in all required fields";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters long";
    } else {
        try {
            // Check if email already exists
            $check_query = "SELECT id FROM users WHERE email = ?";
            $check_stmt = $conn->prepare($check_query);
            $check_stmt->execute([$email]);
            
            if ($check_stmt->rowCount() > 0) {
                $error = "Email already exists";
            } else {
                // Handle file uploads
                $degree_document = '';
                $profile_photo = '';
                
                // Handle degree document upload
                if (isset($_FILES['degree_document']) && $_FILES['degree_document']['error'] == 0) {
                    $allowed_types = ['application/pdf', 'image/jpeg', 'image/png'];
                    if (in_array($_FILES['degree_document']['type'], $allowed_types)) {
                        $upload_dir = '../uploads/documents/';
                        if (!file_exists($upload_dir)) {
                            mkdir($upload_dir, 0777, true);
                        }
                        $degree_document = $upload_dir . time() . '_' . basename($_FILES['degree_document']['name']);
                        move_uploaded_file($_FILES['degree_document']['tmp_name'], $degree_document);
                    } else {
                        $error = "Invalid document format. Please upload PDF, JPEG, or PNG";
                    }
                } else {
                    $error = "Degree document is required";
                }
                
                // Handle profile photo upload
                if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] == 0) {
                    $allowed_types = ['image/jpeg', 'image/png'];
                    if (in_array($_FILES['profile_photo']['type'], $allowed_types)) {
                        $upload_dir = '../uploads/profiles/';
                        if (!file_exists($upload_dir)) {
                            mkdir($upload_dir, 0777, true);
                        }
                        $profile_photo = $upload_dir . time() . '_' . basename($_FILES['profile_photo']['name']);
                        move_uploaded_file($_FILES['profile_photo']['tmp_name'], $profile_photo);
                    } else {
                        $error = "Invalid photo format. Please upload JPEG or PNG";
                    }
                } else {
                    $error = "Profile photo is required";
                }
                
                if (empty($error)) {
                    // Begin transaction
                    $conn->beginTransaction();
                    
                    // Insert user
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $user_query = "INSERT INTO users (full_name, email, password, role, gender, phone, address, profile_photo, status, created_at) 
                                  VALUES (?, ?, ?, 'student', ?, ?, ?, ?, 'inactive', NOW())";
                    $user_stmt = $conn->prepare($user_query);
                    $user_stmt->execute([$full_name, $email, $hashed_password, $gender, $phone, $address, $profile_photo]);
                    $user_id = $conn->lastInsertId();
                    
                    // Insert student details with new fields
                    $student_query = "INSERT INTO students (user_id, degree_document, mother_name, date_of_birth, place_of_birth, nationality, marital_status, bachelor_institution, bachelor_specialization, bachelor_location, bachelor_year, application_type, language_of_instruction, emergency_contact_name, parent_associated_with_uni, parent_name, declaration_signed, created_at) 
                                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, TRUE, NOW())";
                    $student_stmt = $conn->prepare($student_query);
                    $student_stmt->execute([$user_id, $degree_document, $mother_name, $date_of_birth, $place_of_birth, $nationality, $marital_status, $bachelor_institution, $bachelor_specialization, $bachelor_location, $bachelor_year, $application_type, $language_of_instruction, $emergency_contact_name, $parent_associated_with_uni, $parent_name]);
                    
                    // Insert enrollment
                    $enrollment_query = "INSERT INTO enrollment (user_id, program_id, department_id, created_at) 
                                        VALUES (?, ?, ?, NOW())";
                    $enrollment_stmt = $conn->prepare($enrollment_query);
                    $enrollment_stmt->execute([$user_id, $program_id, $department_id]);
                    
                    // Commit transaction
                    $conn->commit();
                    
                    // Use POST-Redirect-GET pattern to prevent form resubmission
                    $_SESSION['registration_success'] = "Registration successful! Your account is pending approval by the administrator.";
                    header("Location: " . $_SERVER['PHP_SELF'] . "?success=1");
                    exit();
                }
            }
        } catch(PDOException $e) {
            // Rollback transaction on error
            $conn->rollBack();
            $error = "Error: " . $e->getMessage();
        }
    }
}

// Handle success message from redirect
if (isset($_GET['success']) && isset($_SESSION['registration_success'])) {
    $success = $_SESSION['registration_success'];
    unset($_SESSION['registration_success']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/auth.css">
    <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
    <div class="auth-container">
        <div class="wizard-container">
            <!-- Back to Login Button -->
            <div class="back-to-login">
                <a href="login.php" class="back-btn">
                    <i class="fas fa-arrow-left"></i> Back to Login
                </a>
            </div>

            <!-- Wizard Header -->
            <div class="wizard-header">
                <img src="../assets/images/ben.png" alt="Benadir University Logo">
                <h1>Student Registration</h1>
                <p>Join Benadir University - Complete your application in 4 simple steps</p>
            </div>

            <!-- Progress Bar -->
            <div class="progress-container">
                <div class="progress-bar">
                    <div class="progress-line" style="width: 0%"></div>
                    <div class="step-indicator active">1</div>
                    <div class="step-indicator">2</div>
                    <div class="step-indicator">3</div>
                    <div class="step-indicator">4</div>
                </div>
                <div class="step-labels">
                    <div class="step-label active">Personal Info</div>
                    <div class="step-label">Academic Background</div>
                    <div class="step-label">Emergency Contact</div>
                    <div class="step-label">Declaration</div>
                </div>
            </div>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger" style="margin: 1rem 2rem;"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if (!empty($success)): ?>
                <div class="alert alert-success" style="margin: 1rem 2rem;"><?php echo $success; ?></div>
                <div class="text-center" style="padding: 2rem;">
                    <a href="login.php" class="wizard-btn wizard-btn-primary">Go to Login</a>
                </div>
            <?php else: ?>

            <!-- Wizard Content -->
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data" id="registrationForm">
                <div class="wizard-content">
                    
                    <!-- Step 1: Personal Information -->
                    <div class="wizard-step active" id="step1">
                        <h3 class="step-title">Personal Information</h3>
                        <p class="step-description">Please provide your basic personal details</p>
                        
                        <div class="wizard-form-row">
                            <div class="wizard-form-group">
                                <label for="full_name">Full Name <span class="required">*</span></label>
                                <input type="text" id="full_name" name="full_name" required value="<?php echo isset($_POST['full_name']) ? htmlspecialchars($_POST['full_name']) : ''; ?>">
                            </div>
                            <div class="wizard-form-group">
                                <label for="mother_name">Mother's Name <span class="required">*</span></label>
                                <input type="text" id="mother_name" name="mother_name" required value="<?php echo isset($_POST['mother_name']) ? htmlspecialchars($_POST['mother_name']) : ''; ?>">
                            </div>
                        </div>

                        <div class="wizard-form-row">
                            <div class="wizard-form-group">
                                <label for="email">Email Address <span class="required">*</span></label>
                                <input type="email" id="email" name="email" required value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                            </div>
                            <div class="wizard-form-group">
                                <label for="phone">Phone Number <span class="required">*</span></label>
                                <input type="tel" id="phone" name="phone" required value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
                            </div>
                        </div>

                        <div class="wizard-form-row">
                            <div class="wizard-form-group">
                                <label for="password">Password <span class="required">*</span></label>
                                <input type="password" id="password" name="password" required>
                            </div>
                            <div class="wizard-form-group">
                                <label for="confirm_password">Confirm Password <span class="required">*</span></label>
                                <input type="password" id="confirm_password" name="confirm_password" required>
                            </div>
                        </div>

                        <div class="wizard-form-row">
                            <div class="wizard-form-group">
                                <label for="date_of_birth">Date of Birth <span class="required">*</span></label>
                                <input type="date" id="date_of_birth" name="date_of_birth" required value="<?php echo isset($_POST['date_of_birth']) ? htmlspecialchars($_POST['date_of_birth']) : ''; ?>">
                            </div>
                            <div class="wizard-form-group">
                                <label for="place_of_birth">Place of Birth <span class="required">*</span></label>
                                <input type="text" id="place_of_birth" name="place_of_birth" required value="<?php echo isset($_POST['place_of_birth']) ? htmlspecialchars($_POST['place_of_birth']) : ''; ?>">
                            </div>
                        </div>

                        <div class="wizard-form-row">
                            <div class="wizard-form-group">
                                <label for="nationality">Nationality <span class="required">*</span></label>
                                <input type="text" id="nationality" name="nationality" required value="<?php echo isset($_POST['nationality']) ? htmlspecialchars($_POST['nationality']) : ''; ?>">
                            </div>
                            <div class="wizard-form-group">
                                <label for="gender">Gender <span class="required">*</span></label>
                                <select id="gender" name="gender" required>
                                    <option value="">Select Gender</option>
                                    <option value="male" <?php echo (isset($_POST['gender']) && $_POST['gender'] == 'male') ? 'selected' : ''; ?>>Male</option>
                                    <option value="female" <?php echo (isset($_POST['gender']) && $_POST['gender'] == 'female') ? 'selected' : ''; ?>>Female</option>
                                </select>
                            </div>
                        </div>

                        <div class="wizard-form-row">
                            <div class="wizard-form-group">
                                <label for="marital_status">Marital Status <span class="required">*</span></label>
                                <select id="marital_status" name="marital_status" required>
                                    <option value="">Select Status</option>
                                    <option value="Single" <?php echo (isset($_POST['marital_status']) && $_POST['marital_status'] == 'Single') ? 'selected' : ''; ?>>Single</option>
                                    <option value="Married" <?php echo (isset($_POST['marital_status']) && $_POST['marital_status'] == 'Married') ? 'selected' : ''; ?>>Married</option>
                                </select>
                            </div>
                            <div class="wizard-form-group">
                                <label for="language_of_instruction">Preferred Language <span class="required">*</span></label>
                                <select id="language_of_instruction" name="language_of_instruction" required>
                                    <option value="">Select Language</option>
                                    <option value="English" <?php echo (isset($_POST['language_of_instruction']) && $_POST['language_of_instruction'] == 'English') ? 'selected' : ''; ?>>English</option>
                                    <option value="Arabic" <?php echo (isset($_POST['language_of_instruction']) && $_POST['language_of_instruction'] == 'Arabic') ? 'selected' : ''; ?>>Arabic</option>
                                    <option value="Other" <?php echo (isset($_POST['language_of_instruction']) && $_POST['language_of_instruction'] == 'Other') ? 'selected' : ''; ?>>Other</option>
                                </select>
                            </div>
                        </div>

                        <div class="wizard-form-group full-width">
                            <label for="address">Home Address <span class="required">*</span></label>
                            <textarea id="address" name="address" required><?php echo isset($_POST['address']) ? htmlspecialchars($_POST['address']) : ''; ?></textarea>
                        </div>

                        <div class="wizard-form-row">
                            <div class="wizard-form-group">
                                <label for="profile_photo">Profile Photo <span class="required">*</span></label>
                                <div class="file-upload-group">
                                    <input type="file" id="profile_photo" name="profile_photo" accept="image/*" required>
                                    <div class="file-upload-info">Upload a clear photo (JPEG/PNG)</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Step 2: Academic Background -->
                    <div class="wizard-step" id="step2">
                        <h3 class="step-title">Academic Background</h3>
                        <p class="step-description">Tell us about your educational background and program preferences</p>
                        
                        <!-- Department Dropdown -->
<div class="form-group">
  <label for="department_id">Department</label>
  <select name="department_id" id="department_id" class="form-control" required>
    <option value="">Select Department</option>
    <?php
      $departments_query = "SELECT id, name FROM departments";
      $stmt = $conn->prepare($departments_query);
      $stmt->execute();
      while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
      }
    ?>
  </select>
</div>

<!-- Program Dropdown -->
<div class="form-group">
  <label for="program_id">Program</label>
  <select name="program_id" id="program_id" class="form-control" required>
    <option value="">Select Program</option>
  </select>
</div>


                        <div class="wizard-form-row">
                            <div class="wizard-form-group">
                                <label for="application_type">Application Type <span class="required">*</span></label>
                                <select id="application_type" name="application_type" required>
                                    <option value="">Select Type</option>
                                    <option value="First Year" <?php echo (isset($_POST['application_type']) && $_POST['application_type'] == 'First Year') ? 'selected' : ''; ?>>First Year</option>
                                    <option value="Transfer" <?php echo (isset($_POST['application_type']) && $_POST['application_type'] == 'Transfer') ? 'selected' : ''; ?>>Transfer</option>
                                </select>
                            </div>
                        </div>

                        <h4 style="margin: 2rem 0 1rem 0; color: var(--text-color);">Bachelor's Degree Information</h4>
                        
                        <div class="wizard-form-row">
                            <div class="wizard-form-group">
                                <label for="bachelor_institution">Institution Name <span class="required">*</span></label>
                                <input type="text" id="bachelor_institution" name="bachelor_institution" required value="<?php echo isset($_POST['bachelor_institution']) ? htmlspecialchars($_POST['bachelor_institution']) : ''; ?>">
                            </div>
                            <div class="wizard-form-group">
                                <label for="bachelor_specialization">Specialization <span class="required">*</span></label>
                                <input type="text" id="bachelor_specialization" name="bachelor_specialization" required value="<?php echo isset($_POST['bachelor_specialization']) ? htmlspecialchars($_POST['bachelor_specialization']) : ''; ?>">
                            </div>
                        </div>

                        <div class="wizard-form-row">
                            <div class="wizard-form-group">
                                <label for="bachelor_location">Institution Location <span class="required">*</span></label>
                                <input type="text" id="bachelor_location" name="bachelor_location" required value="<?php echo isset($_POST['bachelor_location']) ? htmlspecialchars($_POST['bachelor_location']) : ''; ?>">
                            </div>
                            <div class="wizard-form-group">
                                <label for="bachelor_year">Graduation Year <span class="required">*</span></label>
                                <input type="number" id="bachelor_year" name="bachelor_year" min="1990" max="2030" required value="<?php echo isset($_POST['bachelor_year']) ? htmlspecialchars($_POST['bachelor_year']) : ''; ?>">
                            </div>
                        </div>

                        <div class="wizard-form-group full-width">
                            <label for="degree_document">Bachelor's Degree Document <span class="required">*</span></label>
                            <div class="file-upload-group">
                                <input type="file" id="degree_document" name="degree_document" accept=".pdf,image/*" required>
                                <div class="file-upload-info">Upload your degree certificate (PDF or Image)</div>
                            </div>
                        </div>
                    </div>

                    <!-- Step 3: Emergency Contact -->
                    <div class="wizard-step" id="step3">
                        <h3 class="step-title">Emergency Contact & Family Information</h3>
                        <p class="step-description">Provide emergency contact details for safety purposes</p>
                        
                        <div class="wizard-form-group">
                            <label for="emergency_contact_name">Emergency Contact Name <span class="required">*</span></label>
                            <input type="text" id="emergency_contact_name" name="emergency_contact_name" required value="<?php echo isset($_POST['emergency_contact_name']) ? htmlspecialchars($_POST['emergency_contact_name']) : ''; ?>">
                        </div>

                        <div class="checkbox-group">
                            <input type="checkbox" id="parent_associated_with_uni" name="parent_associated_with_uni" <?php echo (isset($_POST['parent_associated_with_uni'])) ? 'checked' : ''; ?>>
                            <label for="parent_associated_with_uni">Is any of your parents associated with Benadir University?</label>
                        </div>

                        <div class="wizard-form-group" id="parentNameGroup" style="display: <?php echo (isset($_POST['parent_associated_with_uni'])) ? 'block' : 'none'; ?>;">
                            <label for="parent_name">Parent's Name</label>
                            <input type="text" id="parent_name" name="parent_name" value="<?php echo isset($_POST['parent_name']) ? htmlspecialchars($_POST['parent_name']) : ''; ?>">
                        </div>
                    </div>

                    <!-- Step 4: Declaration -->
                    <div class="wizard-step" id="step4">
                        <h3 class="step-title">Declaration & Agreement</h3>
                        <p class="step-description">Please read and agree to the following terms</p>
                        
                        <div class="declaration-content">
                            <h4>Student Declaration</h4>
                            <p>By submitting this application, I declare that:</p>
                            <ul>
                                <li>All information provided in this application is true and accurate to the best of my knowledge</li>
                                <li>I understand that providing false information may result in rejection of my application or dismissal from the university</li>
                                <li>I agree to abide by all university rules, regulations, and policies</li>
                                <li>I understand that my application is subject to verification and approval by the admissions committee</li>
                                <li>I consent to the university contacting me regarding my application status</li>
                                <li>I understand that submission of this application does not guarantee admission</li>
                            </ul>
                        </div>

                        <div class="checkbox-group">
                            <input type="checkbox" id="declaration_signed" name="declaration_signed" required>
                            <label for="declaration_signed">
                                <strong>I have read and agree to the above declaration <span class="required">*</span></strong>
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Navigation -->
                <div class="wizard-navigation">
                    <div class="wizard-nav-buttons">
                        <button type="button" id="prevBtn" class="wizard-btn wizard-btn-secondary" style="display: none;">
                            <i class="fas fa-arrow-left"></i> Previous
                        </button>
                        <button type="button" id="nextBtn" class="wizard-btn wizard-btn-primary">
                            Next <i class="fas fa-arrow-right"></i>
                        </button>
                        <button type="submit" id="submitBtn" class="wizard-btn wizard-btn-primary" style="display: none;">
                            <i class="fas fa-check"></i> Submit Application
                        </button>
                    </div>
                </div>
            </form>

            <?php endif; ?>
        </div>
    </div>

    <script src="../assets/js/auth.js"></script>
    <script src="../assets/js/theme.js"></script>
</body>
</html>
