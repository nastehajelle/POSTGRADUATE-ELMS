<?php
session_start();
include_once '../config/init.php';

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$error = '';

// Process login form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = sanitize_input($_POST['email']);
    $password = $_POST['password'];
    
    // Validate input
    if (empty($email) || empty($password)) {
        $error = "Please fill in all fields";
    } else {
        try {
            $query = "SELECT u.id, u.email, u.password, u.role, u.status, s.status as student_status
                      FROM users u 
                      LEFT JOIN students s ON u.id = s.user_id 
                      WHERE u.email = ?";
            $stmt = $conn->prepare($query);
            $stmt->execute([$email]);
            
            if ($stmt->rowCount() > 0) {
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                // Verify password
                if (password_verify($password, $user['password'])) {
                    if ($user['status'] == 'active') {
                        if ($user['role'] === 'student' && $user['student_status'] === 'dead') {
                            $error = "Your account has been deactivated. Please contact the administration.";
                        } else {
                            // Set session variables
                            $_SESSION['user_id'] = $user['id'];
                            $_SESSION['email'] = $user['email'];
                            $_SESSION['role'] = $user['role'];
                            
                            if ($user['role'] === 'student') {
                                $_SESSION['student_status'] = $user['student_status'];
                            }
                            
                            // Redirect based on role
                            if ($user['role'] === 'admin') {
                                header("Location: ../admin/dashboard.php");
                            } elseif ($user['role'] === 'student') {
                                header("Location: ../student/dashboard.php");
                            } elseif ($user['role'] === 'instructor') {
                                header("Location: ../instructor/dashboard.php");
                            }
                            exit();
                        }
                    } else {
                        $error = "Your account is not active. Please wait for admin approval.";
                    }
                } else {
                    $error = "Invalid email or password";
                }
            } else {
                $error = "Invalid email or password";
            }
        } catch(PDOException $e) {
            $error = "Error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/auth.css">
    <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
    <div class="auth-container">
        <div class="auth-form-container">
            <!-- Header Section -->
            <div class="auth-header">
                <div class="auth-logo">
                    <img src="../assets/images/ben.png" alt="Benadir University Logo">
                </div>
                <div class="auth-title-section">
                    <h1>Welcome Back</h1>
                    <p class="auth-subtitle">Sign in to your Benadir University LMS account</p>
                </div>
            </div>

            <!-- Alert Section -->
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span><?php echo $error; ?></span>
                </div>
            <?php endif; ?>
            
            <!-- Login Form Section -->
            <div class="auth-form-section">
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="auth-form">
                    <div class="form-fields-container">
                        <div class="form-group">
                            <label for="email">
                                <i class="fas fa-envelope"></i>
                                Email Address
                            </label>
                            <input type="email" id="email" name="email" required 
                                   placeholder="Enter your email address"
                                   value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="password">
                                <i class="fas fa-lock"></i>
                                Password
                            </label>
                            <div class="password-input-container">
                                <input type="password" id="password" name="password" required 
                                       placeholder="Enter your password">
                                <button type="button" class="password-toggle" onclick="togglePassword()">
                                    <i class="fas fa-eye" id="password-eye"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-options">
                        <div class="remember-me">
                            <input type="checkbox" id="remember" name="remember">
                            <label for="remember">Remember me</label>
                        </div>
                        <a href="forgot-password.php" class="forgot-password-link">
                            Forgot Password?
                        </a>
                    </div>
                    
                    <div class="form-submit-section">
                        <button type="submit" class="btn btn-primary btn-block">
                            <i class="fas fa-sign-in-alt"></i>
                            Sign In
                        </button>
                    </div>
                </form>
            </div>

            <!-- Footer Section -->
            <div class="auth-footer">
                <div class="auth-divider">
                    <span>Don't have an account?</span>
                </div>
                <div class="auth-register-section">
                    <a href="register.php" class="btn btn-outline">
                        <i class="fas fa-user-plus"></i>
                        Register as Student
                    </a>
                </div>
                <div class="auth-help-section">
                    <p>Need help? <a href="#" class="help-link">Contact Support</a></p>
                </div>
            </div>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/auth.js"></script>
</body>
</html>
