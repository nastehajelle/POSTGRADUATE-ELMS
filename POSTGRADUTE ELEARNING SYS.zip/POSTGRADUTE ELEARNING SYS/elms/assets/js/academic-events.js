// Academic Events JavaScript - Consistent with other admin pages
document.addEventListener("DOMContentLoaded", () => {
  // Modal elements
  const modal = document.getElementById("eventModal")
  const addEventBtn = document.getElementById("addEventBtn")
  const closeBtn = document.querySelector(".btn-close")
  const eventForm = document.getElementById("eventForm")
  const modalTitle = document.getElementById("modalTitle")
  const cancelBtns = document.querySelectorAll('[data-bs-dismiss="modal"]')

  let editingEventId = null

  // Open modal for adding new event
  addEventBtn.addEventListener("click", () => {
    openModal("Add New Event")
    resetForm()
    editingEventId = null
  })

  // Close modal handlers
  closeBtn.addEventListener("click", closeModal)
  cancelBtns.forEach((btn) => {
    btn.addEventListener("click", closeModal)
  })

  // Close modal when clicking outside
  window.addEventListener("click", (event) => {
    if (event.target === modal) {
      closeModal()
    }
  })

  // Form submission
  eventForm.addEventListener("submit", (e) => {
    e.preventDefault()
    submitEvent()
  })

  // Edit and delete button handlers
  document.addEventListener("click", (e) => {
    if (e.target.closest(".btn-edit")) {
      const eventId = e.target.closest(".btn-edit").getAttribute("data-id")
      editEvent(eventId)
    }

    if (e.target.closest(".btn-delete")) {
      const eventId = e.target.closest(".btn-delete").getAttribute("data-id")
      deleteEvent(eventId)
    }
  })

  function openModal(title) {
    modalTitle.textContent = title
    modal.style.display = "block"
    document.body.style.overflow = "hidden"
  }

  function closeModal() {
    modal.style.display = "none"
    document.body.style.overflow = "auto"
    resetForm()
    editingEventId = null
  }

  function resetForm() {
    eventForm.reset()
    document.getElementById("eventId").value = ""
  }

  function submitEvent() {
    const formData = new FormData(eventForm)

    if (editingEventId) {
      formData.append("action", "update")
      formData.append("id", editingEventId)
    } else {
      formData.append("action", "create")
    }

    fetch("academic-events.php", {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          showAlert("Event saved successfully!", "success")
          closeModal()
          setTimeout(() => {
            location.reload()
          }, 1000)
        } else {
          showAlert(data.message || "Error saving event", "danger")
        }
      })
      .catch((error) => {
        console.error("Error:", error)
        showAlert("Error saving event", "danger")
      })
  }

  function editEvent(eventId) {
    fetch(`academic-events.php?action=get&id=${eventId}`)
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          const event = data.event
          document.getElementById("title").value = event.title
          document.getElementById("description").value = event.description
          document.getElementById("event_date").value = event.event_date
          document.getElementById("start_time").value = event.start_time || ""
          document.getElementById("end_time").value = event.end_time || ""
          document.getElementById("event_type").value = event.event_type

          editingEventId = eventId
          openModal("Edit Event")
        } else {
          showAlert("Error loading event data", "danger")
        }
      })
      .catch((error) => {
        console.error("Error:", error)
        showAlert("Error loading event data", "danger")
      })
  }

  function deleteEvent(eventId) {
    if (confirm("Are you sure you want to delete this event?")) {
      const formData = new FormData()
      formData.append("action", "delete")
      formData.append("id", eventId)

      fetch("academic-events.php", {
        method: "POST",
        body: formData,
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            showAlert("Event deleted successfully!", "success")
            setTimeout(() => {
              location.reload()
            }, 1000)
          } else {
            showAlert(data.message || "Error deleting event", "danger")
          }
        })
        .catch((error) => {
          console.error("Error:", error)
          showAlert("Error deleting event", "danger")
        })
    }
  }

  function showAlert(message, type) {
    // Remove existing alerts
    const existingAlerts = document.querySelectorAll(".alert-notification")
    existingAlerts.forEach((alert) => alert.remove())

    // Create new alert
    const alert = document.createElement("div")
    alert.className = `alert alert-${type} alert-notification`
    alert.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 10000;
            min-width: 300px;
            animation: slideInRight 0.3s ease;
        `

    alert.innerHTML = `
            <i class="fas fa-${type === "success" ? "check-circle" : "exclamation-triangle"}"></i>
            ${message}
        `

    document.body.appendChild(alert)

    // Remove alert after 3 seconds
    setTimeout(() => {
      alert.style.animation = "slideOutRight 0.3s ease"
      setTimeout(() => {
        if (alert.parentNode) {
          alert.parentNode.removeChild(alert)
        }
      }, 300)
    }, 3000)
  }

  // Add CSS animations
  const style = document.createElement("style")
  style.textContent = `
        @keyframes slideInRight {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOutRight {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
    `
  document.head.appendChild(style)
})
