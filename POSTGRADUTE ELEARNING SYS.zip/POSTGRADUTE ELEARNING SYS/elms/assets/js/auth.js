// Auth Pages JavaScript - Combined login and registration functionality

// Registration Wizard Class
class RegistrationWizard {
  constructor() {
    this.currentStep = 1
    this.totalSteps = 4
    this.init()
  }

  init() {
    this.updateProgressBar()
    this.bindEvents()
    this.showStep(1)
  }

  bindEvents() {
    // Next button
    const nextBtn = document.getElementById("nextBtn")
    if (nextBtn) {
      nextBtn.addEventListener("click", () => {
        if (this.validateCurrentStep()) {
          this.nextStep()
        }
      })
    }

    // Previous button
    const prevBtn = document.getElementById("prevBtn")
    if (prevBtn) {
      prevBtn.addEventListener("click", () => {
        this.prevStep()
      })
    }

    // Form submission
    const registrationForm = document.getElementById("registrationForm")
    if (registrationForm) {
      registrationForm.addEventListener("submit", (e) => {
        if (this.currentStep !== this.totalSteps) {
          e.preventDefault()
          return false
        }
        if (!this.validateCurrentStep()) {
          e.preventDefault()
          return false
        }
      })
    }

    // Parent association checkbox
    const parentCheckbox = document.getElementById("parent_associated_with_uni")
    if (parentCheckbox) {
      parentCheckbox.addEventListener("change", (e) => {
        const parentNameGroup = document.getElementById("parentNameGroup")
        const parentNameInput = document.getElementById("parent_name")
        if (parentNameGroup && parentNameInput) {
          if (e.target.checked) {
            parentNameGroup.style.display = "block"
            parentNameInput.required = true
          } else {
            parentNameGroup.style.display = "none"
            parentNameInput.required = false
            parentNameInput.value = ""
          }
        }
      })
    }

    // Department change handler to load programs
    const departmentSelect = document.getElementById("department_id")
    const programSelect = document.getElementById("program_id")

    if (departmentSelect && programSelect) {
      departmentSelect.addEventListener("change", function () {
        const departmentId = this.value

        if (!departmentId) {
          programSelect.innerHTML = '<option value="">Select Program</option>'
          return
        }

        programSelect.innerHTML = '<option>Loading...</option>'
        programSelect.disabled = true

        fetch('../api/get_programs.php?department_id=' + departmentId)
          .then(response => response.json())
          .then(data => {
            let options = '<option value="">Select Program</option>'
            data.forEach(program => {
              options += `<option value="${program.id}">${program.name}</option>`
            })
            programSelect.innerHTML = options
            programSelect.disabled = false
          })
          .catch(error => {
            console.error('Error fetching programs:', error)
            programSelect.innerHTML = '<option value="">Error loading programs</option>'
            programSelect.disabled = false
          })
      })
    }
  }

  showStep(step) {
    document.querySelectorAll(".wizard-step").forEach((stepEl) => {
      stepEl.classList.remove("active")
    })

    const currentStepEl = document.getElementById(`step${step}`)
    if (currentStepEl) {
      currentStepEl.classList.add("active")
    }

    this.updateNavigationButtons()
    this.updateProgressBar()
  }

  nextStep() {
    if (this.currentStep < this.totalSteps) {
      this.currentStep++
      this.showStep(this.currentStep)
      const wizardContent = document.querySelector(".wizard-content")
      if (wizardContent) wizardContent.scrollTop = 0
    }
  }

  prevStep() {
    if (this.currentStep > 1) {
      this.currentStep--
      this.showStep(this.currentStep)
      const wizardContent = document.querySelector(".wizard-content")
      if (wizardContent) wizardContent.scrollTop = 0
    }
  }

  updateNavigationButtons() {
    const prevBtn = document.getElementById("prevBtn")
    const nextBtn = document.getElementById("nextBtn")
    const submitBtn = document.getElementById("submitBtn")

    if (prevBtn) {
      prevBtn.style.display = this.currentStep === 1 ? "none" : "inline-flex"
    }

    if (this.currentStep === this.totalSteps) {
      if (nextBtn) nextBtn.style.display = "none"
      if (submitBtn) submitBtn.style.display = "inline-flex"
    } else {
      if (nextBtn) nextBtn.style.display = "inline-flex"
      if (submitBtn) submitBtn.style.display = "none"
    }
  }

  updateProgressBar() {
    const progressLine = document.querySelector(".progress-line")
    const stepIndicators = document.querySelectorAll(".step-indicator")
    const stepLabels = document.querySelectorAll(".step-label")

    if (progressLine) {
      const progressPercentage = ((this.currentStep - 1) / (this.totalSteps - 1)) * 100
      progressLine.style.width = `${progressPercentage}%`
    }

    stepIndicators.forEach((indicator, index) => {
      const stepNumber = index + 1
      indicator.classList.remove("active", "completed")

      if (stepNumber < this.currentStep) {
        indicator.classList.add("completed")
        indicator.innerHTML = '<i class="fas fa-check"></i>'
      } else if (stepNumber === this.currentStep) {
        indicator.classList.add("active")
        indicator.innerHTML = stepNumber
      } else {
        indicator.innerHTML = stepNumber
      }
    })

    stepLabels.forEach((label, index) => {
      label.classList.remove("active")
      if (index + 1 === this.currentStep) {
        label.classList.add("active")
      }
    })
  }

  validateCurrentStep() {
    const currentStepEl = document.getElementById(`step${this.currentStep}`)
    if (!currentStepEl) return true

    const requiredFields = currentStepEl.querySelectorAll("[required]")
    let isValid = true

    requiredFields.forEach((field) => {
      field.style.borderColor = ""
      const errorMsg = field.parentNode.querySelector(".field-error")
      if (errorMsg) errorMsg.remove()
    })

    requiredFields.forEach((field) => {
      if (!field.value.trim()) {
        field.style.borderColor = "#ef4444"
        const errorMsg = document.createElement("div")
        errorMsg.className = "field-error"
        errorMsg.textContent = "This field is required"
        errorMsg.style.color = "#ef4444"
        errorMsg.style.fontSize = "0.8rem"
        errorMsg.style.marginTop = "0.25rem"
        field.parentNode.appendChild(errorMsg)
        isValid = false
      }
    })

    if (this.currentStep === 1) isValid = this.validateStep1() && isValid
    if (this.currentStep === 4) isValid = this.validateStep4() && isValid

    if (!isValid) this.showError("Please fill in all required fields correctly.")
    return isValid
  }

  validateStep1() {
    const password = document.getElementById("password")
    const confirmPassword = document.getElementById("confirm_password")
    const email = document.getElementById("email")
    let isValid = true

    if (!password || !confirmPassword || !email) return true

    if (password.value.length < 6) {
      this.addFieldError(password, "Password must be at least 6 characters long.")
      isValid = false
    }

    if (password.value !== confirmPassword.value) {
      this.addFieldError(confirmPassword, "Passwords do not match.")
      isValid = false
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email.value)) {
      this.addFieldError(email, "Please enter a valid email address.")
      isValid = false
    }

    return isValid
  }

  validateStep4() {
    const declarationSigned = document.getElementById("declaration_signed")
    if (declarationSigned && !declarationSigned.checked) {
      this.showError("You must agree to the declaration to proceed.")
      return false
    }
    return true
  }

  addFieldError(field, message) {
    field.style.borderColor = "#ef4444"
    const existingError = field.parentNode.querySelector(".field-error")
    if (existingError) existingError.remove()

    const errorMsg = document.createElement("div")
    errorMsg.className = "field-error"
    errorMsg.textContent = message
    errorMsg.style.color = "#ef4444"
    errorMsg.style.fontSize = "0.8rem"
    errorMsg.style.marginTop = "0.25rem"
    field.parentNode.appendChild(errorMsg)
  }

  showError(message) {
    const existingAlert = document.querySelector(".wizard-error-alert")
    if (existingAlert) existingAlert.remove()

    const alert = document.createElement("div")
    alert.className = "alert alert-danger wizard-error-alert"
    alert.textContent = message
    alert.style.marginBottom = "1rem"

    const currentStep = document.getElementById(`step${this.currentStep}`)
    if (currentStep) {
      currentStep.insertBefore(alert, currentStep.firstChild)
      setTimeout(() => {
        if (alert.parentNode) alert.remove()
      }, 5000)
    }
  }
}

document.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById("registrationForm")) {
    console.log("Initializing registration wizard...")
    new RegistrationWizard()
  }
})
