// Reports Page JavaScript
document.addEventListener("DOMContentLoaded", () => {
  // Auto-hide alerts
  const alerts = document.querySelectorAll(".alert")
  alerts.forEach((alert) => {
    setTimeout(() => {
      alert.style.opacity = "0"
      setTimeout(() => {
        alert.remove()
      }, 300)
    }, 5000)
  })

  // Form submission with loading states
  const filterForm = document.querySelector(".filters-form")
  if (filterForm) {
    filterForm.addEventListener("submit", (e) => {
      const submitBtn = filterForm.querySelector('button[type="submit"]')
      const originalText = submitBtn.innerHTML
      submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Applying...'
      submitBtn.disabled = true

      // Re-enable if form submission fails
      setTimeout(() => {
        submitBtn.innerHTML = originalText
        submitBtn.disabled = false
      }, 10000)
    })
  }

  // Export form handling
  const exportForm = document.getElementById("exportForm")
  if (exportForm) {
    exportForm.addEventListener("submit", (e) => {
      const submitBtn = exportForm.querySelector('button[type="submit"]')
      const originalText = submitBtn.innerHTML
      submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Exporting...'
      submitBtn.disabled = true

      // Close modal after short delay
      setTimeout(() => {
        closeExportModal()
        submitBtn.innerHTML = originalText
        submitBtn.disabled = false
      }, 2000)
    })
  }

  // Smooth scroll for internal links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault()
      const target = document.querySelector(this.getAttribute("href"))
      if (target) {
        target.scrollIntoView({
          behavior: "smooth",
          block: "start",
        })
      }
    })
  })

  // Add tooltips to stat cards
  const statCards = document.querySelectorAll(".stat-card")
  statCards.forEach((card) => {
    card.addEventListener("mouseenter", function () {
      this.style.transform = "translateY(-4px)"
    })

    card.addEventListener("mouseleave", function () {
      this.style.transform = "translateY(-2px)"
    })
  })

  // Table row selection
  const tableRows = document.querySelectorAll(".report-table tbody tr")
  tableRows.forEach((row) => {
    row.addEventListener("click", function () {
      // Remove previous selection
      tableRows.forEach((r) => r.classList.remove("selected"))
      // Add selection to current row
      this.classList.add("selected")
    })
  })

  // Keyboard shortcuts
  document.addEventListener("keydown", (e) => {
    // Ctrl/Cmd + P for print
    if ((e.ctrlKey || e.metaKey) && e.key === "p") {
      e.preventDefault()
      window.print()
    }

    // Ctrl/Cmd + E for export
    if ((e.ctrlKey || e.metaKey) && e.key === "e") {
      e.preventDefault()
      showExportModal()
    }

    // Escape to close modal
    if (e.key === "Escape") {
      closeExportModal()
    }
  })

  // Auto-refresh functionality
  const autoRefreshCheckbox = document.getElementById("autoRefresh")
  if (autoRefreshCheckbox) {
    let refreshInterval

    autoRefreshCheckbox.addEventListener("change", function () {
      if (this.checked) {
        refreshInterval = setInterval(() => {
          // Auto-refresh every 30 seconds
          const currentUrl = new URL(window.location)
          currentUrl.searchParams.set("refresh", Date.now())
          window.location.href = currentUrl.toString()
        }, 30000)
      } else {
        clearInterval(refreshInterval)
      }
    })
  }

  // Print functionality
  const printButton = document.querySelector('button[onclick="window.print()"]')
  if (printButton) {
    printButton.addEventListener("click", (e) => {
      e.preventDefault()

      // Add print-specific styles
      document.body.classList.add("printing")

      // Trigger print
      window.print()

      // Remove print styles after printing
      setTimeout(() => {
        document.body.classList.remove("printing")
      }, 1000)
    })
  }

  // Chart responsiveness
  window.addEventListener("resize", () => {
    // Charts will automatically resize due to responsive: true option
    // This is just a placeholder for any additional resize logic
  })

  // Add loading animation for charts
  const chartContainers = document.querySelectorAll("canvas")
  chartContainers.forEach((canvas) => {
    const container = canvas.parentElement
    container.style.position = "relative"

    // Add loading spinner
    const loader = document.createElement("div")
    loader.className = "chart-loader"
    loader.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading chart...'
    loader.style.cssText = `
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: var(--text-muted);
            font-size: 0.875rem;
        `

    container.appendChild(loader)

    // Remove loader when chart is ready
    setTimeout(() => {
      if (loader.parentElement) {
        loader.remove()
      }
    }, 1000)
  })
})

// Export Modal Functions
function showExportModal() {
  const modal = document.getElementById("exportModal")
  if (modal) {
    modal.classList.add("show")
    // Focus first input
    const firstInput = modal.querySelector("select")
    if (firstInput) {
      firstInput.focus()
    }
  }
}

function closeExportModal() {
  const modal = document.getElementById("exportModal")
  if (modal) {
    modal.classList.remove("show")
  }
}

// Click outside modal to close
document.addEventListener("click", (e) => {
  const modal = document.getElementById("exportModal")
  if (modal && modal.classList.contains("show") && e.target === modal) {
    closeExportModal()
  }
})

// Utility Functions
function formatCurrency(amount) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(amount)
}

function formatDate(dateString) {
  return new Date(dateString).toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  })
}

function formatDateTime(dateString) {
  return new Date(dateString).toLocaleString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  })
}

// Utility function to format numbers
function formatNumber(num) {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + "M"
  } else if (num >= 1000) {
    return (num / 1000).toFixed(1) + "K"
  }
  return num.toString()
}

// Search and Filter Helpers
function debounce(func, wait) {
  let timeout
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout)
      func(...args)
    }
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

// Live search (if needed)
const searchInput = document.querySelector('input[name="search"]')
if (searchInput) {
  const debouncedSearch = debounce((value) => {
    // Auto-submit form on search (optional)
    // searchInput.form.submit();
  }, 500)

  searchInput.addEventListener("input", (e) => {
    debouncedSearch(e.target.value)
  })
}

// Table sorting helpers (if adding client-side sorting)
function sortTable(columnIndex, dataType = "string") {
  const table = document.getElementById("reportTable")
  if (!table) return

  const tbody = table.querySelector("tbody")
  const rows = Array.from(tbody.querySelectorAll("tr"))

  const sortedRows = rows.sort((a, b) => {
    const aValue = a.cells[columnIndex].textContent.trim()
    const bValue = b.cells[columnIndex].textContent.trim()

    switch (dataType) {
      case "number":
        return Number.parseFloat(aValue) - Number.parseFloat(bValue)
      case "date":
        return new Date(aValue) - new Date(bValue)
      default:
        return aValue.localeCompare(bValue)
    }
  })

  // Clear tbody and append sorted rows
  tbody.innerHTML = ""
  sortedRows.forEach((row) => tbody.appendChild(row))
}

// Print function with custom styling
function printReport() {
  // Add print-specific styles
  document.body.classList.add("printing")

  // Custom print setup
  const printContent = document.querySelector(".report-table-section").cloneNode(true)
  const printWindow = window.open("", "_blank")

  printWindow.document.write(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Report - ${document.title}</title>
      <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 8px; border: 1px solid #ddd; text-align: left; }
        th { background-color: #f5f5f5; font-weight: bold; }
        .table-header { margin-bottom: 20px; }
        .table-title { font-size: 24px; font-weight: bold; margin-bottom: 10px; }
        .table-meta { font-size: 14px; color: #666; }
      </style>
    </head>
    <body>
      ${printContent.outerHTML}
    </body>
    </html>
  `)

  printWindow.document.close()
  printWindow.print()
  printWindow.close()

  // Remove print class
  setTimeout(() => {
    document.body.classList.remove("printing")
  }, 1000)
}

// Function to update statistics (for real-time updates if needed)
function updateStatistics() {
  // This function can be called periodically to update statistics
  // Implementation would depend on your real-time requirements
  console.log("Statistics updated")
}

// Export function for additional formats (if needed)
function exportToJSON(data, filename) {
  const jsonStr = JSON.stringify(data, null, 2)
  const blob = new Blob([jsonStr], { type: "application/json" })
  const url = URL.createObjectURL(blob)

  const a = document.createElement("a")
  a.href = url
  a.download = filename + ".json"
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
}
