// Notifications Management JavaScript

// Modal functions
function openCreateModal() {
  document.getElementById("createModal").style.display = "block"
}

function closeCreateModal() {
  document.getElementById("createModal").style.display = "none"
  // Reset form
  document.querySelector("#createModal form").reset()
  updateCharacterCounter() // Reset counter
}

function openDeleteModal() {
  document.getElementById("deleteModal").style.display = "block"
}

function closeDeleteModal() {
  document.getElementById("deleteModal").style.display = "none"
}

// Delete notification function
function deleteNotification(notificationId) {
  document.getElementById("deleteNotificationId").value = notificationId
  openDeleteModal()
}

// Toggle notification status
function toggleNotificationStatus(notificationId) {
  const form = document.createElement("form")
  form.method = "POST"
  form.style.display = "none"

  const actionInput = document.createElement("input")
  actionInput.type = "hidden"
  actionInput.name = "action"
  actionInput.value = "toggle_status"

  const idInput = document.createElement("input")
  idInput.type = "hidden"
  idInput.name = "notification_id"
  idInput.value = notificationId

  form.appendChild(actionInput)
  form.appendChild(idInput)
  document.body.appendChild(form)
  form.submit()
}

// Close modals when clicking outside
window.onclick = (event) => {
  const createModal = document.getElementById("createModal")
  const deleteModal = document.getElementById("deleteModal")

  if (event.target === createModal) {
    closeCreateModal()
  }
  if (event.target === deleteModal) {
    closeDeleteModal()
  }
}

// Close modals with Escape key
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    const modals = document.querySelectorAll(".modal")
    modals.forEach((modal) => {
      if (modal.style.display === "block") {
        modal.style.display = "none"
      }
    })
  }
})

// Character counter for message textarea
function updateCharacterCounter() {
  const textarea = document.getElementById("message")
  const counter = document.getElementById("characterCounter")

  if (textarea && counter) {
    const maxLength = 1000
    const currentLength = textarea.value.length
    counter.textContent = `${currentLength}/${maxLength} characters`

    if (currentLength > maxLength * 0.9) {
      counter.style.color = "#e53e3e"
    } else if (currentLength > maxLength * 0.7) {
      counter.style.color = "#dd6b20"
    } else {
      counter.style.color = "#718096"
    }
  }
}

// Form validation and enhancement
document.addEventListener("DOMContentLoaded", () => {
  const typeSelect = document.getElementById("type")
  const prioritySelect = document.getElementById("priority")

  if (typeSelect && prioritySelect) {
    typeSelect.addEventListener("change", (e) => {
      // Auto-set priority based on type
      if (e.target.value === "urgent") {
        prioritySelect.value = "high"
      } else if (e.target.value === "maintenance") {
        prioritySelect.value = "medium"
      }
    })
  }
})

// Auto-hide alerts
function autoHideAlerts() {
  const alerts = document.querySelectorAll(".alert")
  alerts.forEach((alert) => {
    setTimeout(() => {
      alert.style.opacity = "0"
      setTimeout(() => {
        alert.remove()
      }, 300)
    }, 5000)
  })
}

// Close modal when clicking outside
function setupModalCloseOnOutsideClick() {
  const modals = document.querySelectorAll(".modal")
  modals.forEach((modal) => {
    modal.addEventListener("click", (event) => {
      if (event.target === modal) {
        modal.style.display = "none"
      }
    })
  })
}

// Initialize when DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
  // Setup character counter
  const messageTextarea = document.getElementById("message")
  if (messageTextarea) {
    // Add character counter element
    const counterElement = document.createElement("div")
    counterElement.id = "characterCounter"
    counterElement.className = "character-counter"
    counterElement.textContent = "0/1000 characters"
    messageTextarea.parentNode.appendChild(counterElement)

    // Add event listener
    messageTextarea.addEventListener("input", updateCharacterCounter)
  }

  // Auto-hide alerts
  autoHideAlerts()

  // Setup modal close on outside click
  setupModalCloseOnOutsideClick()

  // Close modal with Escape key
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      const modals = document.querySelectorAll(".modal")
      modals.forEach((modal) => {
        if (modal.style.display === "block") {
          modal.style.display = "none"
        }
      })
    }
  })
})

// Form validation
function validateNotificationForm() {
  const form = document.querySelector("#createModal form")
  const title = form.querySelector("#title").value.trim()
  const message = form.querySelector("#message").value.trim()
  const type = form.querySelector("#type").value
  const priority = form.querySelector("#priority").value
  const targetAudience = form.querySelector("#target_audience").value

  if (!title) {
    alert("Please enter a notification title.")
    return false
  }

  if (!message) {
    alert("Please enter a notification message.")
    return false
  }

  if (!type) {
    alert("Please select a notification type.")
    return false
  }

  if (!priority) {
    alert("Please select a priority level.")
    return false
  }

  if (!targetAudience) {
    alert("Please select a target audience.")
    return false
  }

  return true
}

// Add form validation to submit
document.addEventListener("DOMContentLoaded", () => {
  const createForm = document.querySelector("#createModal form")
  if (createForm) {
    createForm.addEventListener("submit", (event) => {
      if (!validateNotificationForm()) {
        event.preventDefault()
      }
    })
  }
})
