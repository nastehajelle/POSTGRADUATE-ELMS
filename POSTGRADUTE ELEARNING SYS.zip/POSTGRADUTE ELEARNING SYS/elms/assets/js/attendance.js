/**
 * Attendance Management JavaScript
 */
document.addEventListener("DOMContentLoaded", () => {
  // DOM Elements
  const alertContainer = document.getElementById("alertContainer")
  const courseSelect = document.getElementById("course_id")
  const attendanceDate = document.getElementById("attendance_date")
  const loadAttendanceBtn = document.getElementById("loadAttendanceBtn")
  const attendanceForm = document.getElementById("attendanceForm")
  const studentsList = document.getElementById("studentsList")
  const saveAttendanceBtn = document.getElementById("saveAttendanceBtn")
  const cancelAttendanceBtn = document.getElementById("cancelAttendanceBtn")

  // Report Elements
  const reportCourseSelect = document.getElementById("report_course_id")
  const startDate = document.getElementById("start_date")
  const endDate = document.getElementById("end_date")
  const generateReportBtn = document.getElementById("generateReportBtn")
  const attendanceReport = document.getElementById("attendanceReport")
  const reportContent = document.getElementById("reportContent")
  const reportSummary = document.getElementById("reportSummary")
  const printReportBtn = document.getElementById("printReportBtn")
  const exportReportBtn = document.getElementById("exportReportBtn")

  // Tab Elements
  const tabButtons = document.querySelectorAll(".tab-button")
  const tabPanels = document.querySelectorAll(".tab-panel")

  // Show alert message
  function showAlert(message, type = "success") {
    const alert = document.createElement("div")
    alert.className = `alert alert-${type}`
    alert.textContent = message

    alertContainer.appendChild(alert)

    // Auto-remove after 5 seconds
    setTimeout(() => {
      alert.remove()
    }, 5000)
  }

  // Tab functionality
  tabButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const tabId = this.getAttribute("data-tab")

      // Remove active class from all buttons and panels
      tabButtons.forEach((btn) => btn.classList.remove("active"))
      tabPanels.forEach((panel) => panel.classList.remove("active"))

      // Add active class to clicked button and corresponding panel
      this.classList.add("active")
      document.getElementById(`${tabId}-panel`).classList.add("active")
    })
  })

  // Load students for attendance
  if (loadAttendanceBtn) {
    loadAttendanceBtn.addEventListener("click", () => {
      const courseId = courseSelect.value
      const date = attendanceDate.value

      if (!courseId) {
        showAlert("Please select a course", "danger")
        return
      }

      if (!date) {
        showAlert("Please select a date", "danger")
        return
      }

      // Disable button and show loading
      loadAttendanceBtn.disabled = true
      loadAttendanceBtn.textContent = "Loading..."

      // Prepare form data
      const formData = new FormData()
      formData.append("ajax", 1)
      formData.append("action", "get_attendance")
      formData.append("course_id", courseId)
      formData.append("date", date)

      // Send AJAX request
      fetch("attendance.php", {
        method: "POST",
        body: formData,
      })
        .then((response) => response.json())
        .then((data) => {
          loadAttendanceBtn.disabled = false
          loadAttendanceBtn.textContent = "Load Students"

          if (data.success) {
            const students = data.data

            if (students.length === 0) {
              showAlert("No students found for this course", "warning")
              return
            }

            // Create attendance table
            let tableHtml = `
                        <table class="attendance-table">
                            <thead>
                                <tr>
                                    <th>Student ID</th>
                                    <th>Name</th>
                                    <th>Status</th>
                                    <th>Remarks</th>
                                </tr>
                            </thead>
                            <tbody>
                    `

            students.forEach((student) => {
              const studentId = student.id
              const status = student.attendance.status
              const remarks = student.attendance.remarks || ""

              tableHtml += `
                            <tr>
                                <td>${student.enrollment_id || "N/A"}</td>
                                <td>${student.full_name}</td>
                                <td>
                                    <div class="attendance-status">
                                        <div class="status-radio">
                                            <input type="radio" name="status_${studentId}" value="present" id="present_${studentId}" ${status === "present" ? "checked" : ""}>
                                            <label for="present_${studentId}">Present</label>
                                        </div>
                                        <div class="status-radio">
                                            <input type="radio" name="status_${studentId}" value="absent" id="absent_${studentId}" ${status === "absent" ? "checked" : ""}>
                                            <label for="absent_${studentId}">Absent</label>
                                        </div>
                                        <div class="status-radio">
                                            <input type="radio" name="status_${studentId}" value="late" id="late_${studentId}" ${status === "late" ? "checked" : ""}>
                                            <label for="late_${studentId}">Late</label>
                                        </div>
                                        <div class="status-radio">
                                            <input type="radio" name="status_${studentId}" value="excused" id="excused_${studentId}" ${status === "excused" ? "checked" : ""}>
                                            <label for="excused_${studentId}">Excused</label>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <input type="text" class="form-control" name="remarks_${studentId}" value="${remarks}" placeholder="Optional remarks">
                                </td>
                            </tr>
                        `
            })

            tableHtml += `
                            </tbody>
                        </table>
                    `

            // Display the table
            studentsList.innerHTML = tableHtml
            attendanceForm.style.display = "block"
          } else {
            showAlert(data.message, "danger")
          }
        })
        .catch((error) => {
          loadAttendanceBtn.disabled = false
          loadAttendanceBtn.textContent = "Load Students"
          showAlert("An error occurred while loading students", "danger")
          console.error(error)
        })
    })
  }

  // Cancel attendance form
  if (cancelAttendanceBtn) {
    cancelAttendanceBtn.addEventListener("click", () => {
      attendanceForm.style.display = "none"
      studentsList.innerHTML = ""
    })
  }

  // Save attendance
  if (saveAttendanceBtn) {
    saveAttendanceBtn.addEventListener("click", () => {
      const courseId = courseSelect.value
      const date = attendanceDate.value

      if (!courseId || !date) {
        showAlert("Please select a course and date", "danger")
        return
      }

      // Collect attendance data
      const attendanceData = {}
      const remarks = {}

      // Find all status radio buttons that are checked
      const statusInputs = document.querySelectorAll('input[type="radio"]:checked')
      statusInputs.forEach((input) => {
        const name = input.getAttribute("name")
        const studentId = name.replace("status_", "")
        attendanceData[studentId] = input.value
      })

      // Find all remarks inputs
      const remarksInputs = document.querySelectorAll('input[name^="remarks_"]')
      remarksInputs.forEach((input) => {
        const name = input.getAttribute("name")
        const studentId = name.replace("remarks_", "")
        remarks[studentId] = input.value
      })

      if (Object.keys(attendanceData).length === 0) {
        showAlert("No attendance data to save", "danger")
        return
      }

      // Disable button and show loading
      saveAttendanceBtn.disabled = true
      saveAttendanceBtn.textContent = "Saving..."

      // Prepare form data
      const formData = new FormData()
      formData.append("ajax", 1)
      formData.append("action", "save_attendance")
      formData.append("course_id", courseId)
      formData.append("date", date)
      formData.append("attendance_data", JSON.stringify(attendanceData))
      formData.append("remarks", JSON.stringify(remarks))

      // Send AJAX request
      fetch("attendance.php", {
        method: "POST",
        body: formData,
      })
        .then((response) => response.json())
        .then((data) => {
          saveAttendanceBtn.disabled = false
          saveAttendanceBtn.textContent = "Save Attendance"

          if (data.success) {
            showAlert(data.message, "success")

            // Reset form
            attendanceForm.style.display = "none"
            studentsList.innerHTML = ""

            // Reload the page after a short delay to update stats
            setTimeout(() => {
              window.location.reload()
            }, 1500)
          } else {
            showAlert(data.message, "danger")
          }
        })
        .catch((error) => {
          saveAttendanceBtn.disabled = false
          saveAttendanceBtn.textContent = "Save Attendance"
          showAlert("An error occurred while saving attendance", "danger")
          console.error(error)
        })
    })
  }

  // Generate attendance report
  if (generateReportBtn) {
    generateReportBtn.addEventListener("click", () => {
      const courseId = reportCourseSelect.value
      const startDateValue = startDate.value
      const endDateValue = endDate.value

      if (!courseId) {
        showAlert("Please select a course", "danger")
        return
      }

      if (!startDateValue || !endDateValue) {
        showAlert("Please select start and end dates", "danger")
        return
      }

      // Validate date range
      const start = new Date(startDateValue)
      const end = new Date(endDateValue)

      if (start > end) {
        showAlert("Start date cannot be after end date", "danger")
        return
      }

      // Disable button and show loading
      generateReportBtn.disabled = true
      generateReportBtn.textContent = "Generating..."

      // Prepare form data
      const formData = new FormData()
      formData.append("ajax", 1)
      formData.append("action", "get_attendance_report")
      formData.append("course_id", courseId)
      formData.append("start_date", startDateValue)
      formData.append("end_date", endDateValue)

      // Send AJAX request
      fetch("attendance.php", {
        method: "POST",
        body: formData,
      })
        .then((response) => response.json())
        .then((data) => {
          generateReportBtn.disabled = false
          generateReportBtn.textContent = "Generate Report"

          if (data.success) {
            const reportData = data.data
            const students = reportData.students
            const dates = reportData.dates
            const attendance = reportData.attendance

            if (students.length === 0) {
              showAlert("No students found for this course", "warning")
              return
            }

            // Create report table
            let tableHtml = `
                        <table class="report-table" id="reportTable">
                            <thead>
                                <tr>
                                    <th>Student ID</th>
                                    <th>Name</th>
                    `

            // Add date columns
            dates.forEach((date) => {
              const formattedDate = new Date(date).toLocaleDateString("en-US", { month: "short", day: "numeric" })
              tableHtml += `<th>${formattedDate}</th>`
            })

            tableHtml += `
                                    <th>Present</th>
                                    <th>Absent</th>
                                    <th>Late</th>
                                    <th>Excused</th>
                                    <th>Attendance %</th>
                                </tr>
                            </thead>
                            <tbody>
                    `

            // Add student rows
            let totalPresent = 0
            let totalAbsent = 0
            let totalLate = 0
            let totalExcused = 0
            const totalDays = dates.length * students.length

            students.forEach((student) => {
              const studentId = student.id
              let presentCount = 0
              let absentCount = 0
              let lateCount = 0
              let excusedCount = 0

              tableHtml += `
                            <tr>
                                <td>${student.enrollment_id || "N/A"}</td>
                                <td class="student-name">${student.full_name}</td>
                        `

              // Add status for each date
              dates.forEach((date) => {
                // Only count as absent if there's an actual record with 'absent' status
                // Otherwise, mark as 'not recorded' (N/R)
                let status = "not-recorded"
                let displayText = "N/R"

                if (attendance[studentId] && attendance[studentId][date]) {
                  status = attendance[studentId][date]
                  displayText = status.charAt(0).toUpperCase()

                  // Count statuses for actual records
                  if (status === "present") presentCount++
                  else if (status === "absent") absentCount++
                  else if (status === "late") lateCount++
                  else if (status === "excused") excusedCount++
                }

                // Add status cell with appropriate class
                tableHtml += `<td><span class="status-badge status-${status}">${displayText}</span></td>`
              })

              // Calculate attendance percentage
              const totalClasses = dates.length
              const attendancePercentage = totalClasses > 0 ? Math.round((presentCount / totalClasses) * 100) : 0

              // Add summary columns
              tableHtml += `
                                <td>${presentCount}</td>
                                <td>${absentCount}</td>
                                <td>${lateCount}</td>
                                <td>${excusedCount}</td>
                                <td>${attendancePercentage}%</td>
                            </tr>
                        `

              // Add to totals
              totalPresent += presentCount
              totalAbsent += absentCount
              totalLate += lateCount
              totalExcused += excusedCount
            })

            tableHtml += `
                            </tbody>
                        </table>
                    `

            // Display the report
            reportContent.innerHTML = tableHtml

            // Calculate overall attendance percentage based on actual recorded days
            const recordedDays = totalPresent + totalAbsent + totalLate + totalExcused
            const overallAttendance = recordedDays > 0 ? Math.round((totalPresent / recordedDays) * 100) : 0

            // Create summary
            const summaryHtml = `
                        <div class="summary-item">
                            <h3>Present</h3>
                            <p>${totalPresent}</p>
                        </div>
                        <div class="summary-item">
                            <h3>Absent</h3>
                            <p>${totalAbsent}</p>
                        </div>
                        <div class="summary-item">
                            <h3>Late</h3>
                            <p>${totalLate}</p>
                        </div>
                        <div class="summary-item">
                            <h3>Excused</h3>
                            <p>${totalExcused}</p>
                        </div>
                        <div class="summary-item">
                            <h3>Overall Attendance</h3>
                            <p>${overallAttendance}%</p>
                        </div>
                    `

            reportSummary.innerHTML = summaryHtml
            attendanceReport.style.display = "block"
          } else {
            showAlert(data.message, "danger")
          }
        })
        .catch((error) => {
          generateReportBtn.disabled = false
          generateReportBtn.textContent = "Generate Report"
          showAlert("An error occurred while generating the report", "danger")
          console.error(error)
        })
    })
  }

  // Print report
  if (printReportBtn) {
    printReportBtn.addEventListener("click", () => {
      const courseText = reportCourseSelect.options[reportCourseSelect.selectedIndex].text
      const startDateText = new Date(startDate.value).toLocaleDateString()
      const endDateText = new Date(endDate.value).toLocaleDateString()

      // Create a new window for printing
      const printWindow = window.open("", "_blank")

      // Write the print content
      printWindow.document.write(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Attendance Report</title>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            margin: 20px;
                        }
                        h1 {
                            text-align: center;
                            margin-bottom: 10px;
                        }
                        .report-info {
                            text-align: center;
                            margin-bottom: 20px;
                        }
                        table {
                            width: 100%;
                            border-collapse: collapse;
                            margin-bottom: 20px;
                        }
                        th, td {
                            border: 1px solid #ddd;
                            padding: 8px;
                            text-align: center;
                        }
                        th {
                            background-color: #f2f2f2;
                        }
                        .student-name {
                            text-align: left;
                        }
                        .status-badge {
                            padding: 2px 5px;
                            border-radius: 3px;
                            font-size: 12px;
                        }
                        .status-present {
                            background-color: #d1fae5;
                        }
                        .status-absent {
                            background-color: #fee2e2;
                        }
                        .status-late {
                            background-color: #fef3c7;
                        }
                        .status-excused {
                            background-color: #e0e7ff;
                        }
                        .status-not-recorded {
                            background-color: #f3f4f6;
                        }
                        .summary {
                            display: flex;
                            justify-content: space-around;
                            margin-top: 20px;
                        }
                        .summary-item {
                            text-align: center;
                        }
                        .summary-item h3 {
                            margin: 0;
                            font-size: 14px;
                        }
                        .summary-item p {
                            margin: 5px 0 0 0;
                            font-size: 18px;
                            font-weight: bold;
                        }
                        @media print {
                            .no-print {
                                display: none;
                            }
                        }
                    </style>
                </head>
                <body>
                    <h1>Attendance Report</h1>
                    <div class="report-info">
                        <p><strong>Course:</strong> ${courseText}</p>
                        <p><strong>Period:</strong> ${startDateText} to ${endDateText}</p>
                    </div>
                    
                    ${reportContent.innerHTML}
                    
                    <div class="summary">
                        ${reportSummary.innerHTML}
                    </div>
                    
                    <div class="no-print" style="text-align: center; margin-top: 20px;">
                        <button onclick="window.print()">Print</button>
                        <button onclick="window.close()">Close</button>
                    </div>
                </body>
                </html>
            `)

      // Close the document
      printWindow.document.close()
    })
  }

  // Export report to CSV
  if (exportReportBtn) {
    exportReportBtn.addEventListener("click", () => {
      const table = document.getElementById("reportTable")
      if (!table) {
        showAlert("No report data to export", "danger")
        return
      }

      // Get course name
      const courseText = reportCourseSelect.options[reportCourseSelect.selectedIndex].text

      // Create CSV content
      const csv = []

      // Add title row
      csv.push(["Attendance Report - " + courseText])
      csv.push(["Period: " + startDate.value + " to " + endDate.value])
      csv.push([]) // Empty row

      // Add header row
      const header = []
      for (let i = 0; i < table.rows[0].cells.length; i++) {
        header.push(table.rows[0].cells[i].textContent)
      }
      csv.push(header)

      // Add data rows
      for (let i = 1; i < table.rows.length; i++) {
        const row = []
        for (let j = 0; j < table.rows[i].cells.length; j++) {
          // Get text content, removing any HTML
          const cellContent = table.rows[i].cells[j].textContent.trim()
          row.push(cellContent)
        }
        csv.push(row)
      }

      // Convert to CSV string
      const csvContent = csv.map((row) => row.join(",")).join("\n")

      // Create download link
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
      const url = URL.createObjectURL(blob)
      const link = document.createElement("a")
      link.setAttribute("href", url)
      link.setAttribute("download", "attendance_report.csv")
      link.style.visibility = "hidden"
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    })
  }

  // Set default dates for report
  if (startDate && endDate) {
    const today = new Date()
    const oneMonthAgo = new Date()
    oneMonthAgo.setMonth(today.getMonth() - 1)

    startDate.value = oneMonthAgo.toISOString().split("T")[0]
    endDate.value = today.toISOString().split("T")[0]
  }
})
