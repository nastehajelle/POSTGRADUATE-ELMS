// Academic Year Management JavaScript

// Toggle academic year expansion
function toggleYearExpansion(yearId) {
  const content = document.getElementById(`year-content-${yearId}`)
  const icon = document.getElementById(`expand-icon-${yearId}`)

  if (content.style.display === "none" || content.style.display === "") {
    content.style.display = "block"
    icon.classList.add("expanded")
  } else {
    content.style.display = "none"
    icon.classList.remove("expanded")
  }
}

// Modal functions
function openModal(modalId) {
  const modal = document.getElementById(modalId)
  if (modal) {
    modal.style.display = "block"
    document.body.style.overflow = "hidden" // Prevent background scrolling
  }
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId)
  if (modal) {
    modal.style.display = "none"
    document.body.style.overflow = "auto" // Restore scrolling
  }
}

// Close modal when clicking outside
window.onclick = (event) => {
  const modals = document.querySelectorAll(".modal")
  modals.forEach((modal) => {
    if (event.target === modal) {
      modal.style.display = "none"
      document.body.style.overflow = "auto"
    }
  })
}

// Close modal with Escape key
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    const modals = document.querySelectorAll(".modal")
    modals.forEach((modal) => {
      if (modal.style.display === "block") {
        modal.style.display = "none"
        document.body.style.overflow = "auto"
      }
    })
  }
})

// Edit academic year
function editAcademicYear(year) {
  document.getElementById("edit_academic_year_id").value = year.id
  document.getElementById("edit_name").value = year.name
  document.getElementById("edit_start_date").value = year.start_date
  document.getElementById("edit_end_date").value = year.end_date
  document.getElementById("edit_is_active").checked = year.status === "active"

  openModal("editAcademicYearModal")
}

// Delete academic year
function deleteAcademicYear(id, name) {
  if (
    confirm(
      `Are you sure you want to delete the academic year "${name}"? This will also delete all associated semesters.`,
    )
  ) {
    const form = document.createElement("form")
    form.method = "POST"
    form.innerHTML = `
            <input type="hidden" name="action" value="delete_academic_year">
            <input type="hidden" name="academic_year_id" value="${id}">
        `
    document.body.appendChild(form)
    form.submit()
  }
}

// Open create semester modal
function openCreateSemesterModal(academicYearId) {
  document.getElementById("semester_academic_year_id").value = academicYearId
  // Clear form fields
  document.getElementById("semester_name").value = ""
  document.getElementById("semester_start_date").value = ""
  document.getElementById("semester_end_date").value = ""
  document.querySelector('#createSemesterModal input[name="is_active"]').checked = false

  openModal("createSemesterModal")
}

// Edit semester
function editSemester(semester) {
  document.getElementById("edit_semester_id").value = semester.id
  document.getElementById("edit_semester_name").value = semester.name
  document.getElementById("edit_semester_start_date").value = semester.start_date
  document.getElementById("edit_semester_end_date").value = semester.end_date
  document.getElementById("edit_semester_is_active").checked = semester.status === "active"

  openModal("editSemesterModal")
}

// Delete semester
function deleteSemester(id, name) {
  if (confirm(`Are you sure you want to delete the semester "${name}"?`)) {
    const form = document.createElement("form")
    form.method = "POST"
    form.innerHTML = `
            <input type="hidden" name="action" value="delete_semester">
            <input type="hidden" name="semester_id" value="${id}">
        `
    document.body.appendChild(form)
    form.submit()
  }
}

// Form validation
document.addEventListener("DOMContentLoaded", () => {
  // Validate date ranges
  const forms = document.querySelectorAll("form")
  forms.forEach((form) => {
    form.addEventListener("submit", (e) => {
      const startDate = form.querySelector('input[name="start_date"]')
      const endDate = form.querySelector('input[name="end_date"]')

      if (startDate && endDate) {
        if (new Date(startDate.value) >= new Date(endDate.value)) {
          e.preventDefault()
          alert("End date must be after start date.")
          return false
        }
      }
    })
  })

  // Auto-hide alerts after 5 seconds
  const alerts = document.querySelectorAll(".alert")
  alerts.forEach((alert) => {
    setTimeout(() => {
      alert.style.opacity = "0"
      alert.style.transition = "opacity 0.5s ease"
      setTimeout(() => {
        alert.remove()
      }, 500)
    }, 5000)
  })
})

// Initialize theme
document.addEventListener("DOMContentLoaded", () => {
  // Apply saved theme
  const savedTheme = localStorage.getItem("theme") || "light"
  document.documentElement.setAttribute("data-theme", savedTheme)
})

// Prevent form resubmission on page refresh
if (window.history.replaceState) {
  window.history.replaceState(null, null, window.location.href)
}
