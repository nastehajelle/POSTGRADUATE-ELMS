// Thesis Notifications JavaScript Handler

class ThesisNotifications {
  constructor() {
    this.apiUrl = "../api/thesis-notifications.php"
    this.init()
  }

  init() {
    this.loadNotifications()
    this.updateUnreadCount()
    this.setupEventListeners()

    // Auto-refresh every 30 seconds
    setInterval(() => {
      this.updateUnreadCount()
    }, 30000)
  }

  setupEventListeners() {
    // Mark as read when notification is clicked
    document.addEventListener("click", (e) => {
      if (e.target.closest(".thesis-notification-item")) {
        const notificationItem = e.target.closest(".thesis-notification-item")
        const notificationId = notificationItem.dataset.notificationId
        if (notificationItem.classList.contains("unread")) {
          this.markAsRead(notificationId)
        }
      }
    })

    // Mark all as read button
    const markAllBtn = document.getElementById("markAllAsRead")
    if (markAllBtn) {
      markAllBtn.addEventListener("click", () => {
        this.markAllAsRead()
      })
    }

    // Refresh notifications button
    const refreshBtn = document.getElementById("refreshNotifications")
    if (refreshBtn) {
      refreshBtn.addEventListener("click", () => {
        this.loadNotifications()
        this.updateUnreadCount()
      })
    }
  }

  async loadNotifications(limit = 20, offset = 0) {
    try {
      const response = await fetch(`${this.apiUrl}?action=get_notifications&limit=${limit}&offset=${offset}`)
      const data = await response.json()

      if (data.notifications) {
        this.renderNotifications(data.notifications)
      }
    } catch (error) {
      console.error("Error loading notifications:", error)
    }
  }

  async updateUnreadCount() {
    try {
      const response = await fetch(`${this.apiUrl}?action=get_unread_count`)
      const data = await response.json()

      if (data.count !== undefined) {
        this.updateBadge(data.count)
      }
    } catch (error) {
      console.error("Error updating unread count:", error)
    }
  }

  async markAsRead(notificationId) {
    try {
      const formData = new FormData()
      formData.append("action", "mark_as_read")
      formData.append("notification_id", notificationId)

      const response = await fetch(this.apiUrl, {
        method: "POST",
        body: formData,
      })

      const data = await response.json()

      if (data.success) {
        const notificationItem = document.querySelector(`[data-notification-id="${notificationId}"]`)
        if (notificationItem) {
          notificationItem.classList.remove("unread")
          notificationItem.classList.add("read")
        }
        this.updateUnreadCount()
      }
    } catch (error) {
      console.error("Error marking notification as read:", error)
    }
  }

  async markAllAsRead() {
    try {
      const formData = new FormData()
      formData.append("action", "mark_all_as_read")

      const response = await fetch(this.apiUrl, {
        method: "POST",
        body: formData,
      })

      const data = await response.json()

      if (data.success) {
        document.querySelectorAll(".thesis-notification-item.unread").forEach((item) => {
          item.classList.remove("unread")
          item.classList.add("read")
        })
        this.updateUnreadCount()
      }
    } catch (error) {
      console.error("Error marking all notifications as read:", error)
    }
  }

  renderNotifications(notifications) {
    const container = document.getElementById("thesisNotificationsContainer")
    if (!container) return

    if (notifications.length === 0) {
      container.innerHTML = `
                <div class="no-notifications">
                    <i class="fas fa-bell-slash"></i>
                    <h3>No Notifications</h3>
                    <p>You don't have any thesis notifications yet.</p>
                </div>
            `
      return
    }

    const notificationsHtml = notifications
      .map((notification) => {
        const isUnread = notification.is_read == 0
        const typeIcon = this.getTypeIcon(notification.type)
        const timeAgo = this.timeAgo(notification.created_at)

        return `
                <div class="thesis-notification-item ${isUnread ? "unread" : "read"}" 
                     data-notification-id="${notification.id}">
                    <div class="notification-icon ${notification.type}">
                        <i class="fas ${typeIcon}"></i>
                    </div>
                    <div class="notification-content">
                        <div class="notification-header">
                            <h4 class="notification-title">${this.escapeHtml(notification.title)}</h4>
                            <span class="notification-time">${timeAgo}</span>
                        </div>
                        <p class="notification-message">${this.escapeHtml(notification.message)}</p>
                        ${notification.thesis_title ? `<div class="notification-thesis">Thesis: ${this.escapeHtml(notification.thesis_title)}</div>` : ""}
                        ${notification.sender_name ? `<div class="notification-sender">From: ${this.escapeHtml(notification.sender_name)}</div>` : ""}
                    </div>
                    <div class="notification-actions">
                        ${isUnread ? '<span class="unread-indicator"></span>' : ""}
                        <button class="btn-delete" onclick="thesisNotifications.deleteNotification(${notification.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `
      })
      .join("")

    container.innerHTML = notificationsHtml
  }

  updateBadge(count) {
    const badges = document.querySelectorAll(".thesis-notification-badge")
    badges.forEach((badge) => {
      if (count > 0) {
        badge.textContent = count > 99 ? "99+" : count
        badge.style.display = "inline-block"
      } else {
        badge.style.display = "none"
      }
    })
  }

  getTypeIcon(type) {
    const icons = {
      submission: "fa-upload",
      assignment: "fa-user-plus",
      review_completed: "fa-check-circle",
      status_change: "fa-exchange-alt",
      revision_request: "fa-edit",
      approval: "fa-thumbs-up",
      rejection: "fa-thumbs-down",
      general: "fa-info-circle",
    }
    return icons[type] || "fa-bell"
  }

  timeAgo(dateString) {
    const date = new Date(dateString)
    const now = new Date()
    const diffInSeconds = Math.floor((now - date) / 1000)

    if (diffInSeconds < 60) return "Just now"
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`
    if (diffInSeconds < 2592000) return `${Math.floor(diffInSeconds / 86400)}d ago`

    return date.toLocaleDateString()
  }

  escapeHtml(text) {
    const div = document.createElement("div")
    div.textContent = text
    return div.innerHTML
  }

  async deleteNotification(notificationId) {
    if (!confirm("Are you sure you want to delete this notification?")) return

    try {
      const formData = new FormData()
      formData.append("action", "delete_notification")
      formData.append("notification_id", notificationId)

      const response = await fetch(this.apiUrl, {
        method: "POST",
        body: formData,
      })

      const data = await response.json()

      if (data.success) {
        const notificationItem = document.querySelector(`[data-notification-id="${notificationId}"]`)
        if (notificationItem) {
          notificationItem.remove()
        }
        this.updateUnreadCount()
      }
    } catch (error) {
      console.error("Error deleting notification:", error)
    }
  }
}

// Initialize when DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
  window.thesisNotifications = new ThesisNotifications()
})
