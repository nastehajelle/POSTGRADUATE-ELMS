/**
 * Modal Management System
 * Handles creating, opening, and closing modals dynamically
 */
class ModalManager {
    constructor() {
      this.modals = {}
      this.activeModal = null
      this.init()
    }
  
    init() {
      // Close modal when clicking outside
      document.addEventListener("click", (event) => {
        if (this.activeModal && event.target.classList.contains("modal-overlay")) {
          this.closeModal(this.activeModal)
        }
      })
  
      // Close modal with ESC key
      document.addEventListener("keydown", (event) => {
        if (event.key === "Escape" && this.activeModal) {
          this.closeModal(this.activeModal)
        }
      })
  
      // Initialize modal triggers
      document.addEventListener("DOMContentLoaded", () => {
        this.initModalTriggers()
      })
    }
  
    initModalTriggers() {
      // Find all elements with data-modal-target attribute
      const modalTriggers = document.querySelectorAll("[data-modal-target]")
  
      modalTriggers.forEach((trigger) => {
        const modalId = trigger.dataset.modalTarget
  
        trigger.addEventListener("click", (event) => {
          event.preventDefault()
          this.openModal(modalId)
        })
      })
    }
  
    createModal(id, title, content, options = {}) {
      // Check if modal already exists
      if (document.getElementById(`modal-${id}`)) {
        return document.getElementById(`modal-${id}`)
      }
  
      // Create modal elements
      const modalOverlay = document.createElement("div")
      modalOverlay.id = `modal-${id}`
      modalOverlay.className = "modal-overlay"
  
      const modalElement = document.createElement("div")
      modalElement.className = "modal"
  
      // Create modal header
      const modalHeader = document.createElement("div")
      modalHeader.className = "modal-header"
  
      const modalTitle = document.createElement("h2")
      modalTitle.textContent = title
  
      const closeButton = document.createElement("button")
      closeButton.className = "modal-close"
      closeButton.innerHTML = "&times;"
      closeButton.setAttribute("aria-label", "Close")
      closeButton.addEventListener("click", () => this.closeModal(id))
  
      modalHeader.appendChild(modalTitle)
      modalHeader.appendChild(closeButton)
  
      // Create modal body
      const modalBody = document.createElement("div")
      modalBody.className = "modal-body"
  
      if (typeof content === "string") {
        modalBody.innerHTML = content
      } else if (content instanceof HTMLElement) {
        modalBody.appendChild(content)
      }
  
      // Create modal footer if actions provided
      let modalFooter = null
      if (options.actions && options.actions.length) {
        modalFooter = document.createElement("div")
        modalFooter.className = "modal-footer"
  
        options.actions.forEach((action) => {
          const button = document.createElement("button")
          button.className = `btn ${action.className || "btn-secondary"}`
          button.textContent = action.text
          button.addEventListener("click", action.handler)
          modalFooter.appendChild(button)
        })
      }
  
      // Assemble modal
      modalElement.appendChild(modalHeader)
      modalElement.appendChild(modalBody)
      if (modalFooter) {
        modalElement.appendChild(modalFooter)
      }
  
      modalOverlay.appendChild(modalElement)
      document.body.appendChild(modalOverlay)
  
      // Store reference to the modal
      this.modals[id] = modalOverlay
  
      return modalOverlay
    }
  
    openModal(id) {
      const modal = this.modals[id] || document.getElementById(`modal-${id}`)
  
      if (!modal) {
        console.error(`Modal with ID ${id} does not exist.`)
        return
      }
  
      // Close any active modal first
      if (this.activeModal) {
        this.closeModal(this.activeModal)
      }
  
      // Show the modal
      modal.classList.add("active")
      this.activeModal = id
  
      // Prevent scrolling on the body
      document.body.style.overflow = "hidden"
  
      // Dispatch event
      const event = new CustomEvent("modal:opened", { detail: { id } })
      document.dispatchEvent(event)
    }
  
    closeModal(id) {
      const modal = this.modals[id] || document.getElementById(`modal-${id}`)
  
      if (!modal) {
        console.error(`Modal with ID ${id} does not exist.`)
        return
      }
  
      // Hide the modal
      modal.classList.remove("active")
      this.activeModal = null
  
      // Allow scrolling on the body again
      document.body.style.overflow = ""
  
      // Dispatch event
      const event = new CustomEvent("modal:closed", { detail: { id } })
      document.dispatchEvent(event)
    }
  
    updateModalContent(id, content) {
      const modal = this.modals[id] || document.getElementById(`modal-${id}`)
  
      if (!modal) {
        console.error(`Modal with ID ${id} does not exist.`)
        return
      }
  
      const modalBody = modal.querySelector(".modal-body")
  
      if (typeof content === "string") {
        modalBody.innerHTML = content
      } else if (content instanceof HTMLElement) {
        modalBody.innerHTML = ""
        modalBody.appendChild(content)
      }
    }
  
    setLoading(id, isLoading) {
      const modal = this.modals[id] || document.getElementById(`modal-${id}`)
  
      if (!modal) {
        console.error(`Modal with ID ${id} does not exist.`)
        return
      }
  
      let loadingElement = modal.querySelector(".modal-loading")
  
      if (isLoading) {
        if (!loadingElement) {
          loadingElement = document.createElement("div")
          loadingElement.className = "modal-loading"
          loadingElement.innerHTML = '<div class="spinner"></div>'
          modal.querySelector(".modal").appendChild(loadingElement)
        }
      } else if (loadingElement) {
        loadingElement.remove()
      }
    }
  }
  
  // Initialize the global modal manager
  const modalManager = new ModalManager()
  
  // Export the modal manager globally
  window.modalManager = modalManager
