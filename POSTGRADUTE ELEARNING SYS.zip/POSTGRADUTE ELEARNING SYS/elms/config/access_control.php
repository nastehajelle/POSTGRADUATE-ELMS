<?php

/**
 * Check if student has access to course content based on batch and enrollment status
 */
function student_has_course_access($conn, $student_id) {
    try {
        $query = "SELECT u.status as user_status, b.status as batch_status, s.status as student_status, e.batch_id
                  FROM users u
                  INNER JOIN enrollment e ON u.id = e.user_id
                  INNER JOIN batch b ON e.batch_id = b.id
                  INNER JOIN students s ON u.id = s.user_id
                  WHERE u.id = ? AND u.role = 'student'";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([$student_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$result) {
            return false; // No enrollment found
        }
        
        // Dead students cannot access anything
        if ($result['student_status'] === 'dead') {
            return false;
        }
        
        // Graduated students cannot access course content (view-only access)
        if ($result['student_status'] === 'graduated') {
            return false;
        }
        
        // Active and Transfer students can access courses if user status and batch status are active
        // Inactive students cannot access courses
        return $result['user_status'] === 'active' && 
               $result['batch_status'] === 'active' &&
               ($result['student_status'] === 'active' || $result['student_status'] === 'transfer');
        
    } catch (PDOException $e) {
        error_log("Error checking student course access: " . $e->getMessage());
        return false;
    }
}

/**
 * Check if student can login (updated to handle new statuses)
 */
function student_can_login($conn, $student_id) {
    try {
        $query = "SELECT u.status as user_status, s.status as student_status 
                  FROM users u 
                  INNER JOIN students s ON u.id = s.user_id 
                  WHERE u.id = ? AND u.role = 'student'";
        $stmt = $conn->prepare($query);
        $stmt->execute([$student_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$result) {
            return false;
        }
        
        if ($result['student_status'] === 'dead') {
            return false;
        }
        
        // All other statuses can login if user status is active
        return $result['user_status'] === 'active';
        
    } catch (PDOException $e) {
        error_log("Error checking student login access: " . $e->getMessage());
        return false;
    }
}

/**
 * Check if student has view-only access (for graduated students)
 */
function student_has_view_only_access($conn, $student_id) {
    try {
        $query = "SELECT s.status as student_status 
                  FROM students s 
                  WHERE s.user_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->execute([$student_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $result && $result['student_status'] === 'graduated';
        
    } catch (PDOException $e) {
        error_log("Error checking student view-only access: " . $e->getMessage());
        return false;
    }
}

/**
 * Check if student can access academic features (courses, assessments, live classes, etc.)
 */
function student_can_access_academic_features($conn, $student_id) {
    try {
        $query = "SELECT s.status as student_status 
                  FROM students s 
                  WHERE s.user_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->execute([$student_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$result) {
            return false;
        }
        
        // Graduated, dead, and inactive students cannot
        return in_array($result['student_status'], ['active', 'transfer']);
        
    } catch (PDOException $e) {
        error_log("Error checking student academic access: " . $e->getMessage());
        return false;
    }
}

/**
 * Get student's batch status information
 */
function get_student_batch_info($conn, $student_id) {
    try {
        $query = "SELECT u.status as user_status, b.status as batch_status, s.status as student_status,
                         b.name as batch_name, e.batch_id, s.previous_batch_id, s.transfer_date
                  FROM users u
                  INNER JOIN enrollment e ON u.id = e.user_id
                  INNER JOIN batch b ON e.batch_id = b.id
                  INNER JOIN students s ON u.id = s.user_id
                  WHERE u.id = ? AND u.role = 'student'";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([$student_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
        
    } catch (PDOException $e) {
        error_log("Error getting student batch info: " . $e->getMessage());
        return null;
    }
}

/**
 * Get student status information
 */
function get_student_status_info($conn, $student_id) {
    try {
        $query = "SELECT s.status, s.status_changed_at, s.status_changed_by, s.transfer_date, s.previous_batch_id,
                         u_admin.full_name as changed_by_name
                  FROM students s
                  LEFT JOIN users u_admin ON s.status_changed_by = u_admin.id
                  WHERE s.user_id = ?";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([$student_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
        
    } catch (PDOException $e) {
        error_log("Error getting student status info: " . $e->getMessage());
        return null;
    }
}

/**
 * Check if student status can be changed to a new status
 */
function can_change_student_status($current_status, $new_status) {
    $forbidden_changes = [
        'graduated' => ['active', 'inactive', 'transfer'], // Graduated cannot be reactivated or transferred
        'dead' => ['active', 'inactive', 'graduated', 'transfer'] // Dead cannot be changed to anything
    ];
    
    if (isset($forbidden_changes[$current_status]) && in_array($new_status, $forbidden_changes[$current_status])) {
        return false;
    }
    
    return true;
}
?>
