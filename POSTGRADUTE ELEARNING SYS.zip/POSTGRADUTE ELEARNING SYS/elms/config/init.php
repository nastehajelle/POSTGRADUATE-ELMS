<?php
// Include database connection
include_once 'database.php';

// Include academic year helper functions
include_once 'academic_year_helper.php';
if (!function_exists('is_instructor')) {
    function is_instructor() {
        return isset($_SESSION['role']) && $_SESSION['role'] === 'instructor';
    }
}

if (!function_exists('is_student')) {
    function is_student() {
        // Example logic: check if user role is 'student' in session
        return isset($_SESSION['role']) && $_SESSION['role'] === 'student';
    }
}
// Initialize database connection
$database = new Database();
$conn = $database->getConnection();
 
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Example placeholder for is_logged_in and is_admin functions
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function is_admin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// New function to generate student ID
function generate_student_id($batch_id, $conn) {
    // Get batch name
    $batch_query = "SELECT name FROM batch WHERE id = ?";
    $batch_stmt = $conn->prepare($batch_query);
    $batch_stmt->execute([$batch_id]);
    $batch_info = $batch_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$batch_info) {
        throw new Exception("Batch not found for ID: " . $batch_id);
    }
    $batch_name = $batch_info['name'];

    // Find the last student ID for this batch to determine the next serial number
    // Student ID format: batch_name + serial_number (e.g., MIM0210001)
    $last_student_id_query = "SELECT student_id FROM enrollment 
                              WHERE batch_id = ? AND student_id LIKE ? 
                              ORDER BY student_id DESC LIMIT 1";
    $search_pattern = $batch_name . '%';
    $last_student_id_stmt = $conn->prepare($last_student_id_query);
    $last_student_id_stmt->execute([$batch_id, $search_pattern]);
    $last_student_enrollment = $last_student_id_stmt->fetch(PDO::FETCH_ASSOC);

    $next_serial_number = 1; // Default starting serial number

    if ($last_student_enrollment && !empty($last_student_enrollment['student_id'])) {
        $last_student_id = $last_student_enrollment['student_id'];
        // Extract the numeric part (last 3 digits)
        $numeric_part = substr($last_student_id, -3);
        $next_serial_number = intval($numeric_part) + 1;
    }

    // Format the next serial number with leading zeros to be 3 digits
    $formatted_serial_number = sprintf("%03d", $next_serial_number);

    return $batch_name . $formatted_serial_number;
}

// Define FONT_AWESOME_CSS if it's used in your project
if (!defined('FONT_AWESOME_CSS')) {
    define('FONT_AWESOME_CSS', '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">');
}

?>
