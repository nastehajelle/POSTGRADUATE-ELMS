<?php
/**
 * Academic Year Helper Functions
 * Provides consistent access to active academic year and semester data
 */

/**
 * Get the currently active academic year
 * @param PDO $conn Database connection
 * @return array|null Returns array with 'id' and 'name' or null if none found
 */
function get_active_academic_year($conn) {
    try {
        $query = "SELECT id, name, start_date, end_date FROM academic_year WHERE status = 'active' LIMIT 1";
        $stmt = $conn->prepare($query);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error fetching active academic year: " . $e->getMessage());
        return null;
    }
}

/**
 * Get the currently active semester for the active academic year
 * @param PDO $conn Database connection
 * @param int $academic_year_id Optional academic year ID, if null uses active academic year
 * @return array|null Returns array with semester data or null if none found
 */
function get_active_semester($conn, $academic_year_id = null) {
    try {
        if ($academic_year_id === null) {
            $academic_year = get_active_academic_year($conn);
            if (!$academic_year) {
                return null;
            }
            $academic_year_id = $academic_year['id'];
        }
        
        $query = "SELECT id, name, start_date, end_date FROM semester WHERE status = 'active' AND academic_year_id = ? LIMIT 1";
        $stmt = $conn->prepare($query);
        $stmt->execute([$academic_year_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // If no semester found for the academic year, try to get any active semester
        if (!$result) {
            $fallback_query = "SELECT id, name, start_date, end_date FROM semester WHERE status = 'active' LIMIT 1";
            $fallback_stmt = $conn->prepare($fallback_query);
            $fallback_stmt->execute();
            $result = $fallback_stmt->fetch(PDO::FETCH_ASSOC);
        }
        
        return $result;
    } catch (PDOException $e) {
        error_log("Error fetching active semester: " . $e->getMessage());
        return null;
    }
}

/**
 * Get all academic years ordered by most recent first
 * @param PDO $conn Database connection
 * @return array Returns array of academic years
 */
function get_all_academic_years($conn) {
    try {
        $query = "SELECT id, name, start_date, end_date, status FROM academic_year ORDER BY start_date DESC";
        $stmt = $conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error fetching academic years: " . $e->getMessage());
        return [];
    }
}

/**
 * Get all semesters for a specific academic year
 * @param PDO $conn Database connection
 * @param int $academic_year_id Academic year ID
 * @return array Returns array of semesters
 */
function get_semesters_by_academic_year($conn, $academic_year_id) {
    try {
        $query = "SELECT id, name, start_date, end_date, status FROM semester WHERE academic_year_id = ? ORDER BY start_date ASC";
        $stmt = $conn->prepare($query);
        $stmt->execute([$academic_year_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error fetching semesters: " . $e->getMessage());
        return [];
    }
}

/**
 * Ensure only one academic year is active at a time
 * @param PDO $conn Database connection
 * @param int $new_active_id ID of the academic year to make active
 * @return bool Returns true on success, false on failure
 */
function set_active_academic_year($conn, $new_active_id) {
    try {
        $conn->beginTransaction();
        
        // First, set all academic years to inactive
        $deactivate_query = "UPDATE academic_year SET status = 'inactive', updated_at = NOW()";
        $deactivate_stmt = $conn->prepare($deactivate_query);
        $deactivate_stmt->execute();
        
        // Then, set the specified one to active
        $activate_query = "UPDATE academic_year SET status = 'active', updated_at = NOW() WHERE id = ?";
        $activate_stmt = $conn->prepare($activate_query);
        $activate_stmt->execute([$new_active_id]);
        
        $conn->commit();
        return true;
    } catch (PDOException $e) {
        $conn->rollback();
        error_log("Error setting active academic year: " . $e->getMessage());
        return false;
    }
}

/**
 * Ensure only one semester is active at a time for an academic year
 * @param PDO $conn Database connection
 * @param int $new_active_id ID of the semester to make active
 * @param int $academic_year_id Academic year ID
 * @return bool Returns true on success, false on failure
 */
function set_active_semester($conn, $new_active_id, $academic_year_id) {
    try {
        $conn->beginTransaction();
        
        // First, set all semesters for this academic year to inactive
        $deactivate_query = "UPDATE semester SET status = 'inactive', updated_at = NOW() WHERE academic_year_id = ?";
        $deactivate_stmt = $conn->prepare($deactivate_query);
        $deactivate_stmt->execute([$academic_year_id]);
        
        // Then, set the specified one to active
        $activate_query = "UPDATE semester SET status = 'active', updated_at = NOW() WHERE id = ? AND academic_year_id = ?";
        $activate_stmt = $conn->prepare($activate_query);
        $activate_stmt->execute([$new_active_id, $academic_year_id]);
        
        $conn->commit();
        return true;
    } catch (PDOException $e) {
        $conn->rollback();
        error_log("Error setting active semester: " . $e->getMessage());
        return false;
    }
}

/**
 * Validate that only one academic year is active
 * @param PDO $conn Database connection
 * @return array Returns validation result with status and message
 */
function validate_academic_year_integrity($conn) {
    try {
        $query = "SELECT COUNT(*) as active_count FROM academic_year WHERE status = 'active'";
        $stmt = $conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $active_count = $result['active_count'];
        
        if ($active_count == 0) {
            return [
                'status' => 'warning',
                'message' => 'No active academic year found. Please activate one.',
                'count' => $active_count
            ];
        } elseif ($active_count == 1) {
            return [
                'status' => 'success',
                'message' => 'Academic year integrity is valid.',
                'count' => $active_count
            ];
        } else {
            return [
                'status' => 'error',
                'message' => "Multiple active academic years found ($active_count). Only one should be active.",
                'count' => $active_count
            ];
        }
    } catch (PDOException $e) {
        return [
            'status' => 'error',
            'message' => 'Error validating academic year integrity: ' . $e->getMessage(),
            'count' => 0
        ];
    }
}
?>
