<?php
session_start();
include_once 'config/init.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Testimonials - Benadir University E-Learning Management System</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/landing.css">
    <?php echo FONT_AWESOME_CSS; ?>
    <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;500;600;700&family=Open+Sans:wght@400;500;600&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Header Section -->
    <header class="landing-header">
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-brand">
                    <img src="assets/images/ben.png" alt="Benadir University Logo" class="nav-logo">
                    <span class="nav-title">Benadir University LMS</span>
                </div>
                <div class="nav-menu">
                    <a href="landing.php" class="nav-link">Home</a>
                    <a href="features.php" class="nav-link">Features</a>
                    <a href="about.php" class="nav-link">About Us</a>
                    <a href="testimonials.php" class="nav-link">Testimonials</a>
                    <a href="contact.php" class="nav-link">Contact</a>
                    <a href="auth/login.php" class="btn btn-outline btn-sm">Sign In</a>
                    <a href="auth/register.php" class="btn btn-primary btn-sm">Get Started</a>
                </div>
            </div>
        </nav>
    </header>

    <!-- Testimonials Section -->
    <section class="testimonials-section" style="padding-top: 120px;">
        <div class="section-container">
            <div class="section-header">
                <h1 class="section-title">What Our Students Say</h1>
                <p class="section-subtitle">Hear from students who have transformed their learning experience</p>
            </div>
            <div class="testimonials-grid">
                <div class="testimonial-card">
                    <div class="testimonial-content">
                        <div class="testimonial-stars">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="testimonial-text">
                            "The LMS has completely changed how I approach my studies. The interactive features and 24/7 access 
                            have made learning so much more flexible and engaging."
                        </p>
                    </div>
                    <div class="testimonial-author">
                        <img src="/placeholder.svg?height=60&width=60" alt="Student Photo" class="author-photo">
                        <div class="author-info">
                            <h4 class="author-name">Amina Hassan</h4>
                            <p class="author-title">Computer Science Student</p>
                        </div>
                    </div>
                </div>
                <div class="testimonial-card">
                    <div class="testimonial-content">
                        <div class="testimonial-stars">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="testimonial-text">
                            "As a working student, the flexibility of online learning has been invaluable. I can balance my job 
                            and studies effectively thanks to this platform."
                        </p>
                    </div>
                    <div class="testimonial-author">
                        <img src="/placeholder.svg?height=60&width=60" alt="Student Photo" class="author-photo">
                        <div class="author-info">
                            <h4 class="author-name">Omar Ahmed</h4>
                            <p class="author-title">Business Administration Student</p>
                        </div>
                    </div>
                </div>
                <div class="testimonial-card">
                    <div class="testimonial-content">
                        <div class="testimonial-stars">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="testimonial-text">
                            "The support from instructors and the community features have made online learning feel personal 
                            and connected. I never feel alone in my studies."
                        </p>
                    </div>
                    <div class="testimonial-author">
                        <img src="/placeholder.svg?height=60&width=60" alt="Student Photo" class="author-photo">
                        <div class="author-info">
                            <h4 class="author-name">Fatima Ali</h4>
                            <p class="author-title">Education Student</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="landing-footer">
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-section">
                    <div class="footer-brand">
                        <img src="assets/images/ben.png" alt="Benadir University Logo" class="footer-logo">
                        <h3>Benadir University</h3>
                        <p>Empowering minds through innovative education and technology.</p>
                    </div>
                </div>
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul class="footer-links">
                        <li><a href="landing.php">Home</a></li>
                        <li><a href="features.php">Features</a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="auth/register.php">Register</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Support</h4>
                    <ul class="footer-links">
                        <li><a href="#">Help Center</a></li>
                        <li><a href="contact.php">Contact Support</a></li>
                        <li><a href="#">Technical Support</a></li>
                        <li><a href="#">Student Resources</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Contact Info</h4>
                    <div class="contact-info">
                        <div class="contact-item">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>Mogadishu, Somalia</span>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-phone"></i>
                            <span>+252 1 234567</span>
                        </div>
                        <div class="contact-item">
                            <i class="fas fa-envelope"></i>
                            <span>info@benadir.edu.so</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="footer-bottom-content">
                    <p>&copy; 2024 Benadir University. All rights reserved.</p>
                    <div class="social-links">
                        <a href="#" class="social-link"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-linkedin"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
