<?php
session_start();
include_once 'config/init.php';

// If user is logged in, redirect to appropriate dashboard
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'admin') {
        header("Location: admin/dashboard.php");
        exit();
    } elseif ($_SESSION['role'] === 'student') {
        header("Location: student/dashboard.php");
        exit();
    } elseif ($_SESSION['role'] === 'instructor') {
        header("Location: instructor/dashboard.php");
        exit();
    }
}

// Get dynamic stats from database
$database = new Database();
$conn = $database->getConnection();

try {
    // Active Students Count
    $students_query = $conn->query("SELECT COUNT(*) AS total FROM users WHERE role='student' AND status='active'");
    $students_count = $students_query->fetch(PDO::FETCH_ASSOC)['total'];

    // Active Programs Count
    $programs_query = $conn->query("SELECT COUNT(*) AS total FROM programs WHERE status='active'");
    $programs_count = $programs_query->fetch(PDO::FETCH_ASSOC)['total'];

    // Active Departments Count
    $departments_query = $conn->query("SELECT COUNT(*) AS total FROM departments WHERE status='active'");
    $departments_count = $departments_query->fetch(PDO::FETCH_ASSOC)['total'];

    // Active Instructors Count
    $instructors_query = $conn->query("SELECT COUNT(*) AS total FROM users WHERE role='instructor' AND status='active'");
    $instructors_count = $instructors_query->fetch(PDO::FETCH_ASSOC)['total'];

    // Active Courses Count
    $courses_query = $conn->query("SELECT COUNT(*) AS total FROM course WHERE status='active'");
    $courses_count = $courses_query->fetch(PDO::FETCH_ASSOC)['total'];

    // Recent Announcements (from notifications table)
    $announcements_query = $conn->query("
        SELECT title, message, created_at, type, priority 
        FROM notifications 
        WHERE is_active = 1 AND target_audience IN ('all', 'students') 
        ORDER BY created_at DESC 
        LIMIT 3
    ");
    $announcements = $announcements_query->fetchAll(PDO::FETCH_ASSOC);

    // Featured Programs
    $featured_programs_query = $conn->query("
        SELECT p.name, p.code, p.description, d.name as department_name 
        FROM programs p 
        JOIN departments d ON p.department_id = d.id 
        WHERE p.status = 'active' 
        ORDER BY p.created_at DESC 
        LIMIT 6
    ");
    $featured_programs = $featured_programs_query->fetchAll(PDO::FETCH_ASSOC);

    // Upcoming Academic Events
    $events_query = $conn->query("
        SELECT title, description, event_date, start_time, end_time, location, event_type 
        FROM academic_events 
        WHERE status = 'Active' AND event_date >= CURDATE() 
        ORDER BY event_date ASC 
        LIMIT 4
    ");
    $upcoming_events = $events_query->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    // Fallback values if database queries fail
    $students_count = 0;
    $programs_count = 0;
    $departments_count = 0;
    $instructors_count = 0;
    $courses_count = 0;
    $announcements = [];
    $featured_programs = [];
    $upcoming_events = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Benadir University Postgraduate System</title>
    <meta name="description" content="Join Benadir University's modern E-Learning Management System. Access postgraduate programs, connect with expert instructors, and advance your education online.">
    <meta name="keywords" content="Benadir University, E-Learning, LMS, Online Education, Postgraduate Programs, Somalia">
    
    <!-- Updated CSS imports with modern design system -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/landing.css">
    <?php echo FONT_AWESOME_CSS; ?>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;900&family=Open+Sans:wght@400;500;600&display=swap" rel="stylesheet">
    
    <style>
        /* Added modern design system with green color palette */
        :root {
            --primary-color: #2563eb;
            --secondary-color: #64748b;
            --accent-color: #0099CC;
            --text-dark: #374151;
            --text-light: #6b7280;
            --background-light: #f0fdf4;
            --white: #ffffff;
            --border-light: #e5e7eb;
            --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            --radius: 0.5rem;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Open Sans', sans-serif;
            line-height: 1.6;
            color: var(--text-dark);
            background-color: var(--white);
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1rem;
        }

        /* Header Styles */
        .header {
            background: var(--white);
            box-shadow: var(--shadow);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }

        .nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
        }

        .nav-brand {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .nav-logo {
            width: 40px;
            height: 40px;
        }

        .nav-title {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            font-size: 1.25rem;
            color: var(--primary-color);
        }

        .nav-links {
            display: flex;
            gap: 2rem;
            list-style: none;
        }

        .nav-link {
            text-decoration: none;
            color: var(--text-dark);
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .nav-link:hover {
            color: var(--primary-color);
        }

        .nav-actions {
            display: flex;
            gap: 1rem;
        }

        .btn {
            padding: 0.75rem 1.5rem;
            border-radius: var(--radius);
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-primary {
            background: var(--primary-color);
            color: var(--white);
        }

        .btn-primary:hover {
            background: #166534;
            transform: translateY(-2px);
        }

        .btn-outline {
            background: transparent;
            color: var(--primary-color);
            border: 2px solid var(--primary-color);
        }

        .btn-outline:hover {
            background: var(--primary-color);
            color: var(--white);
        }

        /* Hero Section */
        .hero {
            background: linear-gradient(135deg, var(--background-light) 0%, var(--white) 100%);
            padding: 8rem 0 4rem;
            margin-top: 80px;
        }

        .hero-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 4rem;
            align-items: center;
        }

        .hero-title {
            font-family: 'Montserrat', sans-serif;
            font-weight: 900;
            font-size: 3rem;
            line-height: 1.2;
            color: var(--text-dark);
            margin-bottom: 1.5rem;
        }

        .hero-subtitle {
            font-size: 1.25rem;
            color: var(--text-light);
            margin-bottom: 2rem;
            line-height: 1.6;
        }

        .hero-actions {
            display: flex;
            gap: 1rem;
            margin-bottom: 3rem;
        }

        .hero-stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 2rem;
        }

        .stat-card {
            text-align: center;
            padding: 1.5rem;
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
        }

        .stat-number {
            font-family: 'Montserrat', sans-serif;
            font-weight: 900;
            font-size: 2.5rem;
            color: var(--primary-color);
            display: block;
        }

        .stat-label {
            color: var(--text-light);
            font-weight: 500;
            margin-top: 0.5rem;
        }

        .hero-image {
            position: relative;
        }

        .hero-img {
            width: 100%;
            height: auto;
            border-radius: var(--radius);
            box-shadow: var(--shadow-lg);
        }

        /* Sections */
        .section {
            padding: 4rem 0;
        }

        .section-header {
            text-align: center;
            margin-bottom: 3rem;
        }

        .section-title {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            font-size: 2.5rem;
            color: var(--text-dark);
            margin-bottom: 1rem;
        }

        .section-subtitle {
            font-size: 1.125rem;
            color: var(--text-light);
            max-width: 600px;
            margin: 0 auto;
        }

        /* Programs Grid */
        .programs-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 2rem;
        }

        .program-card {
            background: var(--white);
            border-radius: var(--radius);
            padding: 2rem;
            box-shadow: var(--shadow);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .program-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .program-code {
            background: var(--secondary-color);
            color: var(--white);
            padding: 0.5rem 1rem;
            border-radius: var(--radius);
            font-weight: 600;
            font-size: 0.875rem;
            display: inline-block;
            margin-bottom: 1rem;
        }

        .program-title {
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            font-size: 1.25rem;
            margin-bottom: 0.5rem;
        }

        .program-department {
            color: var(--text-light);
            font-size: 0.875rem;
            margin-bottom: 1rem;
        }

        .program-description {
            color: var(--text-light);
            line-height: 1.6;
        }

        /* Announcements */
        .announcements-grid {
            display: grid;
            gap: 1.5rem;
        }

        .announcement-card {
            background: var(--white);
            border-left: 4px solid var(--primary-color);
            padding: 1.5rem;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
        }

        .announcement-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1rem;
        }

        .announcement-title {
            font-weight: 600;
            color: var(--text-dark);
        }

        .announcement-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 500;
        }

        .badge-urgent { background: #fef2f2; color: #dc2626; }
        .badge-academic { background: #eff6ff; color: #2563eb; }
        .badge-general { background: #f0fdf4; color: #16a34a; }

        .announcement-message {
            color: var(--text-light);
            line-height: 1.6;
        }

        .announcement-date {
            color: var(--text-light);
            font-size: 0.875rem;
            margin-top: 1rem;
        }

        /* Events */
        .events-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem;
        }

        .event-card {
            background: var(--white);
            border-radius: var(--radius);
            padding: 1.5rem;
            box-shadow: var(--shadow);
            transition: transform 0.3s ease;
        }

        .event-card:hover {
            transform: translateY(-3px);
        }

        .event-date {
            background: var(--primary-color);
            color: var(--white);
            padding: 0.5rem;
            border-radius: var(--radius);
            text-align: center;
            margin-bottom: 1rem;
        }

        .event-day {
            font-size: 1.5rem;
            font-weight: 700;
        }

        .event-month {
            font-size: 0.875rem;
        }

        .event-title {
            font-weight: 600;
            margin-bottom: 0.5rem;
        }

        .event-details {
            color: var(--text-light);
            font-size: 0.875rem;
        }

        /* Footer */
        .footer {
            background: var(--text-dark);
            color: var(--white);
            padding: 3rem 0 1rem;
        }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .footer-section h4 {
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
            margin-bottom: 1rem;
        }

        .footer-links {
            list-style: none;
        }

        .footer-links li {
            margin-bottom: 0.5rem;
        }

        .footer-links a {
            color: #d1d5db;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .footer-links a:hover {
            color: var(--secondary-color);
        }

        .footer-bottom {
            border-top: 1px solid #4b5563;
            padding-top: 1rem;
            text-align: center;
            color: #9ca3af;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .nav-links {
                display: none;
            }

            .hero-content {
                grid-template-columns: 1fr;
                text-align: center;
            }

            .hero-title {
                font-size: 2rem;
            }

            .hero-stats {
                grid-template-columns: 1fr;
            }

            .programs-grid {
                grid-template-columns: 1fr;
            }

            .events-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <nav class="nav">
                <div class="nav-brand">
                    <img src="assets/images/ben.png" alt="Benadir University Logo" class="nav-logo">
                    <span class="nav-title">Benadir University LMS</span>
                </div>
                <ul class="nav-links">
                    <li><a href="#programs" class="nav-link">Programs</a></li>
                    <li><a href="#announcements" class="nav-link">News</a></li>
                    <li><a href="#events" class="nav-link">Events</a></li>
                    <li><a href="#contact" class="nav-link">Contact</a></li>
                </ul>
                <div class="nav-actions">
                    <a href="auth/login.php" class="btn btn-outline">
                        <i class="fas fa-sign-in-alt"></i>
                        Sign In
                    </a>
                    <a href="auth/register.php" class="btn btn-primary">
                        <i class="fas fa-user-plus"></i>
                        Register
                    </a>
                </div>
            </nav>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <div class="hero-text">
                    <h1 class="hero-title">Excellence in Postgraduate Education</h1>
                    <p class="hero-subtitle">
                        Join Benadir University's cutting-edge Postgraduate System. 
                        Access world-class postgraduate programs, connect with expert faculty, 
                        and advance your academic journey with our innovative online platform.
                    </p>
                    <div class="hero-actions">
                        <a href="auth/register.php" class="btn btn-primary">
                            <i class="fas fa-graduation-cap"></i>
                            Start Your Journey
                        </a>
                        <a href="#programs" class="btn btn-outline">
                            <i class="fas fa-search"></i>
                            Explore Programs
                        </a>
                    </div>
                    <div class="hero-stats">
                        <div class="stat-card">
                            <span class="stat-number"><?php echo number_format($students_count); ?>+</span>
                            <span class="stat-label">Active Students</span>
                        </div>
                        <div class="stat-card">
                            <span class="stat-number"><?php echo number_format($programs_count); ?>+</span>
                            <span class="stat-label">Programs</span>
                        </div>
                        <div class="stat-card">
                            <span class="stat-number"><?php echo number_format($instructors_count); ?>+</span>
                            <span class="stat-label">Expert Faculty</span>
                        </div>
                    </div>
                </div>
                <div class="hero-image">
                    <img src="assets/images/cover.jpeg"height=500&width=600" alt="Benadir University Campus" class="hero-img">
                </div>
            </div>
        </div>
    </section>

    <!-- Added dynamic programs section -->
    <?php if (!empty($featured_programs)): ?>
    <section id="programs" class="section">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">Our Postgraduate Programs</h2>
                <p class="section-subtitle">Discover our comprehensive range of master's degree programs designed for academic and professional excellence</p>
            </div>
            <div class="programs-grid">
                <?php foreach ($featured_programs as $program): ?>
                <div class="program-card">
                    <span class="program-code"><?php echo htmlspecialchars($program['code']); ?></span>
                    <h3 class="program-title"><?php echo htmlspecialchars($program['name']); ?></h3>
                    <p class="program-department">Department of <?php echo htmlspecialchars($program['department_name']); ?></p>
                    <p class="program-description"><?php echo htmlspecialchars($program['description'] ?: 'Advanced degree program designed for professional growth and academic excellence.'); ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- Added dynamic announcements section -->
    <?php if (!empty($announcements)): ?>
    <section id="announcements" class="section" style="background: var(--background-light);">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">Latest Announcements</h2>
                <p class="section-subtitle">Stay updated with the latest news and important information from Benadir University</p>
            </div>
            <div class="announcements-grid">
                <?php foreach ($announcements as $announcement): ?>
                <div class="announcement-card">
                    <div class="announcement-header">
                        <h3 class="announcement-title"><?php echo htmlspecialchars($announcement['title']); ?></h3>
                        <span class="announcement-badge badge-<?php echo $announcement['type']; ?>">
                            <?php echo ucfirst($announcement['type']); ?>
                        </span>
                    </div>
                    <p class="announcement-message"><?php echo htmlspecialchars($announcement['message']); ?></p>
                    <p class="announcement-date">
                        <i class="fas fa-calendar"></i>
                        <?php echo date('F j, Y', strtotime($announcement['created_at'])); ?>
                    </p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- Added dynamic events section -->
    <?php if (!empty($upcoming_events)): ?>
    <section id="events" class="section">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">Upcoming Events</h2>
                <p class="section-subtitle">Don't miss these important academic events and activities</p>
            </div>
            <div class="events-grid">
                <?php foreach ($upcoming_events as $event): ?>
                <div class="event-card">
                    <div class="event-date">
                        <div class="event-day"><?php echo date('d', strtotime($event['event_date'])); ?></div>
                        <div class="event-month"><?php echo date('M', strtotime($event['event_date'])); ?></div>
                    </div>
                    <h3 class="event-title"><?php echo htmlspecialchars($event['title']); ?></h3>
                    <div class="event-details">
                        <p><i class="fas fa-clock"></i> <?php echo date('g:i A', strtotime($event['start_time'])); ?></p>
                        <p><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($event['location']); ?></p>
                        <p><i class="fas fa-tag"></i> <?php echo ucfirst($event['event_type']); ?></p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- Call to Action Section -->
    <section class="section" style="background: var(--primary-color); color: var(--white);">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title" style="color: var(--white);">Ready to Begin Your Academic Journey?</h2>
                <p class="section-subtitle" style="color: rgba(255, 255, 255, 0.9);">
                    Join thousands of students who are advancing their careers with our world-class postgraduate programs
                </p>
                <div style="margin-top: 2rem;">
                    <a href="auth/register.php" class="btn" style="background: var(--white); color: var(--primary-color); margin-right: 1rem;">
                        <i class="fas fa-rocket"></i>
                        Apply Now
                    </a>
                    <a href="auth/login.php" class="btn btn-outline" style="border-color: var(--white); color: var(--white);">
                        <i class="fas fa-sign-in-alt"></i>
                        Student Login
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer id="contact" class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <div class="nav-brand" style="margin-bottom: 1rem;">
                        <img src="assets/images/ben.png" alt="Benadir University Logo" class="nav-logo">
                        <span class="nav-title" style="color: var(--white);">Benadir University</span>
                    </div>
                    <p style="color: #d1d5db;">Empowering minds through innovative postgraduate education and cutting-edge technology.</p>
                </div>
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul class="footer-links">
                        <li><a href="#programs">Programs</a></li>
                        <li><a href="#announcements">Announcements</a></li>
                        <li><a href="#events">Events</a></li>
                        <li><a href="auth/register.php">Apply Now</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Student Services</h4>
                    <ul class="footer-links">
                        <li><a href="auth/login.php">Student Portal</a></li>
                        <li><a href="#">Academic Support</a></li>
                        <li><a href="#">Technical Help</a></li>
                        <li><a href="#">Library Resources</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Contact Information</h4>
                    <div style="color: #d1d5db;">
                        <p><i class="fas fa-map-marker-alt"></i> Mogadishu, Somalia</p>
                        <p><i class="fas fa-phone"></i> +252 1 234567</p>
                        <p><i class="fas fa-envelope"></i> info@benadir.edu.so</p>
                        <p><i class="fas fa-globe"></i> www.benadir.edu.so</p>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> Benadir University. All rights reserved</p>
            </div>
        </div>
    </footer>

    <script>
        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Add scroll effect to header
        window.addEventListener('scroll', function() {
            const header = document.querySelector('.header');
            if (window.scrollY > 100) {
                header.style.background = 'rgba(255, 255, 255, 0.95)';
                header.style.backdropFilter = 'blur(10px)';
            } else {
                header.style.background = 'var(--white)';
                header.style.backdropFilter = 'none';
            }
        });

        // Animate stats on scroll
        const observerOptions = {
            threshold: 0.5,
            rootMargin: '0px 0px -100px 0px'
        };

        const observer = new IntersectionObserver(function(entries) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const statNumbers = entry.target.querySelectorAll('.stat-number');
                    statNumbers.forEach(stat => {
                        const finalValue = parseInt(stat.textContent);
                        animateValue(stat, 0, finalValue, 2000);
                    });
                    observer.unobserve(entry.target);
                }
            });
        }, observerOptions);

        const statsSection = document.querySelector('.hero-stats');
        if (statsSection) {
            observer.observe(statsSection);
        }

        function animateValue(element, start, end, duration) {
            let startTimestamp = null;
            const step = (timestamp) => {
                if (!startTimestamp) startTimestamp = timestamp;
                const progress = Math.min((timestamp - startTimestamp) / duration, 1);
                const currentValue = Math.floor(progress * (end - start) + start);
                element.textContent = currentValue.toLocaleString() + '+';
                if (progress < 1) {
                    window.requestAnimationFrame(step);
                }
            };
            window.requestAnimationFrame(step);
        }
    </script>
</body>
</html>
