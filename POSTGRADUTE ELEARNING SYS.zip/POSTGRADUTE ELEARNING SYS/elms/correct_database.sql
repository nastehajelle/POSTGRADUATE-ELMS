-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 06, 2025 at 08:13 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `new_bmw`
--

-- --------------------------------------------------------

--
-- Table structure for table `academic_events`
--

CREATE TABLE `academic_events` (
  `id` int(11) NOT NULL,
  `event_type` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `event_date` date NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `status` enum('Active','Inactive','Cancelled') NOT NULL DEFAULT 'Active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `academic_events`
--

INSERT INTO `academic_events` (`id`, `event_type`, `title`, `description`, `event_date`, `start_time`, `end_time`, `location`, `status`, `created_at`, `updated_at`, `created_by`) VALUES
(1, 'Exam', 'Midterm Exams Start', 'First round of midterm examinations for all programs.', '2025-08-15', '09:00:00', '17:00:00', 'University Hall', 'Active', '2025-07-31 21:16:40', '2025-07-31 21:16:40', NULL),
(2, 'Holiday', 'National Day Holiday', 'University closed for National Day.', '2025-08-20', NULL, NULL, 'N/A', 'Active', '2025-07-31 21:16:40', '2025-07-31 21:16:40', NULL),
(3, 'Lecture', 'Guest Lecture: AI in Education', 'Special lecture by Dr. Jane Doe on Artificial Intelligence in Education.', '2025-09-01', '10:00:00', '12:00:00', 'Auditorium A', 'Active', '2025-07-31 21:16:40', '2025-07-31 21:16:40', NULL),
(4, 'Registration', 'Course Registration Deadline', 'Last day to register for Fall 2025 courses.', '2025-09-05', '00:00:00', '23:59:59', 'Online', 'Active', '2025-07-31 21:16:40', '2025-07-31 21:16:40', NULL),
(5, 'Workshop', 'Research Methodology Workshop', 'Workshop for graduate students on advanced research methodologies.', '2025-09-10', '14:00:00', '16:00:00', 'Lab 301', 'Active', '2025-07-31 21:16:40', '2025-07-31 21:16:40', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `academic_year`
--

CREATE TABLE `academic_year` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `academic_year`
--

INSERT INTO `academic_year` (`id`, `name`, `start_date`, `end_date`, `status`, `created_at`, `updated_at`) VALUES
(1, '2023-2024', '2023-09-01', '2024-08-31', 'active', '2025-05-08 16:48:23', NULL),
(2, '2024-2025', '2024-09-01', '2025-08-31', 'inactive', '2025-05-08 16:48:23', '2025-05-08 19:55:41');

-- --------------------------------------------------------

--
-- Table structure for table `assessments`
--

CREATE TABLE `assessments` (
  `id` int(11) NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  `type` enum('exam','quiz','assignment','project') NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `total_marks` int(11) NOT NULL,
  `pass_marks` int(11) NOT NULL,
  `duration_minutes` int(11) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(11) NOT NULL,
  `weight` float DEFAULT NULL,
  `instructions` varchar(1000) DEFAULT NULL,
  `randomize_questions` tinyint(1) DEFAULT 0,
  `attempts_allowed` int(11) DEFAULT 1,
  `submission_type` enum('file','text','both','link') DEFAULT NULL,
  `allow_late_submission` tinyint(1) DEFAULT 0,
  `is_group_project` tinyint(1) DEFAULT 0,
  `milestones` text DEFAULT NULL,
  `rubric` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `assessments`
--

INSERT INTO `assessments` (`id`, `course_id`, `program_id`, `department_id`, `type`, `title`, `description`, `total_marks`, `pass_marks`, `duration_minutes`, `start_time`, `end_time`, `status`, `created_at`, `updated_at`, `created_by`, `weight`, `instructions`, `randomize_questions`, `attempts_allowed`, `submission_type`, `allow_late_submission`, `is_group_project`, `milestones`, `rubric`) VALUES
(31, 3, NULL, NULL, 'quiz', 'Ass 1', 'waaw', 20, 12, 5, '2025-08-07 21:55:00', '2025-08-07 22:00:00', 'inactive', '2025-08-07 18:52:06', '2025-08-07 22:00:16', 48, NULL, 'aa', 0, 1, NULL, 0, 0, NULL, NULL),
(32, NULL, 1, NULL, 'exam', 'Mid-term', 'aa', 30, 18, 2, '2025-08-08 08:25:00', '2025-08-08 08:30:00', 'inactive', '2025-08-08 04:57:03', '2025-08-08 16:58:58', 1, NULL, 'aaa', 0, 1, NULL, 0, 0, NULL, NULL),
(33, NULL, 1, NULL, 'exam', 'Midt-term', 'aaaaa', 30, 18, 3, '2025-08-08 19:00:00', '2025-08-08 19:05:00', 'inactive', '2025-08-08 15:53:24', '2025-08-08 19:08:04', 1, NULL, 'aaa', 0, 1, NULL, 0, 0, NULL, NULL),
(34, NULL, 4, NULL, 'exam', 'test', 'a', 30, 18, 2, '2025-08-08 19:09:00', '2025-08-08 19:32:00', 'inactive', '2025-08-08 15:57:37', '2025-08-09 08:07:22', 1, NULL, 'aa', 0, 1, NULL, 0, 0, NULL, NULL),
(35, NULL, NULL, NULL, 'exam', 'Final Exam', 'waaw', 30, 18, 5, '2025-08-09 09:00:00', '2025-08-09 09:30:00', 'inactive', '2025-08-09 05:09:26', '2025-08-09 18:21:00', 1, NULL, 'yahy', 0, 1, NULL, 0, 0, NULL, NULL),
(36, NULL, NULL, NULL, 'exam', 'AA1', 'hh', 30, 18, 2, '2025-08-09 20:40:00', '2025-08-09 20:51:00', 'inactive', '2025-08-09 17:32:09', '2025-08-10 21:00:51', 1, NULL, 'aa', 0, 1, NULL, 0, 0, NULL, NULL),
(37, NULL, 1, NULL, 'exam', 'e1', 'ss', 30, 18, 5, '2025-08-13 08:45:00', '2025-08-13 09:00:00', 'inactive', '2025-08-13 05:38:53', '2025-08-13 09:11:00', 1, NULL, 'yhhh', 1, 1, NULL, 0, 0, NULL, NULL),
(38, NULL, NULL, NULL, 'exam', 'final exam', 'sss', 30, 18, 2, '2025-08-13 10:47:00', '2025-08-13 10:54:00', 'inactive', '2025-08-13 07:42:46', '2025-08-13 11:02:00', 1, NULL, 'yyyy', 1, 1, NULL, 0, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `assessment_questions`
--

CREATE TABLE `assessment_questions` (
  `id` int(11) NOT NULL,
  `assessment_id` int(11) NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `batch_id` int(11) NOT NULL,
  `question_text` text NOT NULL,
  `question_type` enum('mcq','true_false','short_answer','essay') NOT NULL,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`options`)),
  `correct_answer` text DEFAULT NULL,
  `marks` decimal(5,2) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `assessment_questions`
--

INSERT INTO `assessment_questions` (`id`, `assessment_id`, `course_id`, `batch_id`, `question_text`, `question_type`, `options`, `correct_answer`, `marks`, `created_at`, `updated_at`) VALUES
(22, 31, 3, 2, 'somalia waa gobol', 'true_false', NULL, 'True', '16.00', '2025-08-07 21:52:52', '2025-08-09 08:04:05'),
(23, 31, 3, 2, 'saadaq wa qof', 'true_false', NULL, 'True', '4.00', '2025-08-07 21:53:09', '2025-08-09 08:04:05'),
(24, 32, 3, 2, 'somaliw aaa degmo', 'true_false', NULL, 'True', '20.00', '2025-08-08 08:02:57', '2025-08-09 08:04:05'),
(25, 32, 3, 2, 'saadaq waa lax', 'true_false', NULL, 'True', '10.00', '2025-08-08 08:03:16', '2025-08-09 08:04:05'),
(26, 33, 5, 10, 'benadir waa 22 degmo', 'true_false', NULL, 'False', '25.00', '2025-08-08 18:54:32', '2025-08-09 08:04:05'),
(27, 33, 5, 10, 'gobolada dalka waa 22', 'true_false', NULL, 'False', '5.00', '2025-08-08 18:54:58', '2025-08-09 08:04:05'),
(28, 34, 3, 2, '1 waxa ku xigto 10', 'true_false', NULL, 'True', '30.00', '2025-08-08 19:03:04', '2025-08-09 08:04:05'),
(29, 35, 3, 2, 'jaamacdeyda waa benadir', 'true_false', NULL, 'True', '30.00', '2025-08-09 08:11:24', '2025-08-09 08:11:24'),
(30, 35, 5, 10, 'dalkayaga waa somalia', 'true_false', NULL, 'True', '30.00', '2025-08-09 08:12:33', '2025-08-09 08:12:33'),
(31, 35, 4, 4, 'groupkeygaa  ardayda ku jirta waa', 'mcq', '[\"4\",\"7\",\"8\",\"5\"]', 'B', '28.00', '2025-08-09 08:13:34', '2025-08-09 08:13:34'),
(32, 35, 4, 4, 'b19', 'short_answer', NULL, 'waa dad laxa', '2.00', '2025-08-09 08:13:52', '2025-08-09 08:13:52'),
(33, 36, 3, 2, 'nasteho idgaa waa 5', 'true_false', NULL, 'False', '30.00', '2025-08-09 20:34:28', '2025-08-09 20:34:28'),
(34, 36, 4, 4, 'whats oracle', 'short_answer', NULL, 'waa database', '28.00', '2025-08-09 20:35:32', '2025-08-09 20:35:32'),
(35, 37, 6, 2, 'sabarin id waa 97', 'true_false', NULL, 'True', '30.00', '2025-08-13 08:41:45', '2025-08-13 08:41:45'),
(36, 37, 5, 10, 'somali waa gobol', 'true_false', NULL, 'False', '30.00', '2025-08-13 08:42:16', '2025-08-13 08:42:16'),
(37, 38, 3, 2, 'batch 19 waa batch oo akliya', 'true_false', NULL, 'True', '30.00', '2025-08-13 10:47:24', '2025-08-13 10:47:24');

-- --------------------------------------------------------

--
-- Table structure for table `assessment_results`
--

CREATE TABLE `assessment_results` (
  `id` int(11) NOT NULL,
  `assessment_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `marks_obtained` int(11) NOT NULL,
  `grade` varchar(2) DEFAULT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `assessment_results`
--

INSERT INTO `assessment_results` (`id`, `assessment_id`, `student_id`, `marks_obtained`, `grade`, `submitted_at`) VALUES
(5, 31, 129, 16, 'B', '2025-08-07 18:57:46'),
(6, 32, 129, 30, 'A', '2025-08-08 05:26:27'),
(7, 33, 129, 0, 'F', '2025-08-08 16:03:49'),
(8, 33, 138, 0, 'F', '2025-08-08 16:04:55'),
(9, 34, 136, 30, 'A', '2025-08-08 16:09:16'),
(10, 35, 129, 30, 'A', '2025-08-09 06:02:47'),
(11, 35, 136, 2, 'F', '2025-08-09 06:04:48'),
(12, 35, 138, 30, 'A', '2025-08-09 06:05:42'),
(13, 36, 136, 28, 'A', '2025-08-09 17:40:30'),
(14, 36, 129, 0, 'F', '2025-08-09 17:41:04'),
(15, 37, 129, 30, 'A', '2025-08-13 05:46:40'),
(16, 37, 136, 0, 'F', '2025-08-13 05:47:48'),
(17, 37, 130, 30, 'A', '2025-08-13 05:48:24'),
(18, 38, 129, 30, 'A', '2025-08-13 07:48:37');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `status` enum('present','absent','late') NOT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `course_id`, `student_id`, `date`, `status`, `remarks`, `created_at`, `updated_at`) VALUES
(1, 3, 37, '2025-08-04', 'present', '', '2025-08-04 07:24:43', '2025-08-04 07:24:43'),
(2, 3, 129, '2025-08-04', 'present', '', '2025-08-04 07:24:43', '2025-08-04 07:24:43'),
(3, 3, 36, '2025-08-04', 'present', '', '2025-08-04 07:24:43', '2025-08-04 07:24:43'),
(4, 3, 135, '2025-08-04', 'present', '', '2025-08-04 07:24:43', '2025-08-04 07:24:43'),
(5, 3, 22, '2025-08-04', 'present', '', '2025-08-04 07:24:43', '2025-08-04 07:24:43'),
(6, 3, 130, '2025-08-04', 'absent', '', '2025-08-04 07:24:43', '2025-08-04 07:24:43'),
(28, 3, 37, '2025-08-06', 'present', '', '2025-08-06 18:56:34', '2025-08-06 18:56:34'),
(30, 3, 129, '2025-08-06', 'absent', '', '2025-08-06 18:56:34', '2025-08-06 18:56:34'),
(31, 3, 36, '2025-08-06', 'present', '', '2025-08-06 18:56:34', '2025-08-06 18:56:34'),
(32, 3, 135, '2025-08-06', 'absent', '', '2025-08-06 18:56:34', '2025-08-06 18:56:34'),
(33, 3, 22, '2025-08-06', 'present', '', '2025-08-06 18:56:34', '2025-08-06 18:56:34'),
(34, 3, 130, '2025-08-06', 'absent', '', '2025-08-06 18:56:34', '2025-08-06 18:56:34'),
(35, 3, 37, '2025-08-07', 'present', '', '2025-08-07 06:50:52', '2025-08-07 06:50:52'),
(37, 3, 129, '2025-08-07', 'present', '', '2025-08-07 06:50:52', '2025-08-07 06:50:52'),
(38, 3, 36, '2025-08-07', 'absent', '', '2025-08-07 06:50:52', '2025-08-07 06:50:52'),
(39, 3, 135, '2025-08-07', 'absent', '', '2025-08-07 06:50:52', '2025-08-07 06:50:52'),
(40, 3, 22, '2025-08-07', 'present', '', '2025-08-07 06:50:52', '2025-08-07 06:50:52'),
(41, 3, 130, '2025-08-07', 'present', '', '2025-08-07 06:50:52', '2025-08-07 06:50:52'),
(42, 3, 37, '2025-08-08', 'present', '', '2025-08-08 07:06:44', '2025-08-08 07:06:44'),
(44, 3, 129, '2025-08-08', 'present', '', '2025-08-08 07:06:44', '2025-08-08 07:06:44'),
(45, 3, 36, '2025-08-08', 'present', '', '2025-08-08 07:06:44', '2025-08-08 07:06:44'),
(46, 3, 135, '2025-08-08', 'present', '', '2025-08-08 07:06:44', '2025-08-08 07:06:44'),
(47, 3, 22, '2025-08-08', 'present', '', '2025-08-08 07:06:44', '2025-08-08 07:06:44'),
(48, 3, 130, '2025-08-08', 'present', '', '2025-08-08 07:06:44', '2025-08-08 07:06:44'),
(56, 3, 37, '2025-08-09', 'present', '', '2025-08-09 07:18:41', '2025-08-09 07:18:41'),
(58, 3, 129, '2025-08-09', 'absent', '', '2025-08-09 07:18:41', '2025-08-09 07:18:41'),
(59, 3, 36, '2025-08-09', 'present', '', '2025-08-09 07:18:41', '2025-08-09 07:18:41'),
(60, 3, 135, '2025-08-09', 'present', '', '2025-08-09 07:18:41', '2025-08-09 07:18:41'),
(61, 3, 22, '2025-08-09', 'present', '', '2025-08-09 07:18:41', '2025-08-09 07:18:41'),
(62, 3, 130, '2025-08-09', 'present', '', '2025-08-09 07:18:41', '2025-08-09 07:18:41'),
(63, 3, 37, '2025-08-10', 'present', '', '2025-08-10 21:28:09', '2025-08-10 21:28:09'),
(65, 3, 129, '2025-08-10', 'present', '', '2025-08-10 21:28:09', '2025-08-10 21:28:09'),
(66, 3, 36, '2025-08-10', 'present', '', '2025-08-10 21:28:09', '2025-08-10 21:28:09'),
(67, 3, 135, '2025-08-10', 'present', '', '2025-08-10 21:28:09', '2025-08-10 21:28:09'),
(68, 3, 22, '2025-08-10', 'present', '', '2025-08-10 21:28:09', '2025-08-10 21:28:09'),
(69, 3, 130, '2025-08-10', 'present', '', '2025-08-10 21:28:09', '2025-08-10 21:28:09'),
(70, 3, 37, '2025-08-12', 'present', '', '2025-08-12 20:58:24', '2025-08-12 20:58:24'),
(71, 3, 136, '2025-08-12', 'present', '', '2025-08-12 20:58:24', '2025-08-12 20:58:24'),
(73, 3, 129, '2025-08-12', 'absent', '', '2025-08-12 20:58:24', '2025-08-12 20:58:24'),
(74, 3, 36, '2025-08-12', 'present', '', '2025-08-12 20:58:24', '2025-08-12 20:58:24'),
(75, 3, 135, '2025-08-12', 'present', '', '2025-08-12 20:58:24', '2025-08-12 20:58:24'),
(76, 3, 22, '2025-08-12', 'present', '', '2025-08-12 20:58:24', '2025-08-12 20:58:24'),
(77, 3, 130, '2025-08-12', 'absent', '', '2025-08-12 20:58:24', '2025-08-12 20:58:24'),
(85, 3, 37, '2025-08-13', 'absent', '', '2025-08-13 10:46:29', '2025-08-13 10:46:29'),
(86, 3, 136, '2025-08-13', 'present', '', '2025-08-13 10:46:29', '2025-08-13 10:46:29'),
(87, 3, 129, '2025-08-13', 'absent', '', '2025-08-13 10:46:29', '2025-08-13 10:46:29'),
(88, 3, 36, '2025-08-13', 'present', '', '2025-08-13 10:46:29', '2025-08-13 10:46:29'),
(89, 3, 135, '2025-08-13', 'present', '', '2025-08-13 10:46:29', '2025-08-13 10:46:29'),
(90, 3, 22, '2025-08-13', 'present', '', '2025-08-13 10:46:29', '2025-08-13 10:46:29'),
(91, 3, 130, '2025-08-13', 'present', '', '2025-08-13 10:46:29', '2025-08-13 10:46:29'),
(92, 6, 37, '2025-08-21', 'present', '', '2025-08-21 20:18:31', '2025-08-21 20:18:31'),
(93, 6, 136, '2025-08-21', 'present', '', '2025-08-21 20:18:31', '2025-08-21 20:18:31'),
(94, 6, 152, '2025-08-21', 'present', '', '2025-08-21 20:18:31', '2025-08-21 20:18:31'),
(95, 6, 129, '2025-08-21', 'present', '', '2025-08-21 20:18:31', '2025-08-21 20:18:31'),
(96, 6, 36, '2025-08-21', 'present', '', '2025-08-21 20:18:31', '2025-08-21 20:18:31'),
(97, 6, 135, '2025-08-21', 'present', '', '2025-08-21 20:18:31', '2025-08-21 20:18:31'),
(98, 6, 22, '2025-08-21', 'present', '', '2025-08-21 20:18:31', '2025-08-21 20:18:31'),
(99, 6, 130, '2025-08-21', 'present', '', '2025-08-21 20:18:31', '2025-08-21 20:18:31'),
(100, 7, 37, '2025-08-21', 'absent', '', '2025-08-21 20:18:40', '2025-08-21 20:18:40'),
(101, 7, 136, '2025-08-21', 'absent', '', '2025-08-21 20:18:40', '2025-08-21 20:18:40'),
(102, 7, 152, '2025-08-21', 'absent', '', '2025-08-21 20:18:40', '2025-08-21 20:18:40'),
(103, 7, 129, '2025-08-21', 'absent', '', '2025-08-21 20:18:40', '2025-08-21 20:18:40'),
(104, 7, 36, '2025-08-21', 'absent', '', '2025-08-21 20:18:40', '2025-08-21 20:18:40'),
(105, 7, 135, '2025-08-21', 'absent', '', '2025-08-21 20:18:40', '2025-08-21 20:18:40'),
(106, 7, 22, '2025-08-21', 'absent', '', '2025-08-21 20:18:40', '2025-08-21 20:18:40'),
(107, 7, 130, '2025-08-21', 'absent', '', '2025-08-21 20:18:40', '2025-08-21 20:18:40'),
(108, 6, 37, '2025-08-24', 'present', '', '2025-08-24 20:34:39', '2025-08-24 20:34:39'),
(109, 6, 136, '2025-08-24', 'present', '', '2025-08-24 20:34:39', '2025-08-24 20:34:39'),
(110, 6, 152, '2025-08-24', 'present', '', '2025-08-24 20:34:39', '2025-08-24 20:34:39'),
(111, 6, 129, '2025-08-24', 'present', '', '2025-08-24 20:34:39', '2025-08-24 20:34:39'),
(112, 6, 36, '2025-08-24', 'present', '', '2025-08-24 20:34:39', '2025-08-24 20:34:39'),
(113, 6, 135, '2025-08-24', 'present', '', '2025-08-24 20:34:39', '2025-08-24 20:34:39'),
(114, 6, 22, '2025-08-24', 'present', '', '2025-08-24 20:34:39', '2025-08-24 20:34:39'),
(115, 6, 130, '2025-08-24', 'present', '', '2025-08-24 20:34:39', '2025-08-24 20:34:39'),
(116, 3, 37, '2025-08-24', 'absent', '', '2025-08-24 20:34:46', '2025-08-24 20:34:46'),
(117, 3, 136, '2025-08-24', 'absent', '', '2025-08-24 20:34:46', '2025-08-24 20:34:46'),
(118, 3, 152, '2025-08-24', 'absent', '', '2025-08-24 20:34:46', '2025-08-24 20:34:46'),
(119, 3, 129, '2025-08-24', 'absent', '', '2025-08-24 20:34:46', '2025-08-24 20:34:46'),
(120, 3, 36, '2025-08-24', 'absent', '', '2025-08-24 20:34:46', '2025-08-24 20:34:46'),
(121, 3, 135, '2025-08-24', 'absent', '', '2025-08-24 20:34:46', '2025-08-24 20:34:46'),
(122, 3, 22, '2025-08-24', 'absent', '', '2025-08-24 20:34:46', '2025-08-24 20:34:46'),
(123, 3, 130, '2025-08-24', 'absent', '', '2025-08-24 20:34:46', '2025-08-24 20:34:46'),
(124, 7, 37, '2025-08-24', 'absent', '', '2025-08-24 20:34:54', '2025-08-24 20:34:54'),
(125, 7, 136, '2025-08-24', 'absent', '', '2025-08-24 20:34:54', '2025-08-24 20:34:54'),
(126, 7, 152, '2025-08-24', 'absent', '', '2025-08-24 20:34:54', '2025-08-24 20:34:54'),
(127, 7, 129, '2025-08-24', 'absent', '', '2025-08-24 20:34:54', '2025-08-24 20:34:54'),
(128, 7, 36, '2025-08-24', 'absent', '', '2025-08-24 20:34:54', '2025-08-24 20:34:54'),
(129, 7, 135, '2025-08-24', 'absent', '', '2025-08-24 20:34:54', '2025-08-24 20:34:54'),
(130, 7, 22, '2025-08-24', 'absent', '', '2025-08-24 20:34:54', '2025-08-24 20:34:54'),
(131, 7, 130, '2025-08-24', 'absent', '', '2025-08-24 20:34:54', '2025-08-24 20:34:54'),
(132, 3, 37, '2025-08-26', 'present', '', '2025-08-26 06:32:25', '2025-08-26 06:32:25'),
(133, 3, 136, '2025-08-26', 'present', '', '2025-08-26 06:32:25', '2025-08-26 06:32:25'),
(134, 3, 152, '2025-08-26', 'present', '', '2025-08-26 06:32:25', '2025-08-26 06:32:25'),
(135, 3, 129, '2025-08-26', 'present', '', '2025-08-26 06:32:25', '2025-08-26 06:32:25'),
(136, 3, 36, '2025-08-26', 'present', '', '2025-08-26 06:32:25', '2025-08-26 06:32:25'),
(137, 3, 135, '2025-08-26', 'present', '', '2025-08-26 06:32:25', '2025-08-26 06:32:25'),
(138, 3, 22, '2025-08-26', 'present', '', '2025-08-26 06:32:25', '2025-08-26 06:32:25'),
(139, 3, 130, '2025-08-26', 'present', '', '2025-08-26 06:32:25', '2025-08-26 06:32:25'),
(140, 6, 37, '2025-08-26', 'absent', '', '2025-08-26 06:32:30', '2025-08-26 06:32:30'),
(141, 6, 136, '2025-08-26', 'absent', '', '2025-08-26 06:32:30', '2025-08-26 06:32:30'),
(142, 6, 152, '2025-08-26', 'absent', '', '2025-08-26 06:32:30', '2025-08-26 06:32:30'),
(143, 6, 129, '2025-08-26', 'absent', '', '2025-08-26 06:32:30', '2025-08-26 06:32:30'),
(144, 6, 36, '2025-08-26', 'absent', '', '2025-08-26 06:32:30', '2025-08-26 06:32:30'),
(145, 6, 135, '2025-08-26', 'absent', '', '2025-08-26 06:32:30', '2025-08-26 06:32:30'),
(146, 6, 22, '2025-08-26', 'absent', '', '2025-08-26 06:32:30', '2025-08-26 06:32:30'),
(147, 6, 130, '2025-08-26', 'absent', '', '2025-08-26 06:32:30', '2025-08-26 06:32:30'),
(148, 7, 37, '2025-08-26', 'present', '', '2025-08-26 06:32:37', '2025-08-26 06:32:37'),
(149, 7, 136, '2025-08-26', 'present', '', '2025-08-26 06:32:37', '2025-08-26 06:32:37'),
(150, 7, 152, '2025-08-26', 'present', '', '2025-08-26 06:32:37', '2025-08-26 06:32:37'),
(151, 7, 129, '2025-08-26', 'present', '', '2025-08-26 06:32:37', '2025-08-26 06:32:37'),
(152, 7, 36, '2025-08-26', 'present', '', '2025-08-26 06:32:37', '2025-08-26 06:32:37'),
(153, 7, 135, '2025-08-26', 'present', '', '2025-08-26 06:32:37', '2025-08-26 06:32:37'),
(154, 7, 22, '2025-08-26', 'present', '', '2025-08-26 06:32:38', '2025-08-26 06:32:38'),
(155, 7, 130, '2025-08-26', 'present', '', '2025-08-26 06:32:38', '2025-08-26 06:32:38'),
(156, 6, 37, '2025-08-28', 'present', '', '2025-08-28 19:56:44', '2025-08-28 19:56:44'),
(157, 6, 136, '2025-08-28', 'present', '', '2025-08-28 19:56:44', '2025-08-28 19:56:44'),
(158, 6, 152, '2025-08-28', 'present', '', '2025-08-28 19:56:44', '2025-08-28 19:56:44'),
(159, 6, 129, '2025-08-28', 'present', '', '2025-08-28 19:56:44', '2025-08-28 19:56:44'),
(160, 6, 36, '2025-08-28', 'present', '', '2025-08-28 19:56:44', '2025-08-28 19:56:44'),
(161, 6, 135, '2025-08-28', 'present', '', '2025-08-28 19:56:44', '2025-08-28 19:56:44'),
(162, 6, 22, '2025-08-28', 'present', '', '2025-08-28 19:56:44', '2025-08-28 19:56:44'),
(163, 6, 130, '2025-08-28', 'present', '', '2025-08-28 19:56:44', '2025-08-28 19:56:44'),
(164, 7, 37, '2025-08-28', 'present', '', '2025-08-28 19:56:48', '2025-08-28 19:56:48'),
(165, 7, 136, '2025-08-28', 'present', '', '2025-08-28 19:56:48', '2025-08-28 19:56:48'),
(166, 7, 152, '2025-08-28', 'present', '', '2025-08-28 19:56:48', '2025-08-28 19:56:48'),
(167, 7, 129, '2025-08-28', 'present', '', '2025-08-28 19:56:48', '2025-08-28 19:56:48'),
(168, 7, 36, '2025-08-28', 'present', '', '2025-08-28 19:56:48', '2025-08-28 19:56:48'),
(169, 7, 135, '2025-08-28', 'present', '', '2025-08-28 19:56:48', '2025-08-28 19:56:48'),
(170, 7, 22, '2025-08-28', 'present', '', '2025-08-28 19:56:48', '2025-08-28 19:56:48'),
(171, 7, 130, '2025-08-28', 'present', '', '2025-08-28 19:56:48', '2025-08-28 19:56:48'),
(172, 3, 37, '2025-08-28', 'present', '', '2025-08-28 19:56:55', '2025-08-28 19:56:55'),
(173, 3, 136, '2025-08-28', 'present', '', '2025-08-28 19:56:55', '2025-08-28 19:56:55'),
(174, 3, 152, '2025-08-28', 'present', '', '2025-08-28 19:56:55', '2025-08-28 19:56:55'),
(175, 3, 129, '2025-08-28', 'present', '', '2025-08-28 19:56:55', '2025-08-28 19:56:55'),
(176, 3, 36, '2025-08-28', 'present', '', '2025-08-28 19:56:55', '2025-08-28 19:56:55'),
(177, 3, 135, '2025-08-28', 'present', '', '2025-08-28 19:56:55', '2025-08-28 19:56:55'),
(178, 3, 22, '2025-08-28', 'present', '', '2025-08-28 19:56:55', '2025-08-28 19:56:55'),
(179, 3, 130, '2025-08-28', 'present', '', '2025-08-28 19:56:55', '2025-08-28 19:56:55'),
(180, 7, 37, '2025-08-31', 'present', '', '2025-08-31 19:55:16', '2025-08-31 19:55:16'),
(181, 7, 136, '2025-08-31', 'present', '', '2025-08-31 19:55:16', '2025-08-31 19:55:16'),
(182, 7, 152, '2025-08-31', 'present', '', '2025-08-31 19:55:16', '2025-08-31 19:55:16'),
(183, 7, 129, '2025-08-31', 'present', '', '2025-08-31 19:55:16', '2025-08-31 19:55:16'),
(184, 7, 36, '2025-08-31', 'present', '', '2025-08-31 19:55:16', '2025-08-31 19:55:16'),
(185, 7, 135, '2025-08-31', 'present', '', '2025-08-31 19:55:16', '2025-08-31 19:55:16'),
(186, 7, 22, '2025-08-31', 'present', '', '2025-08-31 19:55:16', '2025-08-31 19:55:16'),
(187, 7, 130, '2025-08-31', 'present', '', '2025-08-31 19:55:16', '2025-08-31 19:55:16'),
(188, 7, 37, '2025-09-02', 'present', '', '2025-09-02 19:36:44', '2025-09-02 19:36:44'),
(189, 7, 136, '2025-09-02', 'present', '', '2025-09-02 19:36:44', '2025-09-02 19:36:44'),
(190, 7, 152, '2025-09-02', 'present', '', '2025-09-02 19:36:44', '2025-09-02 19:36:44'),
(191, 7, 129, '2025-09-02', 'present', '', '2025-09-02 19:36:44', '2025-09-02 19:36:44'),
(192, 7, 36, '2025-09-02', 'present', '', '2025-09-02 19:36:44', '2025-09-02 19:36:44'),
(193, 7, 135, '2025-09-02', 'present', '', '2025-09-02 19:36:44', '2025-09-02 19:36:44'),
(194, 7, 22, '2025-09-02', 'present', '', '2025-09-02 19:36:44', '2025-09-02 19:36:44'),
(195, 7, 130, '2025-09-02', 'present', '', '2025-09-02 19:36:44', '2025-09-02 19:36:44'),
(196, 3, 37, '2025-09-02', 'absent', '', '2025-09-02 19:37:54', '2025-09-02 19:37:54'),
(197, 3, 136, '2025-09-02', 'absent', '', '2025-09-02 19:37:54', '2025-09-02 19:37:54'),
(198, 3, 152, '2025-09-02', 'absent', '', '2025-09-02 19:37:54', '2025-09-02 19:37:54'),
(199, 3, 129, '2025-09-02', 'absent', '', '2025-09-02 19:37:54', '2025-09-02 19:37:54'),
(200, 3, 36, '2025-09-02', 'absent', '', '2025-09-02 19:37:54', '2025-09-02 19:37:54'),
(201, 3, 135, '2025-09-02', 'absent', '', '2025-09-02 19:37:54', '2025-09-02 19:37:54'),
(202, 3, 22, '2025-09-02', 'absent', '', '2025-09-02 19:37:54', '2025-09-02 19:37:54'),
(203, 3, 130, '2025-09-02', 'absent', '', '2025-09-02 19:37:54', '2025-09-02 19:37:54'),
(204, 6, 37, '2025-09-02', 'absent', '', '2025-09-02 19:38:41', '2025-09-02 19:38:41'),
(205, 6, 136, '2025-09-02', 'absent', '', '2025-09-02 19:38:41', '2025-09-02 19:38:41'),
(206, 6, 152, '2025-09-02', 'absent', '', '2025-09-02 19:38:41', '2025-09-02 19:38:41'),
(207, 6, 129, '2025-09-02', 'present', '', '2025-09-02 19:38:41', '2025-09-02 19:38:41'),
(208, 6, 36, '2025-09-02', 'absent', '', '2025-09-02 19:38:41', '2025-09-02 19:38:41'),
(209, 6, 135, '2025-09-02', 'absent', '', '2025-09-02 19:38:41', '2025-09-02 19:38:41'),
(210, 6, 22, '2025-09-02', 'absent', '', '2025-09-02 19:38:41', '2025-09-02 19:38:41'),
(211, 6, 130, '2025-09-02', 'absent', '', '2025-09-02 19:38:41', '2025-09-02 19:38:41'),
(220, 6, 37, '2025-09-06', 'present', '', '2025-09-06 13:50:37', '2025-09-06 13:50:37'),
(221, 6, 136, '2025-09-06', 'present', '', '2025-09-06 13:50:37', '2025-09-06 13:50:37'),
(222, 6, 152, '2025-09-06', 'present', '', '2025-09-06 13:50:37', '2025-09-06 13:50:37'),
(223, 6, 129, '2025-09-06', 'present', '', '2025-09-06 13:50:37', '2025-09-06 13:50:37'),
(224, 6, 36, '2025-09-06', 'present', '', '2025-09-06 13:50:37', '2025-09-06 13:50:37'),
(225, 6, 135, '2025-09-06', 'present', '', '2025-09-06 13:50:37', '2025-09-06 13:50:37'),
(226, 6, 22, '2025-09-06', 'present', '', '2025-09-06 13:50:37', '2025-09-06 13:50:37'),
(227, 6, 130, '2025-09-06', 'present', '', '2025-09-06 13:50:37', '2025-09-06 13:50:37'),
(228, 3, 37, '2025-09-06', 'present', '', '2025-09-06 13:50:53', '2025-09-06 13:50:53'),
(229, 3, 136, '2025-09-06', 'present', '', '2025-09-06 13:50:53', '2025-09-06 13:50:53'),
(230, 3, 152, '2025-09-06', 'present', '', '2025-09-06 13:50:53', '2025-09-06 13:50:53'),
(231, 3, 129, '2025-09-06', 'present', '', '2025-09-06 13:50:53', '2025-09-06 13:50:53'),
(232, 3, 36, '2025-09-06', 'present', '', '2025-09-06 13:50:53', '2025-09-06 13:50:53'),
(233, 3, 135, '2025-09-06', 'present', '', '2025-09-06 13:50:53', '2025-09-06 13:50:53'),
(234, 3, 22, '2025-09-06', 'present', '', '2025-09-06 13:50:53', '2025-09-06 13:50:53'),
(235, 3, 130, '2025-09-06', 'present', '', '2025-09-06 13:50:53', '2025-09-06 13:50:53'),
(236, 7, 37, '2025-09-06', 'absent', '', '2025-09-06 20:42:59', '2025-09-06 20:42:59'),
(237, 7, 136, '2025-09-06', 'present', '', '2025-09-06 20:42:59', '2025-09-06 20:42:59'),
(238, 7, 152, '2025-09-06', 'present', '', '2025-09-06 20:42:59', '2025-09-06 20:42:59'),
(239, 7, 129, '2025-09-06', 'present', '', '2025-09-06 20:42:59', '2025-09-06 20:42:59'),
(240, 7, 36, '2025-09-06', 'present', '', '2025-09-06 20:42:59', '2025-09-06 20:42:59'),
(241, 7, 135, '2025-09-06', 'present', '', '2025-09-06 20:42:59', '2025-09-06 20:42:59'),
(242, 7, 22, '2025-09-06', 'present', '', '2025-09-06 20:42:59', '2025-09-06 20:42:59'),
(243, 7, 130, '2025-09-06', 'present', '', '2025-09-06 20:42:59', '2025-09-06 20:42:59');

--
-- Triggers `attendance`
--
DELIMITER $$
CREATE TRIGGER `check_attendance_status` BEFORE INSERT ON `attendance` FOR EACH ROW BEGIN
    IF NEW.status NOT IN ('present', 'absent', 'late', 'excused') THEN
        SET NEW.status = 'absent';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `batch`
--

CREATE TABLE `batch` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `program_id` int(11) DEFAULT NULL,
  `year` varchar(10) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `batch`
--

INSERT INTO `batch` (`id`, `name`, `program_id`, `year`, `start_date`, `end_date`, `status`, `created_at`, `updated_at`) VALUES
(2, 'MIT0201', 1, '2024', '2024-09-01', '2026-08-31', 'active', '2025-05-08 16:48:23', '2025-08-24 19:48:23'),
(3, 'MPH0201', 3, '2025', '2025-09-01', '2027-08-31', 'active', '2025-05-08 17:44:54', '2025-07-29 21:06:49'),
(4, 'MSE0210', 4, '2024', '2025-09-01', '2027-08-31', 'active', '2025-05-08 17:49:58', '2025-07-29 21:05:28'),
(7, 'MPCH0210', 9, '2026', '2025-09-01', '2027-08-31', 'active', '2025-07-29 17:59:05', '2025-07-31 09:27:16'),
(8, 'MIM0201', 2, '2024', '0206-09-01', '0208-08-31', 'active', '2025-07-29 21:03:08', '2025-07-29 21:03:24'),
(10, 'MIT0202', 1, '2025', '2025-09-01', '2027-08-31', 'active', '2025-08-08 17:33:31', NULL),
(11, 'Msd0201', 11, '2030', '2029-09-01', '2031-08-31', 'active', '2025-08-11 06:52:49', '2025-08-11 06:53:19'),
(13, 'MME0201', 12, '2025', '2025-09-01', '2027-08-31', 'active', '2025-08-13 08:33:46', NULL),
(16, 'MIM0202', 2, '2029', '2029-09-01', '2031-08-31', 'active', '2025-09-03 18:33:35', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `attachment_path` varchar(255) DEFAULT NULL,
  `attachment_mime_type` varchar(100) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chats`
--

INSERT INTO `chats` (`id`, `sender_id`, `receiver_id`, `message`, `attachment_path`, `attachment_mime_type`, `is_read`, `created_at`) VALUES
(1, 48, 135, 'asc', NULL, NULL, 0, '2025-08-03 10:47:16'),
(2, 48, 129, 'asc nalka waxa kuso diray chpater 1 aqri', 'uploads/chat_attachments/chat_688f15f8abb74.pdf', 'application/pdf', 1, '2025-08-03 10:55:36'),
(3, 129, 48, 'wcs eng waad mahadsan thy', NULL, NULL, 1, '2025-08-03 10:56:34'),
(4, 129, 3, 'asc', NULL, NULL, 0, '2025-08-04 20:16:34'),
(5, 129, 1, 'asc', NULL, NULL, 0, '2025-08-04 20:16:42'),
(6, 129, 1, 'yea', NULL, NULL, 0, '2025-08-04 20:16:50'),
(7, 135, 48, 'wcs', NULL, NULL, 1, '2025-08-05 09:26:49'),
(8, 129, 48, 'good morning', NULL, NULL, 1, '2025-08-13 08:56:33'),
(9, 129, 48, 'hello', NULL, NULL, 1, '2025-08-13 10:52:30'),
(10, 48, 129, 'heello2', NULL, NULL, 1, '2025-08-13 10:53:41'),
(11, 48, 129, '', 'uploads/chat_attachments/chat_689c44900d726.pdf', 'application/pdf', 1, '2025-08-13 10:53:52'),
(12, 48, 129, 'asc', NULL, NULL, 1, '2025-08-21 19:10:57'),
(13, 48, 136, 'asc', NULL, NULL, 1, '2025-08-21 19:16:04'),
(14, 48, 22, 'waryaaa sadq', NULL, NULL, 1, '2025-08-21 19:19:41'),
(15, 22, 48, 'hee macalin', NULL, NULL, 1, '2025-08-21 20:14:56'),
(16, 48, 22, 'lax matahay', NULL, NULL, 1, '2025-08-21 20:15:25'),
(17, 129, 48, 'wow', NULL, NULL, 1, '2025-09-02 19:22:38'),
(18, 129, 48, 'asc', NULL, NULL, 1, '2025-09-02 19:23:30'),
(19, 48, 129, 'wcs', NULL, NULL, 1, '2025-09-02 19:24:04'),
(20, 48, 129, 'yeah', NULL, NULL, 1, '2025-09-02 19:25:25'),
(21, 48, 129, 'yes', NULL, NULL, 1, '2025-09-02 19:42:01');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(11) NOT NULL,
  `program_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `code` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `credit_hours` int(11) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `instructor_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `program_id`, `department_id`, `semester_id`, `code`, `name`, `credit_hours`, `description`, `status`, `created_at`, `updated_at`, `batch_id`, `instructor_id`) VALUES
(2, 3, 2, 2, 'CS102', 'SQL', 2, 'nm', 'active', '2025-05-10 20:22:09', '2025-08-01 09:48:32', 3, 3),
(3, 1, 1, 7, 'CS106', 'JavaScript', 3, '.', 'active', '2025-07-31 21:22:50', '2025-08-09 19:25:00', 2, 48),
(4, 4, 1, 7, 'CS104', 'oracle', 3, 'nb', 'active', '2025-08-04 21:17:29', '2025-08-13 09:21:28', 4, 48),
(5, 1, 1, 7, 'DS105', 'Data Structure', 3, 'aaa', 'active', '2025-08-08 17:35:02', '2025-08-09 20:14:50', 10, 48),
(6, 1, 1, 7, 'CS107', 'Html', 2, '', 'active', '2025-08-09 18:25:01', '2025-08-13 08:53:02', 2, 48),
(7, 1, 1, 2, 'CS108', 'Database Systems', 4, 'aa', 'active', '2025-08-09 18:27:52', NULL, 2, 48),
(8, 12, 13, 7, 'ME101', 'Principles of Marketing', 3, 'zz', 'active', '2025-08-13 08:34:36', NULL, 13, 48),
(9, 12, 13, 7, 'ME102', 'FINANCE', 3, 'ZAA', 'active', '2025-08-13 10:36:14', NULL, 13, 48),
(10, 1, 1, 1, 'hhd', 'jkjk', 5, 'm', 'active', '2025-09-03 18:30:53', NULL, 2, 48),
(11, 3, 2, 1, 'jjh', 'sss4', 3, 'xx', 'active', '2025-09-03 20:08:48', NULL, 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `course_materials`
--

CREATE TABLE `course_materials` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `material_type` varchar(50) DEFAULT NULL,
  `file_path` varchar(255) NOT NULL,
  `uploaded_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course_materials`
--

INSERT INTO `course_materials` (`id`, `course_id`, `title`, `description`, `material_type`, `file_path`, `uploaded_by`, `created_at`, `updated_at`) VALUES
(2, 2, 'lesson', 'asssghx', 'video', 'uploads/materials/6886fe53ac90e_WhatsApp Video 2025-02-03 at 17.38.03_fbf164be.mp4', 3, '2025-07-28 07:36:35', NULL),
(3, 3, 'rwe', 'hjhds', 'document', 'uploads/materials/688c4179ce271_Subnetting Practice Scenario – FLSM (Fixed Length Subnet Masking).pdf', 48, '2025-07-31 21:24:25', NULL),
(4, 6, 'jj', 'nn', 'video', 'uploads/materials/689c28be99283_pro2.mp4', 48, '2025-08-13 08:55:10', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(10) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`, `code`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Computer Sceinces', 'SC', '?', 'active', '2025-05-08 16:48:23', '2025-08-12 22:12:57'),
(2, 'Health Sciences', 'HS', '??', 'active', '2025-05-08 16:48:23', '2025-08-04 20:24:06'),
(5, 'Medicine', 'MED', '??', 'active', '2025-05-08 16:48:23', '2025-07-29 20:14:08'),
(13, 'Economic', 'EC', 's', 'active', '2025-08-13 08:32:05', NULL),
(14, 'Finance and Accounting', 'fa', 's', 'active', '2025-08-13 10:28:45', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `enrollment`
--

CREATE TABLE `enrollment` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `program_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `student_id` varchar(20) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `enrollment`
--

INSERT INTO `enrollment` (`id`, `user_id`, `program_id`, `department_id`, `batch_id`, `student_id`, `created_at`, `updated_at`, `course_id`) VALUES
(33, 22, 1, 1, 2, 'MIT0201003', '2025-07-29 21:34:20', NULL, 3),
(50, 36, 1, 1, 2, 'MIT0201004', '2025-07-29 23:04:08', NULL, 3),
(51, 37, 2, 5, 8, 'MCSHS00001', '2025-07-30 21:29:53', NULL, 3),
(142, 129, 1, 1, 2, 'MIT0201006', '2025-07-31 10:17:35', NULL, 3),
(143, 130, 1, 1, 2, 'MIT0201005', '2025-07-31 10:25:12', NULL, 3),
(148, 135, 2, 5, 8, 'MIM0201001', '2025-07-31 18:52:41', NULL, 3),
(149, 136, 1, 1, 10, 'MIT0201001', '2025-07-31 19:22:21', NULL, 3),
(151, 138, 11, 5, 11, 'Msd0201001', '2025-08-08 17:37:44', NULL, NULL),
(152, 146, 11, 5, 11, 'Msd0201002', '2025-08-11 08:10:52', NULL, NULL),
(154, 150, 4, 1, 4, 'MSE0210001', '2025-08-13 09:15:56', NULL, 4),
(156, 152, 1, 1, 2, 'MIT0201002', '2025-08-13 19:29:22', NULL, 3),
(157, 154, 2, 5, 8, 'MIM0201002', '2025-08-25 21:37:42', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `instructors`
--

CREATE TABLE `instructors` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `specialization` varchar(100) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `instructors`
--

INSERT INTO `instructors` (`id`, `user_id`, `specialization`, `qualification`, `created_at`, `updated_at`) VALUES
(1, 3, 'Not specified', 'Not specified', '2025-05-08 17:56:44', NULL),
(2, 48, 'Computer sceince', 'master computer sceince', '2025-08-03 09:58:32', '2025-08-03 10:21:06'),
(3, 153, 'wow', '', '2025-08-21 08:03:48', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `instructor_notifications`
--

CREATE TABLE `instructor_notifications` (
  `id` int(11) NOT NULL,
  `instructor_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','success','warning','error') DEFAULT 'info',
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `instructor_notifications`
--

INSERT INTO `instructor_notifications` (`id`, `instructor_id`, `title`, `message`, `type`, `is_read`, `created_at`) VALUES
(1, 48, 'Welcome to the Instructor Portal', 'Welcome to your instructor dashboard! Here you can manage your courses, assessments, and track student progress.', 'info', 1, '2025-08-13 04:12:29'),
(2, 48, 'Assessment Reminder', 'Don\'t forget to review and grade the recent assessments submitted by your students.', 'warning', 1, '2025-08-13 04:12:29'),
(3, 48, 'Course Material Updated', 'Your course materials have been successfully updated and are now available to students.', 'success', 1, '2025-08-13 04:12:29'),
(4, 48, 'Student Enrollment Alert', 'New students have been enrolled in your courses. Please review the updated class rosters.', 'info', 1, '2025-08-13 04:12:29');

-- --------------------------------------------------------

--
-- Table structure for table `live_classes`
--

CREATE TABLE `live_classes` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `instructor_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `scheduled_time` datetime NOT NULL,
  `duration` int(11) NOT NULL DEFAULT 60,
  `platform` enum('zoom','teams','meet','bbb','other') NOT NULL DEFAULT 'zoom',
  `meeting_url` text DEFAULT NULL,
  `meeting_id` varchar(255) DEFAULT NULL,
  `passcode` varchar(255) DEFAULT NULL,
  `status` enum('scheduled','live','completed','cancelled') NOT NULL DEFAULT 'scheduled',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `live_classes`
--

INSERT INTO `live_classes` (`id`, `course_id`, `instructor_id`, `title`, `description`, `scheduled_time`, `duration`, `platform`, `meeting_url`, `meeting_id`, `passcode`, `status`, `created_at`, `updated_at`) VALUES
(1, 3, 48, 'hhhh', 'ass', '2025-08-01 15:17:00', 60, 'meet', 'https://meet.google.com/xyz-abcd-efg', 'xyz-abcd-efg', '123456', 'completed', '2025-08-01 08:17:45', '2025-08-01 16:11:51'),
(2, 3, 48, 'lesson', 'waaw', '2025-08-01 18:20:00', 60, 'meet', 'https://meet.google.com/xyz-abcd-efg', 'xyz-abcd-efg', '123456', 'completed', '2025-08-01 14:20:44', '2025-08-02 15:47:06'),
(3, 3, 48, 'l11', 'ss', '2025-08-01 19:35:00', 60, 'meet', 'https://meet.google.com/xyz-abcd-efg', 'xyz-abcd-efg', '123456', 'cancelled', '2025-08-01 16:33:59', '2025-08-01 17:02:04'),
(4, 3, 48, 'l2', 'nn', '2025-08-01 20:08:00', 60, 'zoom', 'https://us02web.zoom.us/j/1234567890?pwd=abcdEfghIjklMnopQRstuVwxyz123456', '123 456 7890', '987654', 'completed', '2025-08-01 17:05:29', '2025-08-02 15:47:06'),
(5, 6, 48, 'sdd', 'sss', '2025-08-13 09:05:00', 60, 'meet', 'https://meet.google.com/xyz-abcd-efg', 'xyz-abcd-efg', '123456', 'completed', '2025-08-13 06:01:20', '2025-08-13 07:51:42'),
(6, 3, 48, 'hh', 'hhh', '2025-08-13 09:08:00', 60, 'meet', 'https://meet.google.com/xyz-abcd-efg', 'xyz-abcd-efg', '123456', 'completed', '2025-08-13 06:03:16', '2025-08-13 07:51:42'),
(7, 3, 48, 'sa', 'jj', '2025-08-13 10:54:00', 60, 'zoom', 'https://meet.google.com/xyz-abcd-efg', 'xyz-abcd-efg', '123456', 'completed', '2025-08-13 07:50:47', '2025-08-13 16:50:12'),
(8, 6, 48, 'yahu', '', '2025-08-21 19:33:00', 60, 'meet', 'https://meet.google.com/xyz-abcd-efg', 'xyz-abcd-efg', '123456', 'completed', '2025-08-21 15:33:20', '2025-08-23 16:19:27'),
(9, 6, 48, 'yahu', '', '2025-08-21 19:33:00', 60, 'meet', 'https://meet.google.com/xyz-abcd-efg', 'xyz-abcd-efg', '123456', 'completed', '2025-08-21 15:33:46', '2025-08-23 16:19:27'),
(10, 7, 48, '2', 'dd', '2025-08-21 20:33:00', 60, 'zoom', 'https://us02web.zoom.us/j/1234567890?pwd=abcdEfghIjklMnopQRstuVwxyz123456', '123 456 7890', '123456', 'completed', '2025-08-21 15:34:51', '2025-08-23 16:19:27');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('general','academic','event','urgent','maintenance') DEFAULT 'general',
  `priority` enum('low','medium','high') DEFAULT 'medium',
  `target_audience` enum('all','students','instructors') NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_read` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `title`, `message`, `type`, `priority`, `target_audience`, `is_active`, `created_by`, `created_at`, `updated_at`, `is_read`) VALUES
(1, 'Welcome to Benadir LMS', 'Welcome to our new Learning Management System. Please explore the features and let us know if you have any questions.', 'general', 'medium', 'all', 0, 1, '2025-05-25 18:34:08', '2025-05-25 18:42:25', 0),
(2, 'System Maintenance Notice', 'The system will be under maintenance on Sunday from 2:00 AM to 4:00 AM. Please save your work before this time.', 'maintenance', 'high', 'all', 0, 1, '2025-05-25 18:34:08', '2025-05-25 18:42:06', 0),
(3, 'New Course Registration Open', 'Registration for the new semester courses is now open. Please register before the deadline.', 'academic', 'medium', 'students', 1, 1, '2025-05-25 18:34:08', '2025-08-02 16:40:12', 1),
(4, 'jbj', 'njnjhbjb gyvtfcrdr', 'maintenance', 'high', 'all', 1, 1, '2025-05-25 18:42:58', '2025-08-02 16:40:04', 1),
(5, 'Welcome to Benadir LMS', 'Welcome to our new Learning Management System. Please explore the features and let us know if you have any questions.', 'general', 'medium', 'all', 1, 1, '2025-05-26 17:55:41', '2025-08-02 16:40:02', 1),
(6, 'System Maintenance Notice', 'The system will be under maintenance on Sunday from 2:00 AM to 4:00 AM. Please save your work before this time.', 'maintenance', 'high', 'all', 1, 1, '2025-05-26 17:55:41', '2025-08-02 16:40:07', 1),
(7, 'New Course Registration Open', 'Registration for the new semester courses is now open. Please register before the deadline.', 'academic', 'medium', 'students', 1, 1, '2025-05-26 17:55:41', '2025-08-02 16:39:59', 1),
(8, 'mn xjc jsbds', 'abuhqwbduqwdyqwd', 'academic', 'medium', 'students', 1, 1, '2025-05-26 17:58:01', '2025-08-01 07:36:34', 1),
(9, 'mn xjc jsbds', 'abuhqwbduqwdyqwd', 'academic', 'medium', 'students', 1, 1, '2025-05-26 18:03:35', '2025-08-02 16:39:45', 1),
(10, 'mn xjc jsbds', 'abuhqwbduqwdyqwd', 'academic', 'medium', 'students', 1, 1, '2025-05-26 18:10:39', '2025-08-02 16:39:48', 1),
(11, 'sss', 'ssssssssssssssssssss', 'maintenance', 'high', 'all', 1, 1, '2025-05-26 18:11:12', '2025-08-02 16:39:56', 1),
(12, 'vf', 'cdda', 'urgent', 'high', 'all', 1, 1, '2025-06-02 07:26:50', '2025-08-02 16:39:53', 1),
(13, 'fasax gaaban', 'wa run', 'academic', 'high', 'students', 1, 1, '2025-08-01 15:24:25', '2025-08-01 15:24:49', 1),
(14, 'fasax goban', 'sabti ila jimco', 'general', 'high', 'all', 1, 1, '2025-08-13 05:58:01', '2025-08-13 05:58:59', 1);

-- --------------------------------------------------------

--
-- Table structure for table `online_status`
--

CREATE TABLE `online_status` (
  `user_id` int(11) NOT NULL,
  `is_online` tinyint(1) DEFAULT 1,
  `last_seen` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `online_status`
--

INSERT INTO `online_status` (`user_id`, `is_online`, `last_seen`) VALUES
(22, 1, '2025-08-21 17:16:26'),
(48, 1, '2025-09-06 10:40:54'),
(129, 1, '2025-09-06 10:46:36'),
(136, 1, '2025-09-06 17:53:25');

-- --------------------------------------------------------

--
-- Table structure for table `programs`
--

CREATE TABLE `programs` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(10) NOT NULL,
  `description` text DEFAULT NULL,
  `duration` varchar(50) DEFAULT NULL,
  `monthly_fee` decimal(10,2) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `programs`
--

INSERT INTO `programs` (`id`, `name`, `code`, `description`, `duration`, `monthly_fee`, `status`, `created_at`, `updated_at`, `department_id`) VALUES
(1, 'Master of Information Technology', 'MIT', 'Advanced degree program in IT', '3 years', '300.00', 'active', '2025-05-08 16:48:23', '2025-09-03 21:19:25', 1),
(2, 'Master of Internal Medicine', 'MIM', '?', NULL, NULL, 'active', '2025-05-08 16:48:23', '2025-07-29 20:24:21', 5),
(3, 'Master of Public Health', 'MPH', 'Advanced degree program in Public Healths', NULL, NULL, 'active', '2025-05-08 16:48:23', '2025-07-29 20:25:25', 2),
(4, 'Master of Software Engineering', 'MSE', '?', '2 Years', NULL, 'active', '2025-05-08 19:38:51', '2025-07-29 20:22:39', 1),
(9, 'Master of Pediatrics and Child Health', 'MPCH', '?', NULL, NULL, 'active', '2025-07-29 20:25:59', NULL, 5),
(11, 'sdj', 'sd', '?', NULL, NULL, 'active', '2025-07-31 19:27:02', '2025-07-31 19:27:14', 5),
(12, 'Master of  marketing ecomics', 'ME', 'ss', NULL, NULL, 'active', '2025-08-13 08:33:20', NULL, 13),
(13, 'master of artificial intelegiance', 'ai', 'sss', NULL, NULL, 'active', '2025-08-13 10:29:39', NULL, 14);

-- --------------------------------------------------------

--
-- Table structure for table `program_fee_history`
--

CREATE TABLE `program_fee_history` (
  `id` int(11) NOT NULL,
  `program_id` int(11) NOT NULL,
  `old_fee` decimal(10,2) DEFAULT NULL,
  `new_fee` decimal(10,2) DEFAULT NULL,
  `changed_by` int(11) NOT NULL,
  `changed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `reason` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `program_fee_history`
--

INSERT INTO `program_fee_history` (`id`, `program_id`, `old_fee`, `new_fee`, `changed_by`, `changed_at`, `reason`) VALUES
(2, 1, NULL, '300.00', 1, '2025-09-03 18:19:25', 'Fee updated via admin panel');

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `id` int(11) NOT NULL,
  `academic_year_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`id`, `academic_year_id`, `name`, `start_date`, `end_date`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'Fall', '2023-09-01', '2023-12-31', 'inactive', '2025-05-08 16:48:23', NULL),
(2, 1, 'Spring', '2024-01-01', '2024-04-30', 'inactive', '2025-05-08 16:48:23', NULL),
(4, 2, 'Summer', '2024-09-08', '2025-05-08', 'inactive', '2025-05-08 19:57:33', NULL),
(7, 1, 'summer 23', '2025-08-15', '2026-02-09', 'active', '0000-00-00 00:00:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `degree_document` varchar(255) NOT NULL,
  `mother_name` varchar(100) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `place_of_birth` varchar(100) DEFAULT NULL,
  `nationality` varchar(50) DEFAULT NULL,
  `marital_status` enum('Single','Married') DEFAULT NULL,
  `bachelor_institution` varchar(100) DEFAULT NULL,
  `bachelor_specialization` varchar(100) DEFAULT NULL,
  `bachelor_location` varchar(100) DEFAULT NULL,
  `bachelor_year` year(4) DEFAULT NULL,
  `application_type` enum('First Year','Transfer') DEFAULT NULL,
  `language_of_instruction` enum('English','Arabic','Other') DEFAULT NULL,
  `emergency_contact_name` varchar(100) DEFAULT NULL,
  `parent_associated_with_uni` tinyint(1) DEFAULT 0,
  `parent_name` varchar(100) DEFAULT NULL,
  `declaration_signed` tinyint(1) DEFAULT 1,
  `status` enum('active','inactive','graduated','dead','transfer') NOT NULL DEFAULT 'active',
  `previous_batch_id` int(11) DEFAULT NULL,
  `transfer_date` datetime DEFAULT NULL,
  `status_changed_at` datetime DEFAULT NULL,
  `status_changed_by` int(11) DEFAULT NULL,
  `registration_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `user_id`, `degree_document`, `mother_name`, `date_of_birth`, `place_of_birth`, `nationality`, `marital_status`, `bachelor_institution`, `bachelor_specialization`, `bachelor_location`, `bachelor_year`, `application_type`, `language_of_instruction`, `emergency_contact_name`, `parent_associated_with_uni`, `parent_name`, `declaration_signed`, `status`, `previous_batch_id`, `transfer_date`, `status_changed_at`, `status_changed_by`, `registration_date`, `created_at`, `updated_at`) VALUES
(17, 22, '../uploads/documents/22_1753814060_chapter22.pdf', 'Fradowzo salaad farah', '1999-07-29', 'Hargeisa', 'somalia', 'Single', 'somalia university', 'Computer sceince', 'mogadisho', 2019, 'First Year', 'English', 'luul', 0, '', 1, 'active', NULL, NULL, '2025-09-03 20:42:54', NULL, '2025-07-29 18:34:20', '2025-07-29 21:34:20', '2025-08-13 19:32:48'),
(18, 36, '../uploads/documents/36_1753819448_cv tariikh nololeedka.pdf', 'Halimo cabdi sakariye', '1999-07-29', 'Hargeisa', 'somalia', 'Single', 'somalia university', 'Computer sceince', 'mogadisho', 2025, 'First Year', 'English', '666655', 0, '', 1, 'active', NULL, NULL, '2025-09-03 20:42:54', NULL, '2025-07-29 20:04:08', '2025-07-29 23:04:08', '2025-08-13 19:33:08'),
(19, 37, '../uploads/documents/1753900193_Ch22_Natural_Language_Processing.pdf', 'Halimo cabdi sakariye', '2000-07-24', 'Hargeisa', 'somalia', 'Single', 'somalia university', 'medicine', 'mogadisho', 2019, 'First Year', 'Arabic', 'luul', 0, '', 1, 'active', NULL, NULL, '2025-09-03 20:42:54', NULL, '2025-07-30 18:29:53', '2025-07-30 21:29:53', '2025-08-12 21:27:24'),
(20, 129, '../uploads/documents/1753946255_Birth and Death System (2).pdf', 'Halimo cabdi sakariye', '2000-08-01', 'Hargeisa', 'somalia', 'Single', 'benadir university', 'Computer sceince', 'mogadisho', 2022, 'First Year', 'English', 'luul', 0, '', 1, 'active', NULL, NULL, '2025-09-03 20:42:54', NULL, '2025-07-31 07:17:35', '2025-07-31 10:17:35', '2025-08-24 20:33:43'),
(21, 130, '../uploads/documents/130_1753946712_Birth and Death System (2).pdf', 'Fradowzo salaad farah', '2000-07-22', 'Hargeisa', 'somalia', 'Single', 'somalia university', 'finance', 'mogadisho', 2025, 'First Year', 'English', 'luul', 0, '', 1, 'graduated', NULL, NULL, '2025-09-03 21:38:06', 1, '2025-07-31 07:25:12', '2025-07-31 10:25:12', '2025-09-03 21:38:06'),
(24, 135, '../uploads/documents/135_1754013161_Session 2 CISCO CLI AND BOOT SEQUENCES extra.pdf', 'xamdi', '2000-02-22', 'mogdisho', 'somalia', 'Single', 'jhhs', 'sjha', 'jsaj', 2024, 'First Year', 'English', 'Nasteho Jelle', 0, '', 1, 'active', NULL, NULL, '2025-09-03 20:42:54', NULL, '2025-08-01 01:52:41', '2025-07-31 18:52:41', '2025-08-12 21:45:05'),
(25, 136, '../uploads/documents/136_1754014941_Subnetting Practice Scenario – FLSM (Fixed Length Subnet Masking).pdf', 'luul', '2000-02-22', 'mog', 'soma', 'Single', 'jfef', 'jsdj', 'jjs', 2024, 'First Year', 'English', 'najs', 0, '', 1, 'transfer', 2, '2025-09-03 20:55:09', '2025-09-03 20:55:09', 1, '2025-08-01 02:22:21', '2025-07-31 19:22:21', '2025-09-03 20:55:09'),
(27, 138, '../uploads/documents/138_1754663864_Ch22_Natural_Language_Processing.pdf', 'Halimo cabdi sakariye', '2000-08-08', 'Hargeisa', 'somalia', 'Married', 'benadir university', 'Computer sceince', 'mogadisho', 2019, 'First Year', 'English', 'luul', 0, '', 1, 'active', NULL, NULL, '2025-09-03 20:42:54', NULL, '2025-08-08 14:37:44', '2025-08-08 17:37:44', '2025-08-11 07:31:43'),
(35, 146, '../uploads/documents/1754889052_prac.pdf', 'Halimo cabdi sakariye', '1999-08-11', 'Hargeisa', 'somalia', 'Single', 'somalia university', 'medicine', 'mogadisho', 2025, 'First Year', 'Arabic', 'nn', 0, '', 1, 'active', NULL, NULL, '2025-09-03 20:42:54', NULL, '2025-08-11 05:10:52', '2025-08-11 08:10:52', NULL),
(37, 150, '../uploads/documents/1755065756_Ch22_Natural_Language_Processing.pdf', 'maami salaad farah', '2000-08-13', 'Hargeisa', 'somalia', 'Single', 'somalia university', 'Computer sceince', 'mogadisho', 2019, 'Transfer', 'Arabic', 'hh', 0, '', 1, 'active', NULL, NULL, '2025-09-03 20:42:54', NULL, '2025-08-13 06:15:56', '2025-08-13 09:15:56', '2025-08-13 19:25:56'),
(39, 152, '../uploads/documents/1755102561_Ch22_Natural_Language_Processing.pdf', 'Fradowzo salaad farah', '2000-08-13', 'Hargeisa', 'somalia', 'Single', 'somalia university', 'Computer sceince', 'mogadisho', 2025, 'First Year', 'English', 'luul', 0, '', 1, 'dead', NULL, NULL, '2025-09-03 20:51:30', 1, '2025-08-13 16:29:22', '2025-08-13 19:29:22', '2025-09-03 20:51:30'),
(40, 154, '../uploads/documents/1756147062_A.DHEERE ..damaanad.pdf', 'maami salaad farah', '2000-08-25', 'Hargeisa', 'somalia', 'Married', 'somalia university', 'medicine', 'mogadisho', 2019, 'Transfer', 'English', 'ff', 0, '', 1, 'active', NULL, NULL, '2025-09-03 20:42:54', NULL, '2025-08-25 18:37:42', '2025-08-25 21:37:42', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `student_answers`
--

CREATE TABLE `student_answers` (
  `id` int(11) NOT NULL,
  `assessment_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `answer_text` text DEFAULT NULL,
  `marks_obtained` decimal(5,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_answers`
--

INSERT INTO `student_answers` (`id`, `assessment_id`, `student_id`, `question_id`, `answer_text`, `marks_obtained`, `created_at`, `updated_at`) VALUES
(1, 32, 129, 24, 'True', '20.00', '2025-08-08 05:26:27', '2025-08-08 05:26:27'),
(2, 32, 129, 25, 'True', '10.00', '2025-08-08 05:26:27', '2025-08-08 05:26:27'),
(3, 33, 129, 26, 'True', '0.00', '2025-08-08 16:03:49', '2025-08-08 16:03:49'),
(4, 33, 129, 27, 'True', '0.00', '2025-08-08 16:03:49', '2025-08-08 16:03:49'),
(5, 33, 138, 26, 'True', '0.00', '2025-08-08 16:04:55', '2025-08-08 16:04:55'),
(6, 33, 138, 27, 'True', '0.00', '2025-08-08 16:04:55', '2025-08-08 16:04:55'),
(7, 34, 136, 28, 'True', '30.00', '2025-08-08 16:09:16', '2025-08-08 16:09:16'),
(8, 35, 129, 29, 'True', '30.00', '2025-08-09 06:02:47', '2025-08-09 06:02:47'),
(9, 35, 136, 31, 'C', '0.00', '2025-08-09 06:04:48', '2025-08-09 06:04:48'),
(10, 35, 136, 32, 'waaa dad laxa', '2.00', '2025-08-09 06:04:48', '2025-08-09 06:04:48'),
(11, 35, 138, 30, 'True', '30.00', '2025-08-09 06:05:42', '2025-08-09 06:05:42'),
(12, 36, 136, 34, 'waa database camal', '28.00', '2025-08-09 17:40:30', '2025-08-09 17:40:30'),
(13, 36, 129, 33, 'True', '0.00', '2025-08-09 17:41:04', '2025-08-09 17:41:04'),
(14, 37, 129, 35, 'True', '30.00', '2025-08-13 05:46:39', '2025-08-13 05:46:39'),
(15, 37, 136, 35, 'False', '0.00', '2025-08-13 05:47:48', '2025-08-13 05:47:48'),
(16, 37, 130, 35, 'True', '30.00', '2025-08-13 05:48:24', '2025-08-13 05:48:24'),
(17, 38, 129, 37, 'True', '30.00', '2025-08-13 07:48:37', '2025-08-13 07:48:37');

-- --------------------------------------------------------

--
-- Table structure for table `thesis`
--

CREATE TABLE `thesis` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `program_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `academic_year_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `submission_settings_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `abstract` text DEFAULT NULL,
  `keywords` varchar(500) DEFAULT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_type` enum('pdf','doc','docx') NOT NULL,
  `file_size` int(11) NOT NULL,
  `file_hash` varchar(64) DEFAULT NULL,
  `submission_date` datetime NOT NULL,
  `status` enum('pending','under_review','approved','rejected','revision_required') NOT NULL DEFAULT 'pending',
  `supervisor_id` int(11) DEFAULT NULL,
  `assigned_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `thesis`
--

INSERT INTO `thesis` (`id`, `student_id`, `program_id`, `department_id`, `academic_year_id`, `semester_id`, `submission_settings_id`, `title`, `abstract`, `keywords`, `file_path`, `file_type`, `file_size`, `file_hash`, `submission_date`, `status`, `supervisor_id`, `assigned_by`, `created_at`, `updated_at`) VALUES
(1, 129, 1, 1, 1, 7, NULL, 'proposal', 'jdbjhdbjhbbx n', 'sd', 'uploads/thesis/thesis_129_1755968863.pdf', 'pdf', 50132, NULL, '2025-08-23 20:07:43', 'approved', 48, 1, '2025-08-23 20:07:43', '2025-08-23 20:14:39'),
(2, 129, 1, 1, 1, 7, NULL, 'proposal 2', 'sss44', 'ss', 'uploads/thesis/thesis_129_1755972620.pdf', 'pdf', 50132, NULL, '2025-08-23 21:10:20', 'rejected', 48, 1, '2025-08-23 21:10:20', '2025-08-23 21:16:51'),
(3, 129, 1, 1, 1, 7, NULL, 'test_proposal', 'hhhs', 'zz', 'uploads/thesis/thesis_129_1756013336.pdf', 'pdf', 50132, NULL, '2025-08-24 08:28:56', 'approved', 48, 1, '2025-08-24 08:28:56', '2025-08-24 09:31:47'),
(4, 129, 1, 1, 1, 7, NULL, 't1', 'smsjhbdussss', 'ss', 'uploads/thesis/thesis_129_1756013764.pdf', 'pdf', 249616, NULL, '2025-08-24 08:36:04', 'approved', 48, 1, '2025-08-24 08:36:04', '2025-08-24 09:29:45'),
(5, 136, 1, 1, 1, 7, 1, 'jknj', 'ss', 'ss', 'uploads/thesis/thesis_136_1756142407.pdf', 'pdf', 50132, '3239c25c64b7e8e0ee63b8197409724b2203e4cee6751fc6885507dbee60cc95', '2025-08-25 20:20:07', 'approved', 48, 1, '2025-08-25 20:20:07', '2025-08-25 20:21:19');

-- --------------------------------------------------------

--
-- Table structure for table `thesis_committee`
--

CREATE TABLE `thesis_committee` (
  `id` int(11) NOT NULL,
  `thesis_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `role` enum('supervisor','co_supervisor','examiner','external_examiner') NOT NULL,
  `assigned_date` datetime NOT NULL,
  `assigned_by` int(11) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `thesis_committee`
--

INSERT INTO `thesis_committee` (`id`, `thesis_id`, `member_id`, `role`, `assigned_date`, `assigned_by`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 48, 'supervisor', '2025-08-23 20:12:42', 1, 'active', '2025-08-23 20:12:42', NULL),
(2, 2, 48, 'supervisor', '2025-08-23 21:16:22', 1, 'active', '2025-08-23 21:16:22', NULL),
(3, 4, 48, 'supervisor', '2025-08-24 09:28:17', 1, 'active', '2025-08-24 09:24:08', NULL),
(8, 3, 48, 'supervisor', '2025-08-24 09:28:30', 1, 'active', '2025-08-24 09:28:30', NULL),
(9, 5, 48, 'supervisor', '2025-08-25 20:20:33', 1, 'active', '2025-08-25 20:20:33', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `thesis_notifications`
--

CREATE TABLE `thesis_notifications` (
  `id` int(11) NOT NULL,
  `thesis_id` int(11) NOT NULL,
  `recipient_id` int(11) NOT NULL,
  `sender_id` int(11) DEFAULT NULL,
  `type` enum('submission','assignment','review_completed','status_change','revision_request','approval','rejection') NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `thesis_notifications`
--

INSERT INTO `thesis_notifications` (`id`, `thesis_id`, `recipient_id`, `sender_id`, `type`, `title`, `message`, `is_read`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 129, 'submission', 'New Thesis Submission', 'A new thesis titled \'proposal\' has been submitted and requires supervisor assignment.', 0, '2025-08-23 20:07:43', NULL),
(2, 1, 148, 129, 'submission', 'New Thesis Submission', 'A new thesis titled \'proposal\' has been submitted and requires supervisor assignment.', 0, '2025-08-23 20:07:43', NULL),
(3, 1, 48, 1, 'assignment', 'New Thesis Assignment', 'You have been assigned as supervisor for the thesis \'proposal\'. Please review the submission.', 0, '2025-08-23 20:12:42', NULL),
(4, 1, 129, 1, 'assignment', 'Supervisor Assigned', 'A supervisor has been assigned to your thesis \'proposal\'. You will be contacted for further guidance.', 0, '2025-08-23 20:12:42', NULL),
(5, 1, 129, 48, 'approval', 'Thesis Approved', 'Congratulations! Your thesis \'proposal\' has been approved. You can now proceed with the final submission process.', 0, '2025-08-23 20:14:39', NULL),
(6, 2, 1, 129, 'submission', 'New Thesis Submission', 'A new thesis titled \'proposal 2\' has been submitted and requires supervisor assignment.', 0, '2025-08-23 21:10:20', NULL),
(7, 2, 148, 129, 'submission', 'New Thesis Submission', 'A new thesis titled \'proposal 2\' has been submitted and requires supervisor assignment.', 0, '2025-08-23 21:10:20', NULL),
(8, 2, 129, 48, 'rejection', 'Thesis Rejected', 'Your thesis \'proposal 2\' has been rejected. Please review the feedback and consider resubmission. Reason: fail nio...', 0, '2025-08-23 21:13:57', NULL),
(9, 2, 129, 48, 'rejection', 'Thesis Rejected', 'Your thesis \'proposal 2\' has been rejected. Please review the feedback and consider resubmission. Reason: fail nio...', 0, '2025-08-23 21:14:08', NULL),
(10, 2, 129, 48, 'rejection', 'Thesis Rejected', 'Your thesis \'proposal 2\' has been rejected. Please review the feedback and consider resubmission. Reason: fail nio...', 0, '2025-08-23 21:14:20', NULL),
(11, 2, 48, 1, 'assignment', 'New Thesis Assignment', 'You have been assigned as supervisor for the thesis \'proposal 2\'. Please review the submission.', 0, '2025-08-23 21:16:22', NULL),
(12, 2, 129, 1, 'assignment', 'Supervisor Assigned', 'A supervisor has been assigned to your thesis \'proposal 2\'. You will be contacted for further guidance.', 0, '2025-08-23 21:16:22', NULL),
(13, 2, 129, 48, 'rejection', 'Thesis Rejected', 'Your thesis \'proposal 2\' has been rejected. Please review the feedback and consider resubmission. Reason: fail nio...', 0, '2025-08-23 21:16:51', NULL),
(14, 3, 1, 129, 'submission', 'New Thesis Submission', 'A new thesis titled \'test_proposal\' has been submitted and requires supervisor assignment.', 0, '2025-08-24 08:28:56', NULL),
(15, 3, 148, 129, 'submission', 'New Thesis Submission', 'A new thesis titled \'test_proposal\' has been submitted and requires supervisor assignment.', 0, '2025-08-24 08:28:56', NULL),
(16, 4, 1, 129, 'submission', 'New Thesis Submission', 'A new thesis titled \'t1\' has been submitted and requires supervisor assignment.', 0, '2025-08-24 08:36:04', NULL),
(17, 4, 148, 129, 'submission', 'New Thesis Submission', 'A new thesis titled \'t1\' has been submitted and requires supervisor assignment.', 0, '2025-08-24 08:36:04', NULL),
(18, 4, 129, 48, 'revision_request', 'Thesis Revision Required', 'Your thesis \'t1\' requires revisions. Please review the feedback and resubmit. Comments: faile...', 0, '2025-08-24 08:50:36', NULL),
(19, 4, 129, 48, 'revision_request', 'Thesis Revision Required', 'Your thesis \'t1\' requires revisions. Please review the feedback and resubmit. Comments: faile...', 0, '2025-08-24 08:50:41', NULL),
(20, 3, 129, 48, 'approval', 'Thesis Approved', 'Congratulations! Your thesis \'test_proposal\' has been approved. You can now proceed with the final submission process.', 0, '2025-08-24 08:56:57', NULL),
(21, 3, 129, 48, 'approval', 'Thesis Approved', 'Congratulations! Your thesis \'test_proposal\' has been approved. You can now proceed with the final submission process.', 0, '2025-08-24 08:57:20', NULL),
(22, 3, 129, 48, 'approval', 'Thesis Approved', 'Congratulations! Your thesis \'test_proposal\' has been approved. You can now proceed with the final submission process.', 0, '2025-08-24 09:07:39', NULL),
(23, 3, 129, 48, 'approval', 'Thesis Approved', 'Congratulations! Your thesis \'test_proposal\' has been approved. You can now proceed with the final submission process.', 0, '2025-08-24 09:07:42', NULL),
(24, 3, 129, 48, 'approval', 'Thesis Approved', 'Congratulations! Your thesis \'test_proposal\' has been approved. You can now proceed with the final submission process.', 0, '2025-08-24 09:08:12', NULL),
(25, 3, 129, 48, 'approval', 'Thesis Approved', 'Congratulations! Your thesis \'test_proposal\' has been approved. You can now proceed with the final submission process.', 0, '2025-08-24 09:10:14', NULL),
(26, 3, 129, 48, 'approval', 'Thesis Approved', 'Congratulations! Your thesis \'test_proposal\' has been approved. You can now proceed with the final submission process.', 0, '2025-08-24 09:10:18', NULL),
(27, 3, 129, 48, 'approval', 'Thesis Approved', 'Congratulations! Your thesis \'test_proposal\' has been approved. You can now proceed with the final submission process.', 0, '2025-08-24 09:10:38', NULL),
(28, 3, 129, 48, 'approval', 'Thesis Approved', 'Congratulations! Your thesis \'test_proposal\' has been approved. You can now proceed with the final submission process.', 0, '2025-08-24 09:10:56', NULL),
(29, 4, 48, 1, 'assignment', 'New Thesis Assignment', 'You have been assigned as supervisor for the thesis \'t1\'. Please review the submission.', 0, '2025-08-24 09:24:08', NULL),
(30, 4, 129, 1, 'assignment', 'Supervisor Assigned', 'A supervisor has been assigned to your thesis \'t1\'. You will be contacted for further guidance.', 0, '2025-08-24 09:24:08', NULL),
(31, 4, 48, 1, 'assignment', 'New Thesis Assignment', 'You have been assigned as supervisor for the thesis \'t1\'. Please review the submission.', 0, '2025-08-24 09:24:12', NULL),
(32, 4, 129, 1, 'assignment', 'Supervisor Assigned', 'A supervisor has been assigned to your thesis \'t1\'. You will be contacted for further guidance.', 0, '2025-08-24 09:24:12', NULL),
(33, 4, 48, 1, 'assignment', 'New Thesis Assignment', 'You have been assigned as supervisor for the thesis \'t1\'. Please review the submission.', 0, '2025-08-24 09:24:16', NULL),
(34, 4, 129, 1, 'assignment', 'Supervisor Assigned', 'A supervisor has been assigned to your thesis \'t1\'. You will be contacted for further guidance.', 0, '2025-08-24 09:24:16', NULL),
(35, 4, 48, 1, 'assignment', 'New Thesis Assignment', 'You have been assigned as supervisor for the thesis \'t1\'. Please review the submission.', 0, '2025-08-24 09:24:41', NULL),
(36, 4, 129, 1, 'assignment', 'Supervisor Assigned', 'A supervisor has been assigned to your thesis \'t1\'. You will be contacted for further guidance.', 0, '2025-08-24 09:24:41', NULL),
(37, 4, 48, 1, 'assignment', 'New Thesis Assignment', 'You have been assigned as supervisor for the thesis \'t1\'. Please review the submission.', 0, '2025-08-24 09:28:17', NULL),
(38, 4, 129, 1, 'assignment', 'Supervisor Assigned', 'A supervisor has been assigned to your thesis \'t1\'. You will be contacted for further guidance.', 0, '2025-08-24 09:28:17', NULL),
(39, 3, 48, 1, 'assignment', 'New Thesis Assignment', 'You have been assigned as supervisor for the thesis \'test_proposal\'. Please review the submission.', 0, '2025-08-24 09:28:30', NULL),
(40, 3, 129, 1, 'assignment', 'Supervisor Assigned', 'A supervisor has been assigned to your thesis \'test_proposal\'. You will be contacted for further guidance.', 0, '2025-08-24 09:28:30', NULL),
(41, 5, 1, 136, 'submission', 'New Thesis Submission', 'A new thesis titled \'jknj\' has been submitted and requires supervisor assignment.', 0, '2025-08-25 20:20:07', NULL),
(42, 5, 148, 136, 'submission', 'New Thesis Submission', 'A new thesis titled \'jknj\' has been submitted and requires supervisor assignment.', 0, '2025-08-25 20:20:07', NULL),
(43, 5, 48, 1, 'assignment', 'New Thesis Assignment', 'You have been assigned as supervisor for the thesis \'jknj\'. Please review the submission.', 0, '2025-08-25 20:20:33', NULL),
(44, 5, 136, 1, 'assignment', 'Supervisor Assigned', 'A supervisor has been assigned to your thesis \'jknj\'. You will be contacted for further guidance.', 0, '2025-08-25 20:20:33', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `thesis_reviews`
--

CREATE TABLE `thesis_reviews` (
  `id` int(11) NOT NULL,
  `thesis_id` int(11) NOT NULL,
  `reviewer_id` int(11) NOT NULL,
  `review_date` datetime NOT NULL,
  `status` enum('approved','rejected','revision_required') NOT NULL,
  `overall_score` decimal(3,2) DEFAULT NULL,
  `content_score` decimal(3,2) DEFAULT NULL,
  `methodology_score` decimal(3,2) DEFAULT NULL,
  `presentation_score` decimal(3,2) DEFAULT NULL,
  `comments` text DEFAULT NULL,
  `feedback` text DEFAULT NULL,
  `suggestions` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `thesis_reviews`
--

INSERT INTO `thesis_reviews` (`id`, `thesis_id`, `reviewer_id`, `review_date`, `status`, `overall_score`, `content_score`, `methodology_score`, `presentation_score`, `comments`, `feedback`, `suggestions`, `created_at`, `updated_at`) VALUES
(1, 1, 48, '2025-08-23 20:14:39', 'approved', '0.60', '0.40', '0.20', '0.20', 'test', 'xolo', 'ss', '2025-08-23 20:14:39', NULL),
(5, 2, 48, '2025-08-23 21:16:51', 'rejected', '2.00', '2.00', '3.00', '1.00', 'fail nio', 'iagso', 'wah', '2025-08-23 21:16:51', NULL),
(6, 4, 48, '2025-08-24 09:29:45', 'approved', '0.00', '0.00', '1.00', '1.00', 'faile', 'x nxbajhcbs', 'bsvashvasy', '2025-08-24 08:50:36', '2025-08-24 09:29:45'),
(16, 3, 48, '2025-08-24 09:31:47', 'approved', '5.00', '5.00', '4.00', '4.00', 'ddnd', 'ddds', 'cccc', '2025-08-24 09:10:56', '2025-08-24 09:31:47'),
(21, 5, 48, '2025-08-25 20:21:19', 'approved', '4.00', '2.00', '4.00', '5.00', 'wow', 'cajob', 'cnw', '2025-08-25 20:21:19', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `thesis_revisions`
--

CREATE TABLE `thesis_revisions` (
  `id` int(11) NOT NULL,
  `thesis_id` int(11) NOT NULL,
  `version_number` int(11) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_type` enum('pdf','doc','docx') NOT NULL,
  `file_size` int(11) NOT NULL,
  `revision_notes` text DEFAULT NULL,
  `uploaded_by` int(11) NOT NULL,
  `upload_date` datetime NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `thesis_settings`
--

CREATE TABLE `thesis_settings` (
  `id` int(11) NOT NULL,
  `setting_name` varchar(100) NOT NULL,
  `setting_value` text NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `thesis_settings`
--

INSERT INTO `thesis_settings` (`id`, `setting_name`, `setting_value`, `description`, `created_at`, `updated_at`) VALUES
(1, 'max_file_size', '50', 'Maximum file size in MB for thesis uploads', '2025-08-23 19:57:40', NULL),
(2, 'allowed_file_types', 'pdf,doc,docx', 'Allowed file types for thesis submissions', '2025-08-23 19:57:40', NULL),
(3, 'auto_assign_supervisor', '0', 'Automatically assign supervisor based on department (1=yes, 0=no)', '2025-08-23 19:57:40', NULL),
(4, 'require_abstract', '1', 'Require abstract for thesis submission (1=yes, 0=no)', '2025-08-23 19:57:40', NULL),
(5, 'require_keywords', '1', 'Require keywords for thesis submission (1=yes, 0=no)', '2025-08-23 19:57:40', NULL),
(6, 'notification_enabled', '1', 'Enable thesis notifications (1=yes, 0=no)', '2025-08-23 19:57:40', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `thesis_submission_settings`
--

CREATE TABLE `thesis_submission_settings` (
  `id` int(11) NOT NULL,
  `academic_year_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `submission_mode` enum('deadline_based','open_submission') NOT NULL DEFAULT 'deadline_based',
  `submission_deadline` datetime DEFAULT NULL,
  `late_submission_allowed` tinyint(1) NOT NULL DEFAULT 0,
  `late_submission_penalty` decimal(5,2) DEFAULT NULL,
  `max_submissions_per_student` int(11) NOT NULL DEFAULT 1,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `thesis_submission_settings`
--

INSERT INTO `thesis_submission_settings` (`id`, `academic_year_id`, `semester_id`, `submission_mode`, `submission_deadline`, `late_submission_allowed`, `late_submission_penalty`, `max_submissions_per_student`, `status`, `created_at`, `updated_at`, `created_by`) VALUES
(1, 1, 7, 'deadline_based', '2025-08-25 20:25:00', 0, '0.00', 1, 'active', '2025-08-25 19:58:36', '2025-08-25 20:19:12', 1);

-- --------------------------------------------------------

--
-- Table structure for table `typing_status`
--

CREATE TABLE `typing_status` (
  `user_id` int(11) NOT NULL,
  `chat_partner_id` int(11) DEFAULT NULL,
  `is_typing` tinyint(1) DEFAULT 0,
  `last_typing` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `typing_status`
--

INSERT INTO `typing_status` (`user_id`, `chat_partner_id`, `is_typing`, `last_typing`) VALUES
(22, 48, 0, '2025-08-21 17:14:56'),
(48, 136, 0, '2025-09-02 16:42:23'),
(129, 48, 0, '2025-09-02 16:22:38');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','student','instructor') NOT NULL,
  `gender` enum('male','female') NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `profile_photo` varchar(255) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `password`, `role`, `gender`, `phone`, `address`, `profile_photo`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Admin User', 'admin@benadir.edu', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'male', '1234567800', 'Benadir University', '../assets/images/admin-avatar.png', 'active', '2025-05-08 16:48:23', '2025-08-12 23:03:01'),
(3, 'Azad mohamed ali', 'azad@benadir.edu', '$2y$10$G9SZiw7SirWxqu5EN1.tju9INZ4V7cmtKwCeNfdcMsaXWU5wjGKBG', 'instructor', 'male', '7678987', 'benadir,wadajir', '../assets/images/default-avatar.png', 'active', '2025-05-08 17:56:44', NULL),
(22, 'Saadaq mohamed yasin', 'soul@benadir.edu', '$2y$10$XGDrIqiqWXoEqAB/n1ZFN.N1OcgMbZdCNl2jJIeZgj4DHmDkw0dxW', 'student', 'male', '7678986', '', '', 'active', '2025-07-29 21:34:20', '2025-08-13 19:32:48'),
(36, 'Nasteha jelle hassan', 'nasteha@benadir.edu', '$2y$10$uAbMocsYssudNAXfeFpORuE.G0uwMYgGZCBAkKuKhW8AeOt9.Bmqy', 'student', 'female', '7678987', '', '', 'active', '2025-07-29 23:04:08', '2025-08-13 19:33:08'),
(37, 'Abdirizaq diriye', 'eng@benadir.edu', '$2y$10$B4yjK4vknHdnc/GsIEkAQOF.RyhD6m1ue0/TpWo2v9wQvQRYMrkEO', 'student', 'male', '76789833', 'mn', '../uploads/profiles/1753900193_b5.jpg', 'active', '2025-07-30 21:29:53', '2025-08-12 21:27:24'),
(48, 'Abdifitah Abdiwahid Ahmedi', 'engabdiyare@benadir.edu', '$2y$10$iNSNatAH6OfOm5jBDWSANe8EQODU0Lpgb.hpcGIi/kEx6cr/QhcWa', 'instructor', 'male', '61200000000', '', '', 'active', '2025-07-31 09:40:48', '2025-08-13 09:12:16'),
(129, 'Nacimo abdulkadir', 'nacimo@benadir.edu', '$2y$10$UwfA8lNWhPVyLwCTTjlIA.3KbozKKDNmWsQOK.UTVIRWCthsrzSU2', 'student', 'female', '612731804', 'kaxda', '../uploads/profiles/1753946255_WhatsApp Image 2025-01-28 at 16.40.16_ff640c1e.jpg', 'active', '2025-07-31 10:17:35', '2025-08-13 19:51:31'),
(130, 'yahye ali ahmed abii', 'yahye@benadir.edu', '$2y$10$1cV7CrwwqSd.BcOxAiYfNuS.tooE4YKt1xQW.O9gGKUYiAQu6MkEC', 'student', 'male', '7678987', '', '', 'active', '2025-07-31 10:25:12', '2025-08-13 19:51:19'),
(135, 'nasthjelhasan', 'jellenatsha@gmail.com', '$2y$10$0mRF.aGIxE0Xg7A/oVRYhOehji3oM1ySyaakBfL17go36LZkd.YpG', 'student', 'female', '613266320', '', '', 'active', '2025-07-31 18:52:40', '2025-08-12 21:45:05'),
(136, 'Faysal ali mohamed', 'raxmoahmed94@gmail.com', '$2y$10$gs7I2sATmd8mQi5cYSbBp.11DurNEvJie/SWREQex5uG0TscbWvce', 'student', 'male', '34543354', '', '', 'active', '2025-07-31 19:22:21', '2025-08-11 07:24:48'),
(138, 'abdiaziz adan yare', 'tollman@benadir.edu.so', '$2y$10$xmXHUjkQFop3cVE3A/REy.0FYRhCfmUQ18g/LiJlNBQp2Uq8aNUgK', 'student', 'male', '76789833', '', '', 'active', '2025-08-08 17:37:44', '2025-08-11 07:31:43'),
(146, 'foos ali axmed', 'fatima@benadir.edu.so', '$2y$10$vDasIHK3uUwZH4E2Ey0eweW8MX5mOfTmM/cgXTrcy8lMAcBy.fKY6', 'student', 'male', '7678988', 'nhh', '../uploads/profiles/1754889052_beautiful.png', 'active', '2025-08-11 08:10:52', NULL),
(148, 'Admin 2', 'admin2@benadir.edu', '$2y$10$w4dpJbPUnGAYaeum8mpE0eCMKW0u86RiaecgLV9uqUHq/r5BgdS3S', 'admin', 'female', '7678989', '', '', 'active', '2025-08-12 19:21:38', NULL),
(150, 'Sabarin Hassan Mohamed', 'sabna@benadir.edu', '$2y$10$1sB23.zF/iFO4F/dA1/M4u7uDsgKUdcISWTCGVcEZZJH2BF/DWK4O', 'student', 'female', '76789833', 'ceelasha', '../uploads/profiles/1755065756_Screenshot 2025-08-12 193308.png', 'active', '2025-08-13 09:15:56', '2025-08-13 19:25:56'),
(152, 'maxamum mohamed', 'mohamuud@benadir.edu', '$2y$10$QTvtO33spRFhVF0bOnxQXeuVns7PgRn03g9R62bWz9KigHTkvfeAC', 'student', 'male', '7678988', 'lkkkk', '../uploads/profiles/1755102561_b5.jpg', 'active', '2025-08-13 19:29:22', NULL),
(153, 'cabdiraxman maxamed', 'engcabdirahman@benadir.edu', '$2y$10$AbPobE0fXrxIl6yY/MoaYOdAF6aQL/RW9UOWjrxRZC5bSNXKnTGK6', 'instructor', 'male', '5436335634', '', '', 'active', '2025-08-13 20:21:49', '2025-08-21 08:03:48'),
(154, 'foos ahmed', 'jeecle@benadir.edu', '$2y$10$0nLpnp11tKUDS4KGkfJ3ceBxmUuzyzzng.JfjrpT0paspQo09MUC6', 'student', 'female', '788887', 'ss', '../uploads/profiles/1756147062_tw.png', 'active', '2025-08-25 21:37:42', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `academic_events`
--
ALTER TABLE `academic_events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `academic_year`
--
ALTER TABLE `academic_year`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `assessments`
--
ALTER TABLE `assessments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_id` (`course_id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `idx_assessments_program` (`program_id`),
  ADD KEY `idx_assessments_department` (`department_id`);

--
-- Indexes for table `assessment_questions`
--
ALTER TABLE `assessment_questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assessment_id` (`assessment_id`),
  ADD KEY `idx_assessment_questions_course` (`course_id`),
  ADD KEY `idx_assessment_questions_batch` (`batch_id`),
  ADD KEY `idx_assessment_batch_course` (`assessment_id`,`batch_id`,`course_id`);

--
-- Indexes for table `assessment_results`
--
ALTER TABLE `assessment_results`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_assessment_student` (`assessment_id`,`student_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_attendance_course_date` (`course_id`,`date`),
  ADD KEY `idx_attendance_student` (`student_id`,`date`);

--
-- Indexes for table `batch`
--
ALTER TABLE `batch`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `fk_batch_program` (`program_id`);

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sender_id` (`sender_id`),
  ADD KEY `receiver_id` (`receiver_id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`),
  ADD KEY `program_id` (`program_id`),
  ADD KEY `department_id` (`department_id`),
  ADD KEY `semester_id` (`semester_id`),
  ADD KEY `fk_course_batch` (`batch_id`),
  ADD KEY `fk_course_instructor` (`instructor_id`);

--
-- Indexes for table `course_materials`
--
ALTER TABLE `course_materials`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_id` (`course_id`),
  ADD KEY `uploaded_by` (`uploaded_by`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enrollment`
--
ALTER TABLE `enrollment`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_id` (`student_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `program_id` (`program_id`),
  ADD KEY `department_id` (`department_id`),
  ADD KEY `batch_id` (`batch_id`),
  ADD KEY `fk_enrollment_course` (`course_id`);

--
-- Indexes for table `instructors`
--
ALTER TABLE `instructors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `instructor_notifications`
--
ALTER TABLE `instructor_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `instructor_id` (`instructor_id`);

--
-- Indexes for table `live_classes`
--
ALTER TABLE `live_classes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_id` (`course_id`),
  ADD KEY `instructor_id` (`instructor_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `idx_notifications_type` (`type`),
  ADD KEY `idx_notifications_priority` (`priority`),
  ADD KEY `idx_notifications_target_audience` (`target_audience`),
  ADD KEY `idx_notifications_is_active` (`is_active`),
  ADD KEY `idx_notifications_created_at` (`created_at`);

--
-- Indexes for table `online_status`
--
ALTER TABLE `online_status`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `programs`
--
ALTER TABLE `programs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD KEY `idx_programs_monthly_fee` (`monthly_fee`);

--
-- Indexes for table `program_fee_history`
--
ALTER TABLE `program_fee_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `program_id` (`program_id`),
  ADD KEY `changed_by` (`changed_by`);

--
-- Indexes for table `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`id`),
  ADD KEY `academic_year_id` (`academic_year_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `fk_students_previous_batch` (`previous_batch_id`),
  ADD KEY `fk_students_status_changed_by` (`status_changed_by`),
  ADD KEY `idx_students_status` (`status`),
  ADD KEY `idx_students_status_changed_at` (`status_changed_at`);

--
-- Indexes for table `student_answers`
--
ALTER TABLE `student_answers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_student_question` (`assessment_id`,`student_id`,`question_id`),
  ADD KEY `idx_assessment_student` (`assessment_id`,`student_id`),
  ADD KEY `idx_student_answers` (`student_id`),
  ADD KEY `idx_question_answers` (`question_id`);

--
-- Indexes for table `thesis`
--
ALTER TABLE `thesis`
  ADD PRIMARY KEY (`id`),
  ADD KEY `academic_year_id` (`academic_year_id`),
  ADD KEY `semester_id` (`semester_id`),
  ADD KEY `assigned_by` (`assigned_by`),
  ADD KEY `idx_thesis_student` (`student_id`),
  ADD KEY `idx_thesis_supervisor` (`supervisor_id`),
  ADD KEY `idx_thesis_status` (`status`),
  ADD KEY `idx_thesis_department` (`department_id`),
  ADD KEY `idx_thesis_program` (`program_id`),
  ADD KEY `idx_submission_settings` (`submission_settings_id`),
  ADD KEY `idx_file_hash` (`file_hash`);

--
-- Indexes for table `thesis_committee`
--
ALTER TABLE `thesis_committee`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_thesis_member_role` (`thesis_id`,`member_id`,`role`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `assigned_by` (`assigned_by`);

--
-- Indexes for table `thesis_notifications`
--
ALTER TABLE `thesis_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `thesis_id` (`thesis_id`),
  ADD KEY `sender_id` (`sender_id`),
  ADD KEY `idx_thesis_notifications_recipient` (`recipient_id`),
  ADD KEY `idx_thesis_notifications_read` (`is_read`);

--
-- Indexes for table `thesis_reviews`
--
ALTER TABLE `thesis_reviews`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_thesis_reviewer` (`thesis_id`,`reviewer_id`),
  ADD KEY `idx_thesis_reviews_thesis` (`thesis_id`),
  ADD KEY `idx_thesis_reviews_reviewer` (`reviewer_id`);

--
-- Indexes for table `thesis_revisions`
--
ALTER TABLE `thesis_revisions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `thesis_id` (`thesis_id`),
  ADD KEY `uploaded_by` (`uploaded_by`);

--
-- Indexes for table `thesis_settings`
--
ALTER TABLE `thesis_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting_name` (`setting_name`);

--
-- Indexes for table `thesis_submission_settings`
--
ALTER TABLE `thesis_submission_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_academic_semester` (`academic_year_id`,`semester_id`),
  ADD KEY `idx_academic_year` (`academic_year_id`),
  ADD KEY `idx_semester` (`semester_id`),
  ADD KEY `idx_submission_mode` (`submission_mode`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `fk_thesis_settings_created_by` (`created_by`);

--
-- Indexes for table `typing_status`
--
ALTER TABLE `typing_status`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `chat_partner_id` (`chat_partner_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `academic_events`
--
ALTER TABLE `academic_events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `academic_year`
--
ALTER TABLE `academic_year`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `assessments`
--
ALTER TABLE `assessments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `assessment_questions`
--
ALTER TABLE `assessment_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `assessment_results`
--
ALTER TABLE `assessment_results`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=244;

--
-- AUTO_INCREMENT for table `batch`
--
ALTER TABLE `batch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `chats`
--
ALTER TABLE `chats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `course_materials`
--
ALTER TABLE `course_materials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `enrollment`
--
ALTER TABLE `enrollment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=158;

--
-- AUTO_INCREMENT for table `instructors`
--
ALTER TABLE `instructors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `instructor_notifications`
--
ALTER TABLE `instructor_notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `live_classes`
--
ALTER TABLE `live_classes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `programs`
--
ALTER TABLE `programs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `program_fee_history`
--
ALTER TABLE `program_fee_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `semester`
--
ALTER TABLE `semester`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `student_answers`
--
ALTER TABLE `student_answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `thesis`
--
ALTER TABLE `thesis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `thesis_committee`
--
ALTER TABLE `thesis_committee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `thesis_notifications`
--
ALTER TABLE `thesis_notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `thesis_reviews`
--
ALTER TABLE `thesis_reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `thesis_revisions`
--
ALTER TABLE `thesis_revisions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `thesis_settings`
--
ALTER TABLE `thesis_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `thesis_submission_settings`
--
ALTER TABLE `thesis_submission_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=155;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `assessments`
--
ALTER TABLE `assessments`
  ADD CONSTRAINT `assessments_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `assessments_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_assessments_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_assessments_program` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `assessment_questions`
--
ALTER TABLE `assessment_questions`
  ADD CONSTRAINT `assessment_questions_ibfk_1` FOREIGN KEY (`assessment_id`) REFERENCES `assessments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_assessment_questions_batch` FOREIGN KEY (`batch_id`) REFERENCES `batch` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_assessment_questions_course` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `assessment_results`
--
ALTER TABLE `assessment_results`
  ADD CONSTRAINT `assessment_results_ibfk_1` FOREIGN KEY (`assessment_id`) REFERENCES `assessments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `assessment_results_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attendance_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `batch`
--
ALTER TABLE `batch`
  ADD CONSTRAINT `fk_batch_program` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`);

--
-- Constraints for table `chats`
--
ALTER TABLE `chats`
  ADD CONSTRAINT `chats_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chats_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `course`
--
ALTER TABLE `course`
  ADD CONSTRAINT `course_ibfk_1` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `course_ibfk_2` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `course_ibfk_3` FOREIGN KEY (`semester_id`) REFERENCES `semester` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_course_batch` FOREIGN KEY (`batch_id`) REFERENCES `batch` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_course_instructor` FOREIGN KEY (`instructor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `course_materials`
--
ALTER TABLE `course_materials`
  ADD CONSTRAINT `course_materials_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `course_materials_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `enrollment`
--
ALTER TABLE `enrollment`
  ADD CONSTRAINT `enrollment_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `enrollment_ibfk_3` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `enrollment_ibfk_4` FOREIGN KEY (`batch_id`) REFERENCES `batch` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_batch` FOREIGN KEY (`batch_id`) REFERENCES `batch` (`id`),
  ADD CONSTRAINT `fk_course` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`),
  ADD CONSTRAINT `fk_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  ADD CONSTRAINT `fk_enrollment_course` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_enrollment_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_enrollment_department_new` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_enrollment_program` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_program` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`);

--
-- Constraints for table `instructors`
--
ALTER TABLE `instructors`
  ADD CONSTRAINT `instructors_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `instructor_notifications`
--
ALTER TABLE `instructor_notifications`
  ADD CONSTRAINT `instructor_notifications_ibfk_1` FOREIGN KEY (`instructor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `live_classes`
--
ALTER TABLE `live_classes`
  ADD CONSTRAINT `live_classes_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `live_classes_ibfk_2` FOREIGN KEY (`instructor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `online_status`
--
ALTER TABLE `online_status`
  ADD CONSTRAINT `online_status_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `program_fee_history`
--
ALTER TABLE `program_fee_history`
  ADD CONSTRAINT `program_fee_history_ibfk_1` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `program_fee_history_ibfk_2` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `semester`
--
ALTER TABLE `semester`
  ADD CONSTRAINT `semester_ibfk_1` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_year` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `fk_students_previous_batch` FOREIGN KEY (`previous_batch_id`) REFERENCES `batch` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_students_status_changed_by` FOREIGN KEY (`status_changed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `student_answers`
--
ALTER TABLE `student_answers`
  ADD CONSTRAINT `student_answers_ibfk_1` FOREIGN KEY (`assessment_id`) REFERENCES `assessments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `student_answers_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `student_answers_ibfk_3` FOREIGN KEY (`question_id`) REFERENCES `assessment_questions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `thesis`
--
ALTER TABLE `thesis`
  ADD CONSTRAINT `fk_thesis_submission_settings` FOREIGN KEY (`submission_settings_id`) REFERENCES `thesis_submission_settings` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `thesis_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `thesis_ibfk_2` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `thesis_ibfk_3` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `thesis_ibfk_4` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_year` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `thesis_ibfk_5` FOREIGN KEY (`semester_id`) REFERENCES `semester` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `thesis_ibfk_6` FOREIGN KEY (`supervisor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `thesis_ibfk_7` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `thesis_committee`
--
ALTER TABLE `thesis_committee`
  ADD CONSTRAINT `thesis_committee_ibfk_1` FOREIGN KEY (`thesis_id`) REFERENCES `thesis` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `thesis_committee_ibfk_2` FOREIGN KEY (`member_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `thesis_committee_ibfk_3` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `thesis_notifications`
--
ALTER TABLE `thesis_notifications`
  ADD CONSTRAINT `thesis_notifications_ibfk_1` FOREIGN KEY (`thesis_id`) REFERENCES `thesis` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `thesis_notifications_ibfk_2` FOREIGN KEY (`recipient_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `thesis_notifications_ibfk_3` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `thesis_reviews`
--
ALTER TABLE `thesis_reviews`
  ADD CONSTRAINT `thesis_reviews_ibfk_1` FOREIGN KEY (`thesis_id`) REFERENCES `thesis` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `thesis_reviews_ibfk_2` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `thesis_revisions`
--
ALTER TABLE `thesis_revisions`
  ADD CONSTRAINT `thesis_revisions_ibfk_1` FOREIGN KEY (`thesis_id`) REFERENCES `thesis` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `thesis_revisions_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `thesis_submission_settings`
--
ALTER TABLE `thesis_submission_settings`
  ADD CONSTRAINT `fk_thesis_settings_academic_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_year` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_thesis_settings_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_thesis_settings_semester` FOREIGN KEY (`semester_id`) REFERENCES `semester` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `typing_status`
--
ALTER TABLE `typing_status`
  ADD CONSTRAINT `typing_status_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `typing_status_ibfk_2` FOREIGN KEY (`chat_partner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
