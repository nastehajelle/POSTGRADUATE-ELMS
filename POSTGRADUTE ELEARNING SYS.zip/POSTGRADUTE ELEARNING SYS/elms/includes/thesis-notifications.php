<?php
// Thesis Notification Helper Functions

/**
 * Send thesis notification to specific user
 */
function sendThesisNotification($conn, $thesis_id, $recipient_id, $sender_id, $type, $title, $message) {
    try {
        $query = "INSERT INTO thesis_notifications (thesis_id, recipient_id, sender_id, type, title, message, created_at) 
                  VALUES (?, ?, ?, ?, ?, ?, NOW())";
        $stmt = $conn->prepare($query);
        return $stmt->execute([$thesis_id, $recipient_id, $sender_id, $type, $title, $message]);
    } catch (PDOException $e) {
        error_log("Error sending thesis notification: " . $e->getMessage());
        return false;
    }
}

/**
 * Send notification when thesis is submitted
 */
function notifyThesisSubmission($conn, $thesis_id, $student_id, $thesis_title) {
    try {
        // Get admin users
        $admin_query = "SELECT id FROM users WHERE role = 'admin' AND status = 'active'";
        $admin_stmt = $conn->prepare($admin_query);
        $admin_stmt->execute();
        $admins = $admin_stmt->fetchAll(PDO::FETCH_ASSOC);

        $title = "New Thesis Submission";
        $message = "A new thesis titled '{$thesis_title}' has been submitted and requires supervisor assignment.";

        foreach ($admins as $admin) {
            sendThesisNotification($conn, $thesis_id, $admin['id'], $student_id, 'submission', $title, $message);
        }

        return true;
    } catch (PDOException $e) {
        error_log("Error notifying thesis submission: " . $e->getMessage());
        return false;
    }
}

/**
 * Send notification when supervisor is assigned
 */
function notifySupervisorAssignment($conn, $thesis_id, $supervisor_id, $student_id, $admin_id, $thesis_title) {
    try {
        // Notify supervisor
        $supervisor_title = "New Thesis Assignment";
        $supervisor_message = "You have been assigned as supervisor for the thesis '{$thesis_title}'. Please review the submission.";
        sendThesisNotification($conn, $thesis_id, $supervisor_id, $admin_id, 'assignment', $supervisor_title, $supervisor_message);

        // Notify student
        $student_title = "Supervisor Assigned";
        $student_message = "A supervisor has been assigned to your thesis '{$thesis_title}'. You will be contacted for further guidance.";
        sendThesisNotification($conn, $thesis_id, $student_id, $admin_id, 'assignment', $student_title, $student_message);

        return true;
    } catch (PDOException $e) {
        error_log("Error notifying supervisor assignment: " . $e->getMessage());
        return false;
    }
}

/**
 * Send notification when thesis review is completed
 */
function notifyThesisReview($conn, $thesis_id, $student_id, $reviewer_id, $status, $thesis_title) {
    try {
        $status_text = ucwords(str_replace('_', ' ', $status));
        $title = "Thesis Review Completed";
        $message = "Your thesis '{$thesis_title}' has been reviewed and marked as {$status_text}. Please check your thesis dashboard for detailed feedback.";

        sendThesisNotification($conn, $thesis_id, $student_id, $reviewer_id, 'review_completed', $title, $message);

        // Also notify admin about review completion
        $admin_query = "SELECT id FROM users WHERE role = 'admin' AND status = 'active' LIMIT 1";
        $admin_stmt = $conn->prepare($admin_query);
        $admin_stmt->execute();
        $admin = $admin_stmt->fetch(PDO::FETCH_ASSOC);

        if ($admin) {
            $admin_title = "Thesis Review Completed";
            $admin_message = "A thesis review has been completed for '{$thesis_title}' with status: {$status_text}.";
            sendThesisNotification($conn, $thesis_id, $admin['id'], $reviewer_id, 'review_completed', $admin_title, $admin_message);
        }

        return true;
    } catch (PDOException $e) {
        error_log("Error notifying thesis review: " . $e->getMessage());
        return false;
    }
}

/**
 * Send notification when thesis status changes
 */
function notifyStatusChange($conn, $thesis_id, $student_id, $admin_id, $old_status, $new_status, $thesis_title) {
    try {
        $old_status_text = ucwords(str_replace('_', ' ', $old_status));
        $new_status_text = ucwords(str_replace('_', ' ', $new_status));
        
        $title = "Thesis Status Updated";
        $message = "Your thesis '{$thesis_title}' status has been changed from {$old_status_text} to {$new_status_text}.";

        sendThesisNotification($conn, $thesis_id, $student_id, $admin_id, 'status_change', $title, $message);

        return true;
    } catch (PDOException $e) {
        error_log("Error notifying status change: " . $e->getMessage());
        return false;
    }
}

/**
 * Send notification for revision request
 */
function notifyRevisionRequest($conn, $thesis_id, $student_id, $reviewer_id, $thesis_title, $comments) {
    try {
        $title = "Thesis Revision Required";
        $message = "Your thesis '{$thesis_title}' requires revisions. Please review the feedback and resubmit. Comments: " . substr($comments, 0, 100) . "...";

        sendThesisNotification($conn, $thesis_id, $student_id, $reviewer_id, 'revision_request', $title, $message);

        return true;
    } catch (PDOException $e) {
        error_log("Error notifying revision request: " . $e->getMessage());
        return false;
    }
}

/**
 * Send notification when thesis is approved
 */
function notifyThesisApproval($conn, $thesis_id, $student_id, $reviewer_id, $thesis_title) {
    try {
        $title = "Thesis Approved";
        $message = "Congratulations! Your thesis '{$thesis_title}' has been approved. You can now proceed with the final submission process.";

        sendThesisNotification($conn, $thesis_id, $student_id, $reviewer_id, 'approval', $title, $message);

        return true;
    } catch (PDOException $e) {
        error_log("Error notifying thesis approval: " . $e->getMessage());
        return false;
    }
}

/**
 * Send notification when thesis is rejected
 */
function notifyThesisRejection($conn, $thesis_id, $student_id, $reviewer_id, $thesis_title, $reason) {
    try {
        $title = "Thesis Rejected";
        $message = "Your thesis '{$thesis_title}' has been rejected. Please review the feedback and consider resubmission. Reason: " . substr($reason, 0, 100) . "...";

        sendThesisNotification($conn, $thesis_id, $student_id, $reviewer_id, 'rejection', $title, $message);

        return true;
    } catch (PDOException $e) {
        error_log("Error notifying thesis rejection: " . $e->getMessage());
        return false;
    }
}

/**
 * Get unread thesis notifications count for user
 */
function getUnreadThesisNotificationsCount($conn, $user_id) {
    try {
        $query = "SELECT COUNT(*) as count FROM thesis_notifications WHERE recipient_id = ? AND is_read = 0";
        $stmt = $conn->prepare($query);
        $stmt->execute([$user_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] ?? 0;
    } catch (PDOException $e) {
        error_log("Error getting unread notifications count: " . $e->getMessage());
        return 0;
    }
}

/**
 * Mark thesis notification as read
 */
function markThesisNotificationAsRead($conn, $notification_id, $user_id) {
    try {
        $query = "UPDATE thesis_notifications SET is_read = 1, updated_at = NOW() 
                  WHERE id = ? AND recipient_id = ?";
        $stmt = $conn->prepare($query);
        return $stmt->execute([$notification_id, $user_id]);
    } catch (PDOException $e) {
        error_log("Error marking notification as read: " . $e->getMessage());
        return false;
    }
}

/**
 * Get thesis notifications for user with pagination
 */
function getThesisNotifications($conn, $user_id, $limit = 20, $offset = 0) {
    try {
        $query = "SELECT tn.*, t.title as thesis_title, u.full_name as sender_name
                  FROM thesis_notifications tn
                  LEFT JOIN thesis t ON tn.thesis_id = t.id
                  LEFT JOIN users u ON tn.sender_id = u.id
                  WHERE tn.recipient_id = ?
                  ORDER BY tn.created_at DESC
                  LIMIT ? OFFSET ?";
        $stmt = $conn->prepare($query);
        $stmt->execute([$user_id, $limit, $offset]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting thesis notifications: " . $e->getMessage());
        return [];
    }
}

/**
 * Send bulk notification to multiple users
 */
function sendBulkThesisNotification($conn, $recipient_ids, $sender_id, $type, $title, $message, $thesis_id = null) {
    try {
        $conn->beginTransaction();
        
        $query = "INSERT INTO thesis_notifications (thesis_id, recipient_id, sender_id, type, title, message, created_at) 
                  VALUES (?, ?, ?, ?, ?, ?, NOW())";
        $stmt = $conn->prepare($query);
        
        foreach ($recipient_ids as $recipient_id) {
            $stmt->execute([$thesis_id, $recipient_id, $sender_id, $type, $title, $message]);
        }
        
        $conn->commit();
        return true;
    } catch (PDOException $e) {
        $conn->rollBack();
        error_log("Error sending bulk notification: " . $e->getMessage());
        return false;
    }
}

/**
 * Clean up old notifications (older than 6 months)
 */
function cleanupOldThesisNotifications($conn) {
    try {
        $query = "DELETE FROM thesis_notifications WHERE created_at < DATE_SUB(NOW(), INTERVAL 6 MONTH)";
        $stmt = $conn->prepare($query);
        return $stmt->execute();
    } catch (PDOException $e) {
        error_log("Error cleaning up old notifications: " . $e->getMessage());
        return false;
    }
}
?>
