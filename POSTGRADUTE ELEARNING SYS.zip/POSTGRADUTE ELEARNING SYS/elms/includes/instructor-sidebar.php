<?php
// Get current page for active menu highlighting
$current_page = basename($_SERVER['PHP_SELF']);
?>

<div class="admin-sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <img src="../assets/images/logo.png" alt="Benadir University Logo" onerror="this.style.display='none'">
        </div>
        <h2>Instructor Panel</h2>
    </div>
    
    <div class="sidebar-menu">
        <ul>
            <li class="<?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
                <a href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="<?php echo $current_page == 'my-courses.php' ? 'active' : ''; ?>">
                <a href="my-courses.php">
                    <i class="fas fa-book"></i>
                    <span>My Courses</span>
                </a>
            </li>
           
            <li class="<?php echo $current_page == 'attendance.php' ? 'active' : ''; ?>">
                <a href="attendance.php">
                    <i class="fas fa-calendar-check"></i>
                    <span>Attendance</span>
                </a>
            </li>
            <li class="<?php echo $current_page == 'assessments.php' ? 'active' : ''; ?>">
                <a href="assessments.php">
                    <i class="fas fa-clipboard-list"></i>
                    <span>Assessments</span>
                </a>
            </li>
            <li class="<?php echo $current_page == 'results.php' ? 'active' : ''; ?>">
                <a href="results.php">
                    <i class="fas fa-chart-line"></i>
                    <span>Results</span>
                </a>
            </li>
            <!-- Added thesis review menu item -->
            <li class="<?php echo $current_page == 'thesis-review.php' ? 'active' : ''; ?>">
                <a href="thesis-review.php">
                    <i class="fas fa-graduation-cap"></i>
                    <span>Thesis Review</span>
                </a>
            </li>
            <li class="<?php echo $current_page == 'live-class.php' ? 'active' : ''; ?>">
                <a href="live-class.php">
                    <i class="fas fa-video"></i>
                    <span>Live Class</span>
                </a>
            </li>
            <li class="<?php echo $current_page == 'chats.php' ? 'active' : ''; ?>">
                <a href="chats.php">
                    <i class="fas fa-comments"></i>
                    <span>Chats</span>
                </a>
            </li>
            <li class="<?php echo $current_page == 'notifications.php' ? 'active' : ''; ?>">
                <a href="notifications.php">
                    <i class="fas fa-bell"></i>
                    <span>Notifications</span>
                </a>
            </li>
            <li class="<?php echo $current_page == 'profile.php' ? 'active' : ''; ?>">
                <a href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>Profile</span>
                </a>
            </li>
            <li>
                <a href="../auth/logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>
</div>
