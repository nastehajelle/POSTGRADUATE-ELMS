<div class="admin-sidebar">
  <div class="sidebar-header">
      <div class="logo">
          <img src="../assets/images/ben.png" alt="Benadir University Logo">
      </div>
      <h2>Benadir LMS</h2>
  </div>
  
  <div class="sidebar-menu">
      <ul>
          <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
              <a href="dashboard.php">
                  <i class="fas fa-tachometer-alt"></i>
                  <span>Dashboard</span>
              </a>
          </li>
          <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : ''; ?>">
              <a href="users.php">
                  <i class="fas fa-users"></i>
                  <span>Users</span>
              </a>
          </li>
          <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'Departments.php' ? 'active' : ''; ?>">
              <a href="Departments.php">
                  <i class="fas fa-graduation-cap"></i>
                  <span>Departments</span>
              </a>
          </li>
          <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'programs.php' ? 'active' : ''; ?>">
              <a href="programs.php">
                  <i class="fas fa-building"></i>
                  <span>Programs</span>
              </a>
          </li>
          <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'batches.php' ? 'active' : ''; ?>">
              <a href="batches.php">
                  <i class="fas fa-layer-group"></i>
                  <span>Batches</span>
              </a>
          </li>
         
          <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'courses.php' ? 'active' : ''; ?>">
              <a href="courses.php">
                  <i class="fas fa-book"></i>
                  <span>Courses</span>
              </a>
          </li>
          <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'academic-year.php' ? 'active' : ''; ?>">
              <a href="academic-year.php">
                  <i class="fas fa-calendar-alt"></i>
                  <span>Academic Year</span>
              </a>
          </li>
          <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'academic-events.php' ? 'active' : ''; ?>">
              <a href="academic-events.php">
                  <i class="fas fa-calendar-alt"></i>
                  <span>Academic Events</span>
              </a>
          </li>
          
          <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'assessments.php' ? 'active' : ''; ?>">
              <a href="assessments.php">
                  <i class="fas fa-file-alt"></i>
                  <span>Assessments</span>
              </a>
          </li>
        <!-- Thesis Management Submenu -->
<li class="menu-item-with-submenu 
    <?php echo in_array(basename($_SERVER['PHP_SELF']), ['thesis-management.php', 'thesis-submission-settings.php']) ? 'active submenu-open' : ''; ?>">
    
    <a href="#" class="submenu-toggle">
        <i class="fas fa-graduation-cap"></i>
        <span>Thesis </span>
        <i class="fas fa-chevron-down submenu-arrow"></i>
    </a>
    
    <ul class="submenu" style="<?php echo in_array(basename($_SERVER['PHP_SELF']), ['thesis-management.php', 'thesis-submission-settings.php']) ? 'display:block;' : 'display:none;'; ?>">
        <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'thesis-management.php' ? 'active' : ''; ?>">
            <a href="thesis-management.php">
                <i class="fas fa-list"></i>
                <span>All Submissions</span>
            </a>
        </li>
        <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'thesis-submission-settings.php' ? 'active' : ''; ?>">
            <a href="thesis-submission-settings.php">
                <i class="fas fa-cog"></i>
                <span>Submission Settings</span>
            </a>
        </li>
    </ul>
</li>

          <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'notifications.php' ? 'active' : ''; ?>">
              <a href="notifications.php">
                  <i class="fas fa-bell"></i>
                  <span>Notifications</span>
              </a>
          </li>
         
          <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'active' : ''; ?>">
              <a href="reports.php">
                  <i class="fas fa-chart-bar"></i>
                  <span>Reports</span>
              </a>
          </li>
           <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : ''; ?>">
                <a href="profile.php">
                    <i class="fas fa-user-circle"></i>
                    <span>Profile</span>
                </a>
            </li>
          <li>
              <a href="../auth/logout.php">
                  <i class="fas fa-sign-out-alt"></i>
                  <span>Logout</span>
              </a>
          </li>
      </ul>
  </div>
</div>

<!-- Added JavaScript for submenu functionality -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const submenuToggles = document.querySelectorAll('.submenu-toggle');
    
    submenuToggles.forEach(toggle => {
        toggle.addEventListener('click', function(e) {
            e.preventDefault();
            const parentLi = this.parentElement;
            const submenu = parentLi.querySelector('.submenu');
            const arrow = this.querySelector('.submenu-arrow');
            
            // Toggle submenu
            if (submenu.style.display === 'block') {
                submenu.style.display = 'none';
                arrow.style.transform = 'rotate(0deg)';
                parentLi.classList.remove('submenu-open');
            } else {
                submenu.style.display = 'block';
                arrow.style.transform = 'rotate(180deg)';
                parentLi.classList.add('submenu-open');
            }
        });
    });
    
    // Auto-open submenu if current page is in submenu
    const activeSubmenuItem = document.querySelector('.submenu li.active');
    if (activeSubmenuItem) {
        const parentSubmenu = activeSubmenuItem.closest('.submenu');
        const parentLi = parentSubmenu.parentElement;
        const arrow = parentLi.querySelector('.submenu-arrow');
        
        parentSubmenu.style.display = 'block';
        arrow.style.transform = 'rotate(180deg)';
        parentLi.classList.add('submenu-open');
    }
});
</script>
