<div class="admin-sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <img src="../assets/images/ben.png" alt="Benadir University Logo">
        </div>
        <h2>Student Panel</h2>
    </div>
    
    <div class="sidebar-menu">
        <ul>
            <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
                <a href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'my-courses.php' ? 'active' : ''; ?>">
                <a href="my-courses.php">
                    <i class="fas fa-book"></i>
                    <span>My Courses</span>
                </a>
            </li>
            <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'assessments.php' ? 'active' : ''; ?>">
                <a href="assessments.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Assessments</span>
                </a>
            </li>
            <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'results.php' ? 'active' : ''; ?>">
                <a href="results.php">
                    <i class="fas fa-poll-h"></i>
                    <span>Results</span>
                </a>
            </li>
            <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'attendance.php' ? 'active' : ''; ?>">
                <a href="attendance.php">
                    <i class="fas fa-calendar-check"></i>
                    <span>Attendance</span>
                </a>
            </li>
            <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'live-class.php' ? 'active' : ''; ?>">
                <a href="live-class.php">
                    <i class="fas fa-video"></i>
                    <span>Live Classes</span>
                </a>
            </li>
            <!-- Added thesis management menu item -->
            <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'thesis.php' ? 'active' : ''; ?>">
                <a href="thesis.php">
                    <i class="fas fa-graduation-cap"></i>
                    <span>My Thesis</span>
                </a>
            </li>
             <li class="nav-item">
                <a href="chats.php" class="nav-link <?php echo $current_page === 'chats.php' ? 'active' : ''; ?>">
                    <i class="fas fa-comments"></i>
                    <span>Chats</span>
                </a>
            </li>
            <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'notifications.php' ? 'active' : ''; ?>">
                <a href="notifications.php">
                    <i class="fas fa-bell"></i>
                    <span>Notifications</span>
                </a>
            </li>
            <li class="<?php echo basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : ''; ?>">
                <a href="profile.php">
                    <i class="fas fa-user-circle"></i>
                    <span>Profile</span>
                </a>
            </li>
            <li>
                <a href="../auth/logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>
</div>
