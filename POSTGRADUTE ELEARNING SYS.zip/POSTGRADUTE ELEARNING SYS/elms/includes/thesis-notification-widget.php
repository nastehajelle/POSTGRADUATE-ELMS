<?php
// Thesis Notification Widget - Include this in dashboards and headers

include_once 'thesis-notifications.php';

$user_id = $_SESSION['user_id'] ?? 0;
$unread_count = getUnreadThesisNotificationsCount($conn, $user_id);
$recent_notifications = getThesisNotifications($conn, $user_id, 5, 0);
?>

<div class="thesis-notifications-widget">
    <div class="notifications-dropdown">
        <button class="notifications-btn" id="thesisNotificationsBtn">
            <i class="fas fa-graduation-cap"></i>
            <?php if ($unread_count > 0): ?>
            <span class="thesis-notification-badge"><?php echo $unread_count > 99 ? '99+' : $unread_count; ?></span>
            <?php endif; ?>
        </button>
        <div class="notifications-content" id="thesisNotificationsDropdown">
            <div class="notifications-header">
                <h3>Thesis Notifications</h3>
                <div class="header-actions">
                    <?php if ($unread_count > 0): ?>
                    <button class="btn-link" id="markAllAsRead">Mark All Read</button>
                    <?php endif; ?>
                    <button class="btn-link" id="refreshNotifications">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                </div>
            </div>
            <div class="notifications-list" id="thesisNotificationsContainer">
                <?php if (!empty($recent_notifications)): ?>
                    <?php foreach ($recent_notifications as $notification): ?>
                    <div class="thesis-notification-item <?php echo $notification['is_read'] ? 'read' : 'unread'; ?>" 
                         data-notification-id="<?php echo $notification['id']; ?>">
                        <div class="notification-icon <?php echo $notification['type']; ?>">
                            <i class="fas <?php 
                                $icons = [
                                    'submission' => 'fa-upload',
                                    'assignment' => 'fa-user-plus',
                                    'review_completed' => 'fa-check-circle',
                                    'status_change' => 'fa-exchange-alt',
                                    'revision_request' => 'fa-edit',
                                    'approval' => 'fa-thumbs-up',
                                    'rejection' => 'fa-thumbs-down'
                                ];
                                echo $icons[$notification['type']] ?? 'fa-bell';
                            ?>"></i>
                        </div>
                        <div class="notification-content">
                            <div class="notification-title"><?php echo htmlspecialchars($notification['title']); ?></div>
                            <div class="notification-message"><?php echo htmlspecialchars(substr($notification['message'], 0, 80)) . (strlen($notification['message']) > 80 ? '...' : ''); ?></div>
                            <div class="notification-time"><?php echo date('M d, H:i', strtotime($notification['created_at'])); ?></div>
                        </div>
                        <?php if (!$notification['is_read']): ?>
                        <div class="unread-indicator"></div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="no-notifications">
                        <i class="fas fa-bell-slash"></i>
                        <p>No thesis notifications</p>
                    </div>
                <?php endif; ?>
            </div>
            <div class="notifications-footer">
                <a href="thesis-notifications.php" class="view-all-link">View All Notifications</a>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const notificationsBtn = document.getElementById('thesisNotificationsBtn');
    const notificationsDropdown = document.getElementById('thesisNotificationsDropdown');
    
    if (notificationsBtn) {
        notificationsBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            notificationsDropdown.classList.toggle('show');
        });
    }
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.thesis-notifications-widget')) {
            notificationsDropdown.classList.remove('show');
        }
    });
});
</script>
