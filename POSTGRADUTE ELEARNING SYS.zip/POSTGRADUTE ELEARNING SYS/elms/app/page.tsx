"use client"

import  from "../assets/js/thesis-notifications"

export default function SyntheticV0PageForDeployment() {
  return < />
}