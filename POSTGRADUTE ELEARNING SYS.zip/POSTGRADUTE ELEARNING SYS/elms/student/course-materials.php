<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is a student
if (!is_logged_in() || !is_student()) {
    header("Location: ../auth/login.php");
    exit();
}

$student_id = $_SESSION['user_id'];
$course_id = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;
$course_name = "Course Materials";
$materials = [];
$message = '';
$messageType = '';

if ($course_id > 0) {
    try {
        // Get course name first
        $course_query = "SELECT name, code FROM course WHERE id = ?";
        $stmt_course = $conn->prepare($course_query);
        $stmt_course->execute([$course_id]);
        $course_data = $stmt_course->fetch(PDO::FETCH_ASSOC);
        if ($course_data) {
            $course_name = htmlspecialchars($course_data['code'] . ' - ' . $course_data['name']) . " Materials";
        }

        // Fetch course materials for the specific course
        $materials_query = "SELECT cm.id, cm.title, cm.description, cm.file_path, cm.material_type, cm.created_at, u.full_name as uploaded_by_name
                           FROM course_materials cm 
                           LEFT JOIN users u ON cm.uploaded_by = u.id 
                           WHERE cm.course_id = ? 
                           ORDER BY cm.created_at DESC";
        $stmt_materials = $conn->prepare($materials_query);
        $stmt_materials->execute([$course_id]);
        $materials = $stmt_materials->fetchAll(PDO::FETCH_ASSOC);

        if (empty($materials)) {
            $message = "No materials available for this course yet.";
            $messageType = "info";
        }
    } catch (PDOException $e) {
        error_log("Database error fetching course materials for student: " . $e->getMessage());
        $message = "Error loading materials. Please try again later.";
        $messageType = "danger";
    }
} else {
    $message = "Please select a course to view materials.";
    $messageType = "info";
}

// Function to get file extension
function getFileExtension($filename) {
    return strtolower(pathinfo($filename, PATHINFO_EXTENSION));
}

// Function to determine if file is viewable
function isViewableDocument($extension) {
    $viewable_docs = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'txt'];
    return in_array($extension, $viewable_docs);
}

// Function to determine if file is a video
function isVideoFile($extension) {
    $video_extensions = ['mp4', 'webm', 'mov', 'avi', 'mkv', 'wmv'];
    return in_array($extension, $video_extensions);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $course_name; ?> - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/student.css">
    <link rel="stylesheet" href="../assets/css/student-materials.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .material-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
            flex-wrap: wrap;
        }
        
        .btn-play {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            font-size: 14px;
        }
        
        .btn-play:hover {
            background-color: #218838;
            color: white;
            text-decoration: none;
        }
        
        .btn-view {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            font-size: 14px;
        }
        
        .btn-view:hover {
            background-color: #0056b3;
            color: white;
            text-decoration: none;
        }
        
        .btn-download {
            background-color: #6c757d;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            font-size: 14px;
        }
        
        .btn-download:hover {
            background-color: #545b62;
            color: white;
            text-decoration: none;
        }

        /* Modal styles for video player */
        .video-modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.8);
        }

        .video-modal-content {
            position: relative;
            margin: 5% auto;
            width: 80%;
            max-width: 800px;
            background-color: #000;
            border-radius: 8px;
            overflow: hidden;
        }

        .video-modal video {
            width: 100%;
            height: auto;
        }

        .video-modal-close {
            position: absolute;
            top: 10px;
            right: 20px;
            color: white;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            z-index: 1001;
        }

        .video-modal-close:hover {
            opacity: 0.7;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/student-sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1><?php echo $course_name; ?></h1>
                <a href="my-courses.php" class="btn btn-secondary btn-sm">Back to My Courses</a>
            </div>
            
            <?php if (!empty($message)): ?>
                <div class="alert alert-<?php echo $messageType === 'success' ? 'success' : ($messageType === 'info' ? 'info' : 'error'); ?>">
                    <i class="fas fa-<?php echo $messageType === 'success' ? 'check-circle' : ($messageType === 'info' ? 'info-circle' : 'exclamation-circle'); ?>"></i>
                    <span><?php echo $message; ?></span>
                </div>
            <?php endif; ?>

            <?php if ($course_id > 0 && !empty($materials)): ?>
                <div class="materials-list-container">
                    <?php foreach ($materials as $material): ?>
                        <?php 
                        $file_extension = getFileExtension($material['file_path']);
                        $file_url = '../' . htmlspecialchars($material['file_path']);
                        $is_video = isVideoFile($file_extension);
                        $is_viewable_doc = isViewableDocument($file_extension);
                        ?>
                        <div class="material-card">
                            <div class="material-header">
                                <h3 class="material-title"><?php echo htmlspecialchars($material['title']); ?></h3>
                                <span class="material-date">Uploaded: <?php echo date('M d, Y', strtotime($material['created_at'])); ?></span>
                            </div>
                            <?php if (!empty($material['description'])): ?>
                            <div class="material-description">
                                <p><?php echo htmlspecialchars($material['description']); ?></p>
                            </div>
                            <?php endif; ?>
                            <div class="material-details">
                                <div class="detail-item"><strong>Type:</strong> <?php echo htmlspecialchars(ucfirst($material['material_type'])); ?></div>
                                <div class="detail-item"><strong>File:</strong> <?php echo basename($material['file_path']); ?></div>
                                <div class="detail-item"><strong>Format:</strong> <?php echo strtoupper($file_extension); ?></div>
                                <?php if (!empty($material['uploaded_by_name'])): ?>
                                <div class="detail-item"><strong>Uploaded by:</strong> <?php echo htmlspecialchars($material['uploaded_by_name']); ?></div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="material-actions">
                                <?php if ($is_video): ?>
                                    <!-- Play button for videos -->
                                    <button class="btn-play" onclick="openVideoModal('<?php echo $file_url; ?>', '<?php echo htmlspecialchars($material['title']); ?>')">
                                        <i class="fas fa-play"></i> Play
                                    </button>
                                    <a href="<?php echo $file_url; ?>" target="_blank" class="btn-play">
                                        <i class="fas fa-external-link-alt"></i> Open in New Tab
                                    </a>
                                <?php elseif ($is_viewable_doc): ?>
                                    <!-- View button for documents -->
                                    <a href="<?php echo $file_url; ?>" target="_blank" class="btn-view">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                    <?php if ($file_extension === 'pdf'): ?>
                                        <button class="btn-view" onclick="openPdfModal('<?php echo $file_url; ?>', '<?php echo htmlspecialchars($material['title']); ?>')">
                                            <i class="fas fa-expand"></i> View in Modal
                                        </button>
                                    <?php endif; ?>
                                <?php endif; ?>
                                
                                <!-- Download button (always available) -->
                                <a href="<?php echo $file_url; ?>" class="btn-download" download>
                                    <i class="fas fa-download"></i> Download
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php elseif ($course_id > 0): ?>
                <div class="empty-state">
                    <i class="fas fa-folder-open"></i>
                    <h3>No Materials Available</h3>
                    <p>There are no course materials uploaded for this course yet.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Video Modal -->
    <div id="videoModal" class="video-modal">
        <div class="video-modal-content">
            <span class="video-modal-close" onclick="closeVideoModal()">&times;</span>
            <video id="modalVideo" controls>
                <source src="" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        </div>
    </div>

    <!-- PDF Modal -->
    <div id="pdfModal" class="video-modal">
        <div class="video-modal-content" style="background-color: white; height: 80vh;">
            <span class="video-modal-close" onclick="closePdfModal()" style="color: black;">&times;</span>
            <iframe id="modalPdf" src="" style="width: 100%; height: 100%; border: none;"></iframe>
        </div>
    </div>

    <script src="../assets/js/theme.js"></script>
    <script>
        // Video modal functions
        function openVideoModal(videoUrl, title) {
            const modal = document.getElementById('videoModal');
            const video = document.getElementById('modalVideo');
            const source = video.querySelector('source');
            
            source.src = videoUrl;
            video.load();
            modal.style.display = 'block';
            
            // Pause video when modal is closed
            modal.onclick = function(event) {
                if (event.target === modal) {
                    closeVideoModal();
                }
            }
        }

        function closeVideoModal() {
            const modal = document.getElementById('videoModal');
            const video = document.getElementById('modalVideo');
            
            video.pause();
            video.currentTime = 0;
            modal.style.display = 'none';
        }

        // PDF modal functions
        function openPdfModal(pdfUrl, title) {
            const modal = document.getElementById('pdfModal');
            const iframe = document.getElementById('modalPdf');
            
            iframe.src = pdfUrl;
            modal.style.display = 'block';
            
            // Close modal when clicking outside
            modal.onclick = function(event) {
                if (event.target === modal) {
                    closePdfModal();
                }
            }
        }

        function closePdfModal() {
            const modal = document.getElementById('pdfModal');
            const iframe = document.getElementById('modalPdf');
            
            iframe.src = '';
            modal.style.display = 'none';
        }

        // Close modals with Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                closeVideoModal();
                closePdfModal();
            }
        });
    </script>
</body>
</html>
