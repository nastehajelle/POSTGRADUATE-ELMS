<?php
session_start();
include_once '../config/init.php';
include_once '../config/access_control.php';

// Check if user is logged in and is a student
if (!is_logged_in() || !is_student()) {
    header("Location: ../auth/login.php");
    exit();
}

$student_id = $_SESSION['user_id'];
$enrolled_courses = [];

$has_view_only_access = student_has_view_only_access($conn, $student_id);
$can_access_academic_features = student_can_access_academic_features($conn, $student_id);
$has_course_access = student_has_course_access($conn, $student_id);

try {
    if ($has_view_only_access) {
        // Graduated students can see all their historical courses
        $query = "SELECT DISTINCT 
            c.id, c.code, c.name, c.credit_hours, c.description,
            d.name AS department_name, 
            p.name AS program_name, 
            s.name AS semester_name,
            b.name AS batch_name, 
            b.status AS batch_status,
            st.status AS student_status,
            CONCAT(u.full_name, ' (', u.email, ')') AS instructor_name
        FROM course c
        LEFT JOIN departments d ON c.department_id = d.id
        LEFT JOIN programs p ON c.program_id = p.id
        LEFT JOIN semester s ON c.semester_id = s.id
        LEFT JOIN batch b ON c.batch_id = b.id
        LEFT JOIN users u ON c.instructor_id = u.id
        JOIN enrollment e ON e.user_id = ?
        JOIN students st ON st.user_id = ?
        WHERE (c.batch_id = e.batch_id OR c.batch_id = st.previous_batch_id)
          AND c.program_id = e.program_id
          AND c.department_id = e.department_id
        ORDER BY c.name";
    } elseif ($can_access_academic_features) {
        // Active/Transfer students see only current active courses
        $query = "SELECT DISTINCT 
            c.id, c.code, c.name, c.credit_hours, c.description,
            d.name AS department_name, 
            p.name AS program_name, 
            s.name AS semester_name,
            b.name AS batch_name, 
            b.status AS batch_status,
            st.status AS student_status,
            CONCAT(u.full_name, ' (', u.email, ')') AS instructor_name
        FROM course c
        LEFT JOIN departments d ON c.department_id = d.id
        LEFT JOIN programs p ON c.program_id = p.id
        LEFT JOIN semester s ON c.semester_id = s.id
        LEFT JOIN batch b ON c.batch_id = b.id
        LEFT JOIN users u ON c.instructor_id = u.id
        JOIN enrollment e ON e.user_id = ?
        JOIN students st ON st.user_id = ?
        WHERE c.status = 'active'
          AND s.status = 'active'
          AND b.status = 'active'
          AND st.status IN ('active', 'transfer')
          AND c.batch_id = e.batch_id
          AND c.program_id = e.program_id
          AND c.department_id = e.department_id
        ORDER BY c.name";
    } else {
        // Restricted students see no courses
        $enrolled_courses = [];
    }

    if (!empty($query)) {
        $stmt = $conn->prepare($query);
        $stmt->execute([$student_id, $student_id]);
        $enrolled_courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

} catch (PDOException $e) {
    error_log("Database error fetching student courses: " . $e->getMessage());
    $message = "Error loading your courses. Please try again later.";
    $messageType = "danger";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $has_view_only_access ? 'Course History' : 'My Courses'; ?> - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/student.css">
    <link rel="stylesheet" href="../assets/css/student-courses.css">
    <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/student-sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1><?php echo $has_view_only_access ? 'Course History' : 'My Courses'; ?></h1>
                <!-- Added status indicator -->
                <?php if ($has_view_only_access): ?>
                    <div class="status-indicator graduated">
                        <i class="fas fa-graduation-cap"></i>
                        <span>Graduated - View Only Access</span>
                    </div>
                <?php elseif (!$can_access_academic_features): ?>
                    <div class="status-indicator restricted">
                        <i class="fas fa-lock"></i>
                        <span>Academic Access Restricted</span>
                    </div>
                <?php endif; ?>
            </div>
            
            <?php if (!empty($message)): ?>
                <div class="message <?php echo $messageType; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <div class="courses-list-container">
                <?php if (!empty($enrolled_courses)): ?>
                    <?php foreach ($enrolled_courses as $course): ?>
                        <div class="course-card">
                            <div class="course-header">
                                <h3 class="course-title"><?php echo htmlspecialchars($course['name']); ?> (<?php echo htmlspecialchars($course['code']); ?>)</h3>
                                <span class="course-credits"><?php echo htmlspecialchars($course['credit_hours']); ?> Credits</span>
                            </div>
                            <div class="course-details">
                                <div class="detail-item"><strong>Instructor:</strong> <?php echo htmlspecialchars($course['instructor_name'] ?? 'N/A'); ?></div>
                                <div class="detail-item"><strong>Department:</strong> <?php echo htmlspecialchars($course['department_name'] ?? 'N/A'); ?></div>
                                <div class="detail-item"><strong>Program:</strong> <?php echo htmlspecialchars($course['program_name'] ?? 'N/A'); ?></div>
                                <div class="detail-item"><strong>Batch:</strong> <?php echo htmlspecialchars($course['batch_name'] ?? 'N/A'); ?></div>
                                <div class="detail-item"><strong>Semester:</strong> <?php echo htmlspecialchars($course['semester_name'] ?? 'N/A'); ?></div>
                                <!-- Added batch status indicator -->
                                <div class="detail-item">
                                    <strong>Batch Status:</strong> 
                                    <span class="status-badge <?php echo $course['batch_status']; ?>">
                                        <?php echo ucfirst($course['batch_status']); ?>
                                    </span>
                                </div>
                                <!-- Added student status indicator -->
                                <div class="detail-item">
                                    <strong>Student Status:</strong> 
                                    <span class="status-badge <?php echo $course['student_status']; ?>">
                                        <?php echo ucfirst($course['student_status']); ?>
                                    </span>
                                </div>
                            </div>
                            <?php if (!empty($course['description'])): ?>
                                <div class="course-description">
                                    <strong>Description:</strong> <?php echo nl2br(htmlspecialchars($course['description'])); ?>
                                </div>
                            <?php endif; ?>
                            <div class="course-actions">
                                <?php if ($has_view_only_access): ?>
                                    <button class="btn btn-secondary btn-sm" disabled>
                                        <i class="fas fa-eye"></i> View Only
                                    </button>
                                <?php elseif ($can_access_academic_features): ?>
                                    <a href="course-materials.php?course_id=<?php echo $course['id']; ?>" class="btn btn-primary btn-sm">View Materials</a>
                                <?php else: ?>
                                    <button class="btn btn-secondary btn-sm" disabled>
                                        <i class="fas fa-lock"></i> Access Restricted
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-book"></i>
                        <h3><?php echo $has_view_only_access ? 'No Course History' : 'No Active Courses Available'; ?></h3>
                        <p>
                            <?php if ($has_view_only_access): ?>
                                No course history found for your academic record.
                            <?php elseif (!$can_access_academic_features): ?>
                                Your current student status restricts access to courses. Please contact your academic advisor.
                            <?php else: ?>
                                You currently have no courses available. This may be because your batch is inactive, your student status is inactive, or you are not enrolled in any active courses. Please contact your academic advisor.
                            <?php endif; ?>
                        </p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script src="../assets/js/theme.js"></script>
</body>
</html>
