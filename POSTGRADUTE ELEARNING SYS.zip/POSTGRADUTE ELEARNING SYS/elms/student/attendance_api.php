<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is a student
if (!is_logged_in() || !is_student()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax']) && $_POST['action'] === 'get_student_attendance_report') {
    $student_id = $_SESSION['user_id'];
    $course_id = $_POST['course_id'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $mode = $_POST['mode'] ?? 'overall';
    
    try {
        // Get course information
        $course_query = "SELECT c.*, b.name as batch_name 
                        FROM course c 
                        LEFT JOIN batch b ON c.batch_id = b.id 
                        WHERE c.id = ?";
        $course_stmt = $conn->prepare($course_query);
        $course_stmt->execute([$course_id]);
        $course_info = $course_stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$course_info) {
            echo json_encode(['success' => false, 'message' => 'Course not found']);
            exit();
        }
        
        // Check if student is enrolled in this course
        $enrollment_query = "SELECT 1 FROM enrollment e 
                            WHERE e.user_id = ? 
                            AND (e.course_id = ? OR e.batch_id = ? OR e.program_id = ? OR e.department_id = ?)";
        $enrollment_stmt = $conn->prepare($enrollment_query);
        $enrollment_stmt->execute([$student_id, $course_id, $course_info['batch_id'], $course_info['program_id'], $course_info['department_id']]);
        
        if (!$enrollment_stmt->fetch()) {
            echo json_encode(['success' => false, 'message' => 'You are not enrolled in this course']);
            exit();
        }
        
        // Get attendance records for the student in the specified date range
        $attendance_query = "SELECT a.*, c.name as course_name, c.code as course_code
                            FROM attendance a
                            JOIN course c ON a.course_id = c.id
                            WHERE a.student_id = ? 
                            AND a.course_id = ? 
                            AND a.date BETWEEN ? AND ?
                            ORDER BY a.date DESC";
        
        $attendance_stmt = $conn->prepare($attendance_query);
        $attendance_stmt->execute([$student_id, $course_id, $start_date, $end_date]);
        $attendance_records = $attendance_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Calculate summary statistics based on ACTUAL attendance records only
        $total_records = count($attendance_records);
        $present_days = 0;
        $absent_days = 0;
        $late_days = 0;
        $excused_days = 0;

        // Count attendance by status from actual records
        foreach ($attendance_records as $record) {
            switch ($record['status']) {
                case 'present':
                    $present_days++;
                    break;
                case 'absent':
                    $absent_days++;
                    break;
                case 'late':
                    $late_days++;
                    break;
                case 'excused':
                    $excused_days++;
                    break;
            }
        }

        // Calculate attendance percentage based on actual records only
        // (present + late + excused as attended)
        $attended_days = $present_days + $late_days + $excused_days;
        $attendance_percentage = $total_records > 0 ? round(($attended_days / $total_records) * 100, 2) : 0;

        // Calculate total working hours based on actual attendance records
        $hours_per_day = $course_info['credit_hours'] ?? 2; // Default to 2 hours per day
        $total_hours = $total_records * $hours_per_day;

        $summary = [
            'total_days' => $total_records, // Only days with actual attendance records
            'present_days' => $present_days,
            'absent_days' => $absent_days,
            'late_days' => $late_days,
            'excused_days' => $excused_days,
            'attendance_percentage' => $attendance_percentage,
            'total_hours' => $total_hours
        ];
        
        echo json_encode([
            'success' => true,
            'data' => [
                'summary' => $summary,
                'attendance_records' => $attendance_records,
                'course_info' => $course_info,
                'date_range' => [
                    'start' => $start_date,
                    'end' => $end_date
                ]
            ]
        ]);
        
    } catch (PDOException $e) {
        error_log("Database error in attendance report: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Database error occurred']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
}
?>
