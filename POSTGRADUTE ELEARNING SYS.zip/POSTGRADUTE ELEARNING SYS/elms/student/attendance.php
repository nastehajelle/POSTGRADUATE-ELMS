<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is a student
if (!is_logged_in() || !is_student()) {
    header("Location: ../auth/login.php");
    exit();
}

$student_id = $_SESSION['user_id'];
$enrolled_courses = [];
$message = '';
$messageType = '';

try {
    // Fetch student info for display
    $student_query = "SELECT u.full_name, e.student_id as admission_no 
                      FROM users u 
                      JOIN enrollment e ON u.id = e.user_id 
                      WHERE u.id = ?";
    $student_stmt = $conn->prepare($student_query);
    $student_stmt->execute([$student_id]);
    $student_info = $student_stmt->fetch(PDO::FETCH_ASSOC);

    // Fetch courses the student is enrolled in **batch-kiisa kaliya**
$courses_query = "SELECT DISTINCT c.id, c.code, c.name, b.name as batch_name
                  FROM course c
                  LEFT JOIN batch b ON c.batch_id = b.id
                  JOIN enrollment e 
                    ON e.user_id = ? 
                    AND e.batch_id = c.batch_id
                  WHERE c.status = 'active'
                  ORDER BY c.name";

    $courses_stmt = $conn->prepare($courses_query);
    $courses_stmt->execute([$student_id]);
    $enrolled_courses = $courses_stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log("Database error fetching student courses for attendance: " . $e->getMessage());
    $message = "Error loading courses for attendance. Please try again later.";
    $messageType = "danger";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Attendance - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/student.css">
    <link rel="stylesheet" href="../assets/css/attendance.css">
    <?php echo FONT_AWESOME_CSS; ?>
    <style>
        .student-info-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        .info-item {
            display: flex;
            flex-direction: column;
        }
        .info-item label {
            font-weight: bold;
            color: #495057;
            margin-bottom: 5px;
        }
        .info-item span, .info-item select, .info-item input {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            background: white;
        }
        .attendance-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        .summary-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-align: center;
        }
        .summary-card h4 {
            margin: 0 0 10px 0;
            color: #495057;
            font-size: 14px;
        }
        .summary-card .value {
            font-size: 24px;
            font-weight: bold;
            color: #007bff;
        }
        .leave-details {
            margin-top: 20px;
        }
        .no-reports-message {
            text-align: center;
            padding: 40px;
            background: #f8f9fa;
            border-radius: 8px;
            color: #6c757d;
            font-style: italic;
        }
        .mode-selector {
            display: flex;
            gap: 10px;
            margin-bottom: 15px;
        }
        .mode-selector input[type="radio"] {
            margin-right: 5px;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/student-sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>My Attendance Report</h1>
            </div>
            
            <?php if (!empty($message)): ?>
                <div class="message <?php echo $messageType; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <!-- Student Information Section -->
                    <div class="student-info-section">
                        <h3>Student Information</h3>
                        <div class="info-grid">
                            <div class="info-item">
                                <label>Name:</label>
                                <span><?php echo htmlspecialchars($student_info['full_name'] ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <label>Admission No:</label>
                                <span><?php echo htmlspecialchars($student_info['admission_no'] ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <label for="report_course_id">Subject:</label>
                                <select id="report_course_id" required>
                                    <option value="">Select Course</option>
                                    <?php foreach ($enrolled_courses as $course): ?>
                                        <option value="<?php echo $course['id']; ?>">
                                            <?php echo htmlspecialchars($course['code'] . ' - ' . $course['name'] . ' (' . $course['batch_name'] . ')'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="info-grid">
                            <div class="info-item">
                                <label>Mode:</label>
                                <div class="mode-selector">
                                    <label><input type="radio" name="report_mode" value="overall" checked> Overall</label>
                                    <label><input type="radio" name="report_mode" value="monthly"> Monthly</label>
                                </div>
                            </div>
                            <div class="info-item" id="monthYearSelector" style="display: none;">
                                <label for="month_year">Month & Year:</label>
                                <input type="month" id="month_year">
                            </div>
                        </div>
                        
                        <div class="info-grid" id="dateRangeSelector">
                            <div class="info-item">
                                <label for="start_date">Start Date:</label>
                                <input type="date" id="start_date" required>
                            </div>
                            <div class="info-item">
                                <label for="end_date">End Date:</label>
                                <input type="date" id="end_date" required>
                            </div>
                        </div>
                        
                        <div class="form-actions">
                            <button class="btn btn-primary" id="generateReportBtn">Generate Report</button>
                        </div>
                    </div>
                    
                    <!-- Report Results Section -->
                    <div id="attendanceReport" class="attendance-report" style="display: none;">
                        <!-- Attendance Summary -->
                        <div class="attendance-summary" id="attendanceSummary"></div>
                        
                        <!-- Leave Details -->
                        <div class="leave-details">
                            <h3>Leave Details</h3>
                            <div id="leaveDetailsContent"></div>
                        </div>
                        
                        <div class="form-actions">
                            <button class="btn btn-secondary" id="printReportBtn">Print Report</button>
                            <button class="btn btn-primary" id="exportReportBtn">Export to CSV</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // DOM Elements
        const reportCourseSelect = document.getElementById('report_course_id');
        const startDate = document.getElementById('start_date');
        const endDate = document.getElementById('end_date');
        const monthYear = document.getElementById('month_year');
        const generateReportBtn = document.getElementById('generateReportBtn');
        const attendanceReport = document.getElementById('attendanceReport');
        const attendanceSummary = document.getElementById('attendanceSummary');
        const leaveDetailsContent = document.getElementById('leaveDetailsContent');
        const printReportBtn = document.getElementById('printReportBtn');
        const exportReportBtn = document.getElementById('exportReportBtn');
        const modeRadios = document.querySelectorAll('input[name="report_mode"]');
        const monthYearSelector = document.getElementById('monthYearSelector');
        const dateRangeSelector = document.getElementById('dateRangeSelector');
        
        // Show alert message
        function showAlert(message, type = 'success') {
            const alert = document.createElement('div');
            alert.className = `alert alert-${type}`;
            alert.textContent = message;
            alert.style.cssText = 'position: fixed; top: 20px; right: 20px; z-index: 1000; padding: 15px; border-radius: 4px; color: white; font-weight: bold;';
            
            if (type === 'success') alert.style.backgroundColor = '#28a745';
            else if (type === 'danger') alert.style.backgroundColor = '#dc3545';
            else if (type === 'warning') alert.style.backgroundColor = '#ffc107';
            
            document.body.appendChild(alert);
            
            setTimeout(() => {
                alert.remove();
            }, 5000);
        }
        
        // Handle mode change
        modeRadios.forEach(radio => {
            radio.addEventListener('change', function() {
                if (this.value === 'monthly') {
                    monthYearSelector.style.display = 'block';
                    dateRangeSelector.style.display = 'none';
                } else {
                    monthYearSelector.style.display = 'none';
                    dateRangeSelector.style.display = 'block';
                }
            });
        });
        
        // Generate attendance report
        generateReportBtn.addEventListener('click', function() {
            const courseId = reportCourseSelect.value;
            const mode = document.querySelector('input[name="report_mode"]:checked').value;
            
            if (!courseId) {
                showAlert('Please select a course', 'danger');
                return;
            }
            
            let startDateValue, endDateValue;
            
            if (mode === 'monthly') {
                if (!monthYear.value) {
                    showAlert('Please select month and year', 'danger');
                    return;
                }
                const [year, month] = monthYear.value.split('-');
                startDateValue = `${year}-${month}-01`;
                const lastDay = new Date(year, month, 0).getDate();
                endDateValue = `${year}-${month}-${lastDay.toString().padStart(2, '0')}`;
            } else {
                startDateValue = startDate.value;
                endDateValue = endDate.value;
                
                if (!startDateValue || !endDateValue) {
                    showAlert('Please select start and end dates', 'danger');
                    return;
                }
                
                if (new Date(startDateValue) > new Date(endDateValue)) {
                    showAlert('Start date cannot be after end date', 'danger');
                    return;
                }
            }
            
            // Disable button and show loading
            generateReportBtn.disabled = true;
            generateReportBtn.textContent = 'Generating...';
            
            // Prepare form data
            const formData = new FormData();
            formData.append('ajax', 1);
            formData.append('action', 'get_student_attendance_report');
            formData.append('course_id', courseId);
            formData.append('student_id', <?php echo $student_id; ?>);
            formData.append('start_date', startDateValue);
            formData.append('end_date', endDateValue);
            formData.append('mode', mode);
            
            // Send AJAX request
            fetch('attendance_api.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                generateReportBtn.disabled = false;
                generateReportBtn.textContent = 'Generate Report';
                
                if (data.success) {
                    displayAttendanceReport(data.data);
                    attendanceReport.style.display = 'block';
                } else {
                    showAlert(data.message || 'Error generating report', 'danger');
                    attendanceReport.style.display = 'none';
                }
            })
            .catch(error => {
                generateReportBtn.disabled = false;
                generateReportBtn.textContent = 'Generate Report';
                showAlert('An error occurred while generating the report', 'danger');
                console.error(error);
            });
        });
        
        function displayAttendanceReport(data) {
            const { summary, attendance_records, course_info } = data;
            
            // Display attendance summary
            attendanceSummary.innerHTML = `
                <div class="summary-card">
                    <h4>Total Working Hours</h4>
                    <div class="value">${summary.total_hours}</div>
                    <small>Based on recorded days</small>
                </div>
                <div class="summary-card">
                    <h4>Applicable Days</h4>
                    <div class="value">${summary.total_days}</div>
                    <small>Days with attendance records</small>
                </div>
                <div class="summary-card">
                    <h4>Present Days</h4>
                    <div class="value">${summary.present_days}</div>
                </div>
                <div class="summary-card">
                    <h4>Absent Days</h4>
                    <div class="value">${summary.absent_days}</div>
                </div>
                <div class="summary-card">
                    <h4>Attendance Percentage</h4>
                    <div class="value">${summary.attendance_percentage}%</div>
                    <small>Based on recorded attendance</small>
                </div>
            `;
            
            // Display leave details
            if (attendance_records && attendance_records.length > 0) {
                const absentRecords = attendance_records.filter(record => record.status === 'absent');
                
                if (absentRecords.length > 0) {
                    let leaveDetailsHtml = `
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Subject</th>
                                    <th>Class Timing</th>
                                    <th>Remarks</th>
                                </tr>
                            </thead>
                            <tbody>
                    `;
                    
                    absentRecords.forEach(record => {
                        leaveDetailsHtml += `
                            <tr>
                                <td>${new Date(record.date).toLocaleDateString()}</td>
                                <td>${course_info.code} - ${course_info.name}</td>
                                <td>${record.class_timing || 'N/A'}</td>
                                <td>${record.remarks || 'No remarks'}</td>
                            </tr>
                        `;
                    });
                    
                    leaveDetailsHtml += `
                            </tbody>
                        </table>
                    `;
                    
                    leaveDetailsContent.innerHTML = leaveDetailsHtml;
                } else {
                    leaveDetailsContent.innerHTML = `
                        <div class="no-reports-message">
                            <i class="fas fa-check-circle" style="font-size: 48px; color: #28a745; margin-bottom: 15px;"></i>
                            <h4>Excellent Attendance!</h4>
                            <p>No reports for the given period. You have perfect attendance!</p>
                        </div>
                    `;
                }
            } else {
                leaveDetailsContent.innerHTML = `
                    <div class="no-reports-message">
                        <i class="fas fa-info-circle" style="font-size: 48px; color: #6c757d; margin-bottom: 15px;"></i>
                        <h4>No Records Found</h4>
                        <p>No reports for the given period.</p>
                    </div>
                `;
            }
        }
        
        // Print report functionality
        printReportBtn.addEventListener('click', function() {
            const courseText = reportCourseSelect.options[reportCourseSelect.selectedIndex].text;
            const studentName = "<?php echo htmlspecialchars($student_info['full_name'] ?? ''); ?>";
            const admissionNo = "<?php echo htmlspecialchars($student_info['admission_no'] ?? ''); ?>";
            
            const printWindow = window.open('', '_blank');
            printWindow.document.write(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Attendance Report - ${studentName}</title>
                    <style>
                        body { font-family: Arial, sans-serif; margin: 20px; }
                        .header { text-align: center; margin-bottom: 30px; }
                        .student-info { margin-bottom: 20px; }
                        .summary { display: flex; justify-content: space-around; margin: 20px 0; }
                        .summary-item { text-align: center; }
                        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                        th { background-color: #f2f2f2; }
                        .no-reports { text-align: center; padding: 20px; font-style: italic; }
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>Student Attendance Report</h1>
                        <h2>Benadir University</h2>
                    </div>
                    <div class="student-info">
                        <p><strong>Name:</strong> ${studentName}</p>
                        <p><strong>Admission No:</strong> ${admissionNo}</p>
                        <p><strong>Course:</strong> ${courseText}</p>
                    </div>
                    ${attendanceSummary.outerHTML}
                    <h3>Leave Details</h3>
                    ${leaveDetailsContent.innerHTML}
                </body>
                </html>
            `);
            printWindow.document.close();
            printWindow.print();
        });
        
        // Export to CSV functionality
        exportReportBtn.addEventListener('click', function() {
            const studentName = "<?php echo htmlspecialchars($student_info['full_name'] ?? ''); ?>";
            const courseText = reportCourseSelect.options[reportCourseSelect.selectedIndex].text;
            
            let csvContent = `Student Attendance Report\n`;
            csvContent += `Name: ${studentName}\n`;
            csvContent += `Course: ${courseText}\n\n`;
            
            // Add summary data
            const summaryCards = attendanceSummary.querySelectorAll('.summary-card');
            summaryCards.forEach(card => {
                const title = card.querySelector('h4').textContent;
                const value = card.querySelector('.value').textContent;
                csvContent += `${title}: ${value}\n`;
            });
            
            csvContent += `\nLeave Details\n`;
            const table = leaveDetailsContent.querySelector('table');
            if (table) {
                csvContent += `Date,Subject,Class Timing,Remarks\n`;
                const rows = table.querySelectorAll('tbody tr');
                rows.forEach(row => {
                    const cells = row.querySelectorAll('td');
                    const rowData = Array.from(cells).map(cell => cell.textContent.trim()).join(',');
                    csvContent += `${rowData}\n`;
                });
            } else {
                csvContent += `No absent records found\n`;
            }
            
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.setAttribute('href', url);
            link.setAttribute('download', `attendance_report_${studentName.replace(/\s/g, '_')}.csv`);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        });
        
        // Set default dates
        const today = new Date();
        const oneMonthAgo = new Date();
        oneMonthAgo.setMonth(today.getMonth() - 1);
        
        startDate.value = oneMonthAgo.toISOString().split('T')[0];
        endDate.value = today.toISOString().split('T')[0];
        
        // Set default month/year to current month
        const currentMonth = today.toISOString().slice(0, 7);
        monthYear.value = currentMonth;
    });
    </script>
</body>
</html>
