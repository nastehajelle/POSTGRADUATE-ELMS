<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is a student
if (!is_logged_in() || !is_student()) {
    header("Location: ../auth/login.php");
    exit();
}

// Set default timezone
date_default_timezone_set('Africa/Mogadishu');

$student_id = $_SESSION['user_id'];
// Correctly retrieve assessment_id from the URL
$assessment_id = isset($_GET['assessment_id']) ? intval($_GET['assessment_id']) : 0;
$result_id = isset($_GET['result_id']) ? intval($_GET['result_id']) : 0; // Also retrieve result_id

if ($assessment_id <= 0 || $result_id <= 0) {
    // If either ID is missing or invalid, redirect back
    header("Location: assessments.php");
    exit();
}

$assessment = null;
$result = null;
$answers = [];
$questions = [];
$message = '';
$messageType = '';

try {
    // Get student's enrollment details for batch filtering
    $enrollment_query = "SELECT program_id, department_id, batch_id FROM enrollment WHERE user_id = ?";
    $enrollment_stmt = $conn->prepare($enrollment_query);
    $enrollment_stmt->execute([$student_id]);
    $enrollment = $enrollment_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$enrollment) {
        $message = "Enrollment information not found.";
        $messageType = "danger";
    } else {
        $student_batch_id = $enrollment['batch_id'];
        
        // Get assessment details
        $assessment_query = "SELECT a.*, c.name as course_name, c.code as course_code, 
                                    u.full_name as instructor_name, b.name as batch_name
                            FROM assessments a
                            LEFT JOIN course c ON a.course_id = c.id
                            LEFT JOIN users u ON a.created_by = u.id
                            LEFT JOIN batch b ON ? = b.id
                            WHERE a.id = ?";
        $assessment_stmt = $conn->prepare($assessment_query);
        $assessment_stmt->execute([$student_batch_id, $assessment_id]);
        $assessment = $assessment_stmt->fetch(PDO::FETCH_ASSOC);

        if (!$assessment) {
            $message = "Assessment not found.";
            $messageType = "danger";
        } else {
            // Get student's result using result_id for precision
            $result_query = "SELECT * FROM assessment_results WHERE id = ? AND assessment_id = ? AND student_id = ?";
            $result_stmt = $conn->prepare($result_query);
            $result_stmt->execute([$result_id, $assessment_id, $student_id]);
            $result = $result_stmt->fetch(PDO::FETCH_ASSOC);

            if (!$result) {
                $message = "No result found for this assessment with the provided ID.";
                $messageType = "warning";
            } else {
                // Get questions and answers with batch filtering
                $answers_query = "SELECT sa.*, aq.question_text, aq.question_type, aq.options, 
                                         aq.correct_answer, aq.marks as total_marks,
                                         c.name as course_name, c.code as course_code,
                                         b.name as batch_name
                                 FROM student_answers sa
                                 JOIN assessment_questions aq ON sa.question_id = aq.id
                                 LEFT JOIN course c ON aq.course_id = c.id
                                 LEFT JOIN batch b ON aq.batch_id = b.id
                                 WHERE sa.assessment_id = ? AND sa.student_id = ?
                                 AND (
                                     aq.batch_id = ? 
                                     OR (aq.batch_id IS NULL AND aq.course_id IS NULL)
                                     OR (aq.batch_id IS NULL AND aq.course_id IN (
                                         SELECT co.id FROM course co 
                                         WHERE co.program_id = ? AND co.department_id = ? AND co.batch_id = ?
                                     ))
                                 )
                                 ORDER BY aq.id";
                $answers_stmt = $conn->prepare($answers_query);
                $answers_stmt->execute([
                    $assessment_id, 
                    $student_id,
                    $student_batch_id,
                    $enrollment['program_id'], $enrollment['department_id'], $student_batch_id
                ]);
                $answers = $answers_stmt->fetchAll(PDO::FETCH_ASSOC);
            }
        }
    }

} catch (PDOException $e) {
    error_log("Database error in assessment-result: " . $e->getMessage());
    $message = "Database error occurred. Please try again later.";
    $messageType = "danger";
}

// Calculate statistics
$total_questions = count($answers);
$correct_answers = 0;
$partially_correct = 0;

foreach ($answers as $answer) {
    if ($answer['marks_obtained'] == $answer['total_marks']) {
        $correct_answers++;
    } elseif ($answer['marks_obtained'] > 0) {
        $partially_correct++;
    }
}

$percentage = $result ? (($result['marks_obtained'] / $assessment['total_marks']) * 100) : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assessment Result - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/student.css">
    <?php echo FONT_AWESOME_CSS; ?>
    <style>
        .result-header {
            background: var(--card-bg);
            padding: 30px;
            border-radius: 8px;
            margin-bottom: 30px;
            box-shadow: var(--shadow);
            text-align: center;
        }
        
        .result-title {
            font-size: 1.5rem;
            color: var(--text-color);
            margin-bottom: 10px;
        }
        
        .result-score {
            font-size: 3rem;
            font-weight: bold;
            margin: 20px 0;
        }
        
        .result-score.grade-a { color: #059669; }
        .result-score.grade-b { color: #0369a1; }
        .result-score.grade-c { color: #d97706; }
        .result-score.grade-d { color: #dc2626; }
        .result-score.grade-f { color: #991b1b; }
        
        .result-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }
        
        .detail-card {
            background: var(--bg-light);
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }
        
        .detail-number {
            font-size: 2rem;
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 5px;
        }
        
        .detail-label {
            font-size: 0.9rem;
            color: var(--text-muted);
        }
        
        .batch-info {
            background: #f0f9ff;
            color: #0369a1;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 500;
        }
        
        .answers-section {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 8px;
            box-shadow: var(--shadow);
            margin-top: 30px;
        }
        
        .answer-item {
            margin-bottom: 25px;
            padding: 20px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            background: var(--bg-light);
        }
        
        .answer-item.correct {
            border-left: 4px solid #059669;
            background: rgba(5, 150, 105, 0.05);
        }
        
        .answer-item.incorrect {
            border-left: 4px solid #dc2626;
            background: rgba(220, 38, 38, 0.05);
        }
        
        .answer-item.partial {
            border-left: 4px solid #d97706;
            background: rgba(217, 119, 6, 0.05);
        }
        
        .question-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }
        
        .question-number {
            background: var(--primary-color);
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.9rem;
        }
        
        .marks-display {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .marks-obtained {
            font-weight: 600;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.9rem;
        }
        
        .marks-obtained.full {
            background: #d1fae5;
            color: #059669;
        }
        
        .marks-obtained.partial {
            background: #fef3c7;
            color: #d97706;
        }
        
        .marks-obtained.zero {
            background: #fee2e2;
            color: #dc2626;
        }
        
        .question-text {
            font-size: 1rem;
            color: var(--text-color);
            margin: 15px 0;
            line-height: 1.6;
        }
        
        .question-source {
            font-size: 0.8rem;
            color: var(--text-muted);
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .answer-section {
            margin-top: 15px;
        }
        
        .answer-label {
            font-weight: 600;
            color: var(--text-color);
            margin-bottom: 8px;
            display: block;
        }
        
        .student-answer {
            background: var(--card-bg);
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 10px;
            border-left: 3px solid #6b7280;
        }
        
        .correct-answer {
            background: #f0fdf4;
            color: #166534;
            padding: 12px;
            border-radius: 6px;
            border-left: 3px solid #059669;
        }
        
        .action-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 30px;
        }
        
        .btn-action {
            padding: 12px 24px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
        }
        
        .btn-primary {
            background: var(--primary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background: var(--primary-dark);
            color: white;
            text-decoration: none;
        }
        
        .btn-secondary {
            background: var(--bg-secondary);
            color: var(--text-color);
            border: 1px solid var(--border-color);
        }
        
        .btn-secondary:hover {
            background: var(--hover-bg);
            text-decoration: none;
        }
        
        @media (max-width: 768px) {
            .result-details {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .action-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/student-sidebar.php'; ?>
        
        <div class="admin-content">
            <?php if (!empty($message)): ?>
                <div class="message <?php echo $messageType; ?>">
                    <?php echo $message; ?>
                    <div style="margin-top: 15px;">
                        <a href="assessments.php" class="btn btn-primary">Back to Assessments</a>
                    </div>
                </div>
            <?php elseif ($assessment && $result): ?>
                
                 Batch Information 
                <?php if (isset($enrollment['batch_id'])): ?>
                <div class="batch-info">
                    <i class="fas fa-users"></i>
                    <span>Result for Batch: <?php echo htmlspecialchars($assessment['batch_name'] ?? 'Unknown'); ?></span>
                </div>
                <?php endif; ?>
                
                 Result Header 
                <div class="result-header">
                    <h1 class="result-title"><?php echo htmlspecialchars($assessment['title']); ?></h1>
                    <div class="result-score grade-<?php echo strtolower($result['grade']); ?>">
                        <?php echo $result['marks_obtained']; ?>/<?php echo $assessment['total_marks']; ?>
                    </div>
                    <div style="font-size: 1.2rem; color: var(--text-muted);">
                        Grade: <strong><?php echo $result['grade']; ?></strong> 
                        (<?php echo number_format($percentage, 1); ?>%)
                    </div>
                    
                    <div class="result-details">
                        <div class="detail-card">
                            <div class="detail-number"><?php echo $total_questions; ?></div>
                            <div class="detail-label">Total Questions</div>
                        </div>
                        <div class="detail-card">
                            <div class="detail-number"><?php echo $correct_answers; ?></div>
                            <div class="detail-label">Correct Answers</div>
                        </div>
                        <div class="detail-card">
                            <div class="detail-number"><?php echo $partially_correct; ?></div>
                            <div class="detail-label">Partial Credit</div>
                        </div>
                        <div class="detail-card">
                            <div class="detail-number"><?php echo date('M j, Y', strtotime($result['submitted_at'])); ?></div>
                            <div class="detail-label">Submitted On</div>
                        </div>
                    </div>
                </div>

                 Detailed Answers 
                <?php if (!empty($answers)): ?>
                <div class="answers-section">
                    <h2><i class="fas fa-list-alt"></i> Detailed Review</h2>
                    
                    <?php foreach ($answers as $index => $answer): 
                        $is_correct = $answer['marks_obtained'] == $answer['total_marks'];
                        $is_partial = $answer['marks_obtained'] > 0 && $answer['marks_obtained'] < $answer['total_marks'];
                        $status_class = $is_correct ? 'correct' : ($is_partial ? 'partial' : 'incorrect');
                    ?>
                        <div class="answer-item <?php echo $status_class; ?>">
                            <div class="question-header">
                                <span class="question-number"><?php echo $index + 1; ?></span>
                                <div class="marks-display">
                                    <span class="marks-obtained <?php echo $is_correct ? 'full' : ($is_partial ? 'partial' : 'zero'); ?>">
                                        <?php echo $answer['marks_obtained']; ?>/<?php echo $answer['total_marks']; ?> marks
                                    </span>
                                </div>
                            </div>
                            
                            <?php if ($answer['course_name'] || $answer['batch_name']): ?>
                                <div class="question-source">
                                    <i class="fas fa-info-circle"></i>
                                    <?php if ($answer['course_name']): ?>
                                        Course: <?php echo htmlspecialchars($answer['course_name']); ?>
                                        <?php if ($answer['course_code']): ?>
                                            (<?php echo htmlspecialchars($answer['course_code']); ?>)
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if ($answer['batch_name']): ?>
                                        <?php echo $answer['course_name'] ? ' | ' : ''; ?>
                                        Batch: <?php echo htmlspecialchars($answer['batch_name']); ?>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                            
                            <div class="question-text">
                                <?php echo nl2br(htmlspecialchars($answer['question_text'])); ?>
                            </div>
                            
                            <div class="answer-section">
                                <span class="answer-label">Your Answer:</span>
                                <div class="student-answer">
                                    <?php if ($answer['question_type'] === 'mcq' || $answer['question_type'] === 'true_false'): ?>
                                        <?php echo htmlspecialchars($answer['answer_text']); ?>
                                    <?php else: ?>
                                        <?php echo nl2br(htmlspecialchars($answer['answer_text'])); ?>
                                    <?php endif; ?>
                                </div>
                                
                                <?php if ($answer['question_type'] === 'mcq' || $answer['question_type'] === 'true_false'): ?>
                                    <span class="answer-label">Correct Answer:</span>
                                    <div class="correct-answer">
                                        <?php echo htmlspecialchars($answer['correct_answer']); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
                
                 Action Buttons 
                <div class="action-buttons">
                    <a href="assessments.php" class="btn-action btn-primary">
                        <i class="fas fa-arrow-left"></i> Back to Assessments
                    </a>
                    <a href="javascript:window.print()" class="btn-action btn-secondary">
                        <i class="fas fa-print"></i> Print Result
                    </a>
                </div>
                
            <?php endif; ?>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
</body>
</html>
