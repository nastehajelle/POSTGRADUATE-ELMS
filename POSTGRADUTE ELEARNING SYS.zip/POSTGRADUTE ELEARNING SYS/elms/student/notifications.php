<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is a student
if (!is_logged_in() || !is_student()) {
    header("Location: ../auth/login.php");
    exit();
}

$student_id = $_SESSION['user_id'];
$notifications = [];
$message = '';
$messageType = '';

try {
    // Fetch notifications relevant to the student (global and personal)
$query = "SELECT id, title, message, target_audience, created_at, is_read
FROM notifications
WHERE TRIM(target_audience) IN ('all','students')
  AND is_active = 1
ORDER BY created_at DESC;
";


$stmt = $conn->prepare($query);
$stmt->execute();
$notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);


} catch (PDOException $e) {
    error_log("Database error fetching student notifications: " . $e->getMessage());
    $message = "Error loading notifications. Please try again later.";
    $messageType = "danger";
}

// Handle AJAX request to mark as read
if (isset($_POST['ajax']) && $_POST['ajax'] == 1 && $_POST['action'] == 'mark_as_read') {
    header('Content-Type: application/json');
    $notification_id = (int)$_POST['notification_id'];
    try {
        $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE id = ?");
        $stmt->execute([$notification_id]);
        echo json_encode(['success' => true, 'message' => 'Notification marked as read.']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error marking notification as read: ' . $e->getMessage()]);
    }
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Notifications - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/student.css">
    <link rel="stylesheet" href="../assets/css/notifications.css"> <!-- Reusing admin notifications styles -->
    <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/student-sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>My Notifications</h1>
            </div>
            
            <?php if (!empty($message)): ?>
                <div class="message <?php echo $messageType; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <div class="notifications-page-container">
                <?php if (!empty($notifications)): ?>
                    <?php foreach ($notifications as $notification): ?>
                        <div class="notification-item <?php echo $notification['is_read'] ? 'read' : 'unread'; ?>" data-id="<?php echo $notification['id']; ?>">
                            <div class="notification-icon">
                                <i class="fas fa-bell"></i>
                            </div>
                            <div class="notification-details">
                                <div class="notification-title"><?php echo htmlspecialchars($notification['title']); ?></div>
                                <div class="notification-message"><?php echo nl2br(htmlspecialchars($notification['message'])); ?></div>
                                <div class="notification-meta">
                                    <span class="notification-time"><?php echo date('M j, Y g:i A', strtotime($notification['created_at'])); ?></span>
                                    <?php if (!$notification['is_read']): ?>
                                        <button class="btn btn-sm btn-link mark-read-btn" data-id="<?php echo $notification['id']; ?>">Mark as Read</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-bell-slash"></i>
                        <h3>No Notifications</h3>
                        <p>You have no new notifications at the moment.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
    <script>
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('mark-read-btn')) {
        const button = e.target;
        const notificationId = button.getAttribute('data-id');
        const item = button.closest('.notification-item');

        fetch('notifications.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `ajax=1&action=mark_as_read&notification_id=${notificationId}`
        })
        .then(response => response.json())
        .then(data => {
            console.log(data); // Hubi response server
            if (data.success) {
                item.classList.remove('unread');
                item.classList.add('read');
                button.remove();
                alert(data.message); // Ku beddel showAlert si sahlan
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Fetch error:', error);
            alert('Failed to mark as read.');
        });
    }
});

    </script>
</body>
</html>
