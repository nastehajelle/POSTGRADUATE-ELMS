<?php
session_start();
include_once '../config/init.php';
include_once '../config/access_control.php';

// Define is_student() if not already defined
if (!function_exists('is_student')) {
    function is_student() {
        // Example logic: check if user role is 'student' in session
        return isset($_SESSION['role']) && $_SESSION['role'] === 'student';
    }
}

// Check if user is logged in and is a student
if (!is_logged_in() || !is_student()) {
    header("Location: ../auth/login.php");
    exit();
}

$student_id = $_SESSION['user_id'];

$student_status_info = get_student_status_info($conn, $student_id);
$has_view_only_access = student_has_view_only_access($conn, $student_id);
$can_access_academic_features = student_can_access_academic_features($conn, $student_id);
$has_course_access = student_has_course_access($conn, $student_id);

$status_notification = '';
if ($has_view_only_access) {
    $status_notification = [
        'type' => 'info',
        'message' => 'You have graduated and now have view-only access. You can view your academic records but cannot access active courses or submit new work.',
        'icon' => 'fa-graduation-cap'
    ];
} elseif (!$can_access_academic_features) {
    $status_notification = [
        'type' => 'warning', 
        'message' => 'Your student status restricts access to academic features. Please contact administration if you believe this is an error.',
        'icon' => 'fa-exclamation-triangle'
    ];
}

// Initialize variables with default values
$enrolled_courses_count = 0;
$upcoming_assessments_count = 0;
$total_assessments_count = 0;
$average_grade = 'N/A';
$attendance_percentage = 'N/A';
$upcoming_live_classes_count = 0;
$recent_grades = [];
$upcoming_events = [];
$recent_notifications = [];
$student_info = [];
$enrollment_info = [];
$attendance_data = [];
$attendance_labels = [];
$attendance_chart_data = [];

$thesis_submission_status = null;
$thesis_can_submit = false;
$thesis_status_message = '';
$thesis_status_type = 'info'; // success, warning, danger, info

try {
    // Get student's personal info and enrollment details
    // Using INNER JOIN to ensure student has a complete enrollment record
    $user_query = "SELECT u.full_name, u.email, u.gender, u.phone, u.address,
                   e.student_id, e.program_id, e.department_id, e.batch_id,
                   p.name as program_name, d.name as department_name, b.name as batch_name, b.year as batch_year,
                   b.status as batch_status, s.status as student_status
                   FROM users u
                   INNER JOIN enrollment e ON u.id = e.user_id
                   INNER JOIN programs p ON e.program_id = p.id
                   INNER JOIN departments d ON e.department_id = d.id
                   INNER JOIN batch b ON e.batch_id = b.id
                   INNER JOIN students s ON u.id = s.user_id
                   WHERE u.id = ?";
    $user_stmt = $conn->prepare($user_query);
    $user_stmt->execute([$student_id]);
    $student_info = $user_stmt->fetch(PDO::FETCH_ASSOC);

    // Extract enrollment IDs for filtering. If student_info is empty, these will be null.
    $student_program_id = $student_info['program_id'] ?? null;
    $student_department_id = $student_info['department_id'] ?? null;
    $student_batch_id = $student_info['batch_id'] ?? null;
    $enrollment_student_id = $student_info['student_id'] ?? null; // This is the actual student_id from enrollment table
    $batch_status = $student_info['batch_status'] ?? null;
    $student_status = $student_info['student_status'] ?? null;

    // Get active academic year and semester
    $active_academic_year_data = get_active_academic_year($conn);
    $active_academic_year = $active_academic_year_data ? $active_academic_year_data['name'] : 'N/A';
    $active_academic_year_id = $active_academic_year_data ? $active_academic_year_data['id'] : null;

    $active_semester_data = get_active_semester($conn, $active_academic_year_id);
    $active_semester = $active_semester_data ? $active_semester_data['name'] : 'N/A';

    if ($can_access_academic_features && $active_academic_year_data && $active_semester_data) {
        $thesis_settings_query = "SELECT * FROM thesis_submission_settings 
                                 WHERE academic_year_id = ? AND semester_id = ? AND status = 'active'";
        $thesis_settings_stmt = $conn->prepare($thesis_settings_query);
        $thesis_settings_stmt->execute([$active_academic_year_data['id'], $active_semester_data['id']]);
        $thesis_submission_status = $thesis_settings_stmt->fetch(PDO::FETCH_ASSOC);

        if ($thesis_submission_status) {
            // Check submission eligibility
            if ($thesis_submission_status['submission_mode'] === 'open_submission') {
                $thesis_can_submit = true;
                $thesis_status_message = "Thesis submission is currently open. You can submit your thesis at any time.";
                $thesis_status_type = 'success';
            } else {
                // Deadline-based submission
                $deadline = strtotime($thesis_submission_status['submission_deadline']);
                $now = time();
                
                if ($now <= $deadline) {
                    $thesis_can_submit = true;
                    $days_left = ceil(($deadline - $now) / (24 * 60 * 60));
                    $thesis_status_message = "Thesis submission is open. Deadline: " . date('M d, Y H:i', $deadline) . " ({$days_left} days remaining)";
                    $thesis_status_type = $days_left <= 7 ? 'warning' : 'success';
                } elseif ($thesis_submission_status['late_submission_allowed']) {
                    $thesis_can_submit = true;
                    $penalty_text = $thesis_submission_status['late_submission_penalty'] ? 
                                   " (Late penalty: {$thesis_submission_status['late_submission_penalty']}%)" : "";
                    $thesis_status_message = "Late thesis submission is allowed{$penalty_text}. Original deadline was: " . date('M d, Y H:i', $deadline);
                    $thesis_status_type = 'warning';
                } else {
                    $thesis_can_submit = false;
                    $thesis_status_message = "Thesis submission is closed. Deadline has passed: " . date('M d, Y H:i', $deadline);
                    $thesis_status_type = 'danger';
                }
            }

            // Check if student has reached maximum submissions
            $submission_count_query = "SELECT COUNT(*) as count FROM thesis WHERE student_id = ? AND academic_year_id = ? AND semester_id = ?";
            $count_stmt = $conn->prepare($submission_count_query);
            $count_stmt->execute([$student_id, $active_academic_year_data['id'], $active_semester_data['id']]);
            $submission_count = $count_stmt->fetch(PDO::FETCH_ASSOC)['count'];

            if ($submission_count >= $thesis_submission_status['max_submissions_per_student']) {
                $thesis_can_submit = false;
                $thesis_status_message = "You have reached the maximum number of thesis submissions ({$thesis_submission_status['max_submissions_per_student']}) for this academic session.";
                $thesis_status_type = 'info';
            }
        } else {
            $thesis_status_message = "Thesis submission is closed at the moment. No submission settings configured for the current academic session.";
            $thesis_status_type = 'info';
        }
    } else {
        $thesis_submission_status = null;
        $thesis_can_submit = false;
        if ($has_view_only_access) {
            $thesis_status_message = "Thesis submission is not available for graduated students. You can view your previous submissions in the thesis section.";
        } else {
            $thesis_status_message = "Thesis submission is not available due to your current student status.";
        }
        $thesis_status_type = 'info';
    }

    if ($can_access_academic_features && $student_info && $batch_status === 'active' && in_array($student_status, ['active', 'transfer'])) {
        // Count enrolled courses - only show if both batch and student are active
        $enrolled_courses_query = "
            SELECT COUNT(DISTINCT c.id) as count
            FROM course c
            INNER JOIN semester s ON c.semester_id = s.id
            INNER JOIN batch b ON c.batch_id = b.id
            WHERE s.status = 'active' AND b.status = 'active'
              AND (
                    (c.program_id = ? AND c.department_id = ? AND c.batch_id = ?)
                 OR (c.program_id IS NULL AND c.department_id IS NULL AND c.batch_id IS NULL)
              )
        ";

        $enrolled_courses_stmt = $conn->prepare($enrolled_courses_query);
        $enrolled_courses_stmt->execute([$student_program_id, $student_department_id, $student_batch_id]);
        $enrolled_courses_count = $enrolled_courses_stmt->fetch(PDO::FETCH_ASSOC)['count'];

        // Count upcoming assessments - only from active batches and for active students
        $upcoming_assessments_query = "SELECT COUNT(DISTINCT a.id) as count
                                       FROM assessments a
                                       LEFT JOIN course c ON a.course_id = c.id
                                       LEFT JOIN batch b ON c.batch_id = b.id
                                       WHERE a.end_time > NOW() AND a.status = 'active'
                                       AND (
                                           (a.program_id IS NULL AND a.department_id IS NULL AND a.course_id IS NULL) -- General assessment
                                           OR (a.program_id = ? AND a.department_id IS NULL AND a.course_id IS NULL) -- Program-specific
                                           OR (a.program_id = ? AND a.department_id = ? AND a.course_id IS NULL) -- Department-specific within program
                                           OR (EXISTS (
                                               SELECT 1 FROM course co
                                               INNER JOIN batch ba ON co.batch_id = ba.id
                                               WHERE co.id = a.course_id
                                               AND co.program_id = ? AND co.department_id = ? AND co.batch_id = ?
                                               AND ba.status = 'active'
                                           )) -- Course-specific from active batch only
                                       )";
        $upcoming_assessments_stmt = $conn->prepare($upcoming_assessments_query);
        $upcoming_assessments_stmt->execute([
            $student_program_id, // for program-specific
            $student_program_id, $student_department_id, // for department-specific
            $student_program_id, $student_department_id, $student_batch_id // for course-specific subquery
        ]);
        $upcoming_assessments_count = $upcoming_assessments_stmt->fetch(PDO::FETCH_ASSOC)['count'];

        // Count total assessments - only from active batches
        $total_assessments_query = "SELECT COUNT(DISTINCT a.id) as count
                                    FROM assessments a
                                    LEFT JOIN course c ON a.course_id = c.id
                                    LEFT JOIN batch b ON c.batch_id = b.id
                                    WHERE (
                                        (a.program_id IS NULL AND a.department_id IS NULL AND a.course_id IS NULL)
                                        OR (a.program_id = ? AND a.department_id IS NULL AND a.course_id IS NULL)
                                        OR (a.program_id = ? AND a.department_id = ? AND a.course_id IS NULL)
                                        OR (EXISTS (
                                            SELECT 1 FROM course co
                                            INNER JOIN batch ba ON co.batch_id = ba.id
                                            WHERE co.id = a.course_id
                                            AND co.program_id = ? AND co.department_id = ? AND co.batch_id = ?
                                            AND ba.status = 'active'
                                        ))
                                    )";
        $total_assessments_stmt = $conn->prepare($total_assessments_query);
        $total_assessments_stmt->execute([
            $student_program_id,
            $student_program_id, $student_department_id,
            $student_program_id, $student_department_id, $student_batch_id
        ]);
        $total_assessments_count = $total_assessments_stmt->fetch(PDO::FETCH_ASSOC)['count'];

        // Count upcoming live classes - only from active batches
        $upcoming_live_classes_query = "SELECT COUNT(DISTINCT lc.id) as count
                                FROM live_classes lc
                                INNER JOIN course c ON lc.course_id = c.id
                                INNER JOIN batch b ON c.batch_id = b.id
                                WHERE lc.scheduled_time > NOW() AND lc.status = 'scheduled'
                                AND c.program_id = ? AND c.department_id = ? AND c.batch_id = ?
                                AND b.status = 'active'";

        $upcoming_live_classes_stmt = $conn->prepare($upcoming_live_classes_query);
        $upcoming_live_classes_stmt->execute([$student_program_id, $student_department_id, $student_batch_id]);
        $upcoming_live_classes_count = $upcoming_live_classes_stmt->fetch(PDO::FETCH_ASSOC)['count'];

        // Get upcoming events - only from active batches
        $upcoming_events_query = "
            (SELECT 'Academic Event' as type, title, event_date as date, description
             FROM academic_events
             WHERE event_date >= CURDATE()
             ORDER BY event_date ASC
             LIMIT 5)
            UNION ALL
            (SELECT 'Assessment' as type, a.title, a.start_time as date, a.description
             FROM assessments a
             LEFT JOIN course c ON a.course_id = c.id
             LEFT JOIN batch b ON c.batch_id = b.id
             WHERE a.start_time >= NOW() AND a.status = 'active'
             AND (
                 (a.program_id IS NULL AND a.department_id IS NULL AND a.course_id IS NULL)
                 OR (a.program_id = ? AND a.department_id IS NULL AND a.course_id IS NULL)
                 OR (a.program_id = ? AND a.department_id = ? AND a.course_id IS NULL)
                 OR (EXISTS (
                     SELECT 1 FROM course co
                     INNER JOIN batch ba ON co.batch_id = ba.id
                     WHERE co.id = a.course_id
                     AND co.program_id = ? AND co.department_id = ? AND co.batch_id = ?
                     AND ba.status = 'active'
                 ))
             )
             ORDER BY a.start_time ASC
             LIMIT 5)
            UNION ALL
            (SELECT 'Live Class' as type, lc.title as title, lc.scheduled_time as date, lc.description
             FROM live_classes lc
             INNER JOIN course c ON lc.course_id = c.id
             INNER JOIN batch b ON c.batch_id = b.id
             WHERE lc.scheduled_time >= NOW() AND lc.status = 'scheduled'
             AND c.program_id = ? AND c.department_id = ? AND c.batch_id = ?
             AND b.status = 'active'
             ORDER BY lc.scheduled_time ASC
             LIMIT 5)
            ORDER BY date ASC
            LIMIT 10
        ";
        $upcoming_events_stmt = $conn->prepare($upcoming_events_query);
        $upcoming_events_stmt->execute([
            $student_program_id, // for assessment program-specific
            $student_program_id, $student_department_id, // for assessment department-specific
            $student_program_id, $student_department_id, $student_batch_id, // for assessment course-specific subquery
            $student_program_id, $student_department_id, $student_batch_id // for live class
        ]);
        $upcoming_events = $upcoming_events_stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $enrolled_courses_count = 0;
        $upcoming_assessments_count = 0;
        $total_assessments_count = 0;
        $upcoming_live_classes_count = 0;
        $upcoming_events = [];
    }

    // Calculate average grade (this query was already correct as it directly uses student_id)
    $average_grade_query = "SELECT AVG(ar.marks_obtained) as avg_grade
                            FROM assessment_results ar
                            JOIN assessments a ON ar.assessment_id = a.id
                            WHERE ar.student_id = ? AND a.end_time < NOW()";
    $average_grade_stmt = $conn->prepare($average_grade_query);
    $average_grade_stmt->execute([$student_id]);
    $avg_grade_result = $average_grade_stmt->fetch(PDO::FETCH_ASSOC)['avg_grade'];
    $average_grade = $avg_grade_result !== null ? round($avg_grade_result, 2) : 'N/A';

    // FIXED: Calculate attendance percentage using the correct student_id from enrollment table
    // Try multiple approaches to find attendance records
    if ($enrollment_student_id) {
        // First try with enrollment student_id
        $attendance_query = "SELECT COUNT(*) as total_records,
                                    SUM(CASE WHEN LOWER(TRIM(status)) = 'present' THEN 1 ELSE 0 END) as present_count
                             FROM attendance
                             WHERE student_id = ?";
        $attendance_stmt = $conn->prepare($attendance_query);
        $attendance_stmt->execute([$enrollment_student_id]);
        $attendance_result = $attendance_stmt->fetch(PDO::FETCH_ASSOC);
        
        // If no records found with enrollment student_id, try with user_id
        if ($attendance_result['total_records'] == 0) {
            $attendance_stmt->execute([$student_id]);
            $attendance_result = $attendance_stmt->fetch(PDO::FETCH_ASSOC);
        }
    } else {
        // Fallback to user_id if no enrollment student_id
        $attendance_query = "SELECT COUNT(*) as total_records,
                                    SUM(CASE WHEN LOWER(TRIM(status)) = 'present' THEN 1 ELSE 0 END) as present_count
                             FROM attendance
                             WHERE student_id = ?";
        $attendance_stmt = $conn->prepare($attendance_query);
        $attendance_stmt->execute([$student_id]);
        $attendance_result = $attendance_stmt->fetch(PDO::FETCH_ASSOC);
    }

    if ($attendance_result['total_records'] > 0) {
        $attendance_percentage = round(($attendance_result['present_count'] / $attendance_result['total_records']) * 100, 2);
    } else {
        $attendance_percentage = 0; // Show 0 instead of N/A when no records exist
    }

    // Get recent grades (last 5) (this query was already correct)
    $recent_grades_query = "SELECT a.title, ar.marks_obtained, a.total_marks, a.type, a.end_time
                            FROM assessment_results ar
                            JOIN assessments a ON ar.assessment_id = a.id
                            WHERE ar.student_id = ? AND a.end_time < NOW()
                            ORDER BY a.end_time DESC
                            LIMIT 5";
    $recent_grades_stmt = $conn->prepare($recent_grades_query);
    $recent_grades_stmt->execute([$student_id]);
    $recent_grades = $recent_grades_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get recent notifications for the student (this query was already correct)
    $recent_notifications_query = "SELECT title, message, created_at
                                   FROM notification
                                   WHERE user_id = ? OR user_id IS NULL
                                   ORDER BY created_at DESC
                                   LIMIT 5";
    $recent_notifications_stmt = $conn->prepare($recent_notifications_query);
    $recent_notifications_stmt->execute([$student_id]);
    $recent_notifications = $recent_notifications_stmt->fetchAll(PDO::FETCH_ASSOC);

    // FIXED: Get attendance data for chart using the correct student_id
    $chart_student_id = $enrollment_student_id ?: $student_id;
    $attendance_chart_query = "SELECT DATE(date) as attendance_date,
                                      SUM(CASE WHEN LOWER(TRIM(status)) = 'present' THEN 1 ELSE 0 END) as present_count,
                                      COUNT(*) as total_count
                               FROM attendance
                               WHERE student_id = ? AND date >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY)
                               GROUP BY DATE(date)
                               ORDER BY attendance_date ASC";
    $attendance_chart_stmt = $conn->prepare($attendance_chart_query);
    $attendance_chart_stmt->execute([$chart_student_id]);
    $attendance_chart_results = $attendance_chart_stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($attendance_chart_results as $item) {
        $attendance_labels[] = date('M d', strtotime($item['attendance_date']));
        $percentage = $item['total_count'] > 0 ? round(($item['present_count'] / $item['total_count']) * 100) : 0;
        $attendance_chart_data[] = $percentage;
    }

} catch (PDOException $e) {
    error_log("Database error on student dashboard: " . $e->getMessage());
    // Fallback to default values or show an error message on the page
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css"> <!-- Reusing admin styles for layout -->
    <link rel="stylesheet" href="../assets/css/dashboard.css"> <!-- Reusing dashboard styles for cards/charts -->
    <link rel="stylesheet" href="../assets/css/student.css"> <!-- Student specific styles -->
    <link rel="stylesheet" href="../assets/css/thesis.css"> <!-- Add thesis styles -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/student-sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <div class="admin-header-left">
                    <h1>Student Dashboard</h1>
                    <p class="welcome-message">Welcome, <span class="admin-name"><?php echo htmlspecialchars($student_info['full_name'] ?? $_SESSION['email']); ?></span></p>
                </div>
                <div class="admin-header-right">
                    <div class="notifications-dropdown">
                        <button class="notifications-btn">
                            <i class="fas fa-bell"></i>
                            <?php if (count($recent_notifications) > 0): ?>
                            <span class="notification-badge"><?php echo count($recent_notifications); ?></span>
                            <?php endif; ?>
                        </button>
                        <div class="notifications-content">
                            <div class="notifications-header">
                                <h3>Notifications</h3>
                                <a href="notifications.php" class="view-all-link">View All</a>
                            </div>
                            <div class="notifications-list">
                                <?php if (count($recent_notifications) > 0): ?>
                                    <?php foreach ($recent_notifications as $notification): ?>
                                    <div class="notification-item">
                                        <div class="notification-icon">
                                            <i class="fas fa-bell"></i>
                                        </div>
                                        <div class="notification-details">
                                            <div class="notification-title"><?php echo htmlspecialchars($notification['title']); ?></div>
                                            <div class="notification-message"><?php echo substr(htmlspecialchars($notification['message']), 0, 50) . (strlen($notification['message']) > 50 ? '...' : ''); ?></div>
                                            <div class="notification-time"><?php echo date('M d, Y H:i', strtotime($notification['created_at'])); ?></div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="no-notifications"></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="theme-toggle">
                        <input type="checkbox" id="theme-toggle-checkbox" class="theme-toggle-checkbox">
                        <label for="theme-toggle-checkbox" class="theme-toggle-label">
                            <span class="theme-toggle-inner"></span>
                        </label>
                    </div>
                    <div class="admin-profile">
                        <img src="../assets/images/student-avatar.png" alt="Student">
                        <span><?php echo htmlspecialchars($student_info['full_name'] ?? $_SESSION['email']); ?></span>
                    </div>
                </div>
            </div>
            
            <!-- Added status notification for graduated/restricted students -->
            <?php if ($status_notification): ?>
            <div class="status-notification alert alert-<?php echo $status_notification['type']; ?>">
                <div class="status-content">
                    <div class="status-icon">
                        <i class="fas <?php echo $status_notification['icon']; ?>"></i>
                    </div>
                    <div class="status-details">
                        <h4>Student Status Notice</h4>
                        <p><?php echo htmlspecialchars($status_notification['message']); ?></p>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Add thesis submission status notification -->
            <?php if ($thesis_status_message): ?>
            <div class="thesis-status-notification alert alert-<?php echo $thesis_status_type; ?>">
                <div class="thesis-status-content">
                    <div class="thesis-status-icon">
                        <i class="fas <?php 
                            echo $thesis_status_type === 'success' ? 'fa-check-circle' : 
                                ($thesis_status_type === 'warning' ? 'fa-exclamation-triangle' : 
                                ($thesis_status_type === 'danger' ? 'fa-times-circle' : 'fa-info-circle')); 
                        ?>"></i>
                    </div>
                    <div class="thesis-status-details">
                        <h4>Thesis Submission Status</h4>
                        <p><?php echo htmlspecialchars($thesis_status_message); ?></p>
                    </div>
                    <div class="thesis-status-actions">
                        <?php if ($thesis_can_submit): ?>
                            <a href="thesis.php" class="btn btn-primary btn-sm">
                                <i class="fas fa-upload"></i> Submit Thesis
                            </a>
                        <?php endif; ?>
                        <a href="thesis.php" class="btn btn-secondary btn-sm">
                            <i class="fas fa-eye"></i> View Details
                        </a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Student Overview Cards -->
            <div class="dashboard-overview">
                <!-- Modified cards to show appropriate data based on access level -->
                <div class="overview-card total-courses">
                    <div class="overview-icon">
                        <i class="fas fa-book-open"></i>
                    </div>
                    <div class="overview-details">
                        <h3><?php echo $has_view_only_access ? 'Completed Courses' : 'Enrolled Courses'; ?></h3>
                        <p class="overview-count"><?php echo $enrolled_courses_count; ?></p>
                        <div class="overview-trend <?php echo $has_view_only_access ? 'neutral' : 'positive'; ?>">
                            <span><?php echo $has_view_only_access ? 'View History' : 'View All'; ?></span>
                        </div>
                    </div>
                </div>
                
                <div class="overview-card upcoming-assessments">
                    <div class="overview-icon">
                        <i class="fas fa-clipboard-list"></i>
                    </div>
                    <div class="overview-details">
                        <h3><?php echo $has_view_only_access ? 'Assessment History' : 'Upcoming Assessments'; ?></h3>
                        <p class="overview-count"><?php echo $has_view_only_access ? $total_assessments_count : $upcoming_assessments_count; ?></p>
                        <div class="overview-trend neutral">
                            <span><?php echo $has_view_only_access ? 'View Results' : "Total: {$total_assessments_count}"; ?></span>
                        </div>
                    </div>
                </div>
                
                <div class="overview-card average-grade">
                    <div class="overview-icon">
                        <i class="fas fa-percent"></i>
                    </div>
                    <div class="overview-details">
                        <h3>Average Grade</h3>
                        <p class="overview-count"><?php echo $average_grade; ?></p>
                        <div class="overview-trend positive">
                            <span>Based on completed</span>
                        </div>
                    </div>
                </div>
                
                <div class="overview-card attendance-rate">
                    <div class="overview-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="overview-details">
                        <h3>Attendance Rate</h3>
                        <p class="overview-count"><?php echo $attendance_percentage; ?>%</p>
                        <div class="overview-trend positive">
                            <span>Overall</span>
                        </div>
                    </div>
                </div>

                <div class="overview-card live-classes">
                    <div class="overview-icon">
                        <i class="fas fa-video"></i>
                    </div>
                    <div class="overview-details">
                        <h3>Upcoming Live Classes</h3>
                        <p class="overview-count"><?php echo $upcoming_live_classes_count; ?></p>
                        <div class="overview-trend neutral">
                            <span>Join Now</span>
                        </div>
                    </div>
                </div>
                
                <div class="overview-card academic-info">
                    <div class="overview-icon">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <div class="overview-details">
                        <h3>Academic Info</h3>
                        <p class="overview-count"><?php echo htmlspecialchars($student_info['program_name'] ?? 'N/A'); ?></p>
                        <div class="semester-info">
                            <small><strong>Batch:</strong> <?php echo htmlspecialchars($student_info['batch_name'] ?? 'N/A'); ?> (<?php echo htmlspecialchars($student_info['batch_year'] ?? 'N/A'); ?>)</small>
                            <small><strong>Academic Year:</strong> <?php echo htmlspecialchars($active_academic_year); ?></small>
                            <small><strong>Semester:</strong> <?php echo htmlspecialchars($active_semester); ?></small>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Charts & Recent Activities Section -->
            <div class="analytics-section">
                <h2 class="section-title">My Performance</h2>
                <div class="charts-grid">
                    <!-- Attendance Trends Line Chart -->
                    <div class="chart-container chart-wide">
                        <div class="chart-header">
                            <h3>Attendance Trends (Last 30 Days)</h3>
                            <span class="chart-type">Line Chart</span>
                        </div>
                        <div class="chart-body">
                            <canvas id="attendanceChart"></canvas>
                        </div>
                    </div>
                    
                    <!-- Recent Grades Table -->
                    <div class="chart-container chart-wide">
                        <div class="chart-header">
                            <h3>Recent Grades</h3>
                            <a href="results.php" class="view-all-link">View All</a>
                        </div>
                        <div class="chart-body">
                            <div class="recent-table-container">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>Assessment</th>
                                            <th>Type</th>
                                            <th>Marks</th>
                                            <th>Total Marks</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (!empty($recent_grades)): ?>
                                            <?php foreach ($recent_grades as $grade): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($grade['title']); ?></td>
                                                <td><?php echo ucfirst(htmlspecialchars($grade['type'])); ?></td>
                                                <td><?php echo htmlspecialchars($grade['marks_obtained']); ?></td>
                                                <td><?php echo htmlspecialchars($grade['total_marks']); ?></td>
                                                <td><?php echo date('M d, Y', strtotime($grade['end_time'])); ?></td>
                                            </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="5" class="text-center">No recent grades found.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Upcoming Events Section -->
            <div class="dashboard-bottom">
                <div class="recent-activities">
                    <div class="section-header">
                        <h2>Upcoming Events & Deadlines</h2>
                        <a href="academic-events.php" class="view-all-link">View All</a>
                    </div>
                    <div class="activities-list">
                        <?php if (!empty($upcoming_events)): ?>
                            <?php foreach ($upcoming_events as $event): ?>
                            <div class="activity-item">
                                <div class="activity-icon <?php echo strtolower(str_replace(' ', '-', $event['type'])); ?>">
                                    <?php
                                        $icon_class = '';
                                        if ($event['type'] === 'Academic Event') $icon_class = 'fas fa-calendar-day';
                                        else if ($event['type'] === 'Assessment') $icon_class = 'fas fa-file-alt';
                                        else if ($event['type'] === 'Live Class') $icon_class = 'fas fa-video';
                                    ?>
                                    <i class="<?php echo $icon_class; ?>"></i>
                                </div>
                                <div class="activity-details">
                                    <div class="activity-title"><?php echo htmlspecialchars($event['type']); ?></div>
                                    <div class="activity-description"><?php echo htmlspecialchars($event['title']); ?></div>
                                    <div class="activity-time"><?php echo date('M d, Y H:i A', strtotime($event['date'])); ?></div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="no-activities">No upcoming events.</div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="quick-actions">
                    <div class="section-header">
                        <h2>Quick Actions</h2>
                    </div>
                    <div class="action-buttons">
                        <?php if ($has_view_only_access): ?>
                            <a href="my-courses.php" class="btn btn-secondary"><i class="fas fa-book"></i> Course History</a>
                            <a href="results.php" class="btn btn-info"><i class="fas fa-chart-bar"></i> View Results</a>
                            <a href="thesis.php" class="btn btn-primary"><i class="fas fa-graduation-cap"></i> My Thesis</a>
                            <a href="profile.php" class="btn btn-warning"><i class="fas fa-user-circle"></i> Update Profile</a>
                        <?php elseif ($can_access_academic_features): ?>
                            <a href="my-courses.php" class="btn btn-primary"><i class="fas fa-book"></i> My Courses</a>
                            <a href="assessments.php" class="btn btn-secondary"><i class="fas fa-clipboard-list"></i> View Assessments</a>
                            <a href="attendance.php" class="btn btn-info"><i class="fas fa-calendar-check"></i> Check Attendance</a>
                            <a href="profile.php" class="btn btn-warning"><i class="fas fa-user-circle"></i> Update Profile</a>
                            <a href="notifications.php" class="btn btn-danger"><i class="fas fa-bell"></i> Notifications</a>
                        <?php else: ?>
                            <a href="profile.php" class="btn btn-warning"><i class="fas fa-user-circle"></i> Update Profile</a>
                            <a href="notifications.php" class="btn btn-danger"><i class="fas fa-bell"></i> Notifications</a>
                            <button class="btn btn-secondary" disabled><i class="fas fa-lock"></i> Academic Features Restricted</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Notifications dropdown
        const notificationsBtn = document.querySelector('.notifications-btn');
        const notificationsContent = document.querySelector('.notifications-content');
        
        if (notificationsBtn) {
            notificationsBtn.addEventListener('click', function() {
                notificationsContent.classList.toggle('show');
            });
            
            document.addEventListener('click', function(event) {
                if (!notificationsBtn.contains(event.target) && !notificationsContent.contains(event.target)) {
                    notificationsContent.classList.remove('show');
                }
            });
        }

        // Attendance Trends Line Chart
        const attendanceCtx = document.getElementById('attendanceChart');
        if (attendanceCtx) {
            new Chart(attendanceCtx.getContext('2d'), {
                type: 'line',
                data: {
                    labels: <?php echo json_encode($attendance_labels); ?>,
                    datasets: [{
                        label: 'Attendance %',
                        data: <?php echo json_encode($attendance_chart_data); ?>,
                        backgroundColor: 'rgba(76, 111, 255, 0.2)',
                        borderColor: 'rgba(76, 111, 255, 1)',
                        borderWidth: 2,
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 100,
                            ticks: {
                                callback: function(value) {
                                    return value + '%';
                                }
                            }
                        }
                    },
                    plugins: {
                        legend: { display: false }
                    }
                }
            });
        }
    });
    </script>
</body>
</html>
