<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is a student
if (!is_logged_in() || !is_student()) {
header("Location: ../auth/login.php");
exit();
}

// Set default timezone
date_default_timezone_set('Africa/Mogadishu');

$student_id = $_SESSION['user_id'];
$assessments = [];
$message = '';
$messageType = '';

try {
// Get student's enrollment details
$enrollment_query = "SELECT program_id, department_id, batch_id FROM enrollment WHERE user_id = ?";
$enrollment_stmt = $conn->prepare($enrollment_query);
$enrollment_stmt->execute([$student_id]);
$enrollment = $enrollment_stmt->fetch(PDO::FETCH_ASSOC);

if ($enrollment) {
    $student_program_id = $enrollment['program_id'];
    $student_department_id = $enrollment['department_id'];
    $student_batch_id = $enrollment['batch_id'];

    $assessments_query = "SELECT DISTINCT a.id, a.title, a.description, a.type, a.total_marks, 
                                 a.duration_minutes, a.start_time, a.end_time, a.status,
                                 c.name as course_name, c.code as course_code,
                                 u.full_name as instructor_name,
                                 ar.id as result_id, ar.marks_obtained, ar.submitted_at,
                                 b.name as batch_name, b.status as batch_status,
                                 (SELECT COUNT(*) FROM assessment_questions aq 
                                  WHERE aq.assessment_id = a.id 
                                  AND (aq.batch_id = ? OR aq.batch_id IS NULL)
                                  AND (aq.course_id IS NULL OR aq.course_id IN (
                                      SELECT co.id FROM course co 
                                      INNER JOIN batch ba ON co.batch_id = ba.id
                                      WHERE co.program_id = ? AND co.department_id = ? AND co.batch_id = ?
                                      AND ba.status = 'active'
                                  ))
                                 ) as question_count
                          FROM assessments a
                          LEFT JOIN course c ON a.course_id = c.id
                          LEFT JOIN batch cb ON c.batch_id = cb.id
                          LEFT JOIN users u ON a.created_by = u.id
                          LEFT JOIN batch b ON ? = b.id
                          LEFT JOIN assessment_results ar ON (a.id = ar.assessment_id AND ar.student_id = ?)
                          WHERE (
                              -- General assessments (no specific targeting)
                              (a.program_id IS NULL AND a.department_id IS NULL AND a.course_id IS NULL)
                              -- Program-specific assessments
                              OR (a.program_id = ? AND a.department_id IS NULL AND a.course_id IS NULL)
                              -- Department-specific assessments within program
                              OR (a.program_id = ? AND a.department_id = ? AND a.course_id IS NULL)
                              -- Course-specific assessments from active batches only
                              OR EXISTS (
                                  SELECT 1 FROM course co
                                  INNER JOIN batch ba ON co.batch_id = ba.id
                                  WHERE co.id = a.course_id
                                  AND co.program_id = ? AND co.department_id = ? AND co.batch_id = ?
                                  AND ba.status = 'active'
                              )
                          )
                          ORDER BY a.start_time DESC";
    
    $assessments_stmt = $conn->prepare($assessments_query);
    $assessments_stmt->execute([
        $student_batch_id, // for question count subquery
        $student_program_id, $student_department_id, $student_batch_id, // for question count course filter
        $student_batch_id, // for batch name
        $student_id, // for checking existing results
        $student_program_id, // for program-specific
        $student_program_id, $student_department_id, // for department-specific
        $student_program_id, $student_department_id, $student_batch_id // for course-specific
    ]);
    $assessments = $assessments_stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $message = "Enrollment information not found. Please contact administration.";
    $messageType = "danger";
}

} catch (PDOException $e) {
error_log("Database error fetching student assessments: " . $e->getMessage());
$message = "Error loading assessments. Please try again later.";
$messageType = "danger";
}

// Function to determine assessment status for student
function getAssessmentStatus($assessment, $current_time) {
$start_time = strtotime($assessment['start_time']);
$end_time = strtotime($assessment['end_time']);

if ($assessment['result_id']) {
    return ['status' => 'completed', 'text' => 'Completed', 'class' => 'completed'];
} elseif ($current_time < $start_time) {
    return ['status' => 'upcoming', 'text' => 'Upcoming', 'class' => 'upcoming'];
} elseif ($current_time > $end_time) {
    return ['status' => 'expired', 'text' => 'Expired', 'class' => 'expired'];
} else {
    return ['status' => 'available', 'text' => 'Available', 'class' => 'available'];
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Assessments - Benadir University LMS</title>
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="../assets/css/admin.css">
<link rel="stylesheet" href="../assets/css/student.css">
<?php echo FONT_AWESOME_CSS; ?>
<style>
    .assessments-container {
        display: grid;
        gap: 20px;
        margin-top: 20px;
    }
    
    .assessment-card {
        background: var(--card-bg);
        border-radius: 8px;
        padding: 20px;
        box-shadow: var(--shadow);
        border-left: 4px solid var(--primary-color);
        transition: transform 0.2s, box-shadow 0.2s;
    }
    
    .assessment-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    }
    
    .assessment-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 15px;
    }
    
    .assessment-title {
        font-size: 1.2rem;
        font-weight: 600;
        color: var(--text-color);
        margin: 0 0 5px 0;
    }
    
    .assessment-type {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 500;
        text-transform: uppercase;
    }
    
    .assessment-type.exam {
        background: #fee2e2;
        color: #dc2626;
    }
    
    .assessment-type.quiz {
        background: #dbeafe;
        color: #2563eb;
    }
    
    .assessment-type.assignment {
        background: #d1fae5;
        color: #059669;
    }
    
    .assessment-type.project {
        background: #fef3c7;
        color: #d97706;
    }
    
    .assessment-details {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
        margin: 15px 0;
    }
    
    .detail-item {
        display: flex;
        flex-direction: column;
        gap: 2px;
    }
    
    .detail-label {
        font-size: 0.8rem;
        color: var(--text-muted);
        font-weight: 500;
    }
    
    .detail-value {
        font-size: 0.9rem;
        color: var(--text-color);
    }
    
    .assessment-description {
        margin: 15px 0;
        padding: 15px;
        background: var(--bg-light);
        border-radius: 6px;
        color: var(--text-color);
        line-height: 1.5;
    }
    
    .assessment-actions {
        display: flex;
        gap: 10px;
        align-items: center;
        margin-top: 20px;
    }
    
    .status-badge {
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 500;
    }
    
    .status-badge.available {
        background: #d1fae5;
        color: #059669;
    }
    
    .status-badge.upcoming {
        background: #fef3c7;
        color: #d97706;
    }
    
    .status-badge.expired {
        background: #fee2e2;
        color: #dc2626;
    }
    
    .status-badge.completed {
        background: #e0e7ff;
        color: #4338ca;
    }
    
    .btn-take-assessment {
        background: var(--primary-color);
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 6px;
        text-decoration: none;
        font-weight: 500;
        transition: background-color 0.2s;
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }
    
    .btn-take-assessment:hover {
        background: var(--primary-dark);
        color: white;
        text-decoration: none;
    }
    
    .btn-take-assessment:disabled {
        background: #9ca3af;
        cursor: not-allowed;
    }
    
    .btn-view-result {
        background: #059669;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 6px;
        text-decoration: none;
        font-weight: 500;
        transition: background-color 0.2s;
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }
    
    .btn-view-result:hover {
        background: #047857;
        color: white;
        text-decoration: none;
    }
    
    .empty-state {
        text-align: center;
        padding: 60px 20px;
        color: var(--text-muted);
    }
    
    .empty-state i {
        font-size: 4rem;
        margin-bottom: 20px;
        opacity: 0.3;
    }
    
    .result-info {
        background: var(--bg-light);
        padding: 10px 15px;
        border-radius: 6px;
        margin-top: 10px;
    }
    
    .result-info .score {
        font-weight: 600;
        color: var(--primary-color);
    }
    
    .filters-container {
        background: var(--card-bg);
        padding: 20px;
        border-radius: 8px;
        box-shadow: var(--shadow);
        margin-bottom: 20px;
    }
    
    .filters-row {
        display: flex;
        gap: 15px;
        align-items: center;
        flex-wrap: wrap;
    }
    
    .filter-group {
        display: flex;
        flex-direction: column;
        gap: 5px;
    }
    
    .filter-label {
        font-size: 0.9rem;
        font-weight: 500;
        color: var(--text-color);
    }
    
    .filter-select {
        padding: 8px 12px;
        border: 1px solid var(--border-color);
        border-radius: 6px;
        background: var(--card-bg);
        color: var(--text-color);
        font-size: 0.9rem;
    }
    
    .stats-overview {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: var(--card-bg);
        padding: 20px;
        border-radius: 8px;
        box-shadow: var(--shadow);
        text-align: center;
    }
    
    .stat-number {
        font-size: 2rem;
        font-weight: bold;
        color: var(--primary-color);
        margin-bottom: 5px;
    }
    
    .stat-label {
        font-size: 0.9rem;
        color: var(--text-muted);
    }
    
    .countdown-timer {
        background: #fef3c7;
        color: #92400e;
        padding: 10px 15px;
        border-radius: 6px;
        margin-top: 10px;
        font-weight: 500;
        text-align: center;
    }
    
    .countdown-timer.urgent {
        background: #fee2e2;
        color: #dc2626;
    }
    
    .batch-info {
        background: #f0f9ff;
        color: #0369a1;
        padding: 8px 12px;
        border-radius: 6px;
        margin-top: 10px;
        font-size: 0.85rem;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .question-count-badge {
        background: #e0e7ff;
        color: #4338ca;
        padding: 4px 8px;
        border-radius: 12px;
        font-size: 0.75rem;
        font-weight: 500;
    }
    
    .no-questions-warning {
        background: #fef3c7;
        color: #92400e;
        padding: 10px 15px;
        border-radius: 6px;
        margin-top: 10px;
        font-size: 0.85rem;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    @media (max-width: 768px) {
        .assessment-details {
            grid-template-columns: 1fr;
        }
        
        .filters-row {
            flex-direction: column;
            align-items: stretch;
        }
        
        .stats-overview {
            grid-template-columns: repeat(2, 1fr);
        }
    }
</style>
</head>
<body>
<div class="admin-container">
    <?php include_once '../includes/student-sidebar.php'; ?>
    
    <div class="admin-content">
        <div class="admin-header">
            <h1><i class="fas fa-clipboard-list"></i> My Assessments</h1>
            <div class="admin-header-right">
                <span class="assessments-count"><?php echo count($assessments); ?> assessments available</span>
                <?php if (isset($enrollment['batch_id'])): ?>
                    <span class="batch-info">
                        <i class="fas fa-users"></i> 
                        Batch: <?php echo htmlspecialchars($assessments[0]['batch_name'] ?? 'Unknown'); ?>
                    </span>
                <?php endif; ?>
            </div>
        </div>
        
        <?php if (!empty($message)): ?>
            <div class="message <?php echo $messageType; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

         Statistics Overview 
        <div class="stats-overview">
            <?php
            $total_assessments = count($assessments);
            $completed_assessments = count(array_filter($assessments, function($a) { return $a['result_id']; }));
            $upcoming_assessments = count(array_filter($assessments, function($a) { 
                return !$a['result_id'] && strtotime($a['start_time']) > time(); 
            }));
            $available_assessments = count(array_filter($assessments, function($a) { 
                $now = time();
                return !$a['result_id'] && strtotime($a['start_time']) <= $now && strtotime($a['end_time']) >= $now; 
            }));
            ?>
            <div class="stat-card">
                <div class="stat-number"><?php echo $total_assessments; ?></div>
                <div class="stat-label">Total Assessments</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $completed_assessments; ?></div>
                <div class="stat-label">Completed</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $available_assessments; ?></div>
                <div class="stat-label">Available Now</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $upcoming_assessments; ?></div>
                <div class="stat-label">Upcoming</div>
            </div>
        </div>

         Filters 
        <div class="filters-container">
            <div class="filters-row">
                <div class="filter-group">
                    <label class="filter-label">Filter by Type</label>
                    <select class="filter-select" id="typeFilter" onchange="filterAssessments()">
                        <option value="">All Types</option>
                        <option value="quiz">Quiz</option>
                        <option value="assignment">Assignment</option>
                        <option value="project">Project</option>
                        <option value="exam">Exam</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label class="filter-label">Filter by Status</label>
                    <select class="filter-select" id="statusFilter" onchange="filterAssessments()">
                        <option value="">All Status</option>
                        <option value="available">Available</option>
                        <option value="upcoming">Upcoming</option>
                        <option value="completed">Completed</option>
                        <option value="expired">Expired</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label class="filter-label">Sort by</label>
                    <select class="filter-select" id="sortFilter" onchange="filterAssessments()">
                        <option value="start_time_desc">Start Time (Newest)</option>
                        <option value="start_time_asc">Start Time (Oldest)</option>
                        <option value="title_asc">Title (A-Z)</option>
                        <option value="title_desc">Title (Z-A)</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="assessments-container" id="assessmentsContainer">
            <?php if (!empty($assessments)): ?>
                <?php 
                $current_time = time();
                foreach ($assessments as $assessment): 
                    $status = getAssessmentStatus($assessment, $current_time);
                    $start_time = strtotime($assessment['start_time']);
                    $end_time = strtotime($assessment['end_time']);
                    $question_count = intval($assessment['question_count']);
                ?>
                    <div class="assessment-card" 
                         data-type="<?php echo $assessment['type']; ?>" 
                         data-status="<?php echo $status['status']; ?>"
                         data-title="<?php echo htmlspecialchars($assessment['title']); ?>"
                         data-start-time="<?php echo $start_time; ?>">
                        <div class="assessment-header">
                            <div>
                                <h3 class="assessment-title"><?php echo htmlspecialchars($assessment['title']); ?></h3>
                                <div style="display: flex; gap: 10px; align-items: center; margin-top: 5px;">
                                    <span class="assessment-type <?php echo $assessment['type']; ?>">
                                        <?php echo ucfirst($assessment['type']); ?>
                                    </span>
                                    <span class="question-count-badge">
                                        <?php echo $question_count; ?> question<?php echo $question_count != 1 ? 's' : ''; ?>
                                    </span>
                                </div>
                            </div>
                            <span class="status-badge <?php echo $status['class']; ?>">
                                <?php echo $status['text']; ?>
                            </span>
                        </div>
                        
                        <?php if (!empty($assessment['description'])): ?>
                            <div class="assessment-description">
                                <?php echo nl2br(htmlspecialchars($assessment['description'])); ?>
                            </div>
                        <?php endif; ?>
                        
                        <div class="assessment-details">
                            <div class="detail-item">
                                <span class="detail-label">Assessment</span>
                                <span class="detail-value">
                                    <?php echo htmlspecialchars($assessment['course_name'] ?? 'General Assessment'); ?>
                                    <?php if ($assessment['course_code']): ?>
                                        (<?php echo htmlspecialchars($assessment['course_code']); ?>)
                                    <?php endif; ?>
                                </span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Instructor</span>
                                <span class="detail-value"><?php echo htmlspecialchars($assessment['instructor_name'] ?? 'N/A'); ?></span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Total Marks</span>
                                <span class="detail-value"><?php echo htmlspecialchars($assessment['total_marks']); ?></span>
                            </div>
                            <?php if ($assessment['duration_minutes'] > 0): ?>
                            <div class="detail-item">
                                <span class="detail-label">Duration</span>
                                <span class="detail-value"><?php echo htmlspecialchars($assessment['duration_minutes']); ?> minutes</span>
                            </div>
                            <?php endif; ?>
                            <div class="detail-item">
                                <span class="detail-label">Start Time</span>
                                <span class="detail-value"><?php echo date('M j, Y g:i A', strtotime($assessment['start_time'])); ?></span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">End Time</span>
                                <span class="detail-value"><?php echo date('M j, Y g:i A', strtotime($assessment['end_time'])); ?></span>
                            </div>
                        </div>
                        
                         Question availability warning 
                        <?php if ($question_count == 0 && $status['status'] == 'available'): ?>
                            <div class="no-questions-warning">
                                <i class="fas fa-exclamation-triangle"></i>
                                No questions available for your batch yet. Please contact your instructor.
                            </div>
                        <?php endif; ?>
                        
                         Countdown Timer for Upcoming Assessments 
                        <?php if ($status['status'] === 'upcoming'): ?>
                            <div class="countdown-timer" id="countdown-<?php echo $assessment['id']; ?>">
                                <i class="fas fa-clock"></i> <span class="countdown-text">Loading...</span>
                            </div>
                        <?php elseif ($status['status'] === 'available' && $assessment['duration_minutes'] > 0): ?>
                            <div class="countdown-timer urgent" id="countdown-<?php echo $assessment['id']; ?>">
                                <i class="fas fa-hourglass-half"></i> <span class="countdown-text">Time remaining: Loading...</span>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($assessment['result_id']): ?>
                            <div class="result-info">
                                <strong>Your Result:</strong> 
                                <span class="score"><?php echo htmlspecialchars($assessment['marks_obtained']); ?>/<?php echo htmlspecialchars($assessment['total_marks']); ?></span>
                                <small>(Submitted: <?php echo date('M j, Y g:i A', strtotime($assessment['submitted_at'])); ?>)</small>
                            </div>
                        <?php endif; ?>
                        
                        <div class="assessment-actions">
                            <?php if ($status['status'] === 'available' && !$assessment['result_id'] && $question_count > 0): ?>
                                <a href="take-assessment.php?id=<?php echo htmlspecialchars($assessment['id']); ?>" class="btn-take-assessment">
                                    <i class="fas fa-play"></i> Take Assessment
                                </a>
                            <?php elseif ($status['status'] === 'available' && !$assessment['result_id'] && $question_count == 0): ?>
                                <button class="btn-take-assessment" disabled>
                                    <i class="fas fa-exclamation-triangle"></i> No Questions Available
                                </button>
                            <?php elseif ($status['status'] === 'upcoming'): ?>
                                <button class="btn-take-assessment" disabled>
                                    <i class="fas fa-clock"></i> Not Started Yet
                                </button>
                            <?php elseif ($status['status'] === 'expired' && !$assessment['result_id']): ?>
                                <button class="btn-take-assessment" disabled>
                                    <i class="fas fa-times"></i> Expired
                                </button>
                            <?php elseif ($assessment['result_id']): ?>
                                <a href="assessment-result.php?assessment_id=<?php echo htmlspecialchars($assessment['id']); ?>&result_id=<?php echo htmlspecialchars($assessment['result_id']); ?>" class="btn-view-result" onclick="return true;">
                                    <i class="fas fa-chart-bar"></i> View Result
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-clipboard-list"></i>
                    <h3>No Assessments Available</h3>
                    <p>There are no assessments available for you at the moment.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="../assets/js/theme.js"></script>
<script>
    // Filter and sort functionality
    function filterAssessments() {
        const typeFilter = document.getElementById('typeFilter').value;
        const statusFilter = document.getElementById('statusFilter').value;
        const sortFilter = document.getElementById('sortFilter').value;
        const cards = Array.from(document.querySelectorAll('.assessment-card'));
        
        // Filter cards
        cards.forEach(card => {
            const cardType = card.dataset.type;
            const cardStatus = card.dataset.status;
            
            const typeMatch = !typeFilter || cardType === typeFilter;
            const statusMatch = !statusFilter || cardStatus === statusFilter;
            
            if (typeMatch && statusMatch) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
        
        // Sort visible cards
        const visibleCards = cards.filter(card => card.style.display !== 'none');
        const container = document.getElementById('assessmentsContainer');
        
        visibleCards.sort((a, b) => {
            switch (sortFilter) {
                case 'start_time_asc':
                    return parseInt(a.dataset.startTime) - parseInt(b.dataset.startTime);
                case 'start_time_desc':
                    return parseInt(b.dataset.startTime) - parseInt(a.dataset.startTime);
                case 'title_asc':
                    return a.dataset.title.localeCompare(b.dataset.title);
                case 'title_desc':
                    return b.dataset.title.localeCompare(a.dataset.title);
                default:
                    return parseInt(b.dataset.startTime) - parseInt(a.dataset.startTime);
            }
        });
        
        // Reorder cards in DOM
        visibleCards.forEach(card => container.appendChild(card));
    }
    
    // Countdown timer functionality
    function updateCountdowns() {
        const countdownElements = document.querySelectorAll('[id^="countdown-"]');
        
        countdownElements.forEach(element => {
            const assessmentId = element.id.split('-')[1];
            const card = element.closest('.assessment-card');
            const status = card.dataset.status;
            const startTime = parseInt(card.dataset.startTime) * 1000;
            const now = new Date().getTime();
            
            if (status === 'upcoming') {
                const timeUntilStart = startTime - now;
                
                if (timeUntilStart > 0) {
                    const days = Math.floor(timeUntilStart / (1000 * 60 * 60 * 24));
                    const hours = Math.floor((timeUntilStart % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                    const minutes = Math.floor((timeUntilStart % (1000 * 60 * 60)) / (1000 * 60));
                    const seconds = Math.floor((timeUntilStart % (1000 * 60)) / 1000);
                    
                    let countdownText = '';
                    if (days > 0) {
                        countdownText = `Starts in ${days}d ${hours}h ${minutes}m`;
                    } else if (hours > 0) {
                        countdownText = `Starts in ${hours}h ${minutes}m ${seconds}s`;
                    } else {
                        countdownText = `Starts in ${minutes}m ${seconds}s`;
                    }
                    
                    element.querySelector('.countdown-text').textContent = countdownText;
                    
                    if (timeUntilStart < 3600000) { // Less than 1 hour
                        element.classList.add('urgent');
                    }
                } else {
                    // Assessment has started, reload page
                    location.reload();
                }
            }
        });
    }
    
    setInterval(updateCountdowns, 1000);
    updateCountdowns(); // Initial call
    
    // Auto-refresh page every 5 minutes to check for new assessments
    setInterval(() => {
        location.reload();
    }, 300000);
    
    // Notification for new assessments (if supported)
    if ('Notification' in window && Notification.permission === 'granted') {
        // Check for new assessments periodically
        setInterval(checkForNewAssessments, 60000); // Every minute
    }
    
    function checkForNewAssessments() {
        // This would typically make an AJAX call to check for new assessments
        // For now, we'll just reload the page periodically
    }
    
    // Request notification permission
    if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
    }

    // Handle view result button clicks
    document.addEventListener('DOMContentLoaded', function() {
        const viewResultButtons = document.querySelectorAll('.btn-view-result');
        viewResultButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                // Ensure the link works properly
                const href = this.getAttribute('href');
                if (href) {
                    window.location.href = href;
                }
            });
        });
    });
</script>
</body>
</html>
