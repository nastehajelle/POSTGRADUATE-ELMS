<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is a student
if (!is_logged_in() || !is_student()) {
    header("Location: ../auth/login.php");
    exit();
}

$student_id = $_SESSION['user_id'];
$results = [];
$grade_summary = [];
$overall_stats = [];
$message = '';
$messageType = '';

// Grade calculation weights (can be made configurable)
$grade_weights = [
    'quiz' => 0.20,      // 20%
    'assignment' => 0.25, // 25%
    'project' => 0.25,   // 25%
    'exam' => 0.30       // 30%
];

try {
    // Get student's enrollment details for context
    $enrollment_query = "SELECT e.student_id, e.program_id, e.department_id, e.batch_id,
                                p.name as program_name, d.name as department_name, b.name as batch_name
                         FROM enrollment e
                         JOIN programs p ON e.program_id = p.id
                         JOIN departments d ON e.department_id = d.id
                         JOIN batch b ON e.batch_id = b.id
                         WHERE e.user_id = ?";
    $enrollment_stmt = $conn->prepare($enrollment_query);
    $enrollment_stmt->execute([$student_id]);
    $student_info = $enrollment_stmt->fetch(PDO::FETCH_ASSOC);

    // Fetch all assessment results for the student with detailed information
    $results_query = "SELECT ar.id as result_id, ar.marks_obtained, ar.grade, ar.submitted_at,
                             a.id as assessment_id, a.title, a.type, a.total_marks, a.pass_marks,
                             a.start_time, a.end_time, a.weight,
                             c.name as course_name, c.code as course_code,
                             u.full_name as instructor_name
                      FROM assessment_results ar
                      JOIN assessments a ON ar.assessment_id = a.id
                      LEFT JOIN course c ON a.course_id = c.id
                      LEFT JOIN users u ON a.created_by = u.id
                      WHERE ar.student_id = ?
                      ORDER BY a.type, ar.submitted_at DESC";
    
    $results_stmt = $conn->prepare($results_query);
    $results_stmt->execute([$student_id]);
    $all_results = $results_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Organize results by type
    $results_by_type = [
        'quiz' => [],
        'assignment' => [],
        'project' => [],
        'exam' => []
    ];

    $type_totals = [
        'quiz' => ['obtained' => 0, 'total' => 0, 'count' => 0],
        'assignment' => ['obtained' => 0, 'total' => 0, 'count' => 0],
        'project' => ['obtained' => 0, 'total' => 0, 'count' => 0],
        'exam' => ['obtained' => 0, 'total' => 0, 'count' => 0]
    ];

    foreach ($all_results as $result) {
        $type = $result['type'];
        if (isset($results_by_type[$type])) {
            $results_by_type[$type][] = $result;
            $type_totals[$type]['obtained'] += $result['marks_obtained'];
            $type_totals[$type]['total'] += $result['total_marks'];
            $type_totals[$type]['count']++;
        }
    }

    // Calculate averages and weighted grades
    $weighted_total = 0;
    $total_weight_used = 0;

    foreach ($type_totals as $type => $totals) {
        if ($totals['count'] > 0 && $totals['total'] > 0) {
            $average_percentage = ($totals['obtained'] / $totals['total']) * 100;
            $weighted_contribution = $average_percentage * $grade_weights[$type];
            
            $grade_summary[$type] = [
                'average_percentage' => round($average_percentage, 2),
                'total_obtained' => $totals['obtained'],
                'total_possible' => $totals['total'],
                'count' => $totals['count'],
                'weight' => $grade_weights[$type] * 100,
                'weighted_contribution' => round($weighted_contribution, 2),
                'letter_grade' => calculateLetterGrade($average_percentage)
            ];
            
            $weighted_total += $weighted_contribution;
            $total_weight_used += $grade_weights[$type];
        } else {
            $grade_summary[$type] = [
                'average_percentage' => 0,
                'total_obtained' => 0,
                'total_possible' => 0,
                'count' => 0,
                'weight' => $grade_weights[$type] * 100,
                'weighted_contribution' => 0,
                'letter_grade' => 'N/A'
            ];
        }
    }

    // Calculate overall statistics
    $overall_stats = [
        'total_assessments' => count($all_results),
        'weighted_average' => $total_weight_used > 0 ? round($weighted_total / $total_weight_used, 2) : 0,
        'overall_letter_grade' => $total_weight_used > 0 ? calculateLetterGrade($weighted_total / $total_weight_used) : 'N/A',
        'total_marks_obtained' => array_sum(array_column($all_results, 'marks_obtained')),
        'total_marks_possible' => array_sum(array_column($all_results, 'total_marks')),
        'simple_average' => count($all_results) > 0 ? round((array_sum(array_column($all_results, 'marks_obtained')) / array_sum(array_column($all_results, 'total_marks'))) * 100, 2) : 0
    ];

    $results = $results_by_type;

} catch (PDOException $e) {
    error_log("Database error fetching student results: " . $e->getMessage());
    $message = "Error loading your results. Please try again later.";
    $messageType = "danger";
}

// Function to calculate letter grade
function calculateLetterGrade($percentage) {
    if ($percentage >= 90) return 'A';
    elseif ($percentage >= 80) return 'B';
    elseif ($percentage >= 70) return 'C';
    elseif ($percentage >= 60) return 'D';
    else return 'F';
}

// Function to get grade color class
function getGradeColorClass($percentage) {
    if ($percentage >= 80) return 'excellent';
    elseif ($percentage >= 70) return 'good';
    elseif ($percentage >= 60) return 'average';
    else return 'poor';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Results - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/student.css">
    <?php echo FONT_AWESOME_CSS; ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .results-container {
            padding: 20px 0;
        }

        .student-info-card {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
            position: relative;
            overflow: hidden;
        }

        .student-info-card::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            animation: rotate 20s linear infinite;
        }

        @keyframes rotate {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .student-info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
            position: relative;
            z-index: 1;
        }

        .info-item {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .info-label {
            font-size: 0.85rem;
            opacity: 0.9;
            font-weight: 500;
        }

        .info-value {
            font-size: 1rem;
            font-weight: 600;
        }

        .overall-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: var(--card-bg);
            padding: 25px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            text-align: center;
            position: relative;
            overflow: hidden;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color), var(--success-color));
        }

        .stat-icon {
            font-size: 2.5rem;
            margin-bottom: 15px;
            color: var(--primary-color);
        }

        .stat-value {
            font-size: 2.2rem;
            font-weight: bold;
            color: var(--text-color);
            margin-bottom: 5px;
        }

        .stat-label {
            font-size: 0.9rem;
            color: var(--text-muted);
            margin-bottom: 10px;
        }

        .grade-letter {
            display: inline-block;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 1.1rem;
        }

        .grade-letter.excellent { background: #d1fae5; color: #059669; }
        .grade-letter.good { background: #dbeafe; color: #2563eb; }
        .grade-letter.average { background: #fef3c7; color: #d97706; }
        .grade-letter.poor { background: #fee2e2; color: #dc2626; }

        .grades-section {
            margin-bottom: 40px;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--border-color);
        }

        .section-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-color);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .type-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .summary-card {
            background: var(--card-bg);
            padding: 25px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            border-left: 4px solid;
            transition: transform 0.2s;
        }

        .summary-card:hover {
            transform: translateY(-3px);
        }

        .summary-card.quiz { border-left-color: #3b82f6; }
        .summary-card.assignment { border-left-color: #10b981; }
        .summary-card.project { border-left-color: #f59e0b; }
        .summary-card.exam { border-left-color: #ef4444; }

        .summary-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .summary-type {
            font-size: 1.2rem;
            font-weight: 600;
            text-transform: capitalize;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .type-icon {
            font-size: 1.5rem;
        }

        .type-icon.quiz { color: #3b82f6; }
        .type-icon.assignment { color: #10b981; }
        .type-icon.project { color: #f59e0b; }
        .type-icon.exam { color: #ef4444; }

        .summary-stats {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }

        .stat-item {
            text-align: center;
            padding: 15px;
            background: var(--bg-light);
            border-radius: 8px;
        }

        .stat-number {
            font-size: 1.4rem;
            font-weight: bold;
            color: var(--text-color);
        }

        .stat-text {
            font-size: 0.8rem;
            color: var(--text-muted);
            margin-top: 5px;
        }

        .progress-bar {
            width: 100%;
            height: 10px;
            background: var(--bg-secondary);
            border-radius: 5px;
            overflow: hidden;
            margin-bottom: 15px;
        }

        .progress-fill {
            height: 100%;
            border-radius: 5px;
            transition: width 0.8s ease;
            position: relative;
        }

        .progress-fill::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            animation: shimmer 2s infinite;
        }

        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }

        .progress-fill.quiz { background: linear-gradient(90deg, #3b82f6, #60a5fa); }
        .progress-fill.assignment { background: linear-gradient(90deg, #10b981, #34d399); }
        .progress-fill.project { background: linear-gradient(90deg, #f59e0b, #fbbf24); }
        .progress-fill.exam { background: linear-gradient(90deg, #ef4444, #f87171); }

        .detailed-results {
            background: var(--card-bg);
            border-radius: 12px;
            box-shadow: var(--shadow);
            overflow: hidden;
        }

        .results-table {
            width: 100%;
            border-collapse: collapse;
        }

        .results-table th {
            background: var(--bg-secondary);
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: var(--text-color);
            border-bottom: 1px solid var(--border-color);
        }

        .results-table td {
            padding: 15px;
            border-bottom: 1px solid var(--border-light);
            color: var(--text-color);
        }

        .results-table tbody tr {
            transition: background-color 0.2s;
        }

        .results-table tbody tr:hover {
            background: var(--hover-bg);
        }

        .assessment-title {
            font-weight: 600;
            color: var(--text-color);
            margin-bottom: 5px;
        }

        .assessment-type {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 15px;
            font-size: 0.75rem;
            font-weight: 500;
            text-transform: uppercase;
        }

        .assessment-type.quiz { background: #dbeafe; color: #1d4ed8; }
        .assessment-type.assignment { background: #d1fae5; color: #047857; }
        .assessment-type.project { background: #fef3c7; color: #b45309; }
        .assessment-type.exam { background: #fee2e2; color: #b91c1c; }

        .score-display {
            font-weight: 600;
        }

        .percentage {
            font-size: 0.9rem;
            color: var(--text-muted);
        }

        .grade-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 15px;
            font-weight: bold;
            font-size: 0.8rem;
        }

        .empty-state {
            text-align: center;
            padding: 80px 20px;
            color: var(--text-muted);
        }

        .empty-state i {
            font-size: 5rem;
            margin-bottom: 20px;
            opacity: 0.3;
        }

        .tabs {
            display: flex;
            background: var(--card-bg);
            border-radius: 10px;
            padding: 6px;
            margin-bottom: 20px;
            box-shadow: var(--shadow);
        }

        .tab {
            flex: 1;
            padding: 12px 20px;
            text-align: center;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s;
            font-weight: 500;
            color: var(--text-muted);
        }

        .tab.active {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
            animation: fadeIn 0.3s ease-in;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .export-actions {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .btn-export {
            padding: 10px 18px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            background: var(--card-bg);
            color: var(--text-color);
            text-decoration: none;
            font-size: 0.9rem;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .btn-export:hover {
            background: var(--hover-bg);
            text-decoration: none;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }

        .chart-container {
            background: var(--card-bg);
            padding: 25px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
        }

        .chart-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--text-color);
            margin-bottom: 20px;
            text-align: center;
        }

        @media (max-width: 768px) {
            .overall-stats {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .type-summary {
                grid-template-columns: 1fr;
            }
            
            .results-table {
                font-size: 0.9rem;
            }
            
            .results-table th,
            .results-table td {
                padding: 10px 8px;
            }
            
            .export-actions {
                justify-content: center;
            }
            
            .tabs {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/student-sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1><i class="fas fa-chart-line"></i> My Academic Results</h1>
                <div class="export-actions">
                    <button onclick="printResults()" class="btn-export">
                        <i class="fas fa-print"></i> Print
                    </button>
                    <button onclick="exportToCSV()" class="btn-export">
                        <i class="fas fa-download"></i> Export CSV
                    </button>
                    <button onclick="exportToPDF()" class="btn-export">
                        <i class="fas fa-file-pdf"></i> Export PDF
                    </button>
                </div>
            </div>
            
            <?php if (!empty($message)): ?>
                <div class="message <?php echo $messageType; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <div class="results-container">
                <!-- Student Information -->
                <?php if ($student_info): ?>
                <div class="student-info-card">
                    <h3><i class="fas fa-user-graduate"></i> Student Information</h3>
                    <div class="student-info-grid">
                        <div class="info-item">
                            <span class="info-label">Student ID</span>
                            <span class="info-value"><?php echo htmlspecialchars($student_info['student_id']); ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Program</span>
                            <span class="info-value"><?php echo htmlspecialchars($student_info['program_name']); ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Department</span>
                            <span class="info-value"><?php echo htmlspecialchars($student_info['department_name']); ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Batch</span>
                            <span class="info-value"><?php echo htmlspecialchars($student_info['batch_name']); ?></span>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Overall Statistics -->
                <div class="overall-stats">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-chart-line"></i></div>
                        <div class="stat-value"><?php echo $overall_stats['weighted_average']; ?>%</div>
                        <div class="stat-label">Weighted Average</div>
                        <span class="grade-letter <?php echo getGradeColorClass($overall_stats['weighted_average']); ?>">
                            <?php echo $overall_stats['overall_letter_grade']; ?>
                        </span>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-clipboard-list"></i></div>
                        <div class="stat-value"><?php echo $overall_stats['total_assessments']; ?></div>
                        <div class="stat-label">Total Assessments</div>
                        <small><?php echo $overall_stats['total_marks_obtained']; ?>/<?php echo $overall_stats['total_marks_possible']; ?> marks</small>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-percentage"></i></div>
                        <div class="stat-value"><?php echo $overall_stats['simple_average']; ?>%</div>
                        <div class="stat-label">Simple Average</div>
                        <span class="grade-letter <?php echo getGradeColorClass($overall_stats['simple_average']); ?>">
                            <?php echo calculateLetterGrade($overall_stats['simple_average']); ?>
                        </span>
                    </div>
                </div>

                <!-- Performance Charts -->
                <div class="chart-container">
                    <h3 class="chart-title">Performance Overview</h3>
                    <canvas id="performanceChart" width="400" height="200"></canvas>
                </div>

                <!-- Grade Summary by Type -->
                <div class="grades-section">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fas fa-chart-bar"></i>
                            Grade Summary by Assessment Type
                        </h2>
                    </div>
                    
                    <div class="type-summary">
                        <?php foreach (['quiz', 'assignment', 'project', 'exam'] as $type): ?>
                        <div class="summary-card <?php echo $type; ?>">
                            <div class="summary-header">
                                <span class="summary-type">
                                    <i class="type-icon <?php echo $type; ?> fas fa-<?php echo $type === 'quiz' ? 'question-circle' : ($type === 'assignment' ? 'file-alt' : ($type === 'project' ? 'project-diagram' : 'graduation-cap')); ?>"></i>
                                    <?php echo ucfirst($type); ?>s
                                </span>
                                <span class="grade-letter <?php echo getGradeColorClass($grade_summary[$type]['average_percentage']); ?>">
                                    <?php echo $grade_summary[$type]['letter_grade']; ?>
                                </span>
                            </div>
                            
                            <div class="progress-bar">
                                <div class="progress-fill <?php echo $type; ?>" 
                                     style="width: <?php echo $grade_summary[$type]['average_percentage']; ?>%"></div>
                            </div>
                            
                            <div class="summary-stats">
                                <div class="stat-item">
                                    <div class="stat-number"><?php echo $grade_summary[$type]['average_percentage']; ?>%</div>
                                    <div class="stat-text">Average</div>
                                </div>
                                <div class="stat-item">
                                    <div class="stat-number"><?php echo $grade_summary[$type]['count']; ?></div>
                                    <div class="stat-text">Completed</div>
                                </div>
                                <div class="stat-item">
                                    <div class="stat-number"><?php echo $grade_summary[$type]['weight']; ?>%</div>
                                    <div class="stat-text">Weight</div>
                                </div>
                                <div class="stat-item">
                                    <div class="stat-number"><?php echo $grade_summary[$type]['weighted_contribution']; ?></div>
                                    <div class="stat-text">Contribution</div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Detailed Results with Tabs -->
                <div class="grades-section">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fas fa-list-alt"></i>
                            Detailed Results
                        </h2>
                    </div>
                    
                    <div class="tabs">
                        <div class="tab active" onclick="openTab(event, 'all')">All Results</div>
                        <div class="tab" onclick="openTab(event, 'quiz')">Quizzes</div>
                        <div class="tab" onclick="openTab(event, 'assignment')">Assignments</div>
                        <div class="tab" onclick="openTab(event, 'project')">Projects</div>
                        <div class="tab" onclick="openTab(event, 'exam')">Exams</div>
                    </div>

                    <!-- All Results Tab -->
                    <div id="all" class="tab-content active">
                        <div class="detailed-results">
                            <?php if (!empty($all_results)): ?>
                                <table class="results-table">
                                    <thead>
                                        <tr>
                                            <th>Assessment</th>
                                            <th>Type</th>
                                            <th>Course</th>
                                            <th>Score</th>
                                            <th>Grade</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($all_results as $result): ?>
                                        <tr>
                                            <td>
                                                <div class="assessment-title"><?php echo htmlspecialchars($result['title']); ?></div>
                                            </td>
                                            <td>
                                                <span class="assessment-type <?php echo $result['type']; ?>">
                                                    <?php echo ucfirst($result['type']); ?>
                                                </span>
                                            </td>
                                            <td><?php echo htmlspecialchars($result['course_name'] ?? 'General'); ?></td>
                                            <td>
                                                <div class="score-display">
                                                    <?php echo $result['marks_obtained']; ?>/<?php echo $result['total_marks']; ?>
                                                    <div class="percentage">
                                                        (<?php echo round(($result['marks_obtained'] / $result['total_marks']) * 100, 1); ?>%)
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="grade-badge <?php echo getGradeColorClass(($result['marks_obtained'] / $result['total_marks']) * 100); ?>">
                                                    <?php echo $result['grade']; ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('M j, Y', strtotime($result['submitted_at'])); ?></td>
                                            <td>
                                                <?php if ($result['marks_obtained'] >= ($result['pass_marks'] ?? ($result['total_marks'] * 0.6))): ?>
                                                    <span class="grade-badge excellent">Passed</span>
                                                <?php else: ?>
                                                    <span class="grade-badge poor">Failed</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <div class="empty-state">
                                    <i class="fas fa-chart-bar"></i>
                                    <h3>No Results Available</h3>
                                    <p>You haven't completed any assessments yet.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Individual Type Tabs -->
                    <?php foreach (['quiz', 'assignment', 'project', 'exam'] as $type): ?>
                    <div id="<?php echo $type; ?>" class="tab-content">
                        <div class="detailed-results">
                            <?php if (!empty($results[$type])): ?>
                                <table class="results-table">
                                    <thead>
                                        <tr>
                                            <th>Assessment</th>
                                            <th>Course</th>
                                            <th>Score</th>
                                            <th>Grade</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($results[$type] as $result): ?>
                                        <tr>
                                            <td>
                                                <div class="assessment-title"><?php echo htmlspecialchars($result['title']); ?></div>
                                            </td>
                                            <td><?php echo htmlspecialchars($result['course_name'] ?? 'General'); ?></td>
                                            <td>
                                                <div class="score-display">
                                                    <?php echo $result['marks_obtained']; ?>/<?php echo $result['total_marks']; ?>
                                                    <div class="percentage">
                                                        (<?php echo round(($result['marks_obtained'] / $result['total_marks']) * 100, 1); ?>%)
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="grade-badge <?php echo getGradeColorClass(($result['marks_obtained'] / $result['total_marks']) * 100); ?>">
                                                    <?php echo $result['grade']; ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('M j, Y', strtotime($result['submitted_at'])); ?></td>
                                            <td>
                                                <?php if ($result['marks_obtained'] >= ($result['pass_marks'] ?? ($result['total_marks'] * 0.6))): ?>
                                                    <span class="grade-badge excellent">Passed</span>
                                                <?php else: ?>
                                                    <span class="grade-badge poor">Failed</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <div class="empty-state">
                                    <i class="fas fa-<?php echo $type === 'quiz' ? 'question-circle' : ($type === 'assignment' ? 'file-alt' : ($type === 'project' ? 'project-diagram' : 'graduation-cap')); ?>"></i>
                                    <h3>No <?php echo ucfirst($type); ?>s Completed</h3>
                                    <p>You haven't completed any <?php echo $type; ?>s yet.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
    <script>
        // Tab functionality
        function openTab(evt, tabName) {
            var i, tabcontent, tabs;
            tabcontent = document.getElementsByClassName("tab-content");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].classList.remove("active");
            }
            tabs = document.getElementsByClassName("tab");
            for (i = 0; i < tabs.length; i++) {
                tabs[i].classList.remove("active");
            }
            document.getElementById(tabName).classList.add("active");
            evt.currentTarget.classList.add("active");
        }

        // Performance Chart
        const ctx = document.getElementById('performanceChart').getContext('2d');
        const performanceChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Quiz', 'Assignment', 'Project', 'Exam'],
                datasets: [{
                    label: 'Average Performance (%)',
                    data: [
                        <?php echo $grade_summary['quiz']['average_percentage']; ?>,
                        <?php echo $grade_summary['assignment']['average_percentage']; ?>,
                        <?php echo $grade_summary['project']['average_percentage']; ?>,
                        <?php echo $grade_summary['exam']['average_percentage']; ?>
                    ],
                    borderColor: 'rgb(59, 130, 246)',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: 'rgb(59, 130, 246)',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        },
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                },
                elements: {
                    point: {
                        hoverRadius: 8
                    }
                }
            }
        });

        // Print functionality
        function printResults() {
            const printContent = document.querySelector('.results-container').innerHTML;
            const originalContent = document.body.innerHTML;
            
            document.body.innerHTML = `
                <div style="padding: 20px; font-family: Arial, sans-serif;">
                    <div style="text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 20px;">
                        <h1 style="color: #333; margin-bottom: 10px;">Benadir University</h1>
                        <h2 style="color: #666; margin-bottom: 20px;">Academic Results Report</h2>
                        <p style="color: #888;">Generated on: ${new Date().toLocaleDateString()}</p>
                    </div>
                    ${printContent}
                </div>
            `;
            
            window.print();
            document.body.innerHTML = originalContent;
            location.reload();
        }

        // Export to CSV functionality
        function exportToCSV() {
            const results = <?php echo json_encode($all_results); ?>;
            let csvContent = "Assessment,Type,Course,Marks Obtained,Total Marks,Percentage,Grade,Date,Status\n";
            
            results.forEach(result => {
                const percentage = Math.round((result.marks_obtained / result.total_marks) * 100 * 10) / 10;
                const passMarks = result.pass_marks || (result.total_marks * 0.6);
                const status = result.marks_obtained >= passMarks ? 'Passed' : 'Failed';
                const date = new Date(result.submitted_at).toLocaleDateString();
                
                csvContent += `"${result.title}","${result.type}","${result.course_name || 'General'}",${result.marks_obtained},${result.total_marks},${percentage}%,"${result.grade}","${date}","${status}"\n`;
            });
            
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement("a");
            const url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", "academic_results.csv");
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

        // Export to PDF functionality
        function exportToPDF() {
            window.print();
        }

        // Animate progress bars on load
        document.addEventListener('DOMContentLoaded', function() {
            const progressBars = document.querySelectorAll('.progress-fill');
            progressBars.forEach(bar => {
                const width = bar.style.width;
                bar.style.width = '0%';
                setTimeout(() => {
                    bar.style.width = width;
                }, 500);
            });

            // Animate stat cards
            const statCards = document.querySelectorAll('.stat-card');
            statCards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    card.style.transition = 'all 0.5s ease';
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, index * 100);
            });
        });

        // Auto-refresh data every 5 minutes
        setInterval(() => {
            location.reload();
        }, 300000);
    </script>
</body>
</html>
