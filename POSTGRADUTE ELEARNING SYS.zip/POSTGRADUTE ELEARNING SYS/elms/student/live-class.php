<?php
session_start();
include_once '../config/init.php';

if (!is_logged_in() || !is_student()) {
    header("Location: ../auth/login.php");
    exit();
}

$student_id = $_SESSION['user_id'];
$today = date('Y-m-d H:i:s');
$upcoming_classes = [];
$past_classes = [];
$live_now_classes = [];
$message = '';
$messageType = '';

// Auto-update class statuses before fetching data
$conn->query("UPDATE live_classes
              SET status = 'live'
              WHERE status = 'scheduled'
              AND NOW() BETWEEN scheduled_time AND DATE_ADD(scheduled_time, INTERVAL duration MINUTE)");

$conn->query("UPDATE live_classes
              SET status = 'completed'
              WHERE status IN ('scheduled', 'live')
              AND DATE_ADD(scheduled_time, INTERVAL duration MINUTE) < NOW()");


   try {
    // Upcoming classes (scheduled in future)
    $upcoming_query = "SELECT DISTINCT lc.id, lc.title, lc.description, lc.platform, lc.meeting_url,
                lc.scheduled_time, lc.duration, lc.status,
                c.name AS course_name, c.code AS course_code,
                u.full_name AS instructor_name,
                lc.meeting_id, lc.passcode,
                b.name AS batch_name,
                DATE_ADD(lc.scheduled_time, INTERVAL lc.duration MINUTE) AS end_time
    FROM live_classes lc
    JOIN course c ON lc.course_id = c.id
    JOIN batch b ON b.id = c.batch_id
    JOIN enrollment e ON e.batch_id = b.id
    JOIN users u ON lc.instructor_id = u.id
    WHERE e.user_id = ?
      AND lc.scheduled_time > NOW() 
      AND lc.status = 'scheduled'
    ORDER BY lc.scheduled_time ASC";

    $upcoming_stmt = $conn->prepare($upcoming_query);
    $upcoming_stmt->execute([$student_id]);
    $upcoming_classes = $upcoming_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Past classes (already completed)
    $past_query = "SELECT DISTINCT lc.id, lc.title, lc.description, lc.platform, lc.meeting_url,
                lc.scheduled_time, lc.duration, lc.status,
                c.name AS course_name, c.code AS course_code,
                u.full_name AS instructor_name,
                lc.meeting_id, lc.passcode,
                b.name AS batch_name,
                DATE_ADD(lc.scheduled_time, INTERVAL lc.duration MINUTE) AS end_time
    FROM live_classes lc
    JOIN course c ON lc.course_id = c.id
    JOIN batch b ON b.id = c.batch_id
    JOIN enrollment e ON e.batch_id = b.id
    JOIN users u ON lc.instructor_id = u.id
    WHERE e.user_id = ?
      AND lc.scheduled_time <= NOW() 
      AND lc.status = 'completed'
    ORDER BY lc.scheduled_time ASC";

    $past_stmt = $conn->prepare($past_query);
    $past_stmt->execute([$student_id]);
    $past_classes = $past_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Live now classes (currently running)
    $live_now_query = "SELECT DISTINCT lc.id, lc.title, lc.description, lc.platform, lc.meeting_url,
                lc.scheduled_time, lc.duration, lc.status,
                c.name AS course_name, c.code AS course_code,
                u.full_name AS instructor_name,
                lc.meeting_id, lc.passcode,
                b.name AS batch_name,
                DATE_ADD(lc.scheduled_time, INTERVAL lc.duration MINUTE) AS end_time
    FROM live_classes lc
    JOIN course c ON lc.course_id = c.id
    JOIN batch b ON b.id = c.batch_id
    JOIN enrollment e ON e.batch_id = b.id
    JOIN users u ON lc.instructor_id = u.id
    WHERE e.user_id = ?
      AND NOW() BETWEEN lc.scheduled_time 
                  AND DATE_ADD(lc.scheduled_time, INTERVAL lc.duration MINUTE)
      AND lc.status = 'live'
    ORDER BY lc.scheduled_time ASC";

    $live_now_stmt = $conn->prepare($live_now_query);
    $live_now_stmt->execute([$student_id]);
    $live_now_classes = $live_now_stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log("Database error fetching student live classes: " . $e->getMessage());
    $message = "Error loading live classes. Please try again later.";
    $messageType = "danger";
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Live Classes - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/student.css">
    <link rel="stylesheet" href="../assets/css/student-live-class.css">
    <?php echo FONT_AWESOME_CSS; ?>
    <style>
        .class-status.live-now {
            background-color: #e74c3c;
            color: #fff;
            padding: 4px 10px;
            border-radius: 4px;
            font-weight: bold;
        }
    </style>
</head>
<body>
<div class="admin-container">
    <?php include_once '../includes/student-sidebar.php'; ?>

    <div class="admin-content">
        <div class="admin-header">
            <h1>Live Classes</h1>
        </div>

        <?php if (!empty($message)): ?>
            <div class="message <?php echo $messageType; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <div class="tabs">
            <div class="tab active" onclick="openTab(event, 'upcomingClasses')">Upcoming Classes</div>
            <div class="tab" onclick="openTab(event, 'liveNow')">Live Now</div>
            <div class="tab" onclick="openTab(event, 'pastClasses')">Past Classes</div>
        </div>

        <!-- Upcoming Classes -->
        <div id="upcomingClasses" class="tab-content active">
            <div class="live-classes-container">
                <?php if (!empty($upcoming_classes)): ?>
                    <?php foreach ($upcoming_classes as $class): ?>
                        <?php
                            $start_time = $class['scheduled_time'];
                            $end_time = date('Y-m-d H:i:s', strtotime($start_time . ' + ' . $class['duration'] . ' minutes'));
                        ?>
                        <div class="live-class-card">
                            <div class="class-header">
                                <h3 class="class-title"><?php echo htmlspecialchars($class['title']); ?></h3>
                                <span class="class-status scheduled"><?php echo ucfirst($class['status']); ?></span>
                            </div>
                            <div class="class-details">
                                <div class="detail-item"><strong>Course:</strong> <?php echo htmlspecialchars($class['course_code'] . ' - ' . $class['course_name']); ?></div>
                                <div class="detail-item"><strong>Instructor:</strong> <?php echo htmlspecialchars($class['instructor_name']); ?></div>
                                <div class="detail-item"><strong>Platform:</strong> <?php echo htmlspecialchars($class['platform']); ?></div>
                                <div class="detail-item"><strong>Start:</strong> <?php echo date('M j, Y g:i A', strtotime($start_time)); ?></div>
                                <div class="detail-item"><strong>End:</strong> <?php echo date('M j, Y g:i A', strtotime($end_time)); ?></div>
                                <?php if (!empty($class['description'])): ?>
                                    <div class="detail-item full-width"><strong>Description:</strong> <?php echo nl2br(htmlspecialchars($class['description'])); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="class-actions">
                                <?php
                                    $current_time = time();
                                    $start_timestamp = strtotime($start_time);
                                    $end_timestamp = strtotime($end_time);
                                    if ($current_time >= $start_timestamp && $current_time <= $end_timestamp && !empty($class['meeting_url'])):
                                ?>
                                    <a href="<?php echo htmlspecialchars($class['meeting_url']); ?>" target="_blank" class="btn btn-primary">Join Class Now</a>
                                <?php elseif ($current_time < $start_timestamp): ?>
                                    <button class="btn btn-secondary" disabled>Upcoming</button>
                                <?php else: ?>
                                    <button class="btn btn-secondary" disabled>Ended</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-video"></i>
                        <h3>No Upcoming Live Classes</h3>
                        <p>There are no live classes scheduled for you at the moment.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Live Now -->
        <div id="liveNow" class="tab-content">
            <div class="live-classes-container">
                <?php if (!empty($live_now_classes)): ?>
                    <?php foreach ($live_now_classes as $class): ?>
                        <?php
                            $start_time = $class['scheduled_time'];
                            $end_time = date('Y-m-d H:i:s', strtotime($start_time . ' + ' . $class['duration'] . ' minutes'));
                        ?>
                        <div class="live-class-card">
                            <div class="class-header">
                                <h3 class="class-title"><?php echo htmlspecialchars($class['title']); ?></h3>
                                <span class="class-status live-now">Live Now</span>
                            </div>
                            <div class="class-details">
                                <div class="detail-item"><strong>Course:</strong> <?php echo htmlspecialchars($class['course_code'] . ' - ' . $class['course_name']); ?></div>
                                <div class="detail-item"><strong>Instructor:</strong> <?php echo htmlspecialchars($class['instructor_name']); ?></div>
                                <div class="detail-item"><strong>Platform:</strong> <?php echo htmlspecialchars($class['platform']); ?></div>
                                <div class="detail-item"><strong>Start:</strong> <?php echo date('M j, Y g:i A', strtotime($start_time)); ?></div>
                                <div class="detail-item"><strong>End:</strong> <?php echo date('M j, Y g:i A', strtotime($end_time)); ?></div>
                                <?php if (!empty($class['description'])): ?>
                                    <div class="detail-item full-width"><strong>Description:</strong> <?php echo nl2br(htmlspecialchars($class['description'])); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="class-actions">
                                <a href="<?php echo htmlspecialchars($class['meeting_url']); ?>" target="_blank" class="btn btn-success">Join Now</a>
                                <?php if (!empty($class['passcode'])): ?>
                                    <p style="margin-top: 8px; font-weight: bold;">Passcode: <?php echo htmlspecialchars($class['passcode']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-broadcast-tower"></i>
                        <h3>No Live Classes at the Moment</h3>
                        <p>There are no ongoing live classes currently.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Past Classes -->
        <div id="pastClasses" class="tab-content">
            <div class="live-classes-container">
                <?php if (!empty($past_classes)): ?>
                    <?php foreach ($past_classes as $class): ?>
                        <?php
                            $start_time = $class['scheduled_time'];
                            $end_time = date('Y-m-d H:i:s', strtotime($start_time . ' + ' . $class['duration'] . ' minutes'));
                        ?>
                        <div class="live-class-card">
                            <div class="class-header">
                                <h3 class="class-title"><?php echo htmlspecialchars($class['title']); ?></h3>
                                <span class="class-status completed"><?php echo ucfirst($class['status']); ?></span>
                            </div>
                            <div class="class-details">
                                <div class="detail-item"><strong>Course:</strong> <?php echo htmlspecialchars($class['course_code'] . ' - ' . $class['course_name']); ?></div>
                                <div class="detail-item"><strong>Instructor:</strong> <?php echo htmlspecialchars($class['instructor_name']); ?></div>
                                <div class="detail-item"><strong>Platform:</strong> <?php echo htmlspecialchars($class['platform']); ?></div>
                                <div class="detail-item"><strong>Start:</strong> <?php echo date('M j, Y g:i A', strtotime($start_time)); ?></div>
                                <div class="detail-item"><strong>End:</strong> <?php echo date('M j, Y g:i A', strtotime($end_time)); ?></div>
                                <?php if (!empty($class['description'])): ?>
                                    <div class="detail-item full-width"><strong>Description:</strong> <?php echo nl2br(htmlspecialchars($class['description'])); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="class-actions">
                                <?php if (!empty($class['meeting_url'])): ?>
                                 <a href="<?php echo htmlspecialchars($class['meeting_url']); ?>" target="_blank" class="btn btn-secondary btn-sm">View Recording</a>
                                <?php else: ?>
                                    <button class="btn btn-secondary btn-sm" disabled>No Recording</button>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-history"></i>
                        <h3>No Past Live Classes</h3>
                        <p>You have not attended any past live classes.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="../assets/js/theme.js"></script>
<script>
function openTab(event, tabId) {
    const tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(content => content.classList.remove('active'));

    const tabs = document.querySelectorAll('.tab');
    tabs.forEach(tab => tab.classList.remove('active'));

    document.getElementById(tabId).classList.add('active');
    event.currentTarget.classList.add('active');
}
</script>
</body>
</html>
