<?php
session_start();
include_once '../config/init.php';

// Define is_student() if not already defined
if (!function_exists('is_student')) {
    function is_student() {
        return isset($_SESSION['role']) && $_SESSION['role'] === 'student';
    }
}

// Check if user is logged in and is a student
if (!is_logged_in() || !is_student()) {
    header("Location: ../auth/login.php");
    exit();
}

$student_id = $_SESSION['user_id'];
$message = '';
$error = '';

// Get student enrollment info
try {
    $student_query = "SELECT u.full_name, u.email, e.program_id, e.department_id, 
                      p.name as program_name, d.name as department_name
                      FROM users u
                      INNER JOIN enrollment e ON u.id = e.user_id
                      INNER JOIN programs p ON e.program_id = p.id
                      INNER JOIN departments d ON e.department_id = d.id
                      WHERE u.id = ?";
    $student_stmt = $conn->prepare($student_query);
    $student_stmt->execute([$student_id]);
    $student_info = $student_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$student_info) {
        $error = "Student enrollment information not found.";
    }
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}

// Get active academic year and semester
$active_academic_year = get_active_academic_year($conn);
$active_semester = get_active_semester($conn, $active_academic_year['id'] ?? null);

$submission_settings = null;
$can_submit = false;
$submission_message = '';

try {
    if ($active_academic_year && $active_semester) {
        $settings_query = "SELECT * FROM thesis_submission_settings 
                          WHERE academic_year_id = ? AND semester_id = ? AND status = 'active'";
        $settings_stmt = $conn->prepare($settings_query);
        $settings_stmt->execute([$active_academic_year['id'], $active_semester['id']]);
        $submission_settings = $settings_stmt->fetch(PDO::FETCH_ASSOC);

        if ($submission_settings) {
            // Check submission eligibility
            if ($submission_settings['submission_mode'] === 'open_submission') {
                $can_submit = true;
                $submission_message = "Open submission is active - you can submit your thesis at any time.";
            } else {
                // Deadline-based submission
                $deadline = strtotime($submission_settings['submission_deadline']);
                $now = time();
                
                if ($now <= $deadline) {
                    $can_submit = true;
                    $submission_message = "Submission deadline: " . date('M d, Y H:i', $deadline);
                } elseif ($submission_settings['late_submission_allowed']) {
                    $can_submit = true;
                    $penalty_text = $submission_settings['late_submission_penalty'] ? 
                                   " (Late penalty: {$submission_settings['late_submission_penalty']}%)" : "";
                    $submission_message = "Late submission is allowed{$penalty_text}. Original deadline was: " . date('M d, Y H:i', $deadline);
                } else {
                    $can_submit = false;
                    $submission_message = "Submission deadline has passed: " . date('M d, Y H:i', $deadline);
                }
            }

            // Check if student has reached maximum submissions
            $submission_count_query = "SELECT COUNT(*) as count FROM thesis WHERE student_id = ? AND academic_year_id = ? AND semester_id = ?";
            $count_stmt = $conn->prepare($submission_count_query);
            $count_stmt->execute([$student_id, $active_academic_year['id'], $active_semester['id']]);
            $submission_count = $count_stmt->fetch(PDO::FETCH_ASSOC)['count'];

            if ($submission_count >= $submission_settings['max_submissions_per_student']) {
                $can_submit = false;
                $submission_message = "You have reached the maximum number of submissions ({$submission_settings['max_submissions_per_student']}) for this academic session.";
            }
        } else {
            $submission_message = "No submission settings configured for the current academic session. Please contact administration.";
        }
    } else {
        $submission_message = "No active academic year or semester found. Please contact administration.";
    }
} catch (PDOException $e) {
    $error = "Error checking submission settings: " . $e->getMessage();
}

// Handle thesis submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_thesis'])) {
    if (!$can_submit) {
        $error = "Thesis submission is not currently allowed. " . $submission_message;
    } else {
        $title = trim($_POST['title']);
        $abstract = trim($_POST['abstract']);
        $keywords = trim($_POST['keywords']);
        
        if (empty($title) || empty($abstract) || empty($keywords)) {
            $error = "Please fill in all required fields.";
        } elseif (!isset($_FILES['thesis_file']) || $_FILES['thesis_file']['error'] !== UPLOAD_ERR_OK) {
            $error = "Please select a thesis file to upload.";
        } else {
            $file = $_FILES['thesis_file'];
            $allowed_types = ['pdf', 'doc', 'docx'];
            $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            
            if (!in_array($file_extension, $allowed_types)) {
                $error = "Only PDF, DOC, and DOCX files are allowed.";
            } elseif ($file['size'] > 50 * 1024 * 1024) {
                $error = "File size must be less than 50MB.";
            } else {
                // Compute file hash
                $file_hash = hash_file('sha256', $file['tmp_name']);
                
                // Check if same file has already been submitted
                $check_query = "SELECT id FROM thesis 
                                WHERE student_id = ? AND file_hash = ?";
                $check_stmt = $conn->prepare($check_query);
                $check_stmt->execute([$student_id, $file_hash]);

                if ($check_stmt->rowCount() > 0) {
                    $error = "You have already submitted this exact file.";
                } else {
                    $upload_dir = '../uploads/thesis/';
                    if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
                    
                    $filename = 'thesis_' . $student_id . '_' . time() . '.' . $file_extension;
                    $file_path = $upload_dir . $filename;
                    
                    if (move_uploaded_file($file['tmp_name'], $file_path)) {
                        try {
                            $conn->beginTransaction();
                            
                            $insert_query = "INSERT INTO thesis 
                                (student_id, program_id, department_id, academic_year_id, semester_id, submission_settings_id,
                                 title, abstract, keywords, file_path, file_type, file_size, file_hash, 
                                 submission_date, created_at) 
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
                            $insert_stmt = $conn->prepare($insert_query);
                            $insert_stmt->execute([
                                $student_id,
                                $student_info['program_id'],
                                $student_info['department_id'],
                                $active_academic_year['id'] ?? null,
                                $active_semester['id'] ?? null,
                                $submission_settings['id'] ?? null,
                                $title,
                                $abstract,
                                $keywords,
                                'uploads/thesis/' . $filename,
                                $file_extension,
                                $file['size'],
                                $file_hash
                            ]);
                            
                            $thesis_id = $conn->lastInsertId();
                            
                            include_once '../includes/thesis-notifications.php';
                            notifyThesisSubmission($conn, $thesis_id, $student_id, $title);
                            
                            $conn->commit();

                            $_SESSION['success_message'] = "Thesis submitted successfully!";
                            header("Location: " . $_SERVER['PHP_SELF']);
                            exit();
                        } catch (PDOException $e) {
                            $conn->rollBack();
                            $error = "Database error: " . $e->getMessage();
                            unlink($file_path);
                        }
                    } else {
                        $error = "Failed to upload file.";
                    }
                }
            }
        }
    }
}

// Display success message if redirected
if (isset($_SESSION['success_message'])) {
    $message = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}

// Get student's thesis submissions
$thesis_list = [];
try {
    $thesis_query = "SELECT t.*, tr.status as review_status, tr.comments, tr.review_date,
                     u.full_name as supervisor_name, tss.submission_mode, tss.submission_deadline
                     FROM thesis t
                     LEFT JOIN thesis_reviews tr ON t.id = tr.thesis_id
                     LEFT JOIN users u ON t.supervisor_id = u.id
                     LEFT JOIN thesis_submission_settings tss ON t.submission_settings_id = tss.id
                     WHERE t.student_id = ?
                     ORDER BY t.created_at DESC";
    $thesis_stmt = $conn->prepare($thesis_query);
    $thesis_stmt->execute([$student_id]);
    $thesis_list = $thesis_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = "Error fetching thesis data: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Thesis - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link rel="stylesheet" href="../assets/css/student.css">
    <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/student-sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="thesis-dashboard">
                <!-- Submission Status Card -->
                <div class="dashboard-card submission-status-card">
                    <div class="card-header">
                        <div class="card-title">
                            <div class="card-icon submission-icon">
                                <?php if ($can_submit): ?>
                                    <i class="fas fa-unlock"></i>
                                <?php else: ?>
                                    <i class="fas fa-lock"></i>
                                <?php endif; ?>
                            </div>
                            <h3>Submission Status</h3>
                        </div>
                        <div class="card-actions">
                            <?php if ($can_submit): ?>
                            <button class="btn btn-primary btn-sm" onclick="openSubmissionModal()">
                                <i class="fas fa-plus"></i> Submit Thesis
                            </button>
                            <?php else: ?>
                            <button class="btn btn-secondary btn-sm" disabled title="<?php echo htmlspecialchars($submission_message); ?>">
                                <i class="fas fa-lock"></i> Closed
                            </button>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-content">
                        <?php if ($submission_settings): ?>
                            <div class="status-grid">
                                <div class="status-item">
                                    <span class="status-label">Mode</span>
                                    <span class="status-badge mode-<?php echo $submission_settings['submission_mode']; ?>">
                                        <i class="fas fa-<?php echo $submission_settings['submission_mode'] === 'open_submission' ? 'infinity' : 'calendar-alt'; ?>"></i>
                                        <?php echo ucwords(str_replace('_', ' ', $submission_settings['submission_mode'])); ?>
                                    </span>
                                </div>
                                <?php if ($submission_settings['submission_mode'] === 'deadline_based' && $submission_settings['submission_deadline']): ?>
                                <div class="status-item">
                                    <span class="status-label">Deadline</span>
                                    <span class="status-value">
                                        <i class="fas fa-clock"></i>
                                        <?php echo date('M d, Y H:i', strtotime($submission_settings['submission_deadline'])); ?>
                                    </span>
                                </div>
                                <?php endif; ?>
                                <div class="status-item">
                                    <span class="status-label">Max Submissions</span>
                                    <span class="status-value">
                                        <i class="fas fa-file-upload"></i>
                                        <?php echo $submission_settings['max_submissions_per_student']; ?>
                                    </span>
                                </div>
                            </div>
                            <div class="submission-message">
                                <div class="message-content <?php echo $can_submit ? 'success' : 'warning'; ?>">
                                    <i class="fas fa-<?php echo $can_submit ? 'check-circle' : 'exclamation-triangle'; ?>"></i>
                                    <?php echo $submission_message; ?>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="submission-message">
                                <div class="message-content warning">
                                    <i class="fas fa-exclamation-triangle"></i>
                                    No submission settings configured for current academic session
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Student Information Card -->
                <div class="dashboard-card student-info-card">
                    <div class="card-header">
                        <div class="card-title">
                            <div class="card-icon student-icon">
                                <i class="fas fa-user-graduate"></i>
                            </div>
                            <h3>Student Information</h3>
                        </div>
                    </div>
                    <div class="card-content">
                        <div class="info-grid">
                            <div class="info-item">
                                <span class="info-label">Name</span>
                                <span class="info-value"><?php echo htmlspecialchars($student_info['full_name'] ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Program</span>
                                <span class="info-value"><?php echo htmlspecialchars($student_info['program_name'] ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Department</span>
                                <span class="info-value"><?php echo htmlspecialchars($student_info['department_name'] ?? 'N/A'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Academic Year</span>
                                <span class="info-value"><?php echo htmlspecialchars($active_academic_year['name'] ?? 'N/A'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Thesis Submissions -->
            <div class="dashboard-card submissions-card">
                <div class="card-header">
                    <div class="card-title">
                        <div class="card-icon submissions-icon">
                            <i class="fas fa-file-alt"></i>
                        </div>
                        <h3>My Thesis Submissions</h3>
                    </div>
                </div>
                <div class="card-content">
                    <?php if (!empty($thesis_list)): ?>
                        <div class="table-responsive">
                            <table class="thesis-table">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                        <th>Supervisor</th>
                                        <th>Mode</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($thesis_list as $thesis): ?>
                                    <tr>
                                        <td>
                                            <div class="thesis-info">
                                                <div class="thesis-title"><?php echo htmlspecialchars($thesis['title']); ?></div>
                                                <div class="thesis-keywords">
                                                    <i class="fas fa-tags"></i>
                                                    <?php echo htmlspecialchars($thesis['keywords']); ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="date-info">
                                                <i class="fas fa-calendar"></i>
                                                <?php echo date('M d, Y', strtotime($thesis['submission_date'])); ?>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="status-badge status-<?php echo $thesis['status']; ?>">
                                                <i class="fas fa-<?php 
                                                    echo $thesis['status'] === 'approved' ? 'check-circle' : 
                                                        ($thesis['status'] === 'rejected' ? 'times-circle' : 'clock'); 
                                                ?>"></i>
                                                <?php echo ucwords(str_replace('_', ' ', $thesis['status'])); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="supervisor-info">
                                                <i class="fas fa-user-tie"></i>
                                                <?php echo htmlspecialchars($thesis['supervisor_name'] ?? 'Not Assigned'); ?>
                                            </div>
                                        </td>
                                        <td>
                                            <?php if ($thesis['submission_mode']): ?>
                                                <span class="mode-badge mode-<?php echo $thesis['submission_mode']; ?>">
                                                    <i class="fas fa-<?php echo $thesis['submission_mode'] === 'open_submission' ? 'infinity' : 'calendar-alt'; ?>"></i>
                                                    <?php echo ucwords(str_replace('_', ' ', $thesis['submission_mode'])); ?>
                                                </span>
                                                <?php if ($thesis['submission_mode'] === 'deadline_based' && $thesis['submission_deadline']): ?>
                                                    <div class="deadline-info">
                                                        <small><i class="fas fa-clock"></i> <?php echo date('M d, Y', strtotime($thesis['submission_deadline'])); ?></small>
                                                    </div>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span class="text-muted">N/A</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <button class="btn btn-sm btn-info" onclick="viewThesis(<?php echo $thesis['id']; ?>)" title="View Details">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <a href="../<?php echo htmlspecialchars($thesis['file_path']); ?>" 
                                                   class="btn btn-sm btn-secondary" download title="Download">
                                                    <i class="fas fa-download"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="empty-state">
                            <div class="empty-icon">
                                <i class="fas fa-graduation-cap"></i>
                            </div>
                            <h4>No Thesis Submitted Yet</h4>
                            <p><?php echo $can_submit ? 'Click "Submit Thesis" to upload your thesis document.' : 'Thesis submission is currently not available.'; ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Thesis Submission Modal -->
    <div id="submissionModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Submit New Thesis</h3>
                <span class="close" onclick="closeSubmissionModal()">&times;</span>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="title">Thesis Title *</label>
                        <input type="text" id="title" name="title" required maxlength="255">
                    </div>
                    
                    <div class="form-group">
                        <label for="abstract">Abstract *</label>
                        <textarea id="abstract" name="abstract" rows="6" required 
                                  placeholder="Provide a brief summary of your thesis..."></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="keywords">Keywords *</label>
                        <input type="text" id="keywords" name="keywords" required maxlength="500"
                               placeholder="Enter keywords separated by commas">
                        <small>Separate keywords with commas (e.g., machine learning, data analysis, AI)</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="thesis_file">Thesis Document *</label>
                        <input type="file" id="thesis_file" name="thesis_file" required 
                               accept=".pdf,.doc,.docx">
                        <small>Allowed formats: PDF, DOC, DOCX (Max size: 50MB)</small>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeSubmissionModal()">Cancel</button>
                    <button type="submit" name="submit_thesis" class="btn btn-primary">
                        <i class="fas fa-upload"></i> Submit Thesis
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Thesis View Modal -->
    <div id="viewModal" class="modal">
        <div class="modal-content modal-large">
            <div class="modal-header">
                <h3>Thesis Details</h3>
                <span class="close" onclick="closeViewModal()">&times;</span>
            </div>
            <div class="modal-body" id="thesisDetails">
                <!-- Content will be loaded dynamically -->
            </div>
        </div>
    </div>

    <script src="../assets/js/theme.js"></script>
    <script>
        function openSubmissionModal() {
            document.getElementById('submissionModal').style.display = 'block';
        }

        function closeSubmissionModal() {
            document.getElementById('submissionModal').style.display = 'none';
        }

        function closeViewModal() {
            document.getElementById('viewModal').style.display = 'none';
        }

        function viewThesis(thesisId) {
            // Load thesis details via AJAX
            fetch('ajax/get-thesis-details.php?id=' + thesisId)
                .then(response => response.text())
                .then(data => {
                    document.getElementById('thesisDetails').innerHTML = data;
                    document.getElementById('viewModal').style.display = 'block';
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error loading thesis details');
                });
        }

        // Close modals when clicking outside
        window.onclick = function(event) {
            const submissionModal = document.getElementById('submissionModal');
            const viewModal = document.getElementById('viewModal');
            
            if (event.target === submissionModal) {
                submissionModal.style.display = 'none';
            }
            if (event.target === viewModal) {
                viewModal.style.display = 'none';
            }
        }
    </script>
</body>
</html>
