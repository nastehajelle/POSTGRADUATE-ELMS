<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is student
if (!is_logged_in() || $_SESSION['role'] !== 'student') {
    header("Location: ../auth/login.php");
    exit();
}

$student_id = $_SESSION['user_id'];
$selected_instructor_id = isset($_GET['instructor_id']) ? (int)$_GET['instructor_id'] : null;
$selected_instructor = null;

// Get student's instructors for chat list
try {
    $instructors_query = "SELECT DISTINCT u.id, u.full_name, u.email, u.profile_photo,
       b.name AS batch_name,
       (SELECT COUNT(*) FROM chats 
        WHERE sender_id = u.id AND receiver_id = ? AND is_read = 0) AS unread_count,
       (SELECT created_at FROM chats 
        WHERE (sender_id = u.id AND receiver_id = ?) 
           OR (sender_id = ? AND receiver_id = u.id) 
        ORDER BY created_at DESC LIMIT 1) AS last_message_time
FROM users u
JOIN course c ON u.id = c.instructor_id
JOIN batch b ON b.id = c.batch_id
JOIN enrollment e ON e.batch_id = b.id
WHERE e.user_id = ? 
  AND u.role = 'instructor' 
  AND u.status = 'active'
ORDER BY last_message_time DESC, u.full_name;
";
    
    $instructors_stmt = $conn->prepare($instructors_query);
    $instructors_stmt->execute([$student_id, $student_id, $student_id, $student_id]);
    $instructors = $instructors_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // If no instructor selected, select the first one
    if (!$selected_instructor_id && count($instructors) > 0) {
        $selected_instructor_id = $instructors[0]['id'];
    }
    
    // Get selected instructor info
    if ($selected_instructor_id) {
        foreach ($instructors as $instructor) {
            if ($instructor['id'] == $selected_instructor_id) {
                $selected_instructor = $instructor;
                break;
            }
        }
    }
    
    // Get chat messages for selected instructor
    $messages = [];
    if ($selected_instructor_id) {
        $messages_query = "SELECT c.*, u.full_name as sender_name, u.profile_photo as sender_photo
                          FROM chats c
                          JOIN users u ON c.sender_id = u.id
                          WHERE (c.sender_id = ? AND c.receiver_id = ?) OR (c.sender_id = ? AND receiver_id = ?)
                          ORDER BY c.created_at ASC";
        
        $messages_stmt = $conn->prepare($messages_query);
        $messages_stmt->execute([$student_id, $selected_instructor_id, $selected_instructor_id, $student_id]);
        $messages = $messages_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Mark messages as read
        $mark_read_query = "UPDATE chats SET is_read = 1 WHERE sender_id = ? AND receiver_id = ?";
        $mark_read_stmt = $conn->prepare($mark_read_query);
        $mark_read_stmt->execute([$selected_instructor_id, $student_id]);
    }
    
} catch(PDOException $e) {
    error_log("Error fetching chat data: " . $e->getMessage());
    $instructors = [];
    $messages = [];
}

// Handle AJAX requests
if (isset($_POST['ajax'])) {
    header('Content-Type: application/json');
    
    if ($_POST['action'] === 'send_message') {
        $receiver_id = (int)$_POST['receiver_id'];
        $message = trim($_POST['message']);
        $attachment_path = null;
        $attachment_mime_type = null;
        
        // Handle file upload
        if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../uploads/chat_attachments/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            $file_extension = pathinfo($_FILES['attachment']['name'], PATHINFO_EXTENSION);
            $filename = 'chat_' . uniqid() . '.' . $file_extension;
            $attachment_path = $upload_dir . $filename;
            $attachment_mime_type = $_FILES['attachment']['type'];
            
            if (!move_uploaded_file($_FILES['attachment']['tmp_name'], $attachment_path)) {
                echo json_encode(['success' => false, 'message' => 'Failed to upload file']);
                exit();
            }
            
            // Store relative path
            $attachment_path = 'uploads/chat_attachments/' . $filename;
        }
        
        if (!empty($message) || $attachment_path) {
            try {
                $insert_query = "INSERT INTO chats (sender_id, receiver_id, message, attachment_path, attachment_mime_type, created_at) 
                               VALUES (?, ?, ?, ?, ?, NOW())";
                $insert_stmt = $conn->prepare($insert_query);
                $insert_stmt->execute([$student_id, $receiver_id, $message, $attachment_path, $attachment_mime_type]);
                
                echo json_encode(['success' => true]);
            } catch(PDOException $e) {
                echo json_encode(['success' => false, 'message' => 'Failed to send message']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Message cannot be empty']);
        }
        exit();
    }
    
    if ($_POST['action'] === 'get_messages') {
        $instructor_id = (int)$_POST['instructor_id'];
        
        try {
            $messages_query = "SELECT c.*, u.full_name as sender_name, u.profile_photo as sender_photo
                              FROM chats c
                              JOIN users u ON c.sender_id = u.id
                              WHERE (c.sender_id = ? AND c.receiver_id = ?) OR (c.sender_id = ? AND c.receiver_id = ?)
                              ORDER BY c.created_at ASC";
            
            $messages_stmt = $conn->prepare($messages_query);
            $messages_stmt->execute([$student_id, $instructor_id, $instructor_id, $student_id]);
            $messages = $messages_stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Mark messages as read
            $mark_read_query = "UPDATE chats SET is_read = 1 WHERE sender_id = ? AND receiver_id = ?";
            $mark_read_stmt = $conn->prepare($mark_read_query);
            $mark_read_stmt->execute([$instructor_id, $student_id]);
            
            echo json_encode(['success' => true, 'messages' => $messages]);
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Failed to fetch messages']);
        }
        exit();
    }
    
    if ($_POST['action'] === 'get_new_messages') {
        $instructor_id = (int)$_POST['chat_partner_id'];
        $last_check = $_POST['last_check'];
        
        try {
            $new_messages_query = "SELECT c.*, u.full_name as sender_name, u.profile_photo as sender_photo
                                  FROM chats c
                                  JOIN users u ON c.sender_id = u.id
                                  WHERE (c.sender_id = ? AND c.receiver_id = ?) OR (c.sender_id = ? AND c.receiver_id = ?)
                                  AND c.created_at > ?
                                  ORDER BY c.created_at ASC";
            
            $new_messages_stmt = $conn->prepare($new_messages_query);
            $new_messages_stmt->execute([$student_id, $instructor_id, $instructor_id, $student_id, $last_check]);
            $new_messages = $new_messages_stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $timestamp_query = "SELECT NOW() as timestamp";
            $timestamp_stmt = $conn->prepare($timestamp_query);
            $timestamp_stmt->execute();
            $timestamp = $timestamp_stmt->fetch(PDO::FETCH_ASSOC)['timestamp'];
            
            echo json_encode(['success' => true, 'messages' => $new_messages, 'timestamp' => $timestamp]);
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Failed to fetch new messages']);
        }
        exit();
    }
    
    if ($_POST['action'] === 'mark_typing') {
        $instructor_id = (int)$_POST['chat_partner_id'];
        
        try {
            $typing_query = "INSERT INTO typing_status (user_id, chat_partner_id, typing_at) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE typing_at = NOW()";
            $typing_stmt = $conn->prepare($typing_query);
            $typing_stmt->execute([$student_id, $instructor_id]);
            
            echo json_encode(['success' => true]);
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Failed to mark typing']);
        }
        exit();
    }
    
    if ($_POST['action'] === 'get_typing_status') {
        try {
            $typing_status_query = "SELECT user_id FROM typing_status WHERE chat_partner_id = ? AND typing_at > NOW() - INTERVAL 3 SECOND";
            $typing_status_stmt = $conn->prepare($typing_status_query);
            $typing_status_stmt->execute([$student_id]);
            $typing_users = $typing_status_stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode(['success' => true, 'typing_users' => $typing_users]);
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Failed to fetch typing status']);
        }
        exit();
    }
    
    if ($_POST['action'] === 'update_online_status') {
        try {
            $online_status_query = "INSERT INTO online_status (user_id, status, last_seen) VALUES (?, 'online', NOW()) ON DUPLICATE KEY UPDATE status = 'online', last_seen = NOW()";
            $online_status_stmt = $conn->prepare($online_status_query);
            $online_status_stmt->execute([$student_id]);
            
            echo json_encode(['success' => true]);
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Failed to update online status']);
        }
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chats - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <?php echo FONT_AWESOME_CSS; ?>
    <style>
        .chat-container {
            display: flex;
            height: calc(100vh - 120px);
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .chat-sidebar {
            width: 300px;
            border-right: 1px solid #e0e0e0;
            background: #f8f9fa;
            display: flex;
            flex-direction: column;
        }
        
        .chat-sidebar-header {
            padding: 20px;
            border-bottom: 1px solid #e0e0e0;
            background: #fff;
        }
        
        .chat-sidebar-header h3 {
            margin: 0;
            color: #333;
            font-size: 18px;
        }
        
        .instructors-list {
            flex: 1;
            overflow-y: auto;
        }
        
        .instructor-item {
            padding: 15px 20px;
            border-bottom: 1px solid #e0e0e0;
            cursor: pointer;
            transition: background-color 0.2s;
            position: relative;
        }
        
        .instructor-item:hover {
            background: #e9ecef;
        }
        
        .instructor-item.active {
            background: #007bff;
            color: white;
        }
        
        .instructor-item.active .instructor-name,
        .instructor-item.active .instructor-course {
            color: white;
        }
        
        .instructor-item.has-unread {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
        }
        
        .instructor-item.online::after {
            content: '';
            position: absolute;
            top: 15px;
            left: 45px;
            width: 12px;
            height: 12px;
            background: #007bff;
            border: 2px solid white;
            border-radius: 50%;
        }
        
        .instructor-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #ddd;
            display: inline-block;
            vertical-align: middle;
            margin-right: 12px;
            object-fit: cover;
        }
        
        .instructor-info {
            display: inline-block;
            vertical-align: middle;
            width: calc(100% - 60px);
        }
        
        .instructor-name {
            font-weight: 600;
            color: #333;
            margin: 0;
            font-size: 14px;
        }
        
        .instructor-course {
            color: #666;
            font-size: 12px;
            margin: 2px 0 0 0;
        }
        
        .unread-badge {
            position: absolute;
            top: 10px;
            right: 15px;
            background: #dc3545;
            color: white;
            border-radius: 10px;
            padding: 2px 6px;
            font-size: 11px;
            font-weight: bold;
        }
        
        .chat-main {
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        
        .chat-header {
            padding: 20px;
            border-bottom: 1px solid #e0e0e0;
            background: #fff;
            display: flex;
            align-items: center;
        }
        
        .chat-header-avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            margin-right: 15px;
            object-fit: cover;
        }
        
        .chat-header-info h3 {
            margin: 0;
            color: #333;
            font-size: 18px;
        }
        
        .chat-header-info p {
            margin: 2px 0 0 0;
            color: #666;
            font-size: 14px;
        }
        
        .chat-messages {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            background: #f8f9fa;
        }
        
        .message {
            margin-bottom: 15px;
            display: flex;
            align-items: flex-start;
        }
        
        .message.sent {
            flex-direction: row-reverse;
        }
        
        .message-avatar {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            margin: 0 10px;
            object-fit: cover;
        }
        
        .message-content {
            max-width: 70%;
            background: #fff;
            padding: 12px 16px;
            border-radius: 18px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        
        .message.sent .message-content {
            background: #007bff;
            color: white;
        }
        
        .message-text {
            margin: 0;
            line-height: 1.4;
        }
        
        .message-attachment {
            margin-top: 8px;
        }
        
        .message-attachment a {
            color: #007bff;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            padding: 8px 12px;
            background: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #e0e0e0;
        }
        
        .message.sent .message-attachment a {
            color: white;
            background: rgba(255,255,255,0.2);
            border-color: rgba(255,255,255,0.3);
        }
        
        .message-time {
            font-size: 11px;
            color: #999;
            margin-top: 5px;
        }
        
        .message.sent .message-time {
            color: rgba(255,255,255,0.8);
        }
        
        .chat-input {
            padding: 20px;
            border-top: 1px solid #e0e0e0;
            background: #fff;
        }
        
        .chat-input-form {
            display: flex;
            align-items: flex-end;
            gap: 10px;
        }
        
        .chat-input-wrapper {
            flex: 1;
            position: relative;
        }
        
        .chat-input-field {
            width: 100%;
            padding: 12px 50px 12px 16px;
            border: 1px solid #ddd;
            border-radius: 25px;
            resize: none;
            font-family: inherit;
            font-size: 14px;
            max-height: 100px;
            min-height: 44px;
        }
        
        .chat-input-field:focus {
            outline: none;
            border-color: #007bff
        }
        
        .attachment-btn {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #666;
            cursor: pointer;
            padding: 5px;
        }
        
        .attachment-btn:hover {
            color: #28a745;
        }
        
        .send-btn {
            background: #007bff;
            color: white;
            border: none;
            border-radius: 50%;
            width: 44px;
            height: 44px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background-color 0.2s;
        }
        
        .send-btn:hover {
            background: #007bff
        }
        
        .send-btn:disabled {
            background: #ccc;
            cursor: not-allowed;
        }
        
        .no-chat-selected {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100%;
            color: #666;
            font-size: 18px;
        }
        
        .attachment-preview {
            margin-top: 10px;
            padding: 8px 12px;
            background: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #e0e0e0;
            display: none;
        }
        
        .attachment-preview-content {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .attachment-info {
            display: flex;
            align-items: center;
        }
        
        .attachment-info i {
            margin-right: 8px;
            color: #666;
        }
        
        .remove-attachment {
            background: none;
            border: none;
            color: #dc3545;
            cursor: pointer;
            padding: 2px 5px;
        }
        
        .typing-indicator .message-content {
            background: #f1f3f4 !important;
            padding: 8px 16px !important;
        }
        
        .typing-animation {
            display: flex;
            align-items: center;
            gap: 4px;
            height: 20px;
        }
        
        .typing-animation span {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #999;
            animation: typing 1.4s infinite ease-in-out;
        }
        
        .typing-animation span:nth-child(1) {
            animation-delay: -0.32s;
        }
        
        .typing-animation span:nth-child(2) {
            animation-delay: -0.16s;
        }
        
        @keyframes typing {
            0%, 80%, 100% {
                transform: scale(0.8);
                opacity: 0.5;
            }
            40% {
                transform: scale(1);
                opacity: 1;
            }
        }
        
        @media (max-width: 768px) {
            .chat-container {
                flex-direction: column;
                height: calc(100vh - 80px);
            }
            
            .chat-sidebar {
                width: 100%;
                height: 200px;
            }
            
            .instructors-list {
                display: flex;
                overflow-x: auto;
                overflow-y: hidden;
            }
            
            .instructor-item {
                min-width: 200px;
                border-right: 1px solid #e0e0e0;
                border-bottom: none;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/student-sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>Chats</h1>
                <div class="admin-header-right">
                    <span class="chat-count"><?php echo count($instructors); ?> instructors</span>
                </div>
            </div>
            
            <div class="chat-container">
              <div class="chat-sidebar">
    <div class="chat-sidebar-header">
        <h3>Instructors</h3>
    </div>
    <div class="instructors-list">
        <?php foreach ($instructors as $instructor): ?>
        <div class="instructor-item 
             <?php echo $instructor['id'] == $selected_instructor_id ? 'active' : ''; ?> 
             <?php echo $instructor['unread_count'] > 0 ? 'has-unread' : ''; ?>" 
             data-instructor-id="<?php echo $instructor['id']; ?>"
             onclick="selectInstructor(<?php echo $instructor['id']; ?>)">
             
            <img src="<?php echo $instructor['profile_photo'] ?: '../assets/images/default-avatar.png'; ?>" 
                 alt="<?php echo htmlspecialchars($instructor['full_name']); ?>" 
                 class="instructor-avatar">
                 
            <div class="instructor-info">
                <div class="instructor-name">
                    <?php echo htmlspecialchars($instructor['full_name']); ?>
                </div>
                <!-- Show batch name -->
                <div class="instructor-course">
                    <?php echo htmlspecialchars($instructor['batch_name']); ?>
                </div>
            </div>
            
            <?php if ($instructor['unread_count'] > 0): ?>
            <span class="unread-badge"><?php echo $instructor['unread_count']; ?></span>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
        
        <?php if (count($instructors) === 0): ?>
        <div style="padding: 20px; text-align: center; color: #666;">
            No instructors found
        </div>
        <?php endif; ?>
    </div>
</div>

                
                <div class="chat-main">
                    <?php if ($selected_instructor): ?>
                    <div class="chat-header">
                        <img src="<?php echo $selected_instructor['profile_photo'] ?: '../assets/images/default-avatar.png'; ?>" 
                             alt="<?php echo $selected_instructor['full_name']; ?>" class="chat-header-avatar">
                        <div class="chat-header-info">
                            <h3><?php echo $selected_instructor['full_name']; ?></h3>
                            <p><?php echo $selected_instructor['batch_name']; ?></p>
                        </div>
                    </div>
                    
                    <div class="chat-messages" id="chatMessages">
                        <?php foreach ($messages as $message): ?>
                        <div class="message <?php echo $message['sender_id'] == $student_id ? 'sent' : 'received'; ?>" data-message-id="<?php echo $message['id']; ?>">
                            <img src="<?php echo $message['sender_photo'] ?: '../assets/images/default-avatar.png'; ?>" 
                                 alt="<?php echo htmlspecialchars($message['sender_name']); ?>" class="message-avatar">
                            <div class="message-content">
                                <?php if (!empty($message['message'])): ?>
                                <p class="message-text"><?php echo nl2br(htmlspecialchars($message['message'])); ?></p>
                                <?php endif; ?>
                                
                                <?php if ($message['attachment_path']): ?>
                                <div class="message-attachment">
                                    <a href="../<?php echo $message['attachment_path']; ?>" target="_blank">
                                        <i class="fas fa-paperclip"></i>
                                        <?php echo basename($message['attachment_path']); ?>
                                    </a>
                                </div>
                                <?php endif; ?>
                                
                                <div class="message-time">
                                    <?php echo date('M d, Y H:i', strtotime($message['created_at'])); ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="chat-input">
                        <form id="chatForm" class="chat-input-form" enctype="multipart/form-data">
                            <div class="chat-input-wrapper">
                                <textarea id="messageInput" name="message" class="chat-input-field" 
                                         placeholder="Type your message..." rows="1"></textarea>
                                <button type="button" class="attachment-btn" onclick="document.getElementById('fileInput').click()">
                                    <i class="fas fa-paperclip"></i>
                                </button>
                                <input type="file" id="fileInput" name="attachment" style="display: none;" 
                                       accept=".pdf,.doc,.docx,.txt,.jpg,.jpeg,.png,.gif">
                            </div>
                            <button type="submit" class="send-btn" id="sendBtn">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </form>
                        
                        <div class="attachment-preview" id="attachmentPreview">
                            <div class="attachment-preview-content">
                                <div class="attachment-info">
                                    <i class="fas fa-file"></i>
                                    <span id="attachmentName"></span>
                                </div>
                                <button type="button" class="remove-attachment" onclick="removeAttachment()">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="no-chat-selected">
                        <p>Select an instructor to start chatting</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    let currentInstructorId = <?php echo $selected_instructor_id ?: 'null'; ?>;
    let messagePolling;
    let typingTimeout;
    let lastMessageCheck = '<?php echo date('Y-m-d H:i:s'); ?>';
    let isTyping = false;
    let displayedMessageIds = new Set();
    
    function selectInstructor(instructorId) {
        if (instructorId === currentInstructorId) return;
        
        // Clear typing status for previous chat
        if (currentInstructorId) {
            clearTypingStatus();
        }
        
        // Update URL
        window.history.pushState({}, '', `chats.php?instructor_id=${instructorId}`);
        
        // Update UI
        document.querySelectorAll('.instructor-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-instructor-id="${instructorId}"]`).classList.add('active');
        
        displayedMessageIds.clear();
        
        // Load messages
        loadMessages(instructorId);
        currentInstructorId = instructorId;
        
        // Reset last message check time
        lastMessageCheck = new Date().toISOString().slice(0, 19).replace('T', ' ');
    }
    
    function loadMessages(instructorId) {
        const formData = new FormData();
        formData.append('ajax', '1');
        formData.append('action', 'get_messages');
        formData.append('instructor_id', instructorId);
        
        fetch('chats.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateChatMessages(data.messages, instructorId);
            }
        })
        .catch(error => console.error('Error:', error));
    }
    
    function checkNewMessages() {
        if (!currentInstructorId) return;
        
        const formData = new FormData();
        formData.append('action', 'get_new_messages');
        formData.append('chat_partner_id', currentInstructorId);
        formData.append('last_check', lastMessageCheck);
        
        fetch('../api/chat-realtime.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success && data.messages.length > 0) {
                appendNewMessages(data.messages);
                lastMessageCheck = data.timestamp;
            }
        })
        .catch(error => console.error('Error checking new messages:', error));
    }
    
    function appendNewMessages(messages) {
        const chatMessages = document.getElementById('chatMessages');
        const studentId = <?php echo $student_id; ?>;
        let hasNewMessages = false;
        
        messages.forEach(message => {
            // Skip if message already displayed
            if (displayedMessageIds.has(message.id)) {
                return;
            }
            
            displayedMessageIds.add(message.id);
            hasNewMessages = true;
            
            const messageDiv = document.createElement('div');
            messageDiv.className = `message ${message.sender_id == studentId ? 'sent' : 'received'}`;
            messageDiv.setAttribute('data-message-id', message.id);
            
            let attachmentHtml = '';
            if (message.attachment_path) {
                attachmentHtml = `
                    <div class="message-attachment">
                        <a href="../${message.attachment_path}" target="_blank">
                            <i class="fas fa-paperclip"></i>
                            ${message.attachment_path.split('/').pop()}
                        </a>
                    </div>
                `;
            }
            
            messageDiv.innerHTML = `
                <img src="${message.sender_photo || '../assets/images/default-avatar.png'}" 
                     alt="${message.sender_name}" class="message-avatar">
                <div class="message-content">
                    ${message.message ? `<p class="message-text">${message.message.replace(/\n/g, '<br>')}</p>` : ''}
                    ${attachmentHtml}
                    <div class="message-time">
                        ${new Date(message.created_at).toLocaleDateString('en-US', {
                            month: 'short', day: 'numeric', year: 'numeric',
                            hour: '2-digit', minute: '2-digit'
                        })}
                    </div>
                </div>
            `;
            
            chatMessages.appendChild(messageDiv);
        });
        
        if (hasNewMessages) {
            // Scroll to bottom
            chatMessages.scrollTop = chatMessages.scrollHeight;
            
            // Play notification sound for received messages
            if (messages.some(msg => msg.sender_id != <?php echo $student_id; ?>)) {
                playNotificationSound();
            }
        }
    }
    
    function updateChatMessages(messages, instructorId) {
        const chatMessages = document.getElementById('chatMessages');
        const studentId = <?php echo $student_id; ?>;
        
        // Clear existing messages and reset tracking
        chatMessages.innerHTML = '';
        displayedMessageIds.clear();
        
        messages.forEach(message => {
            displayedMessageIds.add(message.id);
            
            const messageDiv = document.createElement('div');
            messageDiv.className = `message ${message.sender_id == studentId ? 'sent' : 'received'}`;
            messageDiv.setAttribute('data-message-id', message.id);
            
            let attachmentHtml = '';
            if (message.attachment_path) {
                attachmentHtml = `
                    <div class="message-attachment">
                        <a href="../${message.attachment_path}" target="_blank">
                            <i class="fas fa-paperclip"></i>
                            ${message.attachment_path.split('/').pop()}
                        </a>
                    </div>
                `;
            }
            
            messageDiv.innerHTML = `
                <img src="${message.sender_photo || '../assets/images/default-avatar.png'}" 
                     alt="${message.sender_name}" class="message-avatar">
                <div class="message-content">
                    ${message.message ? `<p class="message-text">${message.message.replace(/\n/g, '<br>')}</p>` : ''}
                    ${attachmentHtml}
                    <div class="message-time">
                        ${new Date(message.created_at).toLocaleDateString('en-US', {
                            month: 'short', day: 'numeric', year: 'numeric',
                            hour: '2-digit', minute: '2-digit'
                        })}
                    </div>
                </div>
            `;
            
            chatMessages.appendChild(messageDiv);
        });
        
        // Scroll to bottom
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    function checkTypingStatus() {
        if (!currentInstructorId) return;
        
        const formData = new FormData();
        formData.append('action', 'get_typing_status');
        
        fetch('../api/chat-realtime.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateTypingIndicator(data.typing_users);
            }
        })
        .catch(error => console.error('Error checking typing status:', error));
    }
    
    function updateTypingIndicator(typingUsers) {
        const chatMessages = document.getElementById('chatMessages');
        
        // Remove existing typing indicator
        const existingIndicator = chatMessages.querySelector('.typing-indicator');
        if (existingIndicator) {
            existingIndicator.remove();
        }
        
        // Add new typing indicator if someone is typing
        const currentUserTyping = typingUsers.find(user => user.user_id == currentInstructorId);
        if (currentUserTyping) {
            const typingDiv = document.createElement('div');
            typingDiv.className = 'message received typing-indicator';
            typingDiv.innerHTML = `
                <img src="../assets/images/default-avatar.png" alt="Instructor" class="message-avatar">
                <div class="message-content">
                    <div class="typing-animation">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <div class="message-time">typing...</div>
                </div>
            `;
            
            chatMessages.appendChild(typingDiv);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
    }
    
    function updateOnlineStatus() {
        const formData = new FormData();
        formData.append('action', 'update_online_status');
        
        fetch('../api/chat-realtime.php', {
            method: 'POST',
            body: formData
        })
        .catch(error => console.error('Error updating online status:', error));
    }
    
    function playNotificationSound() {
        try {
            const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIG2m98OScTgwOUarm7blmGgU7k9n1unEiBC13yO/eizEIHWq+8+OWT');
            audio.play().catch(() => {}); // Ignore errors if audio can't play
        } catch (e) {
            // Ignore audio errors
        }
    }
    
    document.getElementById('chatForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (!currentInstructorId) return;
        
        const messageInput = document.getElementById('messageInput');
        const fileInput = document.getElementById('fileInput');
        const sendBtn = document.getElementById('sendBtn');
        
        const message = messageInput.value.trim();
        const hasFile = fileInput.files.length > 0;
        
        if (!message && !hasFile) return;
        
        // Disable send button
        sendBtn.disabled = true;
        
        const formData = new FormData();
        formData.append('ajax', '1');
        formData.append('action', 'send_message');
        formData.append('receiver_id', currentInstructorId);
        formData.append('message', message);
        
        if (hasFile) {
            formData.append('attachment', fileInput.files[0]);
        }
        
        fetch('chats.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            sendBtn.disabled = false;
            
            if (data.success) {
                messageInput.value = '';
                fileInput.value = '';
                removeAttachment();
                // This prevents duplicate messages when sending
                // loadMessages(currentInstructorId);
            } else {
                alert(data.message || 'Failed to send message');
            }
        })
        .catch(error => {
            sendBtn.disabled = false;
            console.error('Error:', error);
            alert('Failed to send message');
        });
    });
    
    document.getElementById('fileInput').addEventListener('change', function() {
        const file = this.files[0];
        if (file) {
            document.getElementById('attachmentName').textContent = file.name;
            document.getElementById('attachmentPreview').style.display = 'block';
        }
    });
    
    function removeAttachment() {
        document.getElementById('fileInput').value = '';
        document.getElementById('attachmentPreview').style.display = 'none';
    }
    
    document.getElementById('messageInput').addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 100) + 'px';
        
        // Mark as typing when user types
        if (this.value.trim() && currentInstructorId) {
            markTyping();
        }
    });
    
    if (currentInstructorId) {
        // Check for new messages every 2 seconds
        messagePolling = setInterval(checkNewMessages, 2000);
        
        // Check typing status every 1 second
        setInterval(checkTypingStatus, 1000);
        
        // Update online status every 30 seconds
        setInterval(updateOnlineStatus, 30000);
        
        // Initial online status update
        updateOnlineStatus();
    }
    
    window.addEventListener('beforeunload', function() {
        if (messagePolling) {
            clearInterval(messagePolling);
        }
        clearTypingStatus();
    });
    </script>
    
    <script src="../assets/js/theme.js"></script>
</body>
</html>
