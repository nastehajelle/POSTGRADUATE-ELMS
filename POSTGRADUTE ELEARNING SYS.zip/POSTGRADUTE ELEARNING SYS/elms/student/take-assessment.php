<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is a student
if (!is_logged_in() || !is_student()) {
    header("Location: ../auth/login.php");
    exit();
}

// Set default timezone
date_default_timezone_set('Africa/Mogadishu');

$student_id = $_SESSION['user_id'];
$assessment_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$assessment = null;
$questions = [];
$message = '';
$messageType = '';

if ($assessment_id <= 0) {
    header("Location: assessments.php");
    exit();
}

// --- Initial data fetching for the page (always runs) ---
try {
    // Get student's enrollment details
    $enrollment_query = "SELECT program_id, department_id, batch_id FROM enrollment WHERE user_id = ?";
    $enrollment_stmt = $conn->prepare($enrollment_query);
    $enrollment_stmt->execute([$student_id]);
    $enrollment = $enrollment_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$enrollment) {
        $message = "Enrollment information not found.";
        $messageType = "danger";
    } else {
        $student_program_id = $enrollment['program_id'];
        $student_department_id = $enrollment['department_id'];
        $student_batch_id = $enrollment['batch_id'];

        // Check if assessment exists and is accessible to student
        $assessment_query = "SELECT a.*, c.name as course_name, c.code as course_code, u.full_name as instructor_name,
                                    b.name as batch_name
                            FROM assessments a
                            LEFT JOIN course c ON a.course_id = c.id
                            LEFT JOIN users u ON a.created_by = u.id
                            LEFT JOIN batch b ON ? = b.id
                            WHERE a.id = ? AND a.status = 'active'
                            AND (
                                (a.program_id IS NULL AND a.department_id IS NULL AND a.course_id IS NULL)
                                OR (a.program_id = ? AND a.department_id IS NULL AND a.course_id IS NULL)
                                OR (a.program_id = ? AND a.department_id = ? AND a.course_id IS NULL)
                                OR EXISTS (
                                    SELECT 1 FROM course co
                                    WHERE co.id = a.course_id
                                    AND co.program_id = ? AND co.department_id = ? AND co.batch_id = ?
                                )
                            )";
        
        $assessment_stmt = $conn->prepare($assessment_query);
        $assessment_stmt->execute([
            $student_batch_id, // for batch name
            $assessment_id,
            $student_program_id,
            $student_program_id, $student_department_id,
            $student_program_id, $student_department_id, $student_batch_id
        ]);
        $assessment = $assessment_stmt->fetch(PDO::FETCH_ASSOC);

        if (!$assessment) {
            $message = "Assessment not found or not accessible.";
            $messageType = "danger";
        } else {
            // Check if assessment is within time limits
            $current_time = time();
            $start_time = strtotime($assessment['start_time']);
            $end_time = strtotime($assessment['end_time']);

            if ($current_time < $start_time) {
                $message = "Assessment has not started yet.";
                $messageType = "warning";
            } elseif ($current_time > $end_time) {
                $message = "Assessment has expired.";
                $messageType = "danger";
            } else {
                // Check if student has already submitted
                $result_check_query = "SELECT id FROM assessment_results WHERE assessment_id = ? AND student_id = ?";
                $result_check_stmt = $conn->prepare($result_check_query);
                $result_check_stmt->execute([$assessment_id, $student_id]);
                
                if ($result_check_stmt->fetch()) {
                    $message = "You have already submitted this assessment.";
                    $messageType = "info";
                } else {
                    // Fetch questions for the assessment - BATCH-SPECIFIC QUERY
                    $questions_query = "SELECT aq.id, aq.question_text, aq.question_type, aq.options, aq.marks,
                                               c.name as course_name, c.code as course_code, b.name as batch_name
                                       FROM assessment_questions aq
                                       LEFT JOIN course c ON aq.course_id = c.id
                                       LEFT JOIN batch b ON aq.batch_id = b.id
                                       WHERE aq.assessment_id = ? 
                                       AND (
                                           aq.batch_id = ? 
                                           OR (aq.batch_id IS NULL AND aq.course_id IS NULL)
                                           OR (aq.batch_id IS NULL AND aq.course_id IN (
                                               SELECT co.id FROM course co 
                                               WHERE co.program_id = ? AND co.department_id = ? AND co.batch_id = ?
                                           ))
                                       )
                                       ORDER BY " . ($assessment['randomize_questions'] ? 'RAND()' : 'aq.id');
                    $questions_stmt = $conn->prepare($questions_query);
                    $questions_stmt->execute([
                        $assessment_id, 
                        $student_batch_id,
                        $student_program_id, $student_department_id, $student_batch_id
                    ]);
                    $questions = $questions_stmt->fetchAll(PDO::FETCH_ASSOC);

                    if (empty($questions)) {
                        $message = "No questions available for your batch yet. Please contact your instructor.";
                        $messageType = "warning";
                    }
                }
            }
        }
    }

} catch (PDOException $e) {
    error_log("Database error in take-assessment (initial load): " . $e->getMessage());
    $message = "Database error occurred during page load: " . $e->getMessage();
    $messageType = "danger";
}

// --- Handle form submission (now that $assessment and $questions are populated) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_assessment'])) {
    if (!$assessment || empty($questions)) {
        $_SESSION['form_message'] = "Invalid assessment submission. Please try again.";
        $_SESSION['form_message_type'] = "danger";
        header("Location: take-assessment.php?id=" . $assessment_id);
        exit();
    } else {
        try {
            $conn->beginTransaction();

            $total_marks_obtained = 0;
            $answers = $_POST['answers'] ?? [];

            // Calculate marks using the auto-grading system
            foreach ($questions as $question) {
                $question_id = $question['id'];
                $student_answer = $answers[$question_id] ?? '';
                $marks_for_question = 0;

                if (!empty($student_answer)) {
                    // Get correct answer
                    $correct_answer_query = "SELECT correct_answer FROM assessment_questions WHERE id = ?";
                    $correct_answer_stmt = $conn->prepare($correct_answer_query);
                    $correct_answer_stmt->execute([$question_id]);
                    $correct_answer = $correct_answer_stmt->fetchColumn();

                    // Auto-grading logic
                    if ($question['question_type'] === 'mcq') {
                        if (strtoupper(trim($student_answer)) === strtoupper(trim($correct_answer))) {
                            $marks_for_question = $question['marks'];
                        }
                    } elseif ($question['question_type'] === 'true_false') {
                        if (strtolower(trim($student_answer)) === strtolower(trim($correct_answer))) {
                            $marks_for_question = $question['marks'];
                        }
                    } elseif ($question['question_type'] === 'short_answer') {
                        // For short answers, give full marks if answered (manual grading needed)
                        $marks_for_question = $question['marks'];
                    } elseif ($question['question_type'] === 'essay') {
                        // For essays, give full marks if answered (manual grading needed)
                        $marks_for_question = $question['marks'];
                    }
                }

                $total_marks_obtained += $marks_for_question;

                // Store individual answer
                $insert_answer_query = "INSERT INTO student_answers (assessment_id, student_id, question_id, answer_text, marks_obtained) 
                                       VALUES (?, ?, ?, ?, ?)";
                $insert_answer_stmt = $conn->prepare($insert_answer_query);
                $insert_answer_stmt->execute([$assessment_id, $student_id, $question_id, $student_answer, $marks_for_question]);
            }

            // Calculate grade
            $percentage = 0; // Default to 0
            if ($assessment['total_marks'] > 0) { // Prevent division by zero
                $percentage = ($total_marks_obtained / $assessment['total_marks']) * 100;
            }
            
            $grade = 'F';
            if ($percentage >= 90) $grade = 'A';
            elseif ($percentage >= 80) $grade = 'B';
            elseif ($percentage >= 70) $grade = 'C';
            elseif ($percentage >= 60) $grade = 'D';

            // Insert result
            $insert_result_query = "INSERT INTO assessment_results (assessment_id, student_id, marks_obtained, grade, submitted_at) 
                                   VALUES (?, ?, ?, ?, NOW())";
            $insert_result_stmt = $conn->prepare($insert_result_query);
            $insert_result_stmt->execute([$assessment_id, $student_id, $total_marks_obtained, $grade]);

            $conn->commit();

            $_SESSION['assessment_submitted'] = true;
            $_SESSION['assessment_result'] = [
                'marks_obtained' => $total_marks_obtained,
                'total_marks' => $assessment['total_marks'],
                'grade' => $grade,
                'percentage' => round($percentage, 2)
            ];

            header("Location: assessment-result.php?id=" . $assessment_id);
            exit();

        } catch (PDOException $e) {
            $conn->rollBack();
            error_log("Error submitting assessment: " . $e->getMessage());
            $_SESSION['form_message'] = "Error submitting assessment: " . $e->getMessage();
            $_SESSION['form_message_type'] = "danger";
            header("Location: take-assessment.php?id=" . $assessment_id);
            exit();
        }
    }
}

// Retrieve and clear session messages (for messages set by POST-redirect-GET)
if (isset($_SESSION['form_message'])) {
    $message = $_SESSION['form_message'];
    $messageType = $_SESSION['form_message_type'];
    unset($_SESSION['form_message']);
    unset($_SESSION['form_message_type']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Take Assessment - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/student.css">
    <?php echo FONT_AWESOME_CSS; ?>
    <style>
        .assessment-header {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: var(--shadow);
        }
        
        .assessment-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        
        .info-item {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }
        
        .info-label {
            font-size: 0.8rem;
            color: var(--text-muted);
            font-weight: 500;
        }
        
        .info-value {
            font-size: 0.9rem;
            color: var(--text-color);
            font-weight: 600;
        }
        
        .batch-info-header {
            background: #f0f9ff;
            color: #0369a1;
            padding: 12px 20px;
            border-radius: 6px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 500;
        }
        
        .timer-container {
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--primary-color);
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: var(--shadow);
            z-index: 1000;
            font-weight: 600;
            min-width: 150px;
            text-align: center;
        }
        
        .timer-container.warning {
            background: #f59e0b;
            animation: pulse 2s infinite;
        }
        
        .timer-container.danger {
            background: #ef4444;
            animation: pulse 1s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        
        .questions-container {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 8px;
            box-shadow: var(--shadow);
        }
        
        .question-item {
            margin-bottom: 30px;
            padding: 20px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            background: var(--bg-light);
            transition: border-color 0.2s;
        }
        
        .question-item.answered {
            border-color: var(--success-color);
            background: rgba(16, 185, 129, 0.05);
        }
        
        .question-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }
        
        .question-number {
            background: var(--primary-color);
            color: white;
            width: 35px;
            height: 35px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.9rem;
        }
        
        .question-marks {
            background: var(--bg-secondary);
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            color: var(--text-muted);
            font-weight: 500;
        }
        
        .question-text {
            font-size: 1rem;
            color: var(--text-color);
            line-height: 1.6;
            margin: 15px 0;
            font-weight: 500;
        }
        
        .question-source {
            font-size: 0.8rem;
            color: var(--text-muted);
            margin-bottom: 15px;
            font-style: italic;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .question-options {
            margin-top: 15px;
        }
        
        .option-item {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 12px;
            padding: 12px;
            border-radius: 6px;
            transition: all 0.2s;
            cursor: pointer;
            border: 1px solid transparent;
        }
        
        .option-item:hover {
            background: var(--hover-bg);
            border-color: var(--primary-color);
        }
        
        .option-item.selected {
            background: rgba(59, 130, 246, 0.1);
            border-color: var(--primary-color);
        }
        
        .option-item input[type="radio"] {
            margin: 0;
            transform: scale(1.2);
        }
        
        .option-text {
            flex: 1;
            color: var(--text-color);
            font-size: 0.95rem;
        }
        
        .text-answer {
            width: 100%;
            min-height: 100px;
            padding: 12px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            font-family: inherit;
            font-size: 0.9rem;
            resize: vertical;
            transition: border-color 0.2s;
        }
        
        .text-answer:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.1);
        }
        
        .short-answer {
            min-height: 60px;
        }
        
        .submit-container {
            margin-top: 30px;
            padding: 20px;
            background: var(--card-bg);
            border-radius: 8px;
            text-align: center;
            box-shadow: var(--shadow);
        }
        
        .submit-warning {
            background: #fef3c7;
            color: #92400e;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-weight: 500;
            border-left: 4px solid #f59e0b;
        }
        
        .btn-submit-assessment {
            background: var(--success-color);
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 6px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        
        .btn-submit-assessment:hover {
            background: #059669;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
        }
        
        .progress-bar {
            width: 100%;
            height: 8px;
            background: var(--bg-secondary);
            border-radius: 4px;
            margin: 20px 0;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--primary-color), var(--success-color));
            transition: width 0.3s ease;
            border-radius: 4px;
        }
        
        .progress-text {
            text-align: center;
            font-size: 0.9rem;
            color: var(--text-muted);
            margin-top: 10px;
        }
        
        .navigation-buttons {
            display: flex;
            justify-content: space-between;
            margin: 20px 0;
            gap: 10px;
        }
        
        .btn-nav {
            padding: 10px 20px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            background: var(--card-bg);
            color: var(--text-color);
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-nav:hover {
            background: var(--hover-bg);
            border-color: var(--primary-color);
        }
        
        .btn-nav:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .question-navigator {
            position: fixed;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            background: var(--card-bg);
            padding: 15px;
            border-radius: 8px;
            box-shadow: var(--shadow);
            max-height: 400px;
            overflow-y: auto;
            z-index: 999;
        }
        
        .nav-title {
            font-size: 0.9rem;
            font-weight: 600;
            margin-bottom: 10px;
            color: var(--text-color);
        }
        
        .nav-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 5px;
        }
        
        .nav-item {
            width: 30px;
            height: 30px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 0.8rem;
            transition: all 0.2s;
        }
        
        .nav-item.answered {
            background: var(--success-color);
            color: white;
            border-color: var(--success-color);
        }
        
        .nav-item.current {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }
        
        .nav-item:hover {
            border-color: var(--primary-color);
        }
        
        @media (max-width: 768px) {
            .timer-container {
                position: relative;
                top: auto;
                right: auto;
                margin-bottom: 20px;
            }
            
            .question-navigator {
                position: relative;
                left: auto;
                top: auto;
                transform: none;
                margin-bottom: 20px;
            }
            
            .assessment-info {
                grid-template-columns: 1fr;
            }
            
            .navigation-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/student-sidebar.php'; ?>
        
        <div class="admin-content">
            <?php if (!empty($message)): ?>
                <div class="message <?php echo $messageType; ?>">
                    <?php echo $message; ?>
                    <div style="margin-top: 15px;">
                        <a href="assessments_student.php" class="btn btn-primary">Back to Assessments</a>
                    </div>
                </div>
            <?php elseif ($assessment && !empty($questions)): ?>
                
                 Batch Information 
                <?php if (isset($enrollment['batch_id'])): ?>
                <div class="batch-info-header">
                    <i class="fas fa-users"></i>
                    <span>Taking assessment for Batch: <?php echo htmlspecialchars($assessment['batch_name'] ?? 'Unknown'); ?></span>
                    <span style="margin-left: auto; font-size: 0.9rem;">
                        <?php echo count($questions); ?> question<?php echo count($questions) != 1 ? 's' : ''; ?> available
                    </span>
                </div>
                <?php endif; ?>
                
                 Timer (only for timed assessments) 
                <?php if ($assessment['duration_minutes'] > 0): ?>
                <div class="timer-container" id="timerContainer">
                    <div><i class="fas fa-clock"></i> Time Remaining</div>
                    <div id="timeRemaining" style="font-size: 1.2rem; margin-top: 5px;">
                        <?php echo $assessment['duration_minutes']; ?>:00
                    </div>
                </div>
                <?php endif; ?>
                
                 Question Navigator 
                <div class="question-navigator" id="questionNavigator">
                    <div class="nav-title">Questions</div>
                    <div class="nav-grid" id="navGrid">
                        <?php for ($i = 1; $i <= count($questions); $i++): ?>
                            <div class="nav-item" data-question="<?php echo $i; ?>" onclick="goToQuestion(<?php echo $i; ?>)">
                                <?php echo $i; ?>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>
                
                 Assessment Header 
                <div class="assessment-header">
                    <h1><i class="fas fa-clipboard-check"></i> <?php echo htmlspecialchars($assessment['title']); ?></h1>
                    <div class="assessment-info">
                        <div class="info-item">
                            <span class="info-label">Course</span>
                            <span class="info-value">
                                <?php echo htmlspecialchars($assessment['course_name'] ?? 'General Assessment'); ?>
                            </span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Type</span>
                            <span class="info-value"><?php echo ucfirst($assessment['type']); ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Total Marks</span>
                            <span class="info-value"><?php echo $assessment['total_marks']; ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Questions</span>
                            <span class="info-value"><?php echo count($questions); ?></span>
                        </div>
                        <?php if ($assessment['duration_minutes'] > 0): ?>
                        <div class="info-item">
                            <span class="info-label">Duration</span>
                            <span class="info-value"><?php echo $assessment['duration_minutes']; ?> minutes</span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                 Progress Bar 
                <div class="progress-bar">
                    <div class="progress-fill" id="progressFill" style="width: 0%"></div>
                </div>
                <div class="progress-text" id="progressText">0 of <?php echo count($questions); ?> questions answered</div>

                 Assessment Form 
                <form method="POST" id="assessmentForm">
                    <div class="questions-container">
                        <?php foreach ($questions as $index => $question): ?>
                            <div class="question-item" data-question="<?php echo $index + 1; ?>" id="question-<?php echo $index + 1; ?>">
                                <div class="question-header">
                                    <span class="question-number"><?php echo $index + 1; ?></span>
                                    <span class="question-marks"><?php echo $question['marks']; ?> mark<?php echo $question['marks'] != 1 ? 's' : ''; ?></span>
                                </div>
                                
                                <?php if ($question['course_name'] || $question['batch_name']): ?>
                                    <div class="question-source">
                                        <i class="fas fa-info-circle"></i>
                                        <?php if ($question['course_name']): ?>
                                            Course: <?php echo htmlspecialchars($question['course_name']); ?>
                                            <?php if ($question['course_code']): ?>
                                                (<?php echo htmlspecialchars($question['course_code']); ?>)
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <?php if ($question['batch_name']): ?>
                                            <?php echo $question['course_name'] ? ' | ' : ''; ?>
                                            Batch: <?php echo htmlspecialchars($question['batch_name']); ?>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="question-text">
                                    <?php echo nl2br(htmlspecialchars($question['question_text'])); ?>
                                </div>
                                
                                <div class="question-options">
                                    <?php if ($question['question_type'] === 'mcq'): ?>
                                        <?php 
                                        $options = json_decode($question['options'], true);
                                        $option_labels = ['A', 'B', 'C', 'D', 'E'];
                                        ?>
                                        <?php foreach ($options as $opt_index => $option): ?>
                                            <div class="option-item" onclick="selectOption(this)">
                                                <input type="radio" 
                                                       name="answers[<?php echo $question['id']; ?>]" 
                                                       value="<?php echo $option_labels[$opt_index]; ?>" 
                                                       id="q<?php echo $question['id']; ?>_<?php echo $opt_index; ?>"
                                                       onchange="updateProgress()">
                                                <label for="q<?php echo $question['id']; ?>_<?php echo $opt_index; ?>" class="option-text">
                                                    <strong><?php echo $option_labels[$opt_index]; ?>.</strong> <?php echo htmlspecialchars($option); ?>
                                                </label>
                                            </div>
                                        <?php endforeach; ?>
                                        
                                    <?php elseif ($question['question_type'] === 'true_false'): ?>
                                        <div class="option-item" onclick="selectOption(this)">
                                            <input type="radio" 
                                                   name="answers[<?php echo $question['id']; ?>]" 
                                                   value="True" 
                                                   id="q<?php echo $question['id']; ?>_true"
                                                   onchange="updateProgress()">
                                            <label for="q<?php echo $question['id']; ?>_true" class="option-text">True</label>
                                        </div>
                                        <div class="option-item" onclick="selectOption(this)">
                                            <input type="radio" 
                                                   name="answers[<?php echo $question['id']; ?>]" 
                                                   value="False" 
                                                   id="q<?php echo $question['id']; ?>_false"
                                                   onchange="updateProgress()">
                                            <label for="q<?php echo $question['id']; ?>_false" class="option-text">False</label>
                                        </div>
                                        
                                    <?php elseif ($question['question_type'] === 'short_answer'): ?>
                                        <textarea name="answers[<?php echo $question['id']; ?>]" 
                                                  class="text-answer short-answer" 
                                                  placeholder="Enter your answer here..."
                                                  onchange="updateProgress()"
                                                  oninput="autoSave()"></textarea>
                                        
                                    <?php elseif ($question['question_type'] === 'essay'): ?>
                                        <textarea name="answers[<?php echo $question['id']; ?>]" 
                                                  class="text-answer" 
                                                  placeholder="Write your essay here..."
                                                  onchange="updateProgress()"
                                                  oninput="autoSave()"></textarea>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                     Navigation Buttons 
                    <div class="navigation-buttons">
                        <button type="button" class="btn-nav" id="prevBtn" onclick="previousQuestion()" disabled>
                            <i class="fas fa-chevron-left"></i> Previous
                        </button>
                        <button type="button" class="btn-nav" id="nextBtn" onclick="nextQuestion()">
                            Next <i class="fas fa-chevron-right"></i>
                        </button>
                    </div>
                    
                    <div class="submit-container">
                        <div class="submit-warning">
                            <i class="fas fa-exclamation-triangle"></i>
                            Make sure you have answered all questions before submitting. You cannot change your answers after submission.
                        </div>
                        <button type="submit" name="submit_assessment" class="btn-submit-assessment" onclick="return confirmSubmission()">
                            <i class="fas fa-paper-plane"></i> Submit Assessment
                        </button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
    <script>
        let totalQuestions = <?php echo count($questions); ?>;
        let timeLimit = <?php echo $assessment['duration_minutes'] ?? 0; ?>;
        let startTime = new Date().getTime();
        let currentQuestion = 1;
        
        // Timer functionality
        <?php if ($assessment['duration_minutes'] > 0): ?>
        function updateTimer() {
            let now = new Date().getTime();
            let elapsed = Math.floor((now - startTime) / 1000);
            let remaining = (timeLimit * 60) - elapsed;
            
            if (remaining <= 0) {
                alert('Time is up! Your assessment will be submitted automatically.');
                document.getElementById('assessmentForm').submit();
                return;
            }
            
            let hours = Math.floor(remaining / 3600);
            let minutes = Math.floor((remaining % 3600) / 60);
            let seconds = remaining % 60;
            
            let timeString = '';
            if (hours > 0) {
                timeString = hours.toString().padStart(2, '0') + ':';
            }
            timeString += minutes.toString().padStart(2, '0') + ':' + seconds.toString().padStart(2, '0');
            
            document.getElementById('timeRemaining').textContent = timeString;
            
            let timerContainer = document.getElementById('timerContainer');
            if (remaining <= 300) { // 5 minutes
                timerContainer.className = 'timer-container danger';
            } else if (remaining <= 600) { // 10 minutes
                timerContainer.className = 'timer-container warning';
            }
        }
        
        setInterval(updateTimer, 1000);
        <?php endif; ?>
        
        // Progress tracking
        function updateProgress() {
            let answered = 0;
            let formData = new FormData(document.getElementById('assessmentForm'));
            
            for (let [key, value] of formData.entries()) {
                if (key.startsWith('answers[') && value.trim() !== '') {
                    answered++;
                }
            }
            
            let progress = (answered / totalQuestions) * 100;
            document.getElementById('progressFill').style.width = progress + '%';
            document.getElementById('progressText').textContent = `${answered} of ${totalQuestions} questions answered`;
            
            // Update navigator
            updateNavigator();
        }
        
        // Update question navigator
        function updateNavigator() {
            const formData = new FormData(document.getElementById('assessmentForm'));
            const navItems = document.querySelectorAll('.nav-item');
            
            navItems.forEach((item, index) => {
                const questionNum = index + 1;
                // Find the input/textarea within the specific question item
                const questionItemElement = document.querySelector(`.question-item[data-question="${questionNum}"]`);
                if (!questionItemElement) return; // Skip if element not found

                const inputElement = questionItemElement.querySelector('input[type="radio"], textarea');
                if (!inputElement) return; // Skip if no input element found

                const inputName = inputElement.name;
                
                item.classList.remove('answered', 'current');
                
                if (questionNum === currentQuestion) {
                    item.classList.add('current');
                }
                
                // Check if the answer for this specific question is not empty
                if (formData.get(inputName) && formData.get(inputName).trim() !== '') {
                    item.classList.add('answered');
                    questionItemElement.classList.add('answered'); // Also update the question item itself
                } else {
                    questionItemElement.classList.remove('answered');
                }
            });
        }
        
        // Question navigation
        function goToQuestion(questionNum) {
            // Hide all questions
            document.querySelectorAll('.question-item').forEach(q => q.style.display = 'none');
            
            // Show target question
            document.getElementById(`question-${questionNum}`).style.display = 'block';
            
            currentQuestion = questionNum;
            updateNavigationButtons();
            updateNavigator(); // Update navigator to highlight current question
            
            // Scroll to top
            window.scrollTo(0, 0);
        }
        
        function nextQuestion() {
            if (currentQuestion < totalQuestions) {
                goToQuestion(currentQuestion + 1);
            }
        }
        
        function previousQuestion() {
            if (currentQuestion > 1) {
                goToQuestion(currentQuestion - 1);
            }
        }
        
        function updateNavigationButtons() {
            document.getElementById('prevBtn').disabled = currentQuestion === 1;
            document.getElementById('nextBtn').disabled = currentQuestion === totalQuestions;
            
            if (currentQuestion === totalQuestions) {
                document.getElementById('nextBtn').innerHTML = '<i class="fas fa-check"></i> Review & Submit';
            } else {
                document.getElementById('nextBtn').innerHTML = 'Next <i class="fas fa-chevron-right"></i>';
            }
        }
        
        // Option selection for radio buttons
        function selectOption(optionElement) {
            const radio = optionElement.querySelector('input[type="radio"]');
            if (radio) {
                radio.checked = true;
                
                // Remove selected class from siblings
                optionElement.parentElement.querySelectorAll('.option-item').forEach(item => {
                    item.classList.remove('selected');
                });
                
                // Add selected class to current option
                optionElement.classList.add('selected');
                
                updateProgress();
            }
        }
        
        // Confirmation before submission
        function confirmSubmission() {
            const formData = new FormData(document.getElementById('assessmentForm'));
            let answered = 0;
            
            // Iterate through all questions to count answered ones
            document.querySelectorAll('.question-item').forEach(questionItem => {
                const questionId = questionItem.id.split('-')[1]; // e.g., 'question-1' -> '1'
                const input = questionItem.querySelector(`[name^="answers["]`); // Get the input/textarea for this question
                
                if (input) {
                    if (input.type === 'radio') {
                        // For radio buttons, check if any option is selected
                        const selectedRadio = questionItem.querySelector(`input[type="radio"]:checked`);
                        if (selectedRadio) {
                            answered++;
                        }
                    } else if (input.value.trim() !== '') {
                        // For textareas, check if value is not empty
                        answered++;
                    }
                }
            });

            if (answered < totalQuestions) {
                const unanswered = totalQuestions - answered;
                if (!confirm(`You have ${unanswered} unanswered question(s). Are you sure you want to submit?`)) {
                    return false;
                }
            }
            
            return confirm('Are you sure you want to submit your assessment? You cannot change your answers after submission.');
        }
        
        // Prevent accidental page refresh
        window.addEventListener('beforeunload', function(e) {
            e.preventDefault();
            e.returnValue = 'Are you sure you want to leave? Your progress may be lost.';
        });
        
        // Auto-save functionality
        function autoSave() {
            const formData = new FormData(document.getElementById('assessmentForm'));
            const answers = {};
            
            for (let [key, value] of formData.entries()) {
                if (key.startsWith('answers[')) {
                    answers[key] = value;
                }
            }
            
            localStorage.setItem(`assessment_${<?php echo $assessment_id; ?>}_autosave`, JSON.stringify({
                answers: answers,
                timestamp: new Date().getTime()
            }));
        }
        
        // Load auto-saved data
        function loadAutoSave() {
            const saved = localStorage.getItem(`assessment_${<?php echo $assessment_id; ?>}_autosave`);
            if (saved) {
                try {
                    const data = JSON.parse(saved);
                    const timeDiff = new Date().getTime() - data.timestamp;
                    
                    // Only load if saved within last hour
                    if (timeDiff < 3600000) {
                        for (let [key, value] of Object.entries(data.answers)) {
                            const input = document.querySelector(`[name="${key}"]`);
                            if (input) {
                                if (input.type === 'radio') {
                                    const radioOption = document.querySelector(`[name="${key}"][value="${value}"]`);
                                    if (radioOption) {
                                        radioOption.checked = true;
                                        radioOption.closest('.option-item').classList.add('selected');
                                    }
                                } else {
                                    input.value = value;
                                }
                            }
                        }
                        updateProgress();
                    }
                } catch (e) {
                    console.error('Error loading auto-save data:', e);
                }
            }
        }
        
        // Initialize page
        document.addEventListener('DOMContentLoaded', function() {
            // Show first question only
            document.querySelectorAll('.question-item').forEach((q, index) => {
                q.style.display = index === 0 ? 'block' : 'none';
            });
            
            updateNavigationButtons();
            loadAutoSave();
            updateProgress();
            
            // Auto-save every 30 seconds
            setInterval(autoSave, 30000);
            
            // Add change listeners to all inputs
            document.querySelectorAll('input, textarea').forEach(input => {
                input.addEventListener('change', updateProgress);
                if (input.type !== 'radio') {
                    input.addEventListener('input', autoSave);
                }
            });
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            if (e.ctrlKey || e.metaKey) {
                switch(e.key) {
                    case 'ArrowLeft':
                        e.preventDefault();
                        previousQuestion();
                        break;
                    case 'ArrowRight':
                        e.preventDefault();
                        nextQuestion();
                        break;
                    case 'Enter':
                        if (e.shiftKey) {
                            e.preventDefault();
                            document.querySelector('.btn-submit-assessment').click();
                        }
                        break;
                }
            }
        });
    </script>
</body>
</html>
