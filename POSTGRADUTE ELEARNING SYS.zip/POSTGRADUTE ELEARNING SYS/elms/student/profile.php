<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in
if (!is_logged_in()) {
    header("Location: ../auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];
$user_data = [];
$message = '';
$messageType = '';

// Handle AJAX requests
if (isset($_POST['ajax']) && $_POST['ajax'] == 1) {
    header('Content-Type: application/json');
    
    if ($_POST['action'] == 'update_profile') {
        $full_name = sanitize_input($_POST['full_name']);
        $email = sanitize_input($_POST['email']);
        $phone = sanitize_input($_POST['phone']);
        $gender = sanitize_input($_POST['gender']);
        
        // Validate required fields
        if (empty($full_name) || empty($email) || empty($phone) || empty($gender)) {
            echo json_encode(['success' => false, 'message' => 'All fields are required.']);
            exit();
        }
        
        // Validate email format
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(['success' => false, 'message' => 'Invalid email format.']);
            exit();
        }
        
        try {
            // Check if email is already used by another user
            $check_email_query = "SELECT id FROM users WHERE email = ? AND id != ?";
            $check_email_stmt = $conn->prepare($check_email_query);
            $check_email_stmt->execute([$email, $user_id]);
            
            if ($check_email_stmt->rowCount() > 0) {
                echo json_encode(['success' => false, 'message' => 'Email already used by another user.']);
                exit();
            }
            
            // Update user information
            $update_query = "UPDATE users SET full_name = ?, email = ?, phone = ?, gender = ?, updated_at = NOW() WHERE id = ?";
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->execute([$full_name, $email, $phone, $gender, $user_id]);
            
            // Update session email
            $_SESSION['email'] = $email;
            $_SESSION['full_name'] = $full_name;
            
            echo json_encode(['success' => true, 'message' => 'Profile updated successfully!']);
            exit();
            
        } catch (PDOException $e) {
            error_log("Profile update error: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Database error occurred.']);
            exit();
        }
    }
    
    if ($_POST['action'] == 'change_password') {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        // Validate required fields
        if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
            echo json_encode(['success' => false, 'message' => 'All password fields are required.']);
            exit();
        }
        
        // Validate password match
        if ($new_password !== $confirm_password) {
            echo json_encode(['success' => false, 'message' => 'New password and confirmation do not match.']);
            exit();
        }
        
        // Validate password length
        if (strlen($new_password) < 6) {
            echo json_encode(['success' => false, 'message' => 'New password must be at least 6 characters long.']);
            exit();
        }
        
        try {
            // Verify current password
            $check_password_query = "SELECT password FROM users WHERE id = ?";
            $check_password_stmt = $conn->prepare($check_password_query);
            $check_password_stmt->execute([$user_id]);
            $user = $check_password_stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user || !password_verify($current_password, $user['password'])) {
                echo json_encode(['success' => false, 'message' => 'Current password is incorrect.']);
                exit();
            }
            
            // Update password
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $update_password_query = "UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?";
            $update_password_stmt = $conn->prepare($update_password_query);
            $update_password_stmt->execute([$hashed_password, $user_id]);
            
            echo json_encode(['success' => true, 'message' => 'Password changed successfully!']);
            exit();
            
        } catch (PDOException $e) {
            error_log("Password change error: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Database error occurred.']);
            exit();
        }
    }
}

// Fetch user data with role-specific information
try {
    $base_query = "SELECT u.id, u.full_name, u.email, u.phone, u.gender, u.role, u.status, u.created_at, u.updated_at";
    $joins = " FROM users u";
    $additional_fields = "";
    
    // Add role-specific fields
    if ($user_role == 'student') {
        $additional_fields = ", e.student_id, p.name as program_name, d.name as department_name, b.name as batch_name, b.year as batch_year, s.registration_date, s.date_of_birth, s.place_of_birth, s.nationality, s.mother_name, s.marital_status, s.emergency_contact_name, s.bachelor_institution, s.bachelor_specialization, s.bachelor_location, s.bachelor_year, s.application_type, s.language_of_instruction, s.parent_associated_with_uni, s.parent_name, s.degree_document";
        $joins .= " LEFT JOIN enrollment e ON u.id = e.user_id 
                   LEFT JOIN programs p ON e.program_id = p.id 
                   LEFT JOIN departments d ON e.department_id = d.id 
                   LEFT JOIN batch b ON e.batch_id = b.id
                   LEFT JOIN students s ON u.id = s.user_id";
    } elseif ($user_role == 'teacher') {
        $additional_fields = ", t.employee_id, t.specialization, t.qualification, t.experience_years, t.hire_date, d.name as department_name";
        $joins .= " LEFT JOIN teachers t ON u.id = t.user_id
                   LEFT JOIN departments d ON t.department_id = d.id";
    }
    
    $query = $base_query . $additional_fields . $joins . " WHERE u.id = ?";
    $stmt = $conn->prepare($query);
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user_data) {
        $message = "User data not found.";
        $messageType = "error";
    }
    
} catch (PDOException $e) {
    error_log("Profile fetch error: " . $e->getMessage());
    $message = "Error loading profile data.";
    $messageType = "error";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/modal.css">
    <link rel="stylesheet" href="../assets/css/users.css">
    <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/student-sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>My Profile</h1>
                
                <div class="admin-header-right">
                    <button class="btn btn-primary" id="editProfileBtn">
                        <i class="fas fa-edit"></i> Edit Profile
                    </button>
                    <button class="btn btn-secondary" id="changePasswordBtn">
                        <i class="fas fa-key"></i> Change Password
                    </button>
                </div>
            </div>
            
            <div id="alertContainer"></div>
            
            <!-- Profile Overview Cards -->
            <div class="dashboard-cards">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-user"></i> Basic Information</h3>
                    </div>
                    <div class="card-body">
                        <div class="profile-info">
                            <div class="profile-avatar">
                                <i class="fas fa-user-circle"></i>
                            </div>
                            <div class="profile-details">
                                <h2><?php echo htmlspecialchars($user_data['full_name'] ?? 'N/A'); ?></h2>
                                <p class="role-badge <?php echo $user_role; ?>">
                                    <?php echo ucfirst($user_role); ?>
                                </p>
                                <p class="status-badge <?php echo $user_data['status']; ?>">
                                    <?php echo ucfirst($user_data['status']); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-envelope"></i> Contact Information</h3>
                    </div>
                    <div class="card-body">
                        <div class="user-detail-row">
                            <strong>Email:</strong>
                            <span><?php echo htmlspecialchars($user_data['email'] ?? 'N/A'); ?></span>
                        </div>
                        <div class="user-detail-row">
                            <strong>Phone:</strong>
                            <span><?php echo htmlspecialchars($user_data['phone'] ?? 'N/A'); ?></span>
                        </div>
                        <div class="user-detail-row">
                            <strong>Gender:</strong>
                            <span><?php echo htmlspecialchars(ucfirst($user_data['gender'] ?? 'N/A')); ?></span>
                        </div>
                    </div>
                </div>
                
                <?php if ($user_role == 'student' && isset($user_data['program_name'])): ?>
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-graduation-cap"></i> Academic Information</h3>
                    </div>
                    <div class="card-body">
                        <div class="user-detail-row">
                            <strong>Student ID:</strong>
                            <span><?php echo htmlspecialchars($user_data['student_id'] ?? 'Not Assigned'); ?></span>
                        </div>
                        <div class="user-detail-row">
                            <strong>Program:</strong>
                            <span><?php echo htmlspecialchars($user_data['program_name'] ?? 'N/A'); ?></span>
                        </div>
                        <div class="user-detail-row">
                            <strong>Department:</strong>
                            <span><?php echo htmlspecialchars($user_data['department_name'] ?? 'N/A'); ?></span>
                        </div>
                        <div class="user-detail-row">
                            <strong>Batch:</strong>
                            <span><?php echo htmlspecialchars($user_data['batch_name'] ?? 'N/A'); ?> (<?php echo htmlspecialchars($user_data['batch_year'] ?? 'N/A'); ?>)</span>
                        </div>
                    </div>
                </div>
                <?php elseif ($user_role == 'teacher' && isset($user_data['employee_id'])): ?>
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-chalkboard-teacher"></i> Employment Information</h3>
                    </div>
                    <div class="card-body">
                        <div class="user-detail-row">
                            <strong>Employee ID:</strong>
                            <span><?php echo htmlspecialchars($user_data['employee_id'] ?? 'Not Assigned'); ?></span>
                        </div>
                        <div class="user-detail-row">
                            <strong>Department:</strong>
                            <span><?php echo htmlspecialchars($user_data['department_name'] ?? 'N/A'); ?></span>
                        </div>
                        <div class="user-detail-row">
                            <strong>Specialization:</strong>
                            <span><?php echo htmlspecialchars($user_data['specialization'] ?? 'N/A'); ?></span>
                        </div>
                        <div class="user-detail-row">
                            <strong>Experience:</strong>
                            <span><?php echo htmlspecialchars($user_data['experience_years'] ?? 'N/A'); ?> years</span>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Detailed Profile Information -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-info-circle"></i> Detailed Information</h3>
                </div>
                <div class="card-body">
                    <div class="profile-sections">
                        <div class="profile-section">
                            <h4>Account Information</h4>
                            <div class="user-detail-row">
                                <strong>Account Created:</strong>
                                <span><?php echo date('F j, Y', strtotime($user_data['created_at'])); ?></span>
                            </div>
                            <div class="user-detail-row">
                                <strong>Last Updated:</strong>
                                <span><?php echo $user_data['updated_at'] ? date('F j, Y', strtotime($user_data['updated_at'])) : 'Never'; ?></span>
                            </div>
                        </div>
                        
                        <?php if ($user_role == 'student'): ?>
                        <div class="profile-section">
                            <h4>Personal Information</h4>
                            <div class="user-detail-row">
                                <strong>Date of Birth:</strong>
                                <span><?php echo $user_data['date_of_birth'] ? date('F j, Y', strtotime($user_data['date_of_birth'])) : 'Not specified'; ?></span>
                            </div>
                            <div class="user-detail-row">
                                <strong>Place of Birth:</strong>
                                <span><?php echo htmlspecialchars($user_data['place_of_birth'] ?? 'Not specified'); ?></span>
                            </div>
                            <div class="user-detail-row">
                                <strong>Nationality:</strong>
                                <span><?php echo htmlspecialchars($user_data['nationality'] ?? 'Not specified'); ?></span>
                            </div>
                            <div class="user-detail-row">
                                <strong>Mother's Name:</strong>
                                <span><?php echo htmlspecialchars($user_data['mother_name'] ?? 'Not specified'); ?></span>
                            </div>
                            <div class="user-detail-row">
                                <strong>Marital Status:</strong>
                                <span><?php echo htmlspecialchars($user_data['marital_status'] ?? 'Not specified'); ?></span>
                            </div>
                            <div class="user-detail-row">
                                <strong>Emergency Contact:</strong>
                                <span><?php echo htmlspecialchars($user_data['emergency_contact_name'] ?? 'Not specified'); ?></span>
                            </div>
                        </div>
                        
                        <div class="profile-section">
                            <h4>Academic Background</h4>
                            <div class="user-detail-row">
                                <strong>Bachelor Institution:</strong>
                                <span><?php echo htmlspecialchars($user_data['bachelor_institution'] ?? 'Not specified'); ?></span>
                            </div>
                            <div class="user-detail-row">
                                <strong>Bachelor Specialization:</strong>
                                <span><?php echo htmlspecialchars($user_data['bachelor_specialization'] ?? 'Not specified'); ?></span>
                            </div>
                            <div class="user-detail-row">
                                <strong>Bachelor Location:</strong>
                                <span><?php echo htmlspecialchars($user_data['bachelor_location'] ?? 'Not specified'); ?></span>
                            </div>
                            <div class="user-detail-row">
                                <strong>Bachelor Year:</strong>
                                <span><?php echo htmlspecialchars($user_data['bachelor_year'] ?? 'Not specified'); ?></span>
                            </div>
                            <div class="user-detail-row">
                                <strong>Application Type:</strong>
                                <span><?php echo htmlspecialchars($user_data['application_type'] ?? 'Not specified'); ?></span>
                            </div>
                            <div class="user-detail-row">
                                <strong>Language of Instruction:</strong>
                                <span><?php echo htmlspecialchars($user_data['language_of_instruction'] ?? 'Not specified'); ?></span>
                            </div>
                        </div>
                        
                        <?php if ($user_data['degree_document']): ?>
                        <div class="profile-section">
                            <h4>Documents</h4>
                            <div class="user-detail-row">
                                <strong>Degree Document:</strong>
                                <span>
                                    <a href="<?php echo htmlspecialchars($user_data['degree_document']); ?>" target="_blank" class="btn btn-sm btn-info">
                                        <i class="fas fa-file-pdf"></i> View Document
                                    </a>
                                </span>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <?php elseif ($user_role == 'teacher'): ?>
                        <div class="profile-section">
                            <h4>Professional Information</h4>
                            <div class="user-detail-row">
                                <strong>Qualification:</strong>
                                <span><?php echo htmlspecialchars($user_data['qualification'] ?? 'Not specified'); ?></span>
                            </div>
                            <div class="user-detail-row">
                                <strong>Hire Date:</strong>
                                <span><?php echo $user_data['hire_date'] ? date('F j, Y', strtotime($user_data['hire_date'])) : 'Not specified'; ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Edit Profile Modal -->
    <div id="editProfileModalBackdrop" class="modal-backdrop"></div>
    <div id="editProfileModalContainer" class="modal-container">
        <div class="modal-header">
            <h2>Edit Profile</h2>
            <button class="modal-close" id="closeEditProfileModal">&times;</button>
        </div>
        <div class="modal-body">
            <form id="editProfileForm">
                <div class="form-row">
                    <div class="form-group">
                        <label for="edit_full_name">Full Name *</label>
                        <input type="text" id="edit_full_name" name="full_name" value="<?php echo htmlspecialchars($user_data['full_name'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_email">Email *</label>
                        <input type="email" id="edit_email" name="email" value="<?php echo htmlspecialchars($user_data['email'] ?? ''); ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="edit_phone">Phone *</label>
                        <input type="text" id="edit_phone" name="phone" value="<?php echo htmlspecialchars($user_data['phone'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_gender">Gender *</label>
                        <select id="edit_gender" name="gender" required>
                            <option value="">Select Gender</option>
                            <option value="male" <?php echo (isset($user_data['gender']) && $user_data['gender'] == 'male') ? 'selected' : ''; ?>>Male</option>
                            <option value="female" <?php echo (isset($user_data['gender']) && $user_data['gender'] == 'female') ? 'selected' : ''; ?>>Female</option>
                        </select>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" id="cancelEditProfile">Cancel</button>
            <button class="btn btn-primary" id="saveProfileChanges">Save Changes</button>
        </div>
    </div>
    
    <!-- Change Password Modal -->
    <div id="changePasswordModalBackdrop" class="modal-backdrop"></div>
    <div id="changePasswordModalContainer" class="modal-container">
        <div class="modal-header">
            <h2>Change Password</h2>
            <button class="modal-close" id="closeChangePasswordModal">&times;</button>
        </div>
        <div class="modal-body">
            <form id="changePasswordForm">
                <div class="form-group">
                    <label for="current_password">Current Password *</label>
                    <input type="password" id="current_password" name="current_password" required>
                </div>
                <div class="form-group">
                    <label for="new_password">New Password *</label>
                    <input type="password" id="new_password" name="new_password" required>
                    <small class="form-text">Password must be at least 6 characters long.</small>
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm New Password *</label>
                    <input type="password" id="confirm_password" name="confirm_password" required>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" id="cancelChangePassword">Cancel</button>
            <button class="btn btn-primary" id="savePasswordChanges">Change Password</button>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // DOM Elements
        const alertContainer = document.getElementById('alertContainer');
        const editProfileBtn = document.getElementById('editProfileBtn');
        const changePasswordBtn = document.getElementById('changePasswordBtn');
        
        // Edit Profile Modal Elements
        const editProfileModalBackdrop = document.getElementById('editProfileModalBackdrop');
        const editProfileModalContainer = document.getElementById('editProfileModalContainer');
        const closeEditProfileModal = document.getElementById('closeEditProfileModal');
        const cancelEditProfile = document.getElementById('cancelEditProfile');
        const saveProfileChanges = document.getElementById('saveProfileChanges');
        const editProfileForm = document.getElementById('editProfileForm');
        
        // Change Password Modal Elements
        const changePasswordModalBackdrop = document.getElementById('changePasswordModalBackdrop');
        const changePasswordModalContainer = document.getElementById('changePasswordModalContainer');
        const closeChangePasswordModal = document.getElementById('closeChangePasswordModal');
        const cancelChangePassword = document.getElementById('cancelChangePassword');
        const savePasswordChanges = document.getElementById('savePasswordChanges');
        const changePasswordForm = document.getElementById('changePasswordForm');
        
        // Show alert message
        function showAlert(message, type = 'success') {
            const alert = document.createElement('div');
            alert.className = `alert alert-${type}`;
            alert.textContent = message;
            
            alertContainer.appendChild(alert);
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                alert.remove();
            }, 5000);
        }
        
        // Open Edit Profile Modal
        function openEditProfileModal() {
            editProfileModalBackdrop.classList.add('show');
            editProfileModalContainer.classList.add('show');
        }
        
        // Close Edit Profile Modal
        function closeEditProfileModalFunc() {
            editProfileModalBackdrop.classList.remove('show');
            editProfileModalContainer.classList.remove('show');
            editProfileForm.reset();
            // Restore original values
            document.getElementById('edit_full_name').value = '<?php echo addslashes($user_data['full_name'] ?? ''); ?>';
            document.getElementById('edit_email').value = '<?php echo addslashes($user_data['email'] ?? ''); ?>';
            document.getElementById('edit_phone').value = '<?php echo addslashes($user_data['phone'] ?? ''); ?>';
            document.getElementById('edit_gender').value = '<?php echo addslashes($user_data['gender'] ?? ''); ?>';
        }
        
        // Open Change Password Modal
        function openChangePasswordModal() {
            changePasswordModalBackdrop.classList.add('show');
            changePasswordModalContainer.classList.add('show');
        }
        
        // Close Change Password Modal
        function closeChangePasswordModalFunc() {
            changePasswordModalBackdrop.classList.remove('show');
            changePasswordModalContainer.classList.remove('show');
            changePasswordForm.reset();
        }
        
        // Event Listeners
        editProfileBtn.addEventListener('click', openEditProfileModal);
        changePasswordBtn.addEventListener('click', openChangePasswordModal);
        
        closeEditProfileModal.addEventListener('click', closeEditProfileModalFunc);
        cancelEditProfile.addEventListener('click', closeEditProfileModalFunc);
        editProfileModalBackdrop.addEventListener('click', closeEditProfileModalFunc);
        
        closeChangePasswordModal.addEventListener('click', closeChangePasswordModalFunc);
        cancelChangePassword.addEventListener('click', closeChangePasswordModalFunc);
        changePasswordModalBackdrop.addEventListener('click', closeChangePasswordModalFunc);
        
        // Save Profile Changes
        saveProfileChanges.addEventListener('click', function() {
            const formData = new FormData(editProfileForm);
            formData.append('ajax', 1);
            formData.append('action', 'update_profile');
            
            // Disable button and show loading
            saveProfileChanges.disabled = true;
            saveProfileChanges.innerHTML = 'Saving...';
            
            fetch('profile.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                saveProfileChanges.disabled = false;
                saveProfileChanges.innerHTML = 'Save Changes';
                
                if (data.success) {
                    showAlert(data.message, 'success');
                    closeEditProfileModalFunc();
                    // Reload page to show updated data
                    setTimeout(() => {
                        location.reload();
                    }, 1500);
                } else {
                    showAlert(data.message, 'error');
                }
            })
            .catch(error => {
                saveProfileChanges.disabled = false;
                saveProfileChanges.innerHTML = 'Save Changes';
                console.error('Error:', error);
                showAlert('An error occurred while updating profile.', 'error');
            });
        });
        
        // Save Password Changes
        savePasswordChanges.addEventListener('click', function() {
            const formData = new FormData(changePasswordForm);
            formData.append('ajax', 1);
            formData.append('action', 'change_password');
            
            // Disable button and show loading
            savePasswordChanges.disabled = true;
            savePasswordChanges.innerHTML = 'Changing...';
            
            fetch('profile.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                savePasswordChanges.disabled = false;
                savePasswordChanges.innerHTML = 'Change Password';
                
                if (data.success) {
                    showAlert(data.message, 'success');
                    closeChangePasswordModalFunc();
                } else {
                    showAlert(data.message, 'error');
                }
            })
            .catch(error => {
                savePasswordChanges.disabled = false;
                savePasswordChanges.innerHTML = 'Change Password';
                console.error('Error:', error);
                showAlert('An error occurred while changing password.', 'error');
            });
        });
        
        // Form validation
        editProfileForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveProfileChanges.click();
        });
        
        changePasswordForm.addEventListener('submit', function(e) {
            e.preventDefault();
            savePasswordChanges.click();
        });
        
        // Password confirmation validation
        document.getElementById('confirm_password').addEventListener('input', function() {
            const newPassword = document.getElementById('new_password').value;
            const confirmPassword = this.value;
            
            if (newPassword !== confirmPassword) {
                this.setCustomValidity('Passwords do not match');
            } else {
                this.setCustomValidity('');
            }
        });
    });
    </script>
</body>
</html>
