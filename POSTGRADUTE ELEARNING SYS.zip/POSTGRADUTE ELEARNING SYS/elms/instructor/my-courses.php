<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is instructor
if (!is_logged_in() || !is_instructor()) {
   header("Location: ../auth/login.php");
   exit();
}

$instructor_id = $_SESSION['user_id'];

// Get instructor's assigned courses with detailed information
try {
   $courses_query = "SELECT c.*, d.name as department_name, b.name as batch_name, b.year as batch_year,
                    (SELECT COUNT(*) FROM assessments a WHERE (a.program_id = c.program_id OR a.department_id = c.department_id) AND a.status = 'active') as active_assessments
                    FROM course c 
                    LEFT JOIN departments d ON c.department_id = d.id 
                    LEFT JOIN batch b ON c.batch_id = b.id 
                    WHERE c.instructor_id = ?
                    ORDER BY c.name";
   $courses_stmt = $conn->prepare($courses_query);
   $courses_stmt->execute([$instructor_id]);
   $my_courses = $courses_stmt->fetchAll(PDO::FETCH_ASSOC);
   
} catch(PDOException $e) {
   error_log("Error fetching instructor courses: " . $e->getMessage());
   $my_courses = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>My Courses - Benadir University LMS</title>
   <link rel="stylesheet" href="../assets/css/style.css">
   <link rel="stylesheet" href="../assets/css/admin.css">
   <link rel="stylesheet" href="../assets/css/courses.css">
   <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
   <div class="admin-container">
       <?php include_once '../includes/instructor-sidebar.php'; ?>
       
       <div class="admin-content">
           <div class="admin-header">
               <h1>My Courses</h1>
               <div class="admin-header-right">
                   <span class="course-count"><?php echo count($my_courses); ?> courses assigned</span>
                   <!-- Button to go to the general course materials page -->
                   <a href="course-materials.php" class="btn btn-primary">
                       <i class="fas fa-upload"></i> Upload Materials
                   </a>
               </div>
           </div>
           
           <div id="alertContainer"></div>
           
           <!-- Courses Grid -->
           <div class="courses-grid">
               <?php if (count($my_courses) > 0): ?>
                   <?php foreach ($my_courses as $course): ?>
                   <div class="course-card">
                       <div class="course-header">
                           <div class="course-code"><?php echo $course['code']; ?></div>
                           <div class="course-status">
                               <span class="status-badge status-<?php echo strtolower($course['status'] ?? 'active'); ?>">
                                   <?php echo ucfirst($course['status'] ?? 'Active'); ?>
                               </span>
                           </div>
                       </div>
                       <div class="course-body">
                           <h3 class="course-title"><?php echo htmlspecialchars($course['name']); ?></h3>
                           <div class="course-details">
                               <div class="course-detail">
                                   <i class="fas fa-building"></i>
                                   <span><?php echo htmlspecialchars($course['department_name'] ?? 'No Department'); ?></span>
                               </div>
                               <div class="course-detail">
                                   <i class="fas fa-users"></i>
                                   <span><?php echo htmlspecialchars($course['batch_name'] ? $course['batch_name'] . ' (' . $course['batch_year'] . ')' : 'No Batch'); ?></span>
                               </div>
                               <div class="course-detail">
                                   <i class="fas fa-clock"></i>
                                   <span><?php echo $course['credit_hours']; ?> credit hours</span>
                               </div>
                               <div class="course-detail">
                                   <i class="fas fa-clipboard-list"></i>
                                   <span><?php echo $course['active_assessments'] ?? 0; ?> active assessments</span>
                               </div>
                           </div>
                           <?php if (!empty($course['description'])): ?>
                           <div class="course-description">
                               <?php echo substr(htmlspecialchars($course['description']), 0, 150) . (strlen($course['description']) > 150 ? '...' : ''); ?>
                           </div>
                           <?php endif; ?>
                       </div>
                       <div class="course-footer">
                           <div class="course-actions">
                               <a href="my-students.php?course_id=<?php echo $course['id']; ?>" class="btn btn-sm btn-info">
                                   <i class="fas fa-users"></i> Students
                               </a>
                               <a href="attendance.php?course_id=<?php echo $course['id']; ?>" class="btn btn-sm btn-primary">
                                   <i class="fas fa-calendar-check"></i> Attendance
                               </a>
                               <a href="assessments.php?course_id=<?php echo $course['id']; ?>" class="btn btn-sm btn-success">
                                   <i class="fas fa-clipboard-list"></i> Assessments
                               </a>
                               <a href="live-class.php?course_id=<?php echo $course['id']; ?>" class="btn btn-sm btn-warning">
                                   <i class="fas fa-video"></i> Live Class
                               </a>
                               <a href="course-materials.php?course_id=<?php echo $course['id']; ?>" class="btn btn-sm btn-secondary">
                                   <i class="fas fa-upload"></i> Materials
                               </a>
                           </div>
                       </div>
                   </div>
                   <?php endforeach; ?>
               <?php else: ?>
                   <div class="empty-state">
                       <div class="empty-icon">
                           <i class="fas fa-book"></i>
                       </div>
                       <h3>No Courses Assigned</h3>
                       <p>You don't have any courses assigned yet. Please contact the administrator to assign courses to you.</p>
                   </div>
               <?php endif; ?>
           </div>
       </div>
   </div>
   
   <style>
   .courses-grid {
       display: grid;
       grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
       gap: 20px;
       margin-top: 20px;
   }
   
   .course-card {
       background: var(--card-bg);
       border-radius: 8px;
       box-shadow: var(--shadow);
       overflow: hidden;
       transition: transform 0.2s ease, box-shadow 0.2s ease;
   }
   
   .course-card:hover {
       transform: translateY(-2px);
       box-shadow: var(--shadow-lg);
   }
   
   .course-header {
       display: flex;
       justify-content: space-between;
       align-items: center;
       padding: 15px 20px;
       background: var(--primary-color);
       color: white;
   }
   
   .course-code {
       font-weight: bold;
       font-size: 1.1rem;
   }
   
   
   .course-body {
       padding: 20px;
   }
   
   .course-title {
       margin: 0 0 15px 0;
       color: var(--text-color);
       font-size: 1.2rem;
   }
   
   .course-details {
       margin-bottom: 15px;
   }
   
   .course-detail {
       display: flex;
       align-items: center;
       margin-bottom: 8px;
       color: var(--text-muted);
       font-size: 0.9rem;
   }
   
   .course-detail i {
       width: 20px;
       margin-right: 8px;
       color: var(--primary-color);
   }
   
   .course-description {
       color: var(--text-muted);
       font-size: 0.9rem;
       line-height: 1.4;
       background: var(--bg-secondary);
       padding: 10px;
       border-radius: 4px;
   }
   
   .course-footer {
       padding: 15px 20px;
       background: var(--bg-secondary);
       border-top: 1px solid var(--border-color);
   }
   
   .course-actions {
       display: flex;
       gap: 8px;
       flex-wrap: wrap;
   }
   
   .course-actions .btn {
       flex: 1;
       min-width: 80px;
       text-align: center;
       font-size: 0.8rem;
       padding: 6px 8px;
   }
   
   .empty-state {
       grid-column: 1 / -1;
       text-align: center;
       padding: 60px 20px;
       color: var(--text-muted);
   }
   
   .empty-icon {
       font-size: 4rem;
       margin-bottom: 20px;
       opacity: 0.3;
   }
   
   .empty-state h3 {
       margin: 0 0 10px 0;
       color: var(--text-color);
   }
   
   .course-count {
       color: var(--text-muted);
       font-size: 0.9rem;
   }
   
   @media (max-width: 768px) {
       .courses-grid {
           grid-template-columns: 1fr;
       }
       
       .course-actions {
           flex-direction: column;
       }
       
       .course-actions .btn {
           flex: none;
       }
   }
   </style>
   
   <script src="../assets/js/theme.js"></script>
</body>
</html>
