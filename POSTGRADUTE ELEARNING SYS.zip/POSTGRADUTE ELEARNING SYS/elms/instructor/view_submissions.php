<?php
session_start();
include_once '../config/init.php';
include_once '../config/database.php';

// Check if user is logged in and is instructor
if (!is_logged_in() || !is_instructor()) {
    header("Location: ../auth/login.php");
    exit();
}

$instructor_id = $_SESSION['user_id'];
$assessment_id = isset($_GET['assessment_id']) ? (int)$_GET['assessment_id'] : 0;

if (!$assessment_id) {
    header("Location: assessments.php");
    exit();
}

// Get assessment details
try {
    $assessment_query = "SELECT a.*, c.name as course_name, c.code as course_code
                         FROM assessments a
                         LEFT JOIN course c ON a.course_id = c.id
                         WHERE a.id = ? AND a.created_by = ?";
    $assessment_stmt = $conn->prepare($assessment_query);
    $assessment_stmt->execute([$assessment_id, $instructor_id]);
    $assessment = $assessment_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$assessment) {
        header("Location: assessments.php");
        exit();
    }
} catch (PDOException $e) {
    header("Location: assessments.php");
    exit();
}

// Get submissions based on assessment type
try {
    if ($assessment['type'] === 'quiz') {
        // For quizzes, get from assessment_results
        $submissions_query = "SELECT ar.*, u.full_name, u.email, s.student_id,
                                     ar.submitted_at, ar.marks_obtained, ar.grade
                              FROM assessment_results ar
                              JOIN users u ON ar.student_id = u.id
                              LEFT JOIN students s ON u.id = s.user_id
                              WHERE ar.assessment_id = ?
                              ORDER BY ar.submitted_at DESC";
    } else {
        // For assignments/projects, get from assessment_submissions
        $submissions_query = "SELECT asub.*, u.full_name, u.email, s.student_id,
                                     asub.submitted_at, asub.grade, asub.feedback, asub.status,
                                     asub.submission_text, asub.file_path, asub.submission_url, asub.is_late
                              FROM assessment_submissions asub
                              JOIN users u ON asub.student_id = u.id
                              LEFT JOIN students s ON u.id = s.user_id
                              WHERE asub.assessment_id = ?
                              ORDER BY asub.submitted_at DESC";
    }
    
    $submissions_stmt = $conn->prepare($submissions_query);
    $submissions_stmt->execute([$assessment_id]);
    $submissions = $submissions_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get enrolled students count for completion rate
    $enrolled_query = "SELECT COUNT(*) as total_enrolled
                       FROM enrollment e
                       WHERE e.course_id = ?";
    $enrolled_stmt = $conn->prepare($enrolled_query);
    $enrolled_stmt->execute([$assessment['course_id']]);
    $enrolled_count = $enrolled_stmt->fetchColumn();

} catch (PDOException $e) {
    $submissions = [];
    $enrolled_count = 0;
}

// Calculate statistics
$total_submissions = count($submissions);
$completion_rate = $enrolled_count > 0 ? round(($total_submissions / $enrolled_count) * 100, 1) : 0;
$average_score = 0;
$pass_count = 0;

if ($total_submissions > 0) {
    $total_score = 0;
    foreach ($submissions as $submission) {
        if ($assessment['type'] === 'quiz') {
            $score = $submission['marks_obtained'];
        } else {
            $score = $submission['grade'] ?? 0;
        }
        $total_score += $score;
        if ($score >= $assessment['pass_marks']) {
            $pass_count++;
        }
    }
    $average_score = round($total_score / $total_submissions, 1);
}

$pass_rate = $total_submissions > 0 ? round(($pass_count / $total_submissions) * 100, 1) : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Submissions - <?php echo htmlspecialchars($assessment['title']); ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/assessments.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-align: center;
        }
        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: #007bff;
        }
        .submissions-table {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .submissions-table table {
            width: 100%;
            border-collapse: collapse;
        }
        .submissions-table th,
        .submissions-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        .submissions-table th {
            background: #f8f9fa;
            font-weight: 600;
        }
        .grade-badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.8em;
            font-weight: bold;
        }
        .grade-pass {
            background: #d4edda;
            color: #155724;
        }
        .grade-fail {
            background: #f8d7da;
            color: #721c24;
        }
        .status-submitted {
            color: #28a745;
        }
        .status-graded {
            color: #007bff;
        }
        .late-badge {
            background: #fff3cd;
            color: #856404;
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 0.7em;
        }
        .view-btn {
            padding: 4px 8px;
            font-size: 0.8em;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/instructor-sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>Submissions: <?php echo htmlspecialchars($assessment['title']); ?></h1>
                <div class="admin-header-right">
                    <a href="assessments.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Assessments
                    </a>
                </div>
            </div>

            <!-- Assessment Info -->
            <div class="assessment-info-card" style="background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <h3><?php echo htmlspecialchars($assessment['title']); ?></h3>
                        <p><strong>Course:</strong> <?php echo $assessment['course_code'] . ' - ' . htmlspecialchars($assessment['course_name']); ?></p>
                        <p><strong>Type:</strong> <?php echo ucfirst($assessment['type']); ?></p>
                        <p><strong>Due:</strong> <?php echo date('M d, Y H:i', strtotime($assessment['end_time'])); ?></p>
                    </div>
                    <div style="text-align: right;">
                        <p><strong>Total Marks:</strong> <?php echo $assessment['total_marks']; ?></p>
                        <p><strong>Pass Marks:</strong> <?php echo $assessment['pass_marks']; ?></p>
                        <span class="type-badge type-<?php echo strtolower($assessment['type']); ?>">
                            <?php echo ucfirst($assessment['type']); ?>
                        </span>
                    </div>
                </div>
            </div>

            <!-- Statistics -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $total_submissions; ?></div>
                    <div>Total Submissions</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $completion_rate; ?>%</div>
                    <div>Completion Rate</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $average_score; ?></div>
                    <div>Average Score</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $pass_rate; ?>%</div>
                    <div>Pass Rate</div>
                </div>
            </div>

            <!-- Submissions Table -->
            <div class="submissions-table">
                <table>
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Student ID</th>
                            <th>Submitted At</th>
                            <th>Score</th>
                            <th>Grade</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($submissions) > 0): ?>
                            <?php foreach ($submissions as $submission): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($submission['full_name']); ?></strong><br>
                                    <small><?php echo htmlspecialchars($submission['email']); ?></small>
                                </td>
                                <td><?php echo htmlspecialchars($submission['student_id'] ?? 'N/A'); ?></td>
                                <td>
                                    <?php echo date('M d, Y H:i', strtotime($submission['submitted_at'])); ?>
                                    <?php if ($assessment['type'] !== 'quiz' && isset($submission['is_late']) && $submission['is_late']): ?>
                                        <br><span class="late-badge">LATE</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php 
                                    if ($assessment['type'] === 'quiz') {
                                        echo $submission['marks_obtained'] . '/' . $assessment['total_marks'];
                                    } else {
                                        echo ($submission['grade'] ?? 'Not graded') . '/' . $assessment['total_marks'];
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php 
                                    $score = $assessment['type'] === 'quiz' ? $submission['marks_obtained'] : ($submission['grade'] ?? 0);
                                    $passed = $score >= $assessment['pass_marks'];
                                    ?>
                                    <span class="grade-badge <?php echo $passed ? 'grade-pass' : 'grade-fail'; ?>">
                                        <?php echo $passed ? 'PASS' : 'FAIL'; ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($assessment['type'] === 'quiz'): ?>
                                        <span class="status-graded">Completed</span>
                                    <?php else: ?>
                                        <span class="status-<?php echo $submission['status']; ?>">
                                            <?php echo ucfirst($submission['status']); ?>
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($assessment['type'] === 'quiz'): ?>
                                        <a href="view_quiz_attempt.php?assessment_id=<?php echo $assessment_id; ?>&student_id=<?php echo $submission['student_id']; ?>" 
                                           class="btn btn-sm btn-info view-btn">
                                            <i class="fas fa-eye"></i> View Attempt
                                        </a>
                                    <?php else: ?>
                                        <a href="view_submission_detail.php?submission_id=<?php echo $submission['id']; ?>" 
                                           class="btn btn-sm btn-info view-btn">
                                            <i class="fas fa-eye"></i> View Details
                                        </a>
                                        <?php if ($submission['status'] === 'submitted'): ?>
                                        <a href="grade_submission.php?submission_id=<?php echo $submission['id']; ?>" 
                                           class="btn btn-sm btn-warning view-btn">
                                            <i class="fas fa-edit"></i> Grade
                                        </a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" style="text-align: center; padding: 40px;">
                                    <i class="fas fa-inbox" style="font-size: 3rem; color: #ccc; margin-bottom: 10px;"></i>
                                    <h3>No Submissions Yet</h3>
                                    <p>Students haven't submitted anything for this assessment yet.</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($total_submissions > 0): ?>
            <!-- Export Options -->
            <div style="margin-top: 20px; text-align: center;">
                <a href="export_submissions.php?assessment_id=<?php echo $assessment_id; ?>&format=csv" 
                   class="btn btn-secondary">
                    <i class="fas fa-download"></i> Export as CSV
                </a>
                <a href="export_submissions.php?assessment_id=<?php echo $assessment_id; ?>&format=pdf" 
                   class="btn btn-secondary">
                    <i class="fas fa-file-pdf"></i> Export as PDF
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
