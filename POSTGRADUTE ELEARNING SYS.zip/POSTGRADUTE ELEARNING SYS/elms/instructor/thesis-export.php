<?php
session_start();
include_once '../config/init.php';

// Define is_instructor() if not already defined
if (!function_exists('is_instructor')) {
    function is_instructor() {
        return isset($_SESSION['role']) && $_SESSION['role'] === 'instructor';
    }
}

// Check if user is logged in and is an instructor
if (!is_logged_in() || !is_instructor()) {
    header("Location: ../auth/login.php");
    exit();
}

$instructor_id = $_SESSION['user_id'];
$export_format = $_GET['format'] ?? 'csv';

// Get instructor's department info
try {
    $instructor_query = "SELECT i.*, u.full_name, u.email 
                         FROM instructors i
                         INNER JOIN users u ON i.user_id = u.id
                         WHERE i.user_id = ?";
    $instructor_stmt = $conn->prepare($instructor_query);
    $instructor_stmt->execute([$instructor_id]);
    $instructor_info = $instructor_stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

// Get thesis data
try {
    $thesis_query = "SELECT t.*, u.full_name as student_name, u.email as student_email,
                     p.name as program_name, d.name as department_name,
                     tr.status as review_status, tr.review_date, tr.overall_score,
                     tr.content_score, tr.methodology_score, tr.presentation_score,
                     tr.comments, tr.feedback
                     FROM thesis t
                     INNER JOIN users u ON t.student_id = u.id
                     INNER JOIN programs p ON t.program_id = p.id
                     INNER JOIN departments d ON t.department_id = d.id
                     LEFT JOIN thesis_reviews tr ON t.id = tr.thesis_id AND tr.reviewer_id = ?
                     WHERE t.supervisor_id = ?
                     ORDER BY t.submission_date DESC";
    
    $thesis_stmt = $conn->prepare($thesis_query);
    $thesis_stmt->execute([$instructor_id, $instructor_id]);
    $thesis_data = $thesis_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching thesis data: " . $e->getMessage());
}

if ($export_format === 'csv') {
    // Export as CSV
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="thesis_export_' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    
    // CSV Headers
    fputcsv($output, [
        'Student Name',
        'Student Email',
        'Thesis Title',
        'Program',
        'Department',
        'Submission Date',
        'Status',
        'Review Status',
        'Review Date',
        'Overall Score',
        'Content Score',
        'Methodology Score',
        'Presentation Score',
        'Keywords',
        'Comments'
    ]);
    
    // CSV Data
    foreach ($thesis_data as $thesis) {
        fputcsv($output, [
            $thesis['student_name'],
            $thesis['student_email'],
            $thesis['title'],
            $thesis['program_name'],
            $thesis['department_name'],
            date('Y-m-d', strtotime($thesis['submission_date'])),
            ucwords(str_replace('_', ' ', $thesis['status'])),
            $thesis['review_status'] ? ucwords(str_replace('_', ' ', $thesis['review_status'])) : 'Not Reviewed',
            $thesis['review_date'] ? date('Y-m-d', strtotime($thesis['review_date'])) : '',
            $thesis['overall_score'] ?? '',
            $thesis['content_score'] ?? '',
            $thesis['methodology_score'] ?? '',
            $thesis['presentation_score'] ?? '',
            $thesis['keywords'],
            $thesis['comments'] ?? ''
        ]);
    }
    
    fclose($output);
    exit;
    
} elseif ($export_format === 'json') {
    // Export as JSON
    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="thesis_export_' . date('Y-m-d') . '.json"');
    
    $export_data = [
        'export_date' => date('Y-m-d H:i:s'),
        'instructor' => $instructor_info['full_name'],
        'total_records' => count($thesis_data),
        'thesis_data' => array_map(function($thesis) {
            return [
                'student_name' => $thesis['student_name'],
                'student_email' => $thesis['student_email'],
                'thesis_title' => $thesis['title'],
                'program' => $thesis['program_name'],
                'department' => $thesis['department_name'],
                'submission_date' => $thesis['submission_date'],
                'status' => $thesis['status'],
                'review_status' => $thesis['review_status'],
                'review_date' => $thesis['review_date'],
                'scores' => [
                    'overall' => $thesis['overall_score'],
                    'content' => $thesis['content_score'],
                    'methodology' => $thesis['methodology_score'],
                    'presentation' => $thesis['presentation_score']
                ],
                'keywords' => $thesis['keywords'],
                'abstract' => $thesis['abstract'],
                'comments' => $thesis['comments'],
                'feedback' => $thesis['feedback']
            ];
        }, $thesis_data)
    ];
    
    echo json_encode($export_data, JSON_PRETTY_PRINT);
    exit;
}

// If no valid format or showing export page
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Export Thesis Data - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link rel="stylesheet" href="../assets/css/thesis.css">
    <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/instructor-sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <div class="admin-header-content">
                    <div class="header-title-section">
                        <h1><i class="fas fa-download"></i> Export Thesis Data</h1>
                        <p class="header-subtitle">Download your thesis supervision data in various formats</p>
                    </div>
                    <div class="header-actions">
                        <a href="thesis-review.php" class="btn btn-outline-primary">
                            <i class="fas fa-arrow-left"></i> Back to Review
                        </a>
                    </div>
                </div>
            </div>

            <div class="stats-overview">
                <div class="stat-card">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo count($thesis_data); ?></div>
                        <div class="stat-label">Total Records</div>
                        <div class="stat-description">Ready for export</div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
                        <i class="fas fa-user-tie"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo htmlspecialchars($instructor_info['full_name']); ?></div>
                        <div class="stat-label">Instructor</div>
                        <div class="stat-description">Data owner</div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);">
                        <i class="fas fa-calendar"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo date('M d, Y'); ?></div>
                        <div class="stat-label">Export Date</div>
                        <div class="stat-description">Current date</div>
                    </div>
                </div>
            </div>

            <div class="content-tabs">
                <div class="tabs-content">
                    <div class="tab-panel active">
                        <div class="export-options">
                            <div class="export-card">
                                <div class="export-icon">
                                    <i class="fas fa-file-csv"></i>
                                </div>
                                <div class="export-content">
                                    <h3>CSV Export</h3>
                                    <p>Download thesis data as a CSV file for use in spreadsheet applications like Excel or Google Sheets.</p>
                                    <ul>
                                        <li>Compatible with Excel, Google Sheets</li>
                                        <li>Includes all thesis and review data</li>
                                        <li>Easy to analyze and filter</li>
                                    </ul>
                                    <a href="?format=csv" class="btn btn-primary">
                                        <i class="fas fa-download"></i> Download CSV
                                    </a>
                                </div>
                            </div>
                            
                            <div class="export-card">
                                <div class="export-icon">
                                    <i class="fas fa-file-code"></i>
                                </div>
                                <div class="export-content">
                                    <h3>JSON Export</h3>
                                    <p>Download thesis data as a JSON file for use in applications or further data processing.</p>
                                    <ul>
                                        <li>Structured data format</li>
                                        <li>Includes nested review scores</li>
                                        <li>Perfect for data analysis tools</li>
                                    </ul>
                                    <a href="?format=json" class="btn btn-secondary">
                                        <i class="fas fa-download"></i> Download JSON
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <div class="export-preview">
                            <h3><i class="fas fa-eye"></i> Data Preview</h3>
                            <p>Preview of the data that will be exported:</p>
                            
                            <?php if (!empty($thesis_data)): ?>
                                <div class="table-content">
                                    <table class="data-table">
                                        <thead>
                                            <tr>
                                                <th>Student</th>
                                                <th>Title</th>
                                                <th>Program</th>
                                                <th>Status</th>
                                                <th>Submission Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach (array_slice($thesis_data, 0, 5) as $thesis): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($thesis['student_name']); ?></td>
                                                <td><?php echo htmlspecialchars(substr($thesis['title'], 0, 50)) . '...'; ?></td>
                                                <td><?php echo htmlspecialchars($thesis['program_name']); ?></td>
                                                <td>
                                                    <span class="status-badge status-<?php echo $thesis['status']; ?>">
                                                        <?php echo ucwords(str_replace('_', ' ', $thesis['status'])); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo date('M d, Y', strtotime($thesis['submission_date'])); ?></td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                    <?php if (count($thesis_data) > 5): ?>
                                        <p class="text-center text-muted">... and <?php echo count($thesis_data) - 5; ?> more records</p>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <div class="no-data">
                                    <i class="fas fa-inbox"></i>
                                    <h3>No Data Available</h3>
                                    <p>You don't have any thesis data to export yet.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="../assets/js/theme.js"></script>
    <style>
        .export-options {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 24px;
            margin-bottom: 40px;
        }
        
        .export-card {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            border: 1px solid var(--border-color);
            display: flex;
            gap: 20px;
        }
        
        .export-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
            flex-shrink: 0;
        }
        
        .export-content {
            flex: 1;
        }
        
        .export-content h3 {
            margin: 0 0 12px 0;
            color: var(--text-primary);
            font-size: 18px;
        }
        
        .export-content p {
            margin: 0 0 16px 0;
            color: var(--text-secondary);
            line-height: 1.5;
        }
        
        .export-content ul {
            margin: 0 0 20px 0;
            padding-left: 20px;
            color: var(--text-secondary);
        }
        
        .export-content li {
            margin-bottom: 4px;
        }
        
        .export-preview {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            border: 1px solid var(--border-color);
        }
        
        .export-preview h3 {
            margin: 0 0 16px 0;
            color: var(--text-primary);
        }
        
        .export-preview p {
            margin: 0 0 20px 0;
            color: var(--text-secondary);
        }
        
        @media (max-width: 768px) {
            .export-options {
                grid-template-columns: 1fr;
            }
            
            .export-card {
                flex-direction: column;
                text-align: center;
            }
        }
    </style>
</body>
</html>
