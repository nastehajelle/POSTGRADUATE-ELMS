<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is instructor
if (!is_logged_in() || !is_instructor()) {
    header("Location: ../auth/login.php");
    exit();
}

$instructor_id = $_SESSION['user_id'];
$message = '';
$messageType = '';

// Check for messages from redirects
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    $messageType = $_SESSION['message_type'];
    unset($_SESSION['message'], $_SESSION['message_type']);
}

$course_id = isset($_GET['course_id']) ? (int)$_GET['course_id'] : 0;
$course_name = "All Courses";

// Get course details if a specific course is selected
if ($course_id > 0) {
    try {
        $course_query = "SELECT name, code FROM course WHERE id = ? AND instructor_id = ?";
        $course_stmt = $conn->prepare($course_query);
        $course_stmt->execute([$course_id, $instructor_id]);
        $course_info = $course_stmt->fetch(PDO::FETCH_ASSOC);
        if ($course_info) {
            $course_name = htmlspecialchars($course_info['code'] . ' - ' . $course_info['name']);
        } else {
            $message = "Course not found or you are not assigned to this course.";
            $messageType = "error";
            $course_id = 0; // Reset course_id if not found or unauthorized
        }
    } catch (PDOException $e) {
        $message = "Database error: " . $e->getMessage();
        $messageType = "error";
        $course_id = 0;
    }
}

// Get instructor's courses for the filter dropdown
try {
    $instructor_courses_query = "SELECT id, name, code FROM course WHERE instructor_id = ? ORDER BY name";
    $instructor_courses_stmt = $conn->prepare($instructor_courses_query);
    $instructor_courses_stmt->execute([$instructor_id]);
    $instructor_courses = $instructor_courses_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $message = "Error loading courses: " . $e->getMessage();
    $messageType = "error";
    $instructor_courses = [];
}

// Fetch course materials
$materials = [];
try {
    $materials_query = "SELECT cm.*, c.name as course_name, c.code as course_code, u.full_name as uploaded_by_name
                        FROM course_materials cm
                        JOIN course c ON cm.course_id = c.id
                        JOIN users u ON cm.uploaded_by = u.id
                        WHERE c.instructor_id = ?";
    $params = [$instructor_id];

    if ($course_id > 0) {
        $materials_query .= " AND cm.course_id = ?";
        $params[] = $course_id;
    }
    $materials_query .= " ORDER BY cm.created_at DESC";

    $materials_stmt = $conn->prepare($materials_query);
    $materials_stmt->execute($params);
    $materials = $materials_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $message = "Error loading course materials: " . $e->getMessage();
    $messageType = "error";
}

// Handle material deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_material') {
    $material_id = (int)$_POST['material_id'];
    try {
        // Verify ownership before deleting
        $check_ownership_query = "SELECT cm.file_path FROM course_materials cm JOIN course c ON cm.course_id = c.id WHERE cm.id = ? AND c.instructor_id = ?";
        $check_ownership_stmt = $conn->prepare($check_ownership_query);
        $check_ownership_stmt->execute([$material_id, $instructor_id]);
        $material_to_delete = $check_ownership_stmt->fetch(PDO::FETCH_ASSOC);

        if ($material_to_delete) {
            // Delete file from server
            $file_path = '../' . $material_to_delete['file_path']; // Adjust path as needed
            if (file_exists($file_path)) {
                unlink($file_path);
            }

            $delete_stmt = $conn->prepare("DELETE FROM course_materials WHERE id = ?");
            if ($delete_stmt->execute([$material_id])) {
                $_SESSION['message'] = "Material deleted successfully!";
                $_SESSION['message_type'] = "success";
            } else {
                $_SESSION['message'] = "Error deleting material from database.";
                $_SESSION['message_type'] = "error";
            }
        } else {
            $_SESSION['message'] = "Material not found or unauthorized to delete.";
            $_SESSION['message_type'] = "error";
        }
    } catch (PDOException $e) {
        $_SESSION['message'] = "Database error: " . $e->getMessage();
        $_SESSION['message_type'] = "error";
    }
    header("Location: course-materials.php" . ($course_id > 0 ? "?course_id=" . $course_id : ""));
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Materials - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/courses.css"> <!-- Reusing some course styles -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .materials-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .material-card {
            background: var(--card-bg);
            border-radius: 8px;
            box-shadow: var(--shadow);
            overflow: hidden;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            display: flex;
            flex-direction: column;
        }
        .material-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }
        .material-header {
            padding: 15px 20px;
            background: var(--primary-color);
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .material-header .title {
            font-weight: bold;
            font-size: 1.1rem;
            flex-grow: 1;
        }
        .material-body {
            padding: 20px;
            flex-grow: 1;
        }
        .material-body .course-info {
            font-size: 0.9rem;
            color: var(--text-muted);
            margin-bottom: 10px;
        }
        .material-body .description {
            font-size: 0.9rem;
            color: var(--text-color);
            margin-bottom: 15px;
        }
        .material-details {
            display: flex;
            flex-direction: column;
            gap: 8px;
            font-size: 0.85rem;
            color: var(--text-muted);
        }
        .material-details .detail-item {
            display: flex;
            align-items: center;
        }
        .material-details .detail-item i {
            margin-right: 8px;
            color: var(--primary-color);
        }
        .material-footer {
            padding: 15px 20px;
            background: var(--bg-secondary);
            border-top: 1px solid var(--border-color);
            display: flex;
            gap: 10px;
            justify-content: flex-end;
        }
        .material-footer .btn {
            font-size: 0.8rem;
            padding: 6px 12px;
        }
        .filter-section {
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .filter-section label {
            font-weight: bold;
            color: var(--text-color);
        }
        .filter-section select {
            padding: 8px;
            border-radius: 5px;
            border: 1px solid var(--border-color);
            background: var(--input-bg);
            color: var(--text-color);
        }
        .empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 60px 20px;
            color: var(--text-muted);
        }
        .empty-icon {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.3;
        }
        .empty-state h3 {
            margin: 0 0 10px 0;
            color: var(--text-color);
        }
        /* Modal specific styles for file upload */
        .modal-body .form-group input[type="file"] {
            padding: 8px 0; /* Adjust padding for file input */
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/instructor-sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>Course Materials for <?php echo $course_name; ?></h1>
                <div class="admin-header-right">
                    <button class="btn btn-primary" id="uploadMaterialBtn">
                        <i class="fas fa-upload"></i>
                        Upload Material
                    </button>
                </div>
            </div>
            
            <!-- Alert Messages -->
            <?php if (!empty($message)): ?>
                <div class="alert alert-<?php echo $messageType === 'success' ? 'success' : 'error'; ?>">
                    <i class="fas fa-<?php echo $messageType === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                    <span><?php echo htmlspecialchars($message); ?></span>
                </div>
            <?php endif; ?>

            <div class="filter-section">
                <label for="courseFilter">Filter by Course:</label>
                <select id="courseFilter" onchange="filterMaterials()">
                    <option value="0">All My Courses</option>
                    <?php foreach ($instructor_courses as $c): ?>
                        <option value="<?php echo $c['id']; ?>" <?php echo ($c['id'] == $course_id) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($c['code'] . ' - ' . $c['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="materials-grid">
                <?php if (count($materials) > 0): ?>
                    <?php foreach ($materials as $material): ?>
                    <div class="material-card">
                        <div class="material-header">
                            <div class="title"><?php echo htmlspecialchars($material['title']); ?></div>
                        </div>
                        <div class="material-body">
                            <div class="course-info">
                                <i class="fas fa-book"></i> <?php echo htmlspecialchars($material['course_code'] . ' - ' . $material['course_name']); ?>
                            </div>
                            <?php if (!empty($material['description'])): ?>
                            <p class="description">
                                <?php echo substr(htmlspecialchars($material['description']), 0, 100) . (strlen($material['description']) > 100 ? '...' : ''); ?>
                            </p>
                            <?php endif; ?>
                            <div class="material-details">
                                <div class="detail-item">
                                    <i class="fas fa-file"></i>
                                    <span>File: <?php echo basename($material['file_path']); ?></span>
                                </div>
                                <div class="detail-item">
                                    <i class="fas fa-tag"></i>
                                    <span>Type: <?php echo htmlspecialchars(ucfirst($material['material_type'])); ?></span>
                                </div>
                                <div class="detail-item">
                                    <i class="fas fa-user"></i>
                                    <span>Uploaded by: <?php echo htmlspecialchars($material['uploaded_by_name']); ?></span>
                                </div>
                                <div class="detail-item">
                                    <i class="fas fa-calendar-alt"></i>
                                    <span>Uploaded on: <?php echo date('M j, Y', strtotime($material['created_at'])); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="material-footer">
                            <a href="../<?php echo htmlspecialchars($material['file_path']); ?>" target="_blank" class="btn btn-sm btn-info">
                                <i class="fas fa-download"></i> Download
                            </a>
                            <form method="post" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this material?');">
                                <input type="hidden" name="action" value="delete_material">
                                <input type="hidden" name="material_id" value="<?php echo $material['id']; ?>">
                                <button type="submit" class="btn btn-sm btn-danger">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <div class="empty-icon">
                            <i class="fas fa-folder-open"></i>
                        </div>
                        <h3>No Materials Found</h3>
                        <p>There are no course materials uploaded for this selection yet.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Upload Material Modal -->
    <div id="uploadMaterialModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Upload New Material</h2>
                <button class="modal-close" id="closeUploadModal">&times;</button>
            </div>
            <div class="modal-body">
                <form id="uploadMaterialForm" method="POST" action="../api/upload_course_material.php" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="upload_course_id">Course <span class="required">*</span></label>
                        <select id="upload_course_id" name="course_id" required>
                            <option value="">Select Course</option>
                            <?php foreach ($instructor_courses as $c): ?>
                                <option value="<?php echo $c['id']; ?>" <?php echo ($c['id'] == $course_id) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($c['code'] . ' - ' . $c['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="upload_title">Title <span class="required">*</span></label>
                        <input type="text" id="upload_title" name="title" required>
                    </div>
                    <div class="form-group">
                        <label for="upload_description">Description (Optional)</label>
                        <textarea id="upload_description" name="description" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="material_file">Select File <span class="required">*</span></label>
                        <input type="file" id="material_file" name="material_file" required>
                    </div>
                    <div class="form-group">
                        <label for="detected_material_type">Detected Type</label>
                        <input type="text" id="detected_material_type" name="detected_material_type" readonly value="Not selected">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" id="cancelUploadBtn">Cancel</button>
                        <button type="submit" class="btn btn-primary">Upload Material</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="../assets/js/modal.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const uploadMaterialModal = document.getElementById('uploadMaterialModal');
            const materialFileInput = document.getElementById('material_file');
            const detectedMaterialTypeInput = document.getElementById('detected_material_type');

            document.getElementById('uploadMaterialBtn').addEventListener('click', function() {
                uploadMaterialModal.style.display = 'block';
                // Reset detected type when modal opens
                detectedMaterialTypeInput.value = 'Not selected';
                materialFileInput.value = ''; // Clear file input
            });

            document.getElementById('closeUploadModal').addEventListener('click', function() {
                uploadMaterialModal.style.display = 'none';
            });

            document.getElementById('cancelUploadBtn').addEventListener('click', function() {
                uploadMaterialModal.style.display = 'none';
            });

            window.addEventListener('click', function(event) {
                if (event.target === uploadMaterialModal) {
                    uploadMaterialModal.style.display = 'none';
                }
            });

            function filterMaterials() {
                const selectedCourseId = document.getElementById('courseFilter').value;
                window.location.href = `course-materials.php?course_id=${selectedCourseId}`;
            }
            window.filterMaterials = filterMaterials; // Make it globally accessible

            // Function to determine material type from file extension
            function getMaterialTypeFromExtension(filename) {
                const parts = filename.split('.');
                if (parts.length > 1) {
                    const extension = parts.pop().toLowerCase();
                    switch (extension) {
                        case 'pdf':
                            return 'PDF Document';
                        case 'doc':
                        case 'docx':
                        case 'txt':
                        case 'rtf':
                        case 'odt':
                            return 'Document';
                        case 'mp4':
                        case 'avi':
                        case 'mov':
                        case 'wmv':
                        case 'flv':
                        case 'webm':
                            return 'Video';
                        case 'mp3':
                        case 'wav':
                        case 'ogg':
                        case 'aac':
                            return 'Audio';
                        case 'jpg':
                        case 'jpeg':
                        case 'png':
                        case 'gif':
                        case 'bmp':
                        case 'svg':
                        case 'webp':
                            return 'Image';
                        case 'zip':
                        case 'rar':
                        case '7z':
                        case 'tar':
                        case 'gz':
                            return 'Archive';
                        default:
                            return 'Other';
                    }
                }
                return 'Not selected';
            }

            // Event listener for file input change
            materialFileInput.addEventListener('change', function() {
                if (this.files && this.files[0]) {
                    const fileName = this.files[0].name;
                    detectedMaterialTypeInput.value = getMaterialTypeFromExtension(fileName);
                } else {
                    detectedMaterialTypeInput.value = 'Not selected';
                }
            });
        });
    </script>
    <script src="../assets/js/theme.js"></script>
</body>
</html>
