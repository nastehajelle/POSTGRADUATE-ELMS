<?php
session_start();
include_once '../../config/init.php';

// Check if user is logged in and is an instructor
if (!is_logged_in() || !isset($_SESSION['role']) || $_SESSION['role'] !== 'instructor') {
    http_response_code(403);
    exit('Access denied');
}

$thesis_id = $_GET['id'] ?? 0;
$instructor_id = $_SESSION['user_id'];

try {
    // Get thesis details with student info
    $query = "SELECT t.*, u.full_name as student_name, u.email as student_email,
              p.name as program_name, d.name as department_name,
              tr.status as review_status, tr.comments, tr.feedback, tr.suggestions,
              tr.review_date, tr.overall_score, tr.content_score, tr.methodology_score, 
              tr.presentation_score
              FROM thesis t
              INNER JOIN users u ON t.student_id = u.id
              INNER JOIN programs p ON t.program_id = p.id
              INNER JOIN departments d ON t.department_id = d.id
              LEFT JOIN thesis_reviews tr ON t.id = tr.thesis_id AND tr.reviewer_id = ?
              WHERE t.id = ? AND (t.supervisor_id = ? OR t.supervisor_id IS NULL)";
    $stmt = $conn->prepare($query);
    $stmt->execute([$instructor_id, $thesis_id, $instructor_id]);
    $thesis = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$thesis) {
        echo '<div class="alert alert-danger">Thesis not found or access denied.</div>';
        exit;
    }

    // Get revision history
    $revision_query = "SELECT * FROM thesis_revisions WHERE thesis_id = ? ORDER BY version_number DESC";
    $revision_stmt = $conn->prepare($revision_query);
    $revision_stmt->execute([$thesis_id]);
    $revisions = $revision_stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo '<div class="alert alert-danger">Database error: ' . htmlspecialchars($e->getMessage()) . '</div>';
    exit;
}
?>

<div class="thesis-details">
    <div class="detail-section">
        <h4>Student Information</h4>
        <div class="detail-grid">
            <div class="detail-item">
                <label>Student Name:</label>
                <span><?php echo htmlspecialchars($thesis['student_name']); ?></span>
            </div>
            <div class="detail-item">
                <label>Email:</label>
                <span><?php echo htmlspecialchars($thesis['student_email']); ?></span>
            </div>
            <div class="detail-item">
                <label>Program:</label>
                <span><?php echo htmlspecialchars($thesis['program_name']); ?></span>
            </div>
            <div class="detail-item">
                <label>Department:</label>
                <span><?php echo htmlspecialchars($thesis['department_name']); ?></span>
            </div>
        </div>
    </div>

    <div class="detail-section">
        <h4>Thesis Information</h4>
        <div class="detail-grid">
            <div class="detail-item">
                <label>Title:</label>
                <span><?php echo htmlspecialchars($thesis['title']); ?></span>
            </div>
            <div class="detail-item">
                <label>Status:</label>
                <span class="status-badge status-<?php echo $thesis['status']; ?>">
                    <?php echo ucwords(str_replace('_', ' ', $thesis['status'])); ?>
                </span>
            </div>
            <div class="detail-item">
                <label>Submission Date:</label>
                <span><?php echo date('M d, Y H:i A', strtotime($thesis['submission_date'])); ?></span>
            </div>
            <div class="detail-item">
                <label>File Size:</label>
                <span><?php echo round($thesis['file_size'] / 1024 / 1024, 2); ?> MB</span>
            </div>
        </div>
    </div>

    <div class="detail-section">
        <h4>Abstract</h4>
        <div class="abstract-content">
            <?php echo nl2br(htmlspecialchars($thesis['abstract'])); ?>
        </div>
    </div>

    <div class="detail-section">
        <h4>Keywords</h4>
        <div class="keywords-list">
            <?php 
            $keywords = explode(',', $thesis['keywords']);
            foreach ($keywords as $keyword): 
            ?>
                <span class="keyword-tag"><?php echo trim(htmlspecialchars($keyword)); ?></span>
            <?php endforeach; ?>
        </div>
    </div>

    <?php if ($thesis['review_status']): ?>
    <div class="detail-section">
        <h4>My Review</h4>
        <div class="review-content">
            <div class="review-header">
                <span class="review-status status-<?php echo $thesis['review_status']; ?>">
                    <?php echo ucwords(str_replace('_', ' ', $thesis['review_status'])); ?>
                </span>
                <span class="review-date">
                    Reviewed on <?php echo date('M d, Y', strtotime($thesis['review_date'])); ?>
                </span>
            </div>
            
            <?php if ($thesis['overall_score']): ?>
            <div class="scores-grid">
                <div class="score-item">
                    <label>Overall Score:</label>
                    <span class="score"><?php echo $thesis['overall_score']; ?>/5.00</span>
                </div>
                <div class="score-item">
                    <label>Content:</label>
                    <span class="score"><?php echo $thesis['content_score'] ?? 'N/A'; ?>/5.00</span>
                </div>
                <div class="score-item">
                    <label>Methodology:</label>
                    <span class="score"><?php echo $thesis['methodology_score'] ?? 'N/A'; ?>/5.00</span>
                </div>
                <div class="score-item">
                    <label>Presentation:</label>
                    <span class="score"><?php echo $thesis['presentation_score'] ?? 'N/A'; ?>/5.00</span>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($thesis['comments']): ?>
            <div class="review-comments">
                <h5>Comments:</h5>
                <p><?php echo nl2br(htmlspecialchars($thesis['comments'])); ?></p>
            </div>
            <?php endif; ?>
            
            <?php if ($thesis['feedback']): ?>
            <div class="review-feedback">
                <h5>Detailed Feedback:</h5>
                <p><?php echo nl2br(htmlspecialchars($thesis['feedback'])); ?></p>
            </div>
            <?php endif; ?>

            <?php if ($thesis['suggestions']): ?>
            <div class="review-suggestions">
                <h5>Suggestions for Improvement:</h5>
                <p><?php echo nl2br(htmlspecialchars($thesis['suggestions'])); ?></p>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <?php if (!empty($revisions)): ?>
    <div class="detail-section">
        <h4>Revision History</h4>
        <div class="revisions-list">
            <?php foreach ($revisions as $revision): ?>
            <div class="revision-item">
                <div class="revision-header">
                    <span class="version">Version <?php echo $revision['version_number']; ?></span>
                    <span class="upload-date"><?php echo date('M d, Y H:i A', strtotime($revision['upload_date'])); ?></span>
                </div>
                <?php if ($revision['revision_notes']): ?>
                <div class="revision-notes">
                    <?php echo nl2br(htmlspecialchars($revision['revision_notes'])); ?>
                </div>
                <?php endif; ?>
                <div class="revision-actions">
                    <a href="../<?php echo htmlspecialchars($revision['file_path']); ?>" 
                       class="btn btn-sm btn-secondary" download>
                        <i class="fas fa-download"></i> Download
                    </a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <div class="detail-actions">
        <a href="../<?php echo htmlspecialchars($thesis['file_path']); ?>" 
           class="btn btn-primary" download>
            <i class="fas fa-download"></i> Download Current Version
        </a>
        <?php if (!$thesis['review_status']): ?>
        <button class="btn btn-success" onclick="closeViewModal(); reviewThesis(<?php echo $thesis['id']; ?>)">
            <i class="fas fa-edit"></i> Review This Thesis
        </button>
        <?php else: ?>
        <button class="btn btn-warning" onclick="closeViewModal(); reviewThesis(<?php echo $thesis['id']; ?>)">
            <i class="fas fa-edit"></i> Edit My Review
        </button>
        <?php endif; ?>
    </div>
</div>
