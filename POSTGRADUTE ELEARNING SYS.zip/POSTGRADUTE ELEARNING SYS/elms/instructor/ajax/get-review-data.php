<?php
session_start();
include_once '../../config/init.php';

// Check if user is logged in and is an instructor
if (!is_logged_in() || !isset($_SESSION['role']) || $_SESSION['role'] !== 'instructor') {
    http_response_code(403);
    exit(json_encode(['error' => 'Access denied']));
}

$thesis_id = $_GET['thesis_id'] ?? 0;
$instructor_id = $_SESSION['user_id'];

try {
    // Get existing review data
    $query = "SELECT * FROM thesis_reviews WHERE thesis_id = ? AND reviewer_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->execute([$thesis_id, $instructor_id]);
    $review = $stmt->fetch(PDO::FETCH_ASSOC);

    echo json_encode(['review' => $review]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
