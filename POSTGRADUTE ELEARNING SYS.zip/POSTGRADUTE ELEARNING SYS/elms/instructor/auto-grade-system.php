<?php
// This file contains the automatic grading system functions
// It's included in the student assessment submission process

function calculateAssessmentGrade($assessment_id, $student_answers, $conn) {
    try {
        // Get assessment details
        $assessment_query = "SELECT * FROM assessments WHERE id = ?";
        $assessment_stmt = $conn->prepare($assessment_query);
        $assessment_stmt->execute([$assessment_id]);
        $assessment = $assessment_stmt->fetch(PDO::FETCH_ASSOC);

        if (!$assessment) {
            return ['success' => false, 'message' => 'Assessment not found'];
        }

        // Get all questions for this assessment
        $questions_query = "SELECT * FROM assessment_questions WHERE assessment_id = ? ORDER BY id";
        $questions_stmt = $conn->prepare($questions_query);
        $questions_stmt->execute([$assessment_id]);
        $questions = $questions_stmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($questions)) {
            return ['success' => false, 'message' => 'No questions found for this assessment'];
        }

        $total_marks_obtained = 0;
        $question_results = [];

        // Grade each question
        foreach ($questions as $question) {
            $question_id = $question['id'];
            $student_answer = isset($student_answers[$question_id]) ? trim($student_answers[$question_id]) : '';
            $marks_obtained = 0;

            // Auto-grade based on question type
            switch ($question['question_type']) {
                case 'mcq':
                    $marks_obtained = gradeMCQ($question, $student_answer);
                    break;
                    
                case 'true_false':
                    $marks_obtained = gradeTrueFalse($question, $student_answer);
                    break;
                    
                case 'short_answer':
                    $marks_obtained = gradeShortAnswer($question, $student_answer);
                    break;
                    
                case 'essay':
                    $marks_obtained = gradeEssay($question, $student_answer);
                    break;
            }

            $total_marks_obtained += $marks_obtained;
            
            $question_results[] = [
                'question_id' => $question_id,
                'student_answer' => $student_answer,
                'correct_answer' => $question['correct_answer'],
                'marks_obtained' => $marks_obtained,
                'total_marks' => $question['marks']
            ];
        }

        // Calculate percentage and letter grade
        $percentage = ($total_marks_obtained / $assessment['total_marks']) * 100;
        $letter_grade = calculateLetterGrade($percentage);

        return [
            'success' => true,
            'total_marks_obtained' => $total_marks_obtained,
            'total_marks' => $assessment['total_marks'],
            'percentage' => round($percentage, 2),
            'letter_grade' => $letter_grade,
            'question_results' => $question_results,
            'passed' => $total_marks_obtained >= $assessment['pass_marks']
        ];

    } catch (Exception $e) {
        error_log("Auto-grading error: " . $e->getMessage());
        return ['success' => false, 'message' => 'Error occurred during grading'];
    }
}

function gradeMCQ($question, $student_answer) {
    $correct_answer = strtoupper(trim($question['correct_answer']));
    $student_answer = strtoupper(trim($student_answer));
    
    return ($student_answer === $correct_answer) ? $question['marks'] : 0;
}

function gradeTrueFalse($question, $student_answer) {
    $correct_answer = strtolower(trim($question['correct_answer']));
    $student_answer = strtolower(trim($student_answer));
    
    // Handle various true/false formats
    $true_values = ['true', 't', '1', 'yes', 'y'];
    $false_values = ['false', 'f', '0', 'no', 'n'];
    
    $correct_is_true = in_array($correct_answer, $true_values);
    $student_is_true = in_array($student_answer, $true_values);
    $student_is_false = in_array($student_answer, $false_values);
    
    if ($correct_is_true && $student_is_true) {
        return $question['marks'];
    } elseif (!$correct_is_true && $student_is_false) {
        return $question['marks'];
    }
    
    return 0;
}

function gradeShortAnswer($question, $student_answer) {
    // For short answers, we give full marks if there's a meaningful answer
    // This can be enhanced with keyword matching or similarity algorithms
    
    if (empty($student_answer)) {
        return 0;
    }
    
    // Basic keyword matching
    $correct_answer = strtolower($question['correct_answer']);
    $student_answer = strtolower($student_answer);
    
    // Split correct answer into keywords
    $keywords = preg_split('/[\s,;]+/', $correct_answer);
    $keywords = array_filter($keywords, function($word) {
        return strlen($word) > 2; // Ignore very short words
    });
    
    if (empty($keywords)) {
        // If no keywords, give full marks for any non-empty answer
        return $question['marks'];
    }
    
    $matches = 0;
    foreach ($keywords as $keyword) {
        if (strpos($student_answer, $keyword) !== false) {
            $matches++;
        }
    }
    
    // Calculate partial marks based on keyword matches
    $match_percentage = $matches / count($keywords);
    
    if ($match_percentage >= 0.7) {
        return $question['marks']; // Full marks for 70%+ keyword match
    } elseif ($match_percentage >= 0.4) {
        return $question['marks'] * 0.7; // 70% marks for 40%+ keyword match
    } elseif ($match_percentage > 0) {
        return $question['marks'] * 0.4; // 40% marks for some keyword match
    } else {
        return $question['marks'] * 0.2; // 20% marks for attempting (non-empty answer)
    }
}

function gradeEssay($question, $student_answer) {
    // For essays, we give marks based on length and basic content analysis
    // This is a simplified approach - in practice, you might want manual grading for essays
    
    if (empty($student_answer)) {
        return 0;
    }
    
    $word_count = str_word_count($student_answer);
    $char_count = strlen(trim($student_answer));
    
    // Basic scoring based on effort (length)
    if ($word_count >= 100 && $char_count >= 500) {
        return $question['marks']; // Full marks for substantial essay
    } elseif ($word_count >= 50 && $char_count >= 250) {
        return $question['marks'] * 0.8; // 80% for moderate essay
    } elseif ($word_count >= 20 && $char_count >= 100) {
        return $question['marks'] * 0.6; // 60% for short essay
    } elseif ($word_count >= 5) {
        return $question['marks'] * 0.4; // 40% for very short response
    } else {
        return $question['marks'] * 0.2; // 20% for minimal effort
    }
}

function calculateLetterGrade($percentage) {
    if ($percentage >= 90) return 'A';
    elseif ($percentage >= 80) return 'B';
    elseif ($percentage >= 70) return 'C';
    elseif ($percentage >= 60) return 'D';
    else return 'F';
}

// Function to store assessment result
function storeAssessmentResult($assessment_id, $student_id, $grading_result, $conn) {
    try {
        // Check if result already exists
        $check_query = "SELECT id FROM assessment_results WHERE assessment_id = ? AND student_id = ?";
        $check_stmt = $conn->prepare($check_query);
        $check_stmt->execute([$assessment_id, $student_id]);
        
        if ($check_stmt->fetch()) {
            return ['success' => false, 'message' => 'Assessment already submitted'];
        }

        // Insert new result
        $insert_query = "INSERT INTO assessment_results (assessment_id, student_id, marks_obtained, grade, submitted_at) 
                        VALUES (?, ?, ?, ?, NOW())";
        $insert_stmt = $conn->prepare($insert_query);
        $insert_stmt->execute([
            $assessment_id,
            $student_id,
            $grading_result['total_marks_obtained'],
            $grading_result['letter_grade']
        ]);

        return [
            'success' => true,
            'result_id' => $conn->lastInsertId(),
            'message' => 'Assessment graded and result stored successfully'
        ];

    } catch (PDOException $e) {
        error_log("Error storing assessment result: " . $e->getMessage());
        return ['success' => false, 'message' => 'Error storing result'];
    }
}
?>
