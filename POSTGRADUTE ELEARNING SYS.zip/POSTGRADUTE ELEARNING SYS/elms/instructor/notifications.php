<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include_once '../config/init.php';

// Check if user is logged in and is instructor
if (!is_logged_in() || $_SESSION['role'] !== 'instructor') {
    header("Location: ../auth/login.php");
    exit();
}

$instructor_id = $_SESSION['user_id'];

// Handle mark as read action
if (isset($_POST['mark_read']) && isset($_POST['notification_id'])) {
    $notification_id = $_POST['notification_id'];
    try {
        $update_query = "UPDATE instructor_notifications SET is_read = 1 WHERE id = ? AND instructor_id = ?";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->execute([$notification_id, $instructor_id]);
        
        header("Location: notifications.php");
        exit();
    } catch (PDOException $e) {
        $error_message = "Error marking notification as read: " . $e->getMessage();
    }
}

// Handle mark all as read action
if (isset($_POST['mark_all_read'])) {
    try {
        $update_all_query = "UPDATE instructor_notifications SET is_read = 1 WHERE instructor_id = ?";
        $update_all_stmt = $conn->prepare($update_all_query);
        $update_all_stmt->execute([$instructor_id]);
        
        header("Location: notifications.php");
        exit();
    } catch (PDOException $e) {
        $error_message = "Error marking all notifications as read: " . $e->getMessage();
    }
}

// Handle delete notification action
if (isset($_POST['delete_notification']) && isset($_POST['notification_id'])) {
    $notification_id = $_POST['notification_id'];
    try {
        $delete_query = "DELETE FROM instructor_notifications WHERE id = ? AND instructor_id = ?";
        $delete_stmt = $conn->prepare($delete_query);
        $delete_stmt->execute([$notification_id, $instructor_id]);
        
        header("Location: notifications.php");
        exit();
    } catch (PDOException $e) {
        $error_message = "Error deleting notification: " . $e->getMessage();
    }
}

// Get filter parameters
$filter = $_GET['filter'] ?? 'all';
$search = $_GET['search'] ?? '';

// Build WHERE clause based on filters
$where_conditions = ["instructor_id = ?"];
$params = [$instructor_id];

if ($filter === 'unread') {
    $where_conditions[] = "is_read = 0";
} elseif ($filter === 'read') {
    $where_conditions[] = "is_read = 1";
}

if (!empty($search)) {
    $where_conditions[] = "(title LIKE ? OR message LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$where_clause = implode(' AND ', $where_conditions);

// Get notifications with pagination
$page = $_GET['page'] ?? 1;
$per_page = 15;
$offset = ($page - 1) * $per_page;

try {
    // First, ensure the instructor_notifications table exists
    $create_table_query = "
        CREATE TABLE IF NOT EXISTS instructor_notifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            instructor_id INT NOT NULL,
            title VARCHAR(255) NOT NULL,
            message TEXT NOT NULL,
            type ENUM('info', 'success', 'warning', 'error') DEFAULT 'info',
            is_read BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (instructor_id) REFERENCES users(id) ON DELETE CASCADE
        )
    ";
    $conn->exec($create_table_query);
    
    // Get total count for pagination
    $count_query = "SELECT COUNT(*) as total FROM instructor_notifications WHERE $where_clause";
    $count_stmt = $conn->prepare($count_query);
    $count_stmt->execute($params);
    $total_notifications = $count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    // Get notifications
    $notifications_query = "
        SELECT id, title, message, type, is_read, created_at
        FROM instructor_notifications 
        WHERE $where_clause
        ORDER BY created_at DESC
        LIMIT $per_page OFFSET $offset
    ";
    $notifications_stmt = $conn->prepare($notifications_query);
    $notifications_stmt->execute($params);
    $notifications = $notifications_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get unread count
    $unread_query = "SELECT COUNT(*) as unread FROM instructor_notifications WHERE instructor_id = ? AND is_read = 0";
    $unread_stmt = $conn->prepare($unread_query);
    $unread_stmt->execute([$instructor_id]);
    $unread_count = $unread_stmt->fetch(PDO::FETCH_ASSOC)['unread'];
    
    // If no notifications exist, create some sample ones
    if (empty($notifications) && $filter === 'all' && empty($search)) {
        $sample_notifications = [
            [
                'title' => 'Welcome to the Instructor Portal',
                'message' => 'Welcome to your instructor dashboard! Here you can manage your courses, assessments, and track student progress.',
                'type' => 'info'
            ],
            [
                'title' => 'Assessment Reminder',
                'message' => 'Don\'t forget to review and grade the recent assessments submitted by your students.',
                'type' => 'warning'
            ],
            [
                'title' => 'Course Material Updated',
                'message' => 'Your course materials have been successfully updated and are now available to students.',
                'type' => 'success'
            ],
            [
                'title' => 'Student Enrollment Alert',
                'message' => 'New students have been enrolled in your courses. Please review the updated class rosters.',
                'type' => 'info'
            ]
        ];
        
        foreach ($sample_notifications as $notification) {
            $insert_query = "INSERT INTO instructor_notifications (instructor_id, title, message, type) VALUES (?, ?, ?, ?)";
            $insert_stmt = $conn->prepare($insert_query);
            $insert_stmt->execute([$instructor_id, $notification['title'], $notification['message'], $notification['type']]);
        }
        
        // Refresh the page to show the new notifications
        header("Location: notifications.php");
        exit();
    }
    
} catch (PDOException $e) {
    $error_message = "Database error: " . $e->getMessage();
    $notifications = [];
    $total_notifications = 0;
    $unread_count = 0;
}

$total_pages = ceil($total_notifications / $per_page);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications - Instructor Portal</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/instructor-sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <div class="header-left">
                    <h1><i class="fas fa-bell"></i> Notifications</h1>
                    <?php if ($unread_count > 0): ?>
                        <span class="badge badge-danger"><?php echo $unread_count; ?> unread</span>
                    <?php endif; ?>
                </div>
                <div class="header-right">
                    <?php if ($unread_count > 0): ?>
                        <form method="POST" style="display: inline;">
                            <button type="submit" name="mark_all_read" class="btn btn-primary">
                                <i class="fas fa-check-double"></i> Mark All Read
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>

            <?php if (isset($error_message)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i>
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>

            <!-- Filters Card -->
            <div class="card">
                <div class="card-body">
                    <div class="filters-container">
                        <div class="filter-tabs">
                            <a href="?filter=all<?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>" 
                               class="filter-tab <?php echo $filter === 'all' ? 'active' : ''; ?>">
                                All (<?php echo $total_notifications; ?>)
                            </a>
                            <a href="?filter=unread<?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>" 
                               class="filter-tab <?php echo $filter === 'unread' ? 'active' : ''; ?>">
                                Unread (<?php echo $unread_count; ?>)
                            </a>
                            <a href="?filter=read<?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>" 
                               class="filter-tab <?php echo $filter === 'read' ? 'active' : ''; ?>">
                                Read (<?php echo $total_notifications - $unread_count; ?>)
                            </a>
                        </div>
                        
                        <div class="search-box">
                            <form method="GET" class="search-form">
                                <input type="hidden" name="filter" value="<?php echo htmlspecialchars($filter); ?>">
                                <div class="input-group">
                                    <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" 
                                           placeholder="Search notifications..." class="form-control">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-outline-secondary">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Notifications Card -->
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-list"></i> 
                        <?php 
                        if ($filter === 'unread') echo 'Unread Notifications';
                        elseif ($filter === 'read') echo 'Read Notifications';
                        else echo 'All Notifications';
                        ?>
                    </h5>
                </div>
                <div class="card-body p-0">
                    <?php if (empty($notifications)): ?>
                        <div class="empty-state">
                            <div class="empty-icon">
                                <i class="fas fa-bell-slash"></i>
                            </div>
                            <h4>No notifications found</h4>
                            <p class="text-muted">
                                <?php if (!empty($search)): ?>
                                    No notifications match your search criteria.
                                <?php elseif ($filter === 'unread'): ?>
                                    You have no unread notifications.
                                <?php elseif ($filter === 'read'): ?>
                                    You have no read notifications.
                                <?php else: ?>
                                    You don't have any notifications yet.
                                <?php endif; ?>
                            </p>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <tbody>
                                    <?php foreach ($notifications as $notification): ?>
                                        <tr class="notification-row <?php echo !$notification['is_read'] ? 'unread' : ''; ?>">
                                            <td class="notification-icon-cell">
                                                <div class="notification-type-icon <?php echo $notification['type']; ?>">
                                                    <?php
                                                    $icons = [
                                                        'info' => 'fa-info-circle',
                                                        'success' => 'fa-check-circle',
                                                        'warning' => 'fa-exclamation-triangle',
                                                        'error' => 'fa-times-circle'
                                                    ];
                                                    echo '<i class="fas ' . ($icons[$notification['type']] ?? 'fa-bell') . '"></i>';
                                                    ?>
                                                </div>
                                            </td>
                                            <td class="notification-content-cell">
                                                <div class="notification-title">
                                                    <?php echo htmlspecialchars($notification['title']); ?>
                                                    <?php if (!$notification['is_read']): ?>
                                                        <span class="badge badge-primary badge-sm ml-2">New</span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="notification-message">
                                                    <?php echo nl2br(htmlspecialchars($notification['message'])); ?>
                                                </div>
                                                <div class="notification-meta">
                                                    <small class="text-muted">
                                                        <i class="fas fa-clock"></i> 
                                                        <?php echo date('M d, Y h:i A', strtotime($notification['created_at'])); ?>
                                                    </small>
                                                </div>
                                            </td>
                                            <td class="notification-actions-cell">
                                                <div class="btn-group">
                                                    <?php if (!$notification['is_read']): ?>
                                                        <form method="POST" style="display: inline;">
                                                            <input type="hidden" name="notification_id" value="<?php echo $notification['id']; ?>">
                                                            <button type="submit" name="mark_read" class="btn btn-sm btn-outline-primary" title="Mark as read">
                                                                <i class="fas fa-check"></i>
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                    
                                                    <form method="POST" style="display: inline;">
                                                        <input type="hidden" name="notification_id" value="<?php echo $notification['id']; ?>">
                                                        <button type="submit" name="delete_notification" class="btn btn-sm btn-outline-danger" 
                                                                title="Delete notification" 
                                                                onclick="return confirm('Are you sure you want to delete this notification?')">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
                <div class="pagination-container">
                    <nav aria-label="Notifications pagination">
                        <ul class="pagination justify-content-center">
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo $page - 1; ?>&filter=<?php echo $filter; ?>&search=<?php echo urlencode($search); ?>">
                                        <i class="fas fa-chevron-left"></i> Previous
                                    </a>
                                </li>
                            <?php endif; ?>
                            
                            <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>&filter=<?php echo $filter; ?>&search=<?php echo urlencode($search); ?>">
                                        <?php echo $i; ?>
                                    </a>
                                </li>
                            <?php endfor; ?>
                            
                            <?php if ($page < $total_pages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo $page + 1; ?>&filter=<?php echo $filter; ?>&search=<?php echo urlencode($search); ?>">
                                        Next <i class="fas fa-chevron-right"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="../assets/js/theme.js"></script>
    <script>
        // Auto-submit search form on input
        document.querySelector('input[name="search"]').addEventListener('input', function() {
            clearTimeout(this.searchTimeout);
            this.searchTimeout = setTimeout(() => {
                this.form.submit();
            }, 500);
        });

        // Smooth scroll to top when pagination is clicked
        document.querySelectorAll('.pagination a').forEach(link => {
            link.addEventListener('click', function() {
                setTimeout(() => {
                    document.querySelector('.admin-content').scrollIntoView({
                        behavior: 'smooth'
                    });
                }, 100);
            });
        });
    </script>

    <style>
        /* Admin-style notifications specific styles */
        .filters-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
        }

        .filter-tabs {
            display: flex;
            gap: 5px;
        }

        .filter-tab {
            padding: 8px 16px;
            border: 1px solid #dee2e6;
            background: #f8f9fa;
            color: #495057;
            text-decoration: none;
            border-radius: 4px;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .filter-tab:hover {
            background: #e9ecef;
            color: #495057;
            text-decoration: none;
        }

        .filter-tab.active {
            background: #007bff;
            color: white;
            border-color: #007bff;
        }

        .search-box {
            flex: 1;
            max-width: 300px;
        }

        .notification-row {
            border-left: 4px solid transparent;
            transition: all 0.3s ease;
        }

        .notification-row.unread {
            background-color: #f8f9ff;
            border-left-color: #007bff;
        }

        .notification-row:hover {
            background-color: #f5f5f5;
        }

        .notification-icon-cell {
            width: 60px;
            text-align: center;
            vertical-align: top;
            padding-top: 20px;
        }

        .notification-type-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto;
            font-size: 18px;
        }

        .notification-type-icon.info {
            background: #d1ecf1;
            color: #0c5460;
        }

        .notification-type-icon.success {
            background: #d4edda;
            color: #155724;
        }

        .notification-type-icon.warning {
            background: #fff3cd;
            color: #856404;
        }

        .notification-type-icon.error {
            background: #f8d7da;
            color: #721c24;
        }

        .notification-content-cell {
            vertical-align: top;
            padding: 15px 10px;
        }

        .notification-title {
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
            font-size: 16px;
            display: flex;
            align-items: center;
        }

        .notification-message {
            color: #666;
            line-height: 1.5;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .notification-meta {
            margin-top: 8px;
        }

        .notification-actions-cell {
            width: 120px;
            text-align: center;
            vertical-align: top;
            padding-top: 20px;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
        }

        .empty-icon {
            font-size: 64px;
            color: #dee2e6;
            margin-bottom: 20px;
        }

        .empty-state h4 {
            color: #495057;
            margin-bottom: 10px;
        }

        .pagination-container {
            margin-top: 20px;
        }

        .badge-sm {
            font-size: 0.75em;
        }

        @media (max-width: 768px) {
            .filters-container {
                flex-direction: column;
                align-items: stretch;
            }

            .filter-tabs {
                justify-content: center;
                flex-wrap: wrap;
            }

            .search-box {
                max-width: none;
            }

            .notification-actions-cell {
                width: auto;
            }

            .btn-group {
                display: flex;
                gap: 5px;
            }
        }
    </style>
</body>
</html>
