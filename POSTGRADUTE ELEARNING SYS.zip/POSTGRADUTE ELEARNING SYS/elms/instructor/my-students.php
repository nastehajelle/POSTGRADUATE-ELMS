<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is instructor
if (!is_logged_in() || !is_instructor()) {
    header("Location: ../auth/login.php");
    exit();
}

$instructor_id = $_SESSION['user_id'];
$course_filter = isset($_GET['course_id']) ? (int)$_GET['course_id'] : null;

// Get instructor's courses for filter dropdown
try {
    $courses_query = "SELECT c.id, c.name, c.code 
                     FROM course c 
                     WHERE c.instructor_id = ? AND c.status = 'active'
                     ORDER BY c.name";
    $courses_stmt = $conn->prepare($courses_query);
    $courses_stmt->execute([$instructor_id]);
    $instructor_courses = $courses_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get students enrolled in instructor's courses
    $students_query = "SELECT DISTINCT u.id, u.full_name, u.email, u.phone, u.gender, u.status,
                      e.student_id, p.name as program_name, d.name as department_name, 
                      b.name as batch_name, b.year as batch_year,
                      c.name as course_name, c.code as course_code
                      FROM users u
                      JOIN enrollment e ON u.id = e.user_id
                      JOIN course c ON (e.course_id = c.id OR e.batch_id = c.batch_id)
                      LEFT JOIN programs p ON e.program_id = p.id
                      LEFT JOIN departments d ON e.department_id = d.id
                      LEFT JOIN batch b ON e.batch_id = b.id
                      WHERE c.instructor_id = ? AND u.role = 'student'";
    
    $params = [$instructor_id];
    
    if ($course_filter) {
        $students_query .= " AND c.id = ?";
        $params[] = $course_filter;
    }
    
    $students_query .= " ORDER BY u.full_name";
    
    $students_stmt = $conn->prepare($students_query);
    $students_stmt->execute($params);
    $my_students = $students_stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    error_log("Error fetching instructor students: " . $e->getMessage());
    $my_students = [];
    $instructor_courses = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Students - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/users.css">
    <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/instructor-sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>My Students</h1>
                <div class="admin-header-right">
                    <span class="student-count"><?php echo count($my_students); ?> students</span>
                </div>
            </div>
            
            <div id="alertContainer"></div>
            
            <!-- Filter Controls -->
            <div class="filter-controls">
                <div class="filter-item">
                    <label for="courseFilter">Filter by Course:</label>
                    <select id="courseFilter" onchange="filterByCourse()">
                        <option value="">All Courses</option>
                        <?php foreach ($instructor_courses as $course): ?>
                            <option value="<?php echo $course['id']; ?>" <?php echo $course_filter == $course['id'] ? 'selected' : ''; ?>>
                                <?php echo $course['code'] . ' - ' . $course['name']; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="filter-item">
                    <label for="statusFilter">Status:</label>
                    <select id="statusFilter">
                        <option value="">All Status</option>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
                <div class="filter-item">
                    <label for="searchInput">Search:</label>
                    <input type="text" id="searchInput" placeholder="Name, Email, ID...">
                </div>
            </div>
            
            <!-- Students List -->
            <div class="card">
                <div class="card-body">
                    <table class="data-table" id="studentsTable">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Course</th>
                                <th>Program</th>
                                <th>Batch</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($my_students) > 0): ?>
                                <?php foreach ($my_students as $student): ?>
                                <tr data-status="<?php echo $student['status']; ?>">
                                    <td><?php echo $student['student_id'] ?? 'N/A'; ?></td>
                                    <td><?php echo $student['full_name']; ?></td>
                                    <td><?php echo $student['email']; ?></td>
                                    <td><?php echo $student['course_code'] . ' - ' . $student['course_name']; ?></td>
                                    <td><?php echo $student['program_name'] ?? 'N/A'; ?></td>
                                    <td><?php echo $student['batch_name'] ? $student['batch_name'] . ' (' . $student['batch_year'] . ')' : 'N/A'; ?></td>
                                    <td>
                                        <span class="status-badge <?php echo $student['status']; ?>">
                                            <?php echo ucfirst($student['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-info view-student-btn" data-id="<?php echo $student['id']; ?>">View</button>
                                        <a href="chats.php?student_id=<?php echo $student['id']; ?>" class="btn btn-sm btn-primary">Chat</a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center">No students found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- View Student Modal -->
    <div id="viewModalBackdrop" class="modal-backdrop"></div>
    <div id="viewModalContainer" class="modal-container">
        <div class="modal-header">
            <h2>Student Details</h2>
            <button class="modal-close" id="closeViewModal">&times;</button>
        </div>
        <div class="modal-body">
            <div id="studentDetails">
                <div class="user-detail-row">
                    <strong>Student ID:</strong>
                    <span id="view_student_id"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Full Name:</strong>
                    <span id="view_full_name"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Email:</strong>
                    <span id="view_email"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Phone:</strong>
                    <span id="view_phone"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Gender:</strong>
                    <span id="view_gender"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Status:</strong>
                    <span id="view_status"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Program:</strong>
                    <span id="view_program"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Department:</strong>
                    <span id="view_department"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Batch:</strong>
                    <span id="view_batch"></span>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" id="closeViewBtn">Close</button>
            <button class="btn btn-primary" id="chatWithStudentBtn">Start Chat</button>
        </div>
    </div>
    
    <script>
    function filterByCourse() {
        const courseId = document.getElementById('courseFilter').value;
        if (courseId) {
            window.location.href = `my-students.php?course_id=${courseId}`;
        } else {
            window.location.href = 'my-students.php';
        }
    }
    
    document.addEventListener('DOMContentLoaded', function() {
        // Filter functionality
        const statusFilter = document.getElementById('statusFilter');
        const searchInput = document.getElementById('searchInput');
        
        function filterTable() {
            const statusFilterValue = statusFilter.value.toLowerCase();
            const searchValue = searchInput.value.toLowerCase();
            
            const rows = document.querySelectorAll('#studentsTable tbody tr');
            
            rows.forEach(row => {
                const status = row.getAttribute('data-status').toLowerCase();
                const text = row.textContent.toLowerCase();
                
                const statusMatch = !statusFilterValue || status === statusFilterValue;
                const searchMatch = !searchValue || text.includes(searchValue);
                
                if (statusMatch && searchMatch) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }
        
        statusFilter.addEventListener('change', filterTable);
        searchInput.addEventListener('input', filterTable);
        
        // Modal functionality
        const viewModalBackdrop = document.getElementById('viewModalBackdrop');
        const viewModalContainer = document.getElementById('viewModalContainer');
        
        function openViewModal() {
            viewModalBackdrop.classList.add('show');
            viewModalContainer.classList.add('show');
        }

        function closeViewModal() {
            viewModalBackdrop.classList.remove('show');
            viewModalContainer.classList.remove('show');
        }
        
        document.getElementById('closeViewModal').addEventListener('click', closeViewModal);
        document.getElementById('closeViewBtn').addEventListener('click', closeViewModal);
        viewModalBackdrop.addEventListener('click', closeViewModal);
        
        // View student details
        document.querySelectorAll('.view-student-btn').forEach(button => {
            button.addEventListener('click', function() {
                const userId = this.getAttribute('data-id');
                
                // Set loading state
                button.disabled = true;
                button.innerHTML = 'Loading...';
                
                // Fetch user data
                const formData = new FormData();
                formData.append('ajax', 1);
                formData.append('action', 'get');
                formData.append('user_id', userId);
                
                fetch('../admin/users.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    button.disabled = false;
                    button.innerHTML = 'View';
                    
                    if (data.success) {
                        const student = data.data;
                        
                        // Fill view modal with student data
                        document.getElementById('view_student_id').textContent = student.student_id || 'N/A';
                        document.getElementById('view_full_name').textContent = student.full_name;
                        document.getElementById('view_email').textContent = student.email;
                        document.getElementById('view_phone').textContent = student.phone;
                        document.getElementById('view_gender').textContent = student.gender.charAt(0).toUpperCase() + student.gender.slice(1);
                        
                        // Set status with badge
                        const statusBadge = document.createElement('span');
                        statusBadge.className = `status-badge ${student.status}`;
                        statusBadge.textContent = student.status.charAt(0).toUpperCase() + student.status.slice(1);
                        document.getElementById('view_status').innerHTML = '';
                        document.getElementById('view_status').appendChild(statusBadge);
                        
                        // Get program and department from the table row
                        const studentRow = this.closest('tr');
                        document.getElementById('view_program').textContent = studentRow.cells[4].textContent.trim();
                        document.getElementById('view_department').textContent = 'N/A'; // Not shown in table
                        document.getElementById('view_batch').textContent = studentRow.cells[5].textContent.trim();
                        
                        // Set up chat button
                        document.getElementById('chatWithStudentBtn').onclick = function() {
                            window.location.href = `chats.php?student_id=${userId}`;
                        };
                        
                        openViewModal();
                    } else {
                        alert('Error loading student data');
                    }
                })
                .catch(error => {
                    button.disabled = false;
                    button.innerHTML = 'View';
                    console.error('Error:', error);
                    alert('Error loading student data');
                });
            });
        });
    });
    </script>
    
    <script src="../assets/js/theme.js"></script>
</body>
</html>
