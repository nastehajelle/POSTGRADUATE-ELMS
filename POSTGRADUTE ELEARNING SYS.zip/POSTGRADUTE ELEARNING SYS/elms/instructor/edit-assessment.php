<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is an instructor
if (!is_logged_in() || !is_instructor()) {
    header("Location: ../auth/login.php");
    exit();
}

$instructor_id = $_SESSION['user_id'];
$assessment_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$assessment = null;
$message = '';
$messageType = '';

if ($assessment_id <= 0) {
    header("Location: assessments.php");
    exit();
}

// Get instructor's courses for dropdown
$instructor_courses = [];
try {
    $courses_query = "SELECT id, name, code FROM course WHERE instructor_id = ? AND status = 'active' ORDER BY name";
    $courses_stmt = $conn->prepare($courses_query);
    $courses_stmt->execute([$instructor_id]);
    $instructor_courses = $courses_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching instructor courses: " . $e->getMessage());
}

// Get assessment details and verify ownership
try {
    $assessment_query = "SELECT a.*, c.name as course_name 
                        FROM assessments a
                        LEFT JOIN course c ON a.course_id = c.id
                        WHERE a.id = ? AND a.created_by = ? AND a.type != 'exam'";
    $assessment_stmt = $conn->prepare($assessment_query);
    $assessment_stmt->execute([$assessment_id, $instructor_id]);
    $assessment = $assessment_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$assessment) {
        $message = "Assessment not found or you don't have permission to edit it.";
        $messageType = "danger";
    }
} catch (PDOException $e) {
    error_log("Error fetching assessment: " . $e->getMessage());
    $message = "Error loading assessment.";
    $messageType = "danger";
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_assessment']) && $assessment) {
    $title = sanitize_input($_POST['title']);
    $description = sanitize_input($_POST['description']);
    $course_id = !empty($_POST['course_id']) ? intval($_POST['course_id']) : null;
    $total_marks = intval($_POST['total_marks']);
    $pass_marks = intval($_POST['pass_marks']);
    $start_time = sanitize_input($_POST['start_time']);
    $end_time = sanitize_input($_POST['end_time']);
    $duration_minutes = intval($_POST['duration_minutes']);
    $instructions = sanitize_input($_POST['instructions']);
    $randomize_questions = isset($_POST['randomize_questions']) ? 1 : 0;
    $attempts_allowed = intval($_POST['attempts_allowed']);

    // Validate course ownership if course is selected
    $course_valid = true;
    if ($course_id) {
        $course_check_query = "SELECT id FROM course WHERE id = ? AND instructor_id = ?";
        $course_check_stmt = $conn->prepare($course_check_query);
        $course_check_stmt->execute([$course_id, $instructor_id]);
        if (!$course_check_stmt->fetch()) {
            $course_valid = false;
            $message = "You can only assign assessments to your own courses.";
            $messageType = "danger";
        }
    }

    if ($course_valid && !empty($title) && $total_marks > 0 && $pass_marks >= 0) {
        try {
            $update_query = "UPDATE assessments SET 
                            title = ?, description = ?, course_id = ?, total_marks = ?, pass_marks = ?,
                            start_time = ?, end_time = ?, duration_minutes = ?, instructions = ?,
                            randomize_questions = ?, attempts_allowed = ?
                            WHERE id = ? AND created_by = ?";
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->execute([
                $title, $description, $course_id, $total_marks, $pass_marks,
                $start_time, $end_time, $duration_minutes, $instructions,
                $randomize_questions, $attempts_allowed, $assessment_id, $instructor_id
            ]);

            $message = "Assessment updated successfully!";
            $messageType = "success";
            
            // Refresh assessment data
            $assessment_stmt->execute([$assessment_id, $instructor_id]);
            $assessment = $assessment_stmt->fetch(PDO::FETCH_ASSOC);
            
        } catch (PDOException $e) {
            error_log("Error updating assessment: " . $e->getMessage());
            $message = "Error updating assessment. Please try again.";
            $messageType = "danger";
        }
    } else {
        $message = "Please fill in all required fields correctly.";
        $messageType = "danger";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Assessment - <?php echo htmlspecialchars($assessment['title'] ?? ''); ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <?php echo FONT_AWESOME_CSS; ?>
    <style>
        .edit-container {
            max-width: 800px;
            margin: 0 auto;
        }

        .assessment-header {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
            border-left: 4px solid var(--primary-color);
        }

        .form-container {
            background: var(--card-bg);
            padding: 30px;
            border-radius: 12px;
            box-shadow: var(--shadow);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--text-color);
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            font-size: 0.9rem;
            background: var(--input-bg);
            color: var(--text-color);
            transition: border-color 0.2s;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--primary-color);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-top: 10px;
        }

        .checkbox-group input[type="checkbox"] {
            width: auto;
        }

        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid var(--border-color);
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            font-size: 0.9rem;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
        }

        .btn-primary {
            background: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
        }

        .btn-secondary {
            background: var(--bg-secondary);
            color: var(--text-color);
            border: 1px solid var(--border-color);
        }

        .btn-secondary:hover {
            background: var(--hover-bg);
            text-decoration: none;
        }

        .btn-danger {
            background: #ef4444;
            color: white;
        }

        .btn-danger:hover {
            background: #dc2626;
        }

        .warning-box {
            background: #fef3c7;
            color: #92400e;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #f59e0b;
        }

        .warning-box i {
            margin-right: 8px;
        }

        .info-box {
            background: #dbeafe;
            color: #1e40af;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #3b82f6;
        }

        .info-box i {
            margin-right: 8px;
        }

        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .form-actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/instructor-sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="edit-container">
                <div class="admin-header">
                    <h1>Edit Assessment</h1>
                    <a href="assessments.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Assessments
                    </a>
                </div>
                
                <?php if (!empty($message)): ?>
                    <div class="message <?php echo $messageType; ?>">
                        <?php echo $message; ?>
                    </div>
                <?php endif; ?>

                <?php if ($assessment): ?>
                    <!-- Assessment Header -->
                    <div class="assessment-header">
                        <h2><?php echo htmlspecialchars($assessment['title']); ?></h2>
                        <p style="color: var(--text-muted); margin: 5px 0 0 0;">
                            <i class="fas fa-tag"></i> <?php echo ucfirst($assessment['type']); ?>
                            <?php if ($assessment['course_name']): ?>
                                | <i class="fas fa-book"></i> <?php echo htmlspecialchars($assessment['course_name']); ?>
                            <?php endif; ?>
                        </p>
                    </div>

                    <!-- Warning Box -->
                    <div class="warning-box">
                        <i class="fas fa-exclamation-triangle"></i>
                        <strong>Important:</strong> Changes to assessment settings will affect all future attempts. Students who have already submitted will not be affected.
                    </div>

                    <!-- Edit Form -->
                    <div class="form-container">
                        <form method="POST">
                            <div class="form-group">
                                <label for="title">Assessment Title *</label>
                                <input type="text" name="title" id="title" required 
                                       value="<?php echo htmlspecialchars($assessment['title']); ?>"
                                       placeholder="Enter assessment title">
                            </div>
                            
                            <div class="form-group">
                                <label for="course_id">Course</label>
                                <select name="course_id" id="course_id">
                                    <option value="">General Assessment</option>
                                    <?php foreach ($instructor_courses as $course): ?>
                                        <option value="<?php echo $course['id']; ?>" 
                                                <?php echo ($assessment['course_id'] == $course['id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($course['code'] . ' - ' . $course['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="description">Description</label>
                                <textarea name="description" id="description" 
                                          placeholder="Enter assessment description"><?php echo htmlspecialchars($assessment['description']); ?></textarea>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="total_marks">Total Marks *</label>
                                    <input type="number" name="total_marks" id="total_marks" required min="1" 
                                           value="<?php echo $assessment['total_marks']; ?>" placeholder="100">
                                </div>
                                <div class="form-group">
                                    <label for="pass_marks">Pass Marks *</label>
                                    <input type="number" name="pass_marks" id="pass_marks" required min="0" 
                                           value="<?php echo $assessment['pass_marks']; ?>" placeholder="60">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="start_time">Start Time *</label>
                                    <input type="datetime-local" name="start_time" id="start_time" required
                                           value="<?php echo date('Y-m-d\TH:i', strtotime($assessment['start_time'])); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="end_time">End Time *</label>
                                    <input type="datetime-local" name="end_time" id="end_time" required
                                           value="<?php echo date('Y-m-d\TH:i', strtotime($assessment['end_time'])); ?>">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="duration_minutes">Duration (Minutes)</label>
                                    <input type="number" name="duration_minutes" id="duration_minutes" min="0" 
                                           value="<?php echo $assessment['duration_minutes']; ?>" placeholder="60">
                                    <small style="color: var(--text-muted);">Leave 0 for no time limit</small>
                                </div>
                                <div class="form-group">
                                    <label for="attempts_allowed">Attempts Allowed</label>
                                    <input type="number" name="attempts_allowed" id="attempts_allowed" min="1" 
                                           value="<?php echo $assessment['attempts_allowed']; ?>" placeholder="1">
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="instructions">Instructions</label>
                                <textarea name="instructions" id="instructions" 
                                          placeholder="Enter instructions for students"><?php echo htmlspecialchars($assessment['instructions']); ?></textarea>
                            </div>
                            
                            <div class="checkbox-group">
                                <input type="checkbox" name="randomize_questions" id="randomize_questions" 
                                       <?php echo $assessment['randomize_questions'] ? 'checked' : ''; ?>>
                                <label for="randomize_questions">Randomize question order</label>
                            </div>
                            
                            <div class="form-actions">
                                <button type="submit" name="update_assessment" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Update Assessment
                                </button>
                                
                                <a href="assessments.php" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancel
                                </a>
                                
                                <a href="manage-questions.php?assessment_id=<?php echo $assessment['id']; ?>" class="btn btn-secondary">
                                    <i class="fas fa-question-circle"></i> Manage Questions
                                </a>
                            </div>
                        </form>
                    </div>
                <?php else: ?>
                    <div class="info-box">
                        <i class="fas fa-info-circle"></i>
                        Assessment not found or you don't have permission to edit it.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
    <script>
        // Update pass marks when total marks change
        document.getElementById('total_marks').addEventListener('input', function() {
            const totalMarks = parseInt(this.value);
            if (totalMarks > 0) {
                const currentPassMarks = parseInt(document.getElementById('pass_marks').value);
                if (currentPassMarks === 0 || currentPassMarks > totalMarks) {
                    const passMarks = Math.floor(totalMarks * 0.6); // 60% pass rate
                    document.getElementById('pass_marks').value = passMarks;
                }
            }
        });
        
        // Validate end time is after start time
        document.getElementById('end_time').addEventListener('change', function() {
            const startTime = new Date(document.getElementById('start_time').value);
            const endTime = new Date(this.value);
            
            if (endTime <= startTime) {
                alert('End time must be after start time');
                this.value = '';
            }
        });
        
        // Validate pass marks don't exceed total marks
        document.getElementById('pass_marks').addEventListener('input', function() {
            const totalMarks = parseInt(document.getElementById('total_marks').value);
            const passMarks = parseInt(this.value);
            
            if (passMarks > totalMarks) {
                alert('Pass marks cannot exceed total marks');
                this.value = totalMarks;
            }
        });
    </script>
</body>
</html>
