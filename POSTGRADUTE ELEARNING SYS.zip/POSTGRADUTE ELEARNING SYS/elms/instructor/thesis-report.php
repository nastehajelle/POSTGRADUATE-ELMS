<?php
session_start();
include_once '../config/init.php';

// Define is_instructor() if not already defined
if (!function_exists('is_instructor')) {
    function is_instructor() {
        return isset($_SESSION['role']) && $_SESSION['role'] === 'instructor';
    }
}

// Check if user is logged in and is an instructor
if (!is_logged_in() || !is_instructor()) {
    header("Location: ../auth/login.php");
    exit();
}

$instructor_id = $_SESSION['user_id'];
$message = '';
$error = '';

// Get filter parameters
$status_filter = $_GET['status'] ?? '';
$program_filter = $_GET['program'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';

// Get instructor's department info
try {
    $instructor_query = "SELECT i.*, u.full_name, u.email 
                         FROM instructors i
                         INNER JOIN users u ON i.user_id = u.id
                         WHERE i.user_id = ?";
    $instructor_stmt = $conn->prepare($instructor_query);
    $instructor_stmt->execute([$instructor_id]);
    $instructor_info = $instructor_stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}

// Build query with filters
$where_conditions = ["t.supervisor_id = ?"];
$params = [$instructor_id];

if ($status_filter) {
    $where_conditions[] = "t.status = ?";
    $params[] = $status_filter;
}

if ($program_filter) {
    $where_conditions[] = "t.program_id = ?";
    $params[] = $program_filter;
}

if ($date_from) {
    $where_conditions[] = "t.submission_date >= ?";
    $params[] = $date_from;
}

if ($date_to) {
    $where_conditions[] = "t.submission_date <= ?";
    $params[] = $date_to;
}

$where_clause = implode(' AND ', $where_conditions);

// Get thesis data with filters
try {
    $thesis_query = "SELECT t.*, u.full_name as student_name, u.email as student_email,
                     p.name as program_name, d.name as department_name,
                     tr.status as review_status, tr.review_date, tr.overall_score,
                     tr.content_score, tr.methodology_score, tr.presentation_score
                     FROM thesis t
                     INNER JOIN users u ON t.student_id = u.id
                     INNER JOIN programs p ON t.program_id = p.id
                     INNER JOIN departments d ON t.department_id = d.id
                     LEFT JOIN thesis_reviews tr ON t.id = tr.thesis_id AND tr.reviewer_id = ?
                     WHERE $where_clause
                     ORDER BY t.submission_date DESC";
    
    $thesis_stmt = $conn->prepare($thesis_query);
    $thesis_stmt->execute(array_merge([$instructor_id], $params));
    $thesis_data = $thesis_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get programs for filter dropdown
    $programs_query = "SELECT DISTINCT p.id, p.name FROM programs p
                       INNER JOIN thesis t ON p.id = t.program_id
                       WHERE t.supervisor_id = ?
                       ORDER BY p.name";
    $programs_stmt = $conn->prepare($programs_query);
    $programs_stmt->execute([$instructor_id]);
    $programs = $programs_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Calculate statistics
    $total_thesis = count($thesis_data);
    $approved_count = count(array_filter($thesis_data, fn($t) => $t['status'] === 'approved'));
    $rejected_count = count(array_filter($thesis_data, fn($t) => $t['status'] === 'rejected'));
    $pending_count = count(array_filter($thesis_data, fn($t) => $t['status'] === 'pending'));
    $revision_count = count(array_filter($thesis_data, fn($t) => $t['status'] === 'revision_required'));

    // Calculate average scores
    $scored_thesis = array_filter($thesis_data, fn($t) => $t['overall_score'] !== null);
    $avg_overall = $scored_thesis ? array_sum(array_column($scored_thesis, 'overall_score')) / count($scored_thesis) : 0;
    $avg_content = $scored_thesis ? array_sum(array_column($scored_thesis, 'content_score')) / count($scored_thesis) : 0;
    $avg_methodology = $scored_thesis ? array_sum(array_column($scored_thesis, 'methodology_score')) / count($scored_thesis) : 0;
    $avg_presentation = $scored_thesis ? array_sum(array_column($scored_thesis, 'presentation_score')) / count($scored_thesis) : 0;

} catch (PDOException $e) {
    $error = "Error fetching thesis data: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thesis Reports - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link rel="stylesheet" href="../assets/css/thesis.css">
    <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/instructor-sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <div class="admin-header-content">
                    <div class="header-title-section">
                        <h1><i class="fas fa-chart-bar"></i> Thesis Reports</h1>
                        <p class="header-subtitle">Generate detailed reports on thesis submissions and reviews</p>
                    </div>
                    <div class="header-actions">
                        <a href="thesis-review.php" class="btn btn-outline-primary">
                            <i class="fas fa-arrow-left"></i> Back to Review
                        </a>
                        <button onclick="window.print()" class="btn btn-primary">
                            <i class="fas fa-print"></i> Print Report
                        </button>
                    </div>
                </div>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <!-- Filters -->
            <div class="info-card">
                <div class="info-header">
                    <h3><i class="fas fa-filter"></i> Report Filters</h3>
                </div>
                <form method="GET" class="filter-form">
                    <div class="filter-grid">
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select id="status" name="status">
                                <option value="">All Statuses</option>
                                <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="under_review" <?php echo $status_filter === 'under_review' ? 'selected' : ''; ?>>Under Review</option>
                                <option value="approved" <?php echo $status_filter === 'approved' ? 'selected' : ''; ?>>Approved</option>
                                <option value="rejected" <?php echo $status_filter === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                                <option value="revision_required" <?php echo $status_filter === 'revision_required' ? 'selected' : ''; ?>>Revision Required</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="program">Program</label>
                            <select id="program" name="program">
                                <option value="">All Programs</option>
                                <?php foreach ($programs as $program): ?>
                                    <option value="<?php echo $program['id']; ?>" <?php echo $program_filter == $program['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($program['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="date_from">From Date</label>
                            <input type="date" id="date_from" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>">
                        </div>
                        <div class="form-group">
                            <label for="date_to">To Date</label>
                            <input type="date" id="date_to" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>">
                        </div>
                    </div>
                    <div class="filter-actions">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-search"></i> Apply Filters
                        </button>
                        <a href="thesis-report.php" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Clear Filters
                        </a>
                    </div>
                </form>
            </div>

            <!-- Statistics Overview -->
            <div class="stats-overview">
                <div class="stat-card">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo $total_thesis; ?></div>
                        <div class="stat-label">Total Thesis</div>
                        <div class="stat-description">Supervised by you</div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo $approved_count; ?></div>
                        <div class="stat-label">Approved</div>
                        <div class="stat-description"><?php echo $total_thesis > 0 ? round(($approved_count / $total_thesis) * 100, 1) : 0; ?>% of total</div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
                        <i class="fas fa-times-circle"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo $rejected_count; ?></div>
                        <div class="stat-label">Rejected</div>
                        <div class="stat-description"><?php echo $total_thesis > 0 ? round(($rejected_count / $total_thesis) * 100, 1) : 0; ?>% of total</div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);">
                        <i class="fas fa-star"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo number_format($avg_overall, 1); ?></div>
                        <div class="stat-label">Avg Score</div>
                        <div class="stat-description">Out of 5.0</div>
                    </div>
                </div>
            </div>

            <!-- Detailed Scores -->
            <?php if (count($scored_thesis) > 0): ?>
            <div class="info-card">
                <div class="info-header">
                    <h3><i class="fas fa-chart-line"></i> Average Scores Breakdown</h3>
                </div>
                <div class="scores-grid">
                    <div class="score-item">
                        <label>Overall Score</label>
                        <span class="score"><?php echo number_format($avg_overall, 2); ?>/5.0</span>
                    </div>
                    <div class="score-item">
                        <label>Content Score</label>
                        <span class="score"><?php echo number_format($avg_content, 2); ?>/5.0</span>
                    </div>
                    <div class="score-item">
                        <label>Methodology Score</label>
                        <span class="score"><?php echo number_format($avg_methodology, 2); ?>/5.0</span>
                    </div>
                    <div class="score-item">
                        <label>Presentation Score</label>
                        <span class="score"><?php echo number_format($avg_presentation, 2); ?>/5.0</span>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Thesis List -->
            <div class="data-table-container">
                <div class="table-header">
                    <h3>Thesis Details</h3>
                    <p class="table-description">Detailed list of thesis submissions matching your filters</p>
                </div>
                <div class="table-content">
                    <?php if (!empty($thesis_data)): ?>
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Student</th>
                                    <th>Title</th>
                                    <th>Program</th>
                                    <th>Submission Date</th>
                                    <th>Status</th>
                                    <th>Overall Score</th>
                                    <th>Review Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($thesis_data as $thesis): ?>
                                <tr>
                                    <td>
                                        <div class="student-info">
                                            <div class="student-name"><?php echo htmlspecialchars($thesis['student_name']); ?></div>
                                            <div class="student-email"><?php echo htmlspecialchars($thesis['student_email']); ?></div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="thesis-title"><?php echo htmlspecialchars($thesis['title']); ?></div>
                                    </td>
                                    <td>
                                        <div class="program-info">
                                            <div><?php echo htmlspecialchars($thesis['program_name']); ?></div>
                                            <small><?php echo htmlspecialchars($thesis['department_name']); ?></small>
                                        </div>
                                    </td>
                                    <td><?php echo date('M d, Y', strtotime($thesis['submission_date'])); ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo $thesis['status']; ?>">
                                            <?php echo ucwords(str_replace('_', ' ', $thesis['status'])); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($thesis['overall_score']): ?>
                                            <span class="score"><?php echo number_format($thesis['overall_score'], 1); ?>/5.0</span>
                                        <?php else: ?>
                                            <span class="text-muted">Not scored</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($thesis['review_date']): ?>
                                            <?php echo date('M d, Y', strtotime($thesis['review_date'])); ?>
                                        <?php else: ?>
                                            <span class="text-muted">Not reviewed</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="no-data">
                            <i class="fas fa-chart-bar"></i>
                            <h3>No Data Found</h3>
                            <p>No thesis submissions match your current filters.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="../assets/js/theme.js"></script>
    <style>
        .filter-form {
            margin: 0;
        }
        
        .filter-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .filter-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
        }
        
        @media print {
            .admin-sidebar,
            .header-actions,
            .filter-form,
            .no-print {
                display: none !important;
            }
            
            .admin-content {
                margin-left: 0 !important;
                padding: 20px !important;
            }
        }
        
        @media (max-width: 768px) {
            .filter-grid {
                grid-template-columns: 1fr;
            }
            
            .filter-actions {
                justify-content: stretch;
            }
            
            .filter-actions .btn {
                flex: 1;
            }
        }
    </style>
</body>
</html>
