<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is instructor
if (!is_logged_in() || !is_instructor()) {
    header("Location: ../auth/login.php");
    exit();
}

$instructor_id = $_SESSION['user_id'];
$message = '';
$messageType = '';

// Check for messages from redirects
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    $messageType = $_SESSION['message_type'];
    unset($_SESSION['message'], $_SESSION['message_type']);
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'schedule_class') {
            $course_id = (int)$_POST['course_id'];
            $title = sanitize_input($_POST['title']);
            $description = sanitize_input($_POST['description']);
            $scheduled_time = sanitize_input($_POST['scheduled_time']);
            $duration = (int)$_POST['duration'];
            $platform = sanitize_input($_POST['platform']);
            $meeting_url = sanitize_input($_POST['meeting_url']);
            $meeting_id = sanitize_input($_POST['meeting_id']);
            $passcode = sanitize_input($_POST['passcode']);
            
            try {
                // Verify course belongs to instructor
                $verify_query = "SELECT id FROM course WHERE id = ? AND instructor_id = ?";
                $verify_stmt = $conn->prepare($verify_query);
                $verify_stmt->execute([$course_id, $instructor_id]);
                
                if ($verify_stmt->rowCount() === 0) {
                    throw new Exception("Unauthorized access to course");
                }
                
                $stmt = $conn->prepare("INSERT INTO live_classes (course_id, instructor_id, title, description, scheduled_time, duration, platform, meeting_url, meeting_id, passcode, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'scheduled', NOW())");
                
                if ($stmt->execute([$course_id, $instructor_id, $title, $description, $scheduled_time, $duration, $platform, $meeting_url, $meeting_id, $passcode])) {
                    $_SESSION['message'] = "Live class scheduled successfully!";
                    $_SESSION['message_type'] = "success";
                } else {
                    $_SESSION['message'] = "Error scheduling live class.";
                    $_SESSION['message_type'] = "error";
                }
            } catch (Exception $e) {
                $_SESSION['message'] = "Error: " . $e->getMessage();
                $_SESSION['message_type'] = "error";
            }
            
            header('Location: live-class.php');
            exit();
        }
        
        if ($_POST['action'] === 'update_class_status') {
            $class_id = (int)$_POST['class_id'];
            $status = sanitize_input($_POST['status']);
            
            try {
                $stmt = $conn->prepare("UPDATE live_classes SET status = ?, updated_at = NOW() WHERE id = ? AND instructor_id = ?");
                
                if ($stmt->execute([$status, $class_id, $instructor_id])) {
                    $_SESSION['message'] = "Class status updated successfully!";
                    $_SESSION['message_type'] = "success";
                } else {
                    $_SESSION['message'] = "Error updating class status.";
                    $_SESSION['message_type'] = "error";
                }
            } catch (PDOException $e) {
                $_SESSION['message'] = "Database error: " . $e->getMessage();
                $_SESSION['message_type'] = "error";
            }
            
            header('Location: live-classes.php');
            exit();
        }
    }
}

// Create live_classes table if it doesn't exist
try {
    $create_table_query = "CREATE TABLE IF NOT EXISTS live_classes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        course_id INT NOT NULL,
        instructor_id INT NOT NULL,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        scheduled_time DATETIME NOT NULL,
        duration INT NOT NULL DEFAULT 60,
        platform ENUM('zoom', 'teams', 'meet', 'bbb', 'other') NOT NULL DEFAULT 'zoom',
        meeting_url TEXT,
        meeting_id VARCHAR(255),
        passcode VARCHAR(255),
        status ENUM('scheduled', 'live', 'completed', 'cancelled') NOT NULL DEFAULT 'scheduled',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES course(id) ON DELETE CASCADE,
        FOREIGN KEY (instructor_id) REFERENCES users(id) ON DELETE CASCADE
    )";
    $conn->exec($create_table_query);
} catch (PDOException $e) {
    // Table might already exist, continue
}

// Get instructor's courses
try {
    $courses_query = "SELECT c.id, c.name, c.code, d.name as department_name
                     FROM course c 
                     LEFT JOIN departments d ON c.department_id = d.id 
                     WHERE c.instructor_id = ? AND c.status = 'active'
                     ORDER BY c.name";
    $courses_stmt = $conn->prepare($courses_query);
    $courses_stmt->execute([$instructor_id]);
    $instructor_courses = $courses_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $instructor_courses = [];
}

$view = isset($_GET['view']) ? $_GET['view'] : 'upcoming';
$classes = [];

try {
    if ($view === 'upcoming') {
        $classes_query = "SELECT lc.*, c.name as course_name, c.code as course_code
                         FROM live_classes lc
                         JOIN course c ON lc.course_id = c.id
                         WHERE lc.instructor_id = ?
                         AND lc.scheduled_time > NOW()
                         AND lc.status != 'completed'
                         ORDER BY lc.scheduled_time ASC";
    } else {
        $classes_query = "SELECT lc.*, c.name as course_name, c.code as course_code
                         FROM live_classes lc
                         JOIN course c ON lc.course_id = c.id
                         WHERE lc.instructor_id = ?
                         AND (lc.scheduled_time <= NOW() OR lc.status = 'completed')
                         ORDER BY lc.scheduled_time DESC";
    }
    
    $classes_stmt = $conn->prepare($classes_query);
    $classes_stmt->execute([$instructor_id]);
    $classes = $classes_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching classes: " . $e->getMessage());
    $message = "Error loading classes.";
    $messageType = "danger";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live Classes - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <?php echo FONT_AWESOME_CSS; ?>
    <style>
        /* Updated styles to match assessments page design */
        .view-tabs {
            display: flex;
            background: var(--card-bg);
            border-radius: 8px;
            padding: 4px;
            margin-bottom: 20px;
            box-shadow: var(--shadow);
        }

        .view-tab {
            flex: 1;
            padding: 12px 20px;
            text-align: center;
            border-radius: 6px;
            text-decoration: none;
            transition: all 0.2s;
            font-weight: 500;
            color: var(--text-muted);
        }

        .view-tab.active {
            background: var(--primary-color);
            color: white;
        }

        .view-tab:hover {
            text-decoration: none;
            background: var(--hover-bg);
        }

        .view-tab.active:hover {
            background: var(--primary-dark);
        }

        .classes-grid {
            display: grid;
            gap: 20px;
            margin-top: 20px;
        }

        .class-card {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 20px;
            box-shadow: var(--shadow);
            border-left: 4px solid;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .class-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }

        .class-card.scheduled { border-left-color: #3b82f6; }
        .class-card.live { border-left-color: #10b981; }
        .class-card.completed { border-left-color: #8b5cf6; }
        .class-card.cancelled { border-left-color: #ef4444; }

        .class-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }

        .class-title {
            font-size: 1.3rem;
            font-weight: 600;
            color: var(--text-color);
            margin: 0 0 8px 0;
        }

        .class-course {
            color: var(--text-muted);
            font-size: 0.9rem;
        }

        .class-status {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
            text-transform: uppercase;
        }

        .status-badge.scheduled { background: #dbeafe; color: #1d4ed8; }
        .status-badge.live { background: #d1fae5; color: #047857; animation: pulse 2s infinite; }
        .status-badge.completed { background: #f3e8ff; color: #7c3aed; }
        .status-badge.cancelled { background: #fee2e2; color: #b91c1c; }

        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.7; }
            100% { opacity: 1; }
        }

        .platform-icon {
            width: 24px;
            height: 24px;
            border-radius: 4px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
            font-weight: bold;
            color: white;
        }

        .platform-zoom { background: #2d8cff; }
        .platform-teams { background: #6264a7; }
        .platform-meet { background: #34a853; }
        .platform-bbb { background: #ff6b35; }
        .platform-other { background: #666; }

        .class-meta {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin: 15px 0;
            padding: 15px;
            background: var(--bg-light);
            border-radius: 8px;
        }

        .meta-item {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }

        .meta-label {
            font-size: 0.8rem;
            color: var(--text-muted);
            font-weight: 500;
        }

        .meta-value {
            font-size: 0.9rem;
            color: var(--text-color);
            font-weight: 600;
        }

        .class-actions {
            display: flex;
            gap: 10px;
            margin-top: 20px;
            flex-wrap: wrap;
        }

        .btn-action {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-primary {
            background: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            color: white;
            text-decoration: none;
        }

        .btn-secondary {
            background: var(--bg-secondary);
            color: var(--text-color);
            border: 1px solid var(--border-color);
        }

        .btn-secondary:hover {
            background: var(--hover-bg);
            text-decoration: none;
        }

        .btn-success {
            background: #10b981;
            color: white;
        }

        .btn-success:hover {
            background: #059669;
            color: white;
            text-decoration: none;
        }

        .btn-warning {
            background: #f59e0b;
            color: white;
        }

        .btn-warning:hover {
            background: #d97706;
            color: white;
            text-decoration: none;
        }

        .btn-danger {
            background: #ef4444;
            color: white;
        }

        .btn-danger:hover {
            background: #dc2626;
            color: white;
            text-decoration: none;
        }

        .create-class-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: var(--primary-color);
            color: white;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            transition: all 0.2s;
            z-index: 1000;
        }

        .create-class-btn:hover {
            background: var(--primary-dark);
            transform: scale(1.1);
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }

        .modal-content {
            background-color: var(--card-bg);
            margin: 5% auto;
            padding: 30px;
            border-radius: 12px;
            width: 90%;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border-color);
        }

        .close {
            color: var(--text-muted);
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.2s;
        }

        .close:hover {
            color: var(--text-color);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--text-color);
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            font-size: 0.9rem;
            background: var(--input-bg);
            color: var(--text-color);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-muted);
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.3;
        }

        @media (max-width: 768px) {
            .class-meta {
                grid-template-columns: 1fr;
            }
            
            .class-actions {
                flex-direction: column;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/instructor-sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>Live Classes</h1>
                <div class="admin-header-right">
                    <span class="classes-count"><?php echo count($classes); ?> classes</span>
                </div>
            </div>
            
            <?php if (!empty($message)): ?>
                <div class="message <?php echo $messageType; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <!-- Added view tabs matching assessments page -->
            <div class="view-tabs">
                <a href="?view=upcoming" class="view-tab <?php echo $view === 'upcoming' ? 'active' : ''; ?>">
                    <i class="fas fa-clock"></i> Upcoming Classes
                </a>
                <a href="?view=past" class="view-tab <?php echo $view === 'past' ? 'active' : ''; ?>">
                    <i class="fas fa-history"></i> Past Classes
                </a>
            </div>

            <!-- Classes Grid with card layout matching assessments -->
            <div class="classes-grid">
                <?php if (!empty($classes)): ?>
                    <?php foreach ($classes as $class): ?>
                        <div class="class-card <?php echo $class['status']; ?>">
                            <div class="class-header">
                                <div>
                                    <h3 class="class-title"><?php echo htmlspecialchars($class['title']); ?></h3>
                                    <p class="class-course"><?php echo $class['course_code'] . ' - ' . $class['course_name']; ?></p>
                                </div>
                                <div class="class-status">
                                    <span class="platform-icon platform-<?php echo $class['platform']; ?>">
                                        <?php echo strtoupper(substr($class['platform'], 0, 1)); ?>
                                    </span>
                                    <span class="status-badge <?php echo $class['status']; ?>">
                                        <?php echo ucfirst($class['status']); ?>
                                    </span>
                                </div>
                            </div>
                            
                            <?php if (!empty($class['description'])): ?>
                                <p style="color: var(--text-muted); margin: 10px 0;">
                                    <?php echo nl2br(htmlspecialchars($class['description'])); ?>
                                </p>
                            <?php endif; ?>
                            
                            <div class="class-meta">
                                <div class="meta-item">
                                    <span class="meta-label">Date</span>
                                    <span class="meta-value"><?php echo date('M j, Y', strtotime($class['scheduled_time'])); ?></span>
                                </div>
                                <div class="meta-item">
                                    <span class="meta-label">Time</span>
                                    <span class="meta-value"><?php echo date('g:i A', strtotime($class['scheduled_time'])); ?></span>
                                </div>
                                <div class="meta-item">
                                    <span class="meta-label">Duration</span>
                                    <span class="meta-value"><?php echo $class['duration']; ?> min</span>
                                </div>
                                <div class="meta-item">
                                    <span class="meta-label">Platform</span>
                                    <span class="meta-value"><?php echo ucfirst($class['platform']); ?></span>
                                </div>
                                <?php if (!empty($class['meeting_id'])): ?>
                                <div class="meta-item">
                                    <span class="meta-label">Meeting ID</span>
                                    <span class="meta-value"><?php echo htmlspecialchars($class['meeting_id']); ?></span>
                                </div>
                                <?php endif; ?>
                                <?php if (!empty($class['passcode'])): ?>
                                <div class="meta-item">
                                    <span class="meta-label">Passcode</span>
                                    <span class="meta-value"><?php echo htmlspecialchars($class['passcode']); ?></span>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="class-actions">
                                <?php if (!empty($class['meeting_url']) && $view === 'upcoming'): ?>
                                <a href="<?php echo $class['meeting_url']; ?>" target="_blank" class="btn-action btn-success">
                                    <i class="fas fa-video"></i> Join Class
                                </a>
                                <?php endif; ?>
                                
                                <?php if ($view === 'upcoming' && strtotime($class['scheduled_time']) <= time() + 900): // 15 minutes before ?>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="update_class_status">
                                    <input type="hidden" name="class_id" value="<?php echo $class['id']; ?>">
                                    <input type="hidden" name="status" value="live">
                                    <button type="submit" class="btn-action btn-primary">
                                        <i class="fas fa-play"></i> Start Class
                                    </button>
                                </form>
                                <?php endif; ?>
                                
                                <?php if ($view === 'upcoming'): ?>
                                <button class="btn-action btn-secondary edit-class-btn" data-id="<?php echo $class['id']; ?>">
                                    <i class="fas fa-edit"></i> Edit
                                </button>
                                
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="update_class_status">
                                    <input type="hidden" name="class_id" value="<?php echo $class['id']; ?>">
                                    <input type="hidden" name="status" value="cancelled">
                                    <button type="submit" class="btn-action btn-danger" onclick="return confirm('Are you sure you want to cancel this class?')">
                                        <i class="fas fa-times"></i> Cancel
                                    </button>
                                </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-video"></i>
                        <h3>No <?php echo $view === 'upcoming' ? 'Upcoming' : 'Past'; ?> Classes</h3>
                        <p>
                            <?php if ($view === 'upcoming'): ?>
                                You don't have any upcoming classes scheduled. Schedule a new class to get started.
                            <?php else: ?>
                                You don't have any past classes yet.
                            <?php endif; ?>
                        </p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Create Class Button (only for upcoming view) matching assessments -->
            <?php if ($view === 'upcoming'): ?>
            <button class="create-class-btn" onclick="openModal('scheduleModal')" title="Schedule New Class">
                <i class="fas fa-plus"></i>
            </button>
            <?php endif; ?>
        </div>
    </div>

    <!-- Updated modal to match assessments styling -->
    <div id="scheduleModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Schedule New Class</h2>
                <span class="close" onclick="closeModal('scheduleModal')">&times;</span>
            </div>
            
            <form method="POST">
                <input type="hidden" name="action" value="schedule_class">
                
                <div class="form-group">
                    <label for="title">Class Title *</label>
                    <input type="text" name="title" id="title" required placeholder="Enter class title">
                </div>
                
                <div class="form-group">
                    <label for="course_id">Course *</label>
                    <select name="course_id" id="course_id" required>
                        <option value="">Select Course</option>
                        <?php foreach ($instructor_courses as $course): ?>
                            <option value="<?php echo $course['id']; ?>">
                                <?php echo htmlspecialchars($course['code'] . ' - ' . $course['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea name="description" id="description" placeholder="Enter class description"></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="scheduled_time">Date & Time *</label>
                        <input type="datetime-local" name="scheduled_time" id="scheduled_time" required>
                    </div>
                    <div class="form-group">
                        <label for="duration">Duration (minutes) *</label>
                        <input type="number" name="duration" id="duration" value="60" min="15" max="480" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="platform">Platform *</label>
                        <select name="platform" id="platform" required>
                            <option value="zoom">Zoom</option>
                            <option value="teams">Microsoft Teams</option>
                            <option value="meet">Google Meet</option>
                            <option value="bbb">BigBlueButton</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="meeting_url">Meeting URL *</label>
                        <input type="url" name="meeting_url" id="meeting_url" placeholder="https://..." required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="meeting_id">Meeting ID</label>
                        <input type="text" name="meeting_id" id="meeting_id" placeholder="Optional">
                    </div>
                    <div class="form-group">
                        <label for="passcode">Passcode</label>
                        <input type="text" name="passcode" id="passcode" placeholder="Optional">
                    </div>
                </div>
                
                <div class="form-group" style="margin-top: 30px;">
                    <button type="submit" class="btn btn-primary" style="width: 100%; padding: 12px;">
                        <i class="fas fa-plus"></i> Schedule Class
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
    <script>
        // Modal functionality
        function openModal(modalId) {
            document.getElementById(modalId).style.display = 'block';
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
        
        // Set default scheduled time to current time + 1 hour
        document.addEventListener('DOMContentLoaded', function() {
            const now = new Date();
            now.setHours(now.getHours() + 1);
            const scheduledTime = now.toISOString().slice(0, 16);
            document.getElementById('scheduled_time').value = scheduledTime;
            
            // Set minimum datetime to current time
            const minTime = new Date();
            minTime.setMinutes(minTime.getMinutes() - minTime.getTimezoneOffset());
            document.getElementById('scheduled_time').min = minTime.toISOString().slice(0, 16);
        });
        
        // Validate scheduled time is in the future
        document.getElementById('scheduled_time').addEventListener('change', function() {
            const scheduledTime = new Date(this.value);
            const now = new Date();
            
            if (scheduledTime <= now) {
                alert('Please select a future date and time for the class.');
                this.value = '';
            }
        });
        
        // Auto-refresh page every 30 seconds to update live status
        setInterval(function() {
            const liveClasses = document.querySelectorAll('.status-live, .status-scheduled');
            if (liveClasses.length > 0) {
                location.reload();
            }
        }, 30000);
    </script>
</body>
</html>
