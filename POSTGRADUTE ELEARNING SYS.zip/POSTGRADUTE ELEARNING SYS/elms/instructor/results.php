<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is instructor
if (!is_logged_in() || !is_instructor()) {
    header("Location: ../auth/login.php");
    exit();
}

$instructor_id = $_SESSION['user_id'];
$message = '';
$messageType = '';

// Check for messages from redirects
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    $messageType = $_SESSION['message_type'];
    unset($_SESSION['message'], $_SESSION['message_type']);
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'save_results') {
        $assessment_id = (int)$_POST['assessment_id'];
        $results = $_POST['results'] ?? [];
        
        try {
            // Verify assessment belongs to instructor
            $verify_query = "SELECT a.id FROM assessments a
                           JOIN course c ON (a.program_id = c.program_id OR a.department_id = c.department_id)
                           WHERE a.id = ? AND c.instructor_id = ? AND a.created_by = ?";
            $verify_stmt = $conn->prepare($verify_query);
            $verify_stmt->execute([$assessment_id, $instructor_id, $instructor_id]);
            
            if ($verify_stmt->rowCount() === 0) {
                throw new Exception("Unauthorized access to assessment");
            }
            
            // Begin transaction
            $conn->beginTransaction();
            
            // Delete existing results for this assessment
            $delete_query = "DELETE FROM assessment_results WHERE assessment_id = ?";
            $delete_stmt = $conn->prepare($delete_query);
            $delete_stmt->execute([$assessment_id]);
            
            // Insert new results
            $insert_query = "INSERT INTO assessment_results (assessment_id, user_id, marks_obtained, feedback, graded_by, graded_at) VALUES (?, ?, ?, ?, ?, NOW())";
            $insert_stmt = $conn->prepare($insert_query);
            
            foreach ($results as $student_id => $result) {
                if (!empty($result['marks']) || !empty($result['feedback'])) {
                    $marks = !empty($result['marks']) ? (float)$result['marks'] : null;
                    $feedback = !empty($result['feedback']) ? sanitize_input($result['feedback']) : null;
                    
                    $insert_stmt->execute([$assessment_id, $student_id, $marks, $feedback, $instructor_id]);
                }
            }
            
            $conn->commit();
            $_SESSION['message'] = "Results saved successfully!";
            $_SESSION['message_type'] = "success";
            
        } catch (Exception $e) {
            $conn->rollBack();
            $_SESSION['message'] = "Error saving results: " . $e->getMessage();
            $_SESSION['message_type'] = "error";
        }
        
        header("Location: results.php?assessment_id=" . $assessment_id);
        exit();
    }
}

// Get instructor's assessments
try {
    $assessments_query = "SELECT DISTINCT a.id, a.title, a.type, a.total_marks, a.end_time, c.name as course_name, c.code as course_code
                         FROM assessments a
                         JOIN course c ON (a.program_id = c.program_id OR a.department_id = c.department_id)
                         WHERE a.created_by = ? AND c.instructor_id = ?
                         ORDER BY a.created_at DESC";
    $assessments_stmt = $conn->prepare($assessments_query);
    $assessments_stmt->execute([$instructor_id, $instructor_id]);
    $assessments = $assessments_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $assessments = [];
}

// Get selected assessment details and results
$selected_assessment_id = isset($_GET['assessment_id']) ? (int)$_GET['assessment_id'] : null;
$assessment_details = null;
$students_results = [];

if ($selected_assessment_id) {
    try {
        // Get assessment details
        $assessment_query = "SELECT a.*, c.name as course_name, c.code as course_code
                           FROM assessments a
                           JOIN course c ON (a.program_id = c.program_id OR a.department_id = c.department_id)
                           WHERE a.id = ? AND a.created_by = ? AND c.instructor_id = ?
                           LIMIT 1";
        $assessment_stmt = $conn->prepare($assessment_query);
        $assessment_stmt->execute([$selected_assessment_id, $instructor_id, $instructor_id]);
        $assessment_details = $assessment_stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($assessment_details) {
            // Get students and their results
            $students_query = "SELECT DISTINCT u.id, u.full_name, u.email, e.student_id,
                              ar.marks_obtained, ar.feedback, ar.graded_at
                              FROM users u
                              JOIN enrollment e ON u.id = e.user_id
                              JOIN course c ON (e.course_id = c.id OR e.batch_id = c.batch_id)
                              LEFT JOIN assessment_results ar ON (u.id = ar.user_id AND ar.assessment_id = ?)
                              WHERE c.instructor_id = ? AND u.role = 'student'
                              AND (c.program_id = ? OR c.department_id = ?)
                              ORDER BY u.full_name";
            $students_stmt = $conn->prepare($students_query);
            $students_stmt->execute([
                $selected_assessment_id, 
                $instructor_id, 
                $assessment_details['program_id'], 
                $assessment_details['department_id']
            ]);
            $students_results = $students_stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        
    } catch (PDOException $e) {
        $assessment_details = null;
        $students_results = [];
    }
}

// Calculate statistics
$total_students = count($students_results);
$graded_students = count(array_filter($students_results, function($student) {
    return !is_null($student['marks_obtained']);
}));
$average_marks = 0;
$highest_marks = 0;
$lowest_marks = 0;

if ($graded_students > 0) {
    $marks = array_filter(array_column($students_results, 'marks_obtained'), function($mark) {
        return !is_null($mark);
    });
    
    if (count($marks) > 0) {
        $average_marks = round(array_sum($marks) / count($marks), 2);
        $highest_marks = max($marks);
        $lowest_marks = min($marks);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Results - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/assessments.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/instructor-sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>Results Management</h1>
                <div class="admin-header-right">
                    <?php if ($assessment_details): ?>
                    <button class="btn btn-success" onclick="exportResults()">
                        <i class="fas fa-download"></i>
                        Export Results
                    </button>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Alert Messages -->
            <?php if (!empty($message)): ?>
                <div class="alert alert-<?php echo $messageType === 'success' ? 'success' : 'error'; ?>">
                    <i class="fas fa-<?php echo $messageType === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                    <span><?php echo htmlspecialchars($message); ?></span>
                </div>
            <?php endif; ?>
            
            <!-- Assessment Selection -->
            <div class="results-controls">
                <div class="control-group">
                    <label for="assessmentSelect">Select Assessment:</label>
                    <select id="assessmentSelect" onchange="selectAssessment()">
                        <option value="">Choose an assessment...</option>
                        <?php foreach ($assessments as $assessment): ?>
                            <option value="<?php echo $assessment['id']; ?>" <?php echo $selected_assessment_id == $assessment['id'] ? 'selected' : ''; ?>>
                                <?php echo $assessment['course_code'] . ' - ' . $assessment['title'] . ' (' . ucfirst($assessment['type']) . ')'; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            
            <?php if ($assessment_details): ?>
            <!-- Assessment Info -->
            <div class="assessment-info">
                <div class="info-card">
                    <h3><?php echo htmlspecialchars($assessment_details['title']); ?></h3>
                    <div class="info-details">
                        <span class="info-item">
                            <i class="fas fa-book"></i>
                            <?php echo $assessment_details['course_code'] . ' - ' . $assessment_details['course_name']; ?>
                        </span>
                        <span class="info-item">
                            <i class="fas fa-clipboard-list"></i>
                            <?php echo ucfirst($assessment_details['type']); ?>
                        </span>
                        <span class="info-item">
                            <i class="fas fa-star"></i>
                            <?php echo $assessment_details['total_marks']; ?> marks
                        </span>
                        <span class="info-item">
                            <i class="fas fa-calendar"></i>
                            Due: <?php echo date('M d, Y H:i', strtotime($assessment_details['end_time'])); ?>
                        </span>
                    </div>
                </div>
            </div>
            
            <!-- Results Statistics -->
            <div class="results-stats">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-details">
                        <h3>Total Students</h3>
                        <p class="stat-number"><?php echo $total_students; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon graded">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-details">
                        <h3>Graded</h3>
                        <p class="stat-number"><?php echo $graded_students; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="stat-details">
                        <h3>Average</h3>
                        <p class="stat-number"><?php echo $average_marks; ?>%</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon highest">
                        <i class="fas fa-trophy"></i>
                    </div>
                    <div class="stat-details">
                        <h3>Highest</h3>
                        <p class="stat-number"><?php echo $highest_marks; ?></p>
                    </div>
                </div>
            </div>
            
            <!-- Results Form -->
            <?php if (count($students_results) > 0): ?>
            <div class="results-form-container">
                <form method="POST" id="resultsForm">
                    <input type="hidden" name="action" value="save_results">
                    <input type="hidden" name="assessment_id" value="<?php echo $selected_assessment_id; ?>">
                    
                    <div class="results-header">
                        <h3>Enter Results</h3>
                        <div class="results-actions">
                            <button type="button" class="btn btn-sm btn-info" onclick="calculateGrades()">Calculate Grades</button>
                            <button type="submit" class="btn btn-primary">Save Results</button>
                        </div>
                    </div>
                    
                    <div class="results-table">
                        <table>
                            <thead>
                                <tr>
                                    <th>Student ID</th>
                                    <th>Student Name</th>
                                    <th>Email</th>
                                    <th>Marks (out of <?php echo $assessment_details['total_marks']; ?>)</th>
                                    <th>Percentage</th>
                                    <th>Grade</th>
                                    <th>Feedback</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($students_results as $student): ?>
                                <tr>
                                    <td><?php echo $student['student_id'] ?? 'N/A'; ?></td>
                                    <td><?php echo $student['full_name']; ?></td>
                                    <td><?php echo $student['email']; ?></td>
                                    <td>
                                        <input type="number" 
                                               name="results[<?php echo $student['id']; ?>][marks]" 
                                               value="<?php echo $student['marks_obtained']; ?>"
                                               min="0" 
                                               max="<?php echo $assessment_details['total_marks']; ?>"
                                               step="0.5"
                                               class="marks-input"
                                               data-student-id="<?php echo $student['id']; ?>"
                                               data-total-marks="<?php echo $assessment_details['total_marks']; ?>">
                                    </td>
                                    <td>
                                        <span class="percentage-display" data-student-id="<?php echo $student['id']; ?>">
                                            <?php 
                                            if (!is_null($student['marks_obtained'])) {
                                                echo round(($student['marks_obtained'] / $assessment_details['total_marks']) * 100, 1) . '%';
                                            } else {
                                                echo '-';
                                            }
                                            ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="grade-display" data-student-id="<?php echo $student['id']; ?>">
                                            <?php 
                                            if (!is_null($student['marks_obtained'])) {
                                                $percentage = ($student['marks_obtained'] / $assessment_details['total_marks']) * 100;
                                                if ($percentage >= 90) echo 'A+';
                                                elseif ($percentage >= 85) echo 'A';
                                                elseif ($percentage >= 80) echo 'A-';
                                                elseif ($percentage >= 75) echo 'B+';
                                                elseif ($percentage >= 70) echo 'B';
                                                elseif ($percentage >= 65) echo 'B-';
                                                elseif ($percentage >= 60) echo 'C+';
                                                elseif ($percentage >= 55) echo 'C';
                                                elseif ($percentage >= 50) echo 'C-';
                                                else echo 'F';
                                            } else {
                                                echo '-';
                                            }
                                            ?>
                                        </span>
                                    </td>
                                    <td>
                                        <textarea name="results[<?php echo $student['id']; ?>][feedback]" 
                                                  rows="2" 
                                                  placeholder="Optional feedback..."><?php echo $student['feedback']; ?></textarea>
                                    </td>
                                    <td>
                                        <span class="status-badge <?php echo !is_null($student['marks_obtained']) ? 'status-graded' : 'status-pending'; ?>">
                                            <?php echo !is_null($student['marks_obtained']) ? 'Graded' : 'Pending'; ?>
                                        </span>
                                        <?php if (!is_null($student['graded_at'])): ?>
                                        <small class="graded-date">
                                            <?php echo date('M d, Y', strtotime($student['graded_at'])); ?>
                                        </small>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </form>
            </div>
            <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-user-graduate"></i>
                <h3>No Students Found</h3>
                <p>No students are enrolled for this assessment.</p>
            </div>
            <?php endif; ?>
            
            <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-chart-line"></i>
                <h3>Select an Assessment</h3>
                <p>Please select an assessment to view and enter results.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
    function selectAssessment() {
        const assessmentId = document.getElementById('assessmentSelect').value;
        if (assessmentId) {
            window.location.href = `results.php?assessment_id=${assessmentId}`;
        } else {
            window.location.href = 'results.php';
        }
    }
    
    function calculateGrades() {
        const marksInputs = document.querySelectorAll('.marks-input');
        
        marksInputs.forEach(input => {
            const studentId = input.getAttribute('data-student-id');
            const totalMarks = parseFloat(input.getAttribute('data-total-marks'));
            const marks = parseFloat(input.value);
            
            if (!isNaN(marks) && marks >= 0) {
                const percentage = (marks / totalMarks) * 100;
                const percentageDisplay = document.querySelector(`.percentage-display[data-student-id="${studentId}"]`);
                const gradeDisplay = document.querySelector(`.grade-display[data-student-id="${studentId}"]`);
                
                percentageDisplay.textContent = percentage.toFixed(1) + '%';
                
                let grade = 'F';
                if (percentage >= 90) grade = 'A+';
                else if (percentage >= 85) grade = 'A';
                else if (percentage >= 80) grade = 'A-';
                else if (percentage >= 75) grade = 'B+';
                else if (percentage >= 70) grade = 'B';
                else if (percentage >= 65) grade = 'B-';
                else if (percentage >= 60) grade = 'C+';
                else if (percentage >= 55) grade = 'C';
                else if (percentage >= 50) grade = 'C-';
                
                gradeDisplay.textContent = grade;
            }
        });
    }
    
    function exportResults() {
        const assessmentId = <?php echo $selected_assessment_id ?? 'null'; ?>;
        if (assessmentId) {
            window.open(`../api/export_results.php?assessment_id=${assessmentId}&format=csv`, '_blank');
        }
    }
    
    // Auto-calculate when marks are entered
    document.addEventListener('DOMContentLoaded', function() {
        const marksInputs = document.querySelectorAll('.marks-input');
        
        marksInputs.forEach(input => {
            input.addEventListener('input', function() {
                const studentId = this.getAttribute('data-student-id');
                const totalMarks = parseFloat(this.getAttribute('data-total-marks'));
                const marks = parseFloat(this.value);
                
                const percentageDisplay = document.querySelector(`.percentage-display[data-student-id="${studentId}"]`);
                const gradeDisplay = document.querySelector(`.grade-display[data-student-id="${studentId}"]`);
                
                if (!isNaN(marks) && marks >= 0) {
                    const percentage = (marks / totalMarks) * 100;
                    percentageDisplay.textContent = percentage.toFixed(1) + '%';
                    
                    let grade = 'F';
                    if (percentage >= 90) grade = 'A+';
                    else if (percentage >= 85) grade = 'A';
                    else if (percentage >= 80) grade = 'A-';
                    else if (percentage >= 75) grade = 'B+';
                    else if (percentage >= 70) grade = 'B';
                    else if (percentage >= 65) grade = 'B-';
                    else if (percentage >= 60) grade = 'C+';
                    else if (percentage >= 55) grade = 'C';
                    else if (percentage >= 50) grade = 'C-';
                    
                    gradeDisplay.textContent = grade;
                } else {
                    percentageDisplay.textContent = '-';
                    gradeDisplay.textContent = '-';
                }
            });
        });
        
        // Form validation
        document.getElementById('resultsForm')?.addEventListener('submit', function(e) {
            const marksInputs = document.querySelectorAll('.marks-input');
            let hasInvalidMarks = false;
            
            marksInputs.forEach(input => {
                const marks = parseFloat(input.value);
                const totalMarks = parseFloat(input.getAttribute('data-total-marks'));
                
                if (!isNaN(marks) && (marks < 0 || marks > totalMarks)) {
                    hasInvalidMarks = true;
                    input.style.borderColor = '#e74c3c';
                } else {
                    input.style.borderColor = '';
                }
            });
            
            if (hasInvalidMarks) {
                e.preventDefault();
                alert('Please ensure all marks are within the valid range (0 to total marks).');
            }
        });
    });
    </script>
    
    <script src="../assets/js/theme.js"></script>
</body>
</html>
