<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is an instructor
if (!is_logged_in() || !is_instructor()) {
    header("Location: ../auth/login.php");
    exit();
}

$instructor_id = $_SESSION['user_id'];
$assessment_id = isset($_GET['assessment_id']) ? intval($_GET['assessment_id']) : 0;
$selected_department_id = isset($_GET['department_id']) ? intval($_GET['department_id']) : 0;
$selected_program_id = isset($_GET['program_id']) ? intval($_GET['program_id']) : 0;
$selected_batch_id = isset($_GET['batch_id']) ? intval($_GET['batch_id']) : 0;
$selected_course_id = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;

$assessment = null;
$course = null;
$batch = null;
$questions = [];
$message = '';
$messageType = '';

if ($assessment_id <= 0) {
    header("Location: assessments.php");
    exit();
}

try {
    // Get assessment details
    $assessment_query = "SELECT a.*, 
                                d.name as department_name, 
                                p.name as program_name,
                                u.full_name as creator_name
                         FROM assessments a
                         LEFT JOIN departments d ON a.department_id = d.id
                         LEFT JOIN programs p ON a.program_id = p.id
                         LEFT JOIN users u ON a.created_by = u.id
                         WHERE a.id = ?";
    $assessment_stmt = $conn->prepare($assessment_query);
    $assessment_stmt->execute([$assessment_id]);
    $assessment = $assessment_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$assessment) {
        header("Location: assessments.php");
        exit();
    }

    // --- Data for cascading dropdowns (Departments, Programs, Batches, Courses) ---
    $departments = [];
    $programs = [];
    $batches = [];
    $courses_for_selection = [];

    // Fetch departments relevant to instructor's courses
    $dept_query = "SELECT DISTINCT d.id, d.name 
                   FROM departments d
                   JOIN programs p ON d.id = p.department_id
                   JOIN course c ON p.id = c.program_id
                   WHERE c.instructor_id = ? AND c.status = 'active'";
    
    // Filter by assessment scope
    $dept_params = [$instructor_id];
    if ($assessment['department_id']) {
        $dept_query .= " AND d.id = ?";
        $dept_params[] = $assessment['department_id'];
    }
    $dept_query .= " ORDER BY d.name";
    
    $dept_stmt = $conn->prepare($dept_query);
    $dept_stmt->execute($dept_params);
    $departments = $dept_stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($selected_department_id > 0) {
        // Fetch programs for selected department
        $prog_query = "SELECT DISTINCT p.id, p.name 
                       FROM programs p
                       JOIN course c ON p.id = c.program_id
                       WHERE p.department_id = ? AND c.instructor_id = ? AND c.status = 'active'";
        
        $prog_params = [$selected_department_id, $instructor_id];
        if ($assessment['program_id']) {
            $prog_query .= " AND p.id = ?";
            $prog_params[] = $assessment['program_id'];
        }
        $prog_query .= " ORDER BY p.name";
        
        $prog_stmt = $conn->prepare($prog_query);
        $prog_stmt->execute($prog_params);
        $programs = $prog_stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    if ($selected_program_id > 0) {
        // Fetch batches for selected program
        $batch_query = "SELECT DISTINCT b.id, b.name 
                        FROM batch b
                        JOIN course c ON b.id = c.batch_id
                        WHERE c.program_id = ? AND c.instructor_id = ? AND c.status = 'active'
                        ORDER BY b.name";
        $batch_stmt = $conn->prepare($batch_query);
        $batch_stmt->execute([$selected_program_id, $instructor_id]);
        $batches = $batch_stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    if ($selected_batch_id > 0) {
        // Fetch courses for selected batch, program, department, and instructor
        $course_selection_query = "SELECT c.id, c.name, c.code, b.name as batch_name, p.name as program_name, d.name as department_name
                                   FROM course c
                                   JOIN batch b ON c.batch_id = b.id
                                   JOIN programs p ON c.program_id = p.id
                                   JOIN departments d ON c.department_id = d.id
                                   WHERE c.instructor_id = ? 
                                   AND c.department_id = ? 
                                   AND c.program_id = ? 
                                   AND c.batch_id = ? 
                                   AND c.status = 'active'
                                   ORDER BY c.name";
        $course_selection_stmt = $conn->prepare($course_selection_query);
        $course_selection_stmt->execute([$instructor_id, $selected_department_id, $selected_program_id, $selected_batch_id]);
        $courses_for_selection = $course_selection_stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // If a course is finally selected
    if ($selected_course_id > 0 && $selected_batch_id > 0) {
        // Verify the selected course belongs to the instructor and matches assessment scope
        $course_check_query = "SELECT c.*, b.name as batch_name, p.name as program_name, d.name as department_name
                               FROM course c
                               JOIN batch b ON c.batch_id = b.id
                               JOIN programs p ON c.program_id = p.id
                               JOIN departments d ON c.department_id = d.id
                               WHERE c.id = ? AND c.instructor_id = ? AND c.batch_id = ?";
        $course_check_params = [$selected_course_id, $instructor_id, $selected_batch_id];

        // Check assessment scope compatibility
        if ($assessment['program_id']) {
            $course_check_query .= " AND c.program_id = ?";
            $course_check_params[] = $assessment['program_id'];
        } elseif ($assessment['department_id']) {
            $course_check_query .= " AND c.department_id = ?";
            $course_check_params[] = $assessment['department_id'];
        }
        
        $course_stmt = $conn->prepare($course_check_query);
        $course_stmt->execute($course_check_params);
        $course = $course_stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$course) {
            $message = "Selected course not found or you don't have permission to add questions for it.";
            $messageType = "danger";
            $selected_course_id = 0;
        } else {
            // Get batch details
            $batch_query = "SELECT * FROM batch WHERE id = ?";
            $batch_stmt = $conn->prepare($batch_query);
            $batch_stmt->execute([$selected_batch_id]);
            $batch = $batch_stmt->fetch(PDO::FETCH_ASSOC);
            
            // Get existing questions for this assessment, course, and batch
            $questions_query = "SELECT * FROM assessment_questions 
                               WHERE assessment_id = ? AND course_id = ? AND batch_id = ?
                               ORDER BY id";
            $questions_stmt = $conn->prepare($questions_query);
            $questions_stmt->execute([$assessment_id, $selected_course_id, $selected_batch_id]);
            $questions = $questions_stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }

} catch (PDOException $e) {
    error_log("Error fetching assessment or related data: " . $e->getMessage());
    $message = "Error loading assessment details or courses.";
    $messageType = "danger";
}

// Handle question creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_question']) && $selected_course_id > 0 && $selected_batch_id > 0) {
    $question_text = sanitize_input($_POST['question_text']);
    $question_type = sanitize_input($_POST['question_type']);
    $marks = floatval($_POST['marks']);
    $correct_answer = sanitize_input($_POST['correct_answer']);
    $options = null;

    // Handle MCQ options
    if ($question_type === 'mcq' && isset($_POST['options'])) {
        $options_array = array_filter($_POST['options'], function($option) {
            return !empty(trim($option));
        });
        if (count($options_array) >= 2) {
            $options = json_encode(array_values($options_array));
        } else {
            $message = "MCQ questions must have at least 2 options.";
            $messageType = "danger";
        }
    }

    if (empty($message) && !empty($question_text) && !empty($question_type) && $marks > 0) {
        try {
            $insert_query = "INSERT INTO assessment_questions (assessment_id, course_id, batch_id, question_text, question_type, options, correct_answer, marks) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $insert_stmt = $conn->prepare($insert_query);
            $insert_stmt->execute([$assessment_id, $selected_course_id, $selected_batch_id, $question_text, $question_type, $options, $correct_answer, $marks]);

            $message = "Question added successfully!";
            $messageType = "success";
            
            // Refresh questions
            $questions_query = "SELECT * FROM assessment_questions 
                               WHERE assessment_id = ? AND course_id = ? AND batch_id = ?
                               ORDER BY id";
            $questions_stmt = $conn->prepare($questions_query);
            $questions_stmt->execute([$assessment_id, $selected_course_id, $selected_batch_id]);
            $questions = $questions_stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error adding question: " . $e->getMessage());
            $message = "Error adding question.";
            $messageType = "danger";
        }
    } elseif (empty($message)) {
        $message = "Please fill in all required fields.";
        $messageType = "danger";
    }
}

// Handle question deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_question']) && $selected_course_id > 0 && $selected_batch_id > 0) {
    $question_id = intval($_POST['question_id']);
    
    try {
        $delete_query = "DELETE FROM assessment_questions WHERE id = ? AND assessment_id = ? AND course_id = ? AND batch_id = ?";
        $delete_stmt = $conn->prepare($delete_query);
        $delete_stmt->execute([$question_id, $assessment_id, $selected_course_id, $selected_batch_id]);

        $message = "Question deleted successfully!";
        $messageType = "success";
        
        // Refresh questions
        $questions_query = "SELECT * FROM assessment_questions 
                           WHERE assessment_id = ? AND course_id = ? AND batch_id = ?
                           ORDER BY id";
        $questions_stmt = $conn->prepare($questions_query);
        $questions_stmt->execute([$assessment_id, $selected_course_id, $selected_batch_id]);
        $questions = $questions_stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error deleting question: " . $e->getMessage());
        $message = "Error deleting question.";
        $messageType = "danger";
    }
}

// Calculate total marks from questions
$total_question_marks = array_sum(array_column($questions, 'marks'));

// Function to get assessment scope display
function getAssessmentScope($assessment) {
    if ($assessment['program_id'] && $assessment['program_name']) {
        return $assessment['program_name'] . ' Program';
    } elseif ($assessment['department_id'] && $assessment['department_name']) {
        return $assessment['department_name'] . ' Department';
    } else {
        return 'System-wide';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Questions - <?php echo htmlspecialchars($assessment['title'] ?? ''); ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <?php echo FONT_AWESOME_CSS; ?>
    <style>
        .assessment-info {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
            border-left: 4px solid var(--primary-color);
        }

        .assessment-meta {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }

        .meta-item {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .meta-label {
            font-size: 0.85rem;
            color: var(--text-muted);
            font-weight: 500;
        }

        .meta-value {
            font-size: 1rem;
            color: var(--text-color);
            font-weight: 600;
        }

        .selection-container {
            background: var(--card-bg);
            padding: 25px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
            text-align: center;
        }

        .selection-container h3 {
            margin-bottom: 15px;
            color: var(--text-color);
        }

        .selection-container p {
            color: var(--text-muted);
            margin-bottom: 20px;
        }

        .selection-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .selection-grid .form-group {
            margin-bottom: 0;
            text-align: left;
        }

        .selection-grid .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            background: var(--input-bg);
            color: var(--text-color);
        }

        .batch-info {
            background: #f3e8ff;
            color: #7c3aed;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #8b5cf6;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .batch-info a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
        }

        .batch-info a:hover {
            text-decoration: underline;
        }

        .questions-container {
            background: var(--card-bg);
            border-radius: 12px;
            box-shadow: var(--shadow);
            overflow: hidden;
        }

        .questions-header {
            background: var(--bg-secondary);
            padding: 20px;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .question-item {
            padding: 20px;
            border-bottom: 1px solid var(--border-light);
            transition: background-color 0.2s;
        }

        .question-item:hover {
            background: var(--hover-bg);
        }

        .question-item:last-child {
            border-bottom: none;
        }

        .question-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }

        .question-number {
            background: var(--primary-color);
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .question-type {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 500;
            text-transform: uppercase;
        }

        .question-type.mcq { background: #dbeafe; color: #1d4ed8; }
        .question-type.true_false { background: #d1fae5; color: #047857; }
        .question-type.short_answer { background: #fef3c7; color: #b45309; }
        .question-type.essay { background: #fee2e2; color: #b91c1c; }

        .question-marks {
            background: var(--bg-secondary);
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.8rem;
            color: var(--text-muted);
            margin-left: 10px;
        }

        .question-text {
            font-size: 1rem;
            color: var(--text-color);
            line-height: 1.6;
            margin: 15px 0;
        }

        .question-options {
            margin: 15px 0;
            padding-left: 20px;
        }

        .option-item {
            margin: 8px 0;
            color: var(--text-muted);
        }

        .correct-answer {
            background: #d1fae5;
            color: #047857;
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 0.9rem;
            margin: 10px 0;
            display: inline-block;
        }

        .question-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }

        .btn-sm {
            padding: 6px 12px;
            font-size: 0.8rem;
        }

        .add-question-btn {
            background: var(--primary-color);
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            transition: background-color 0.2s;
        }

        .add-question-btn:hover {
            background: var(--primary-dark);
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }

        .modal-content {
            background-color: var(--card-bg);
            margin: 2% auto;
            padding: 30px;
            border-radius: 12px;
            width: 90%;
            max-width: 700px;
            max-height: 90vh;
            overflow-y: auto;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border-color);
        }

        .close {
            color: var(--text-muted);
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.2s;
        }

        .close:hover {
            color: var(--text-color);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--text-color);
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            font-size: 0.9rem;
            background: var(--input-bg);
            color: var(--text-color);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }

        .options-container {
            margin-top: 15px;
        }

        .option-input {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 10px;
        }

        .option-input input {
            flex: 1;
        }

        .btn-remove-option {
            background: #ef4444;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.8rem;
        }

        .btn-add-option {
            background: var(--success-color);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.9rem;
            margin-top: 10px;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-muted);
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.3;
        }

        .batch-notice {
            background: #f3e8ff;
            color: #7c3aed;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #8b5cf6;
        }

        .batch-notice i {
            margin-right: 8px;
        }

        @media (max-width: 768px) {
            .assessment-meta {
                grid-template-columns: 1fr;
            }
            
            .selection-grid {
                grid-template-columns: 1fr;
            }
            
            .question-header {
                flex-direction: column;
                gap: 10px;
            }
            
            .question-actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/instructor-sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>Manage Questions</h1>
                <a href="assessments.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Assessments
                </a>
            </div>
            
            <?php if (!empty($message)): ?>
                <div class="message <?php echo $messageType; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <?php if ($assessment): ?>
                 Assessment Information 
                <div class="assessment-info">
                    <h2><?php echo htmlspecialchars($assessment['title']); ?></h2>
                    <p style="color: var(--text-muted); margin: 5px 0 0 0;">
                        <i class="fas fa-tag"></i> <?php echo ucfirst($assessment['type']); ?>
                    </p>
                    <div class="assessment-meta">
                        <div class="meta-item">
                            <span class="meta-label">Type</span>
                            <span class="meta-value"><?php echo ucfirst($assessment['type']); ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Scope</span>
                            <span class="meta-value"><?php echo getAssessmentScope($assessment); ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Created By</span>
                            <span class="meta-value"><?php echo htmlspecialchars($assessment['creator_name']); ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Total Marks</span>
                            <span class="meta-value"><?php echo $assessment['total_marks']; ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Start Time</span>
                            <span class="meta-value"><?php echo date('M j, Y g:i A', strtotime($assessment['start_time'])); ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">End Time</span>
                            <span class="meta-value"><?php echo date('M j, Y g:i A', strtotime($assessment['end_time'])); ?></span>
                        </div>
                    </div>
                </div>

                 Batch Notice 
                <div class="batch-notice">
                    <i class="fas fa-layer-group"></i>
                    <strong>Batch-Based Questions:</strong> Questions are specific to each batch. Select your department, program, batch, and course to create questions for that specific batch of students.
                </div>

                <?php if ($selected_course_id === 0 || $selected_batch_id === 0): ?>
                     Multi-level Selection 
                    <div class="selection-container">
                        <h3>Select Course and Batch for Questions</h3>
                        <p>
                            To add questions to this assessment, please select the specific Department, Program, Batch, and Course. Questions are unique to each batch.
                        </p>

                        <div class="selection-grid">
                            <div class="form-group">
                                <label for="department_select">Department</label>
                                <select id="department_select" onchange="updateSelection('department_id', this.value)">
                                    <option value="0">Select Department</option>
                                    <?php foreach ($departments as $dept): ?>
                                        <option value="<?php echo $dept['id']; ?>" <?php echo ($selected_department_id == $dept['id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($dept['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="program_select">Program</label>
                                <select id="program_select" onchange="updateSelection('program_id', this.value)" <?php echo empty($programs) ? 'disabled' : ''; ?>>
                                    <option value="0">Select Program</option>
                                    <?php foreach ($programs as $prog): ?>
                                        <option value="<?php echo $prog['id']; ?>" <?php echo ($selected_program_id == $prog['id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($prog['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="batch_select">Batch</label>
                                <select id="batch_select" onchange="updateSelection('batch_id', this.value)" <?php echo empty($batches) ? 'disabled' : ''; ?>>
                                    <option value="0">Select Batch</option>
                                    <?php foreach ($batches as $batch_option): ?>
                                        <option value="<?php echo $batch_option['id']; ?>" <?php echo ($selected_batch_id == $batch_option['id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($batch_option['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="course_select">Course</label>
                                <select id="course_select" onchange="updateSelection('course_id', this.value)" <?php echo empty($courses_for_selection) ? 'disabled' : ''; ?>>
                                    <option value="0">Select Course</option>
                                    <?php foreach ($courses_for_selection as $course_option): ?>
                                        <option value="<?php echo $course_option['id']; ?>" <?php echo ($selected_course_id == $course_option['id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($course_option['code'] . ' - ' . $course_option['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <?php if (empty($departments)): ?>
                            <div class="empty-state" style="margin-top: 30px;">
                                <i class="fas fa-exclamation-triangle"></i>
                                <h3>No Courses Found</h3>
                                <p>You don't have any courses assigned that match the scope for this assessment. Please contact the administrator.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <?php if ($selected_course_id > 0 && $selected_batch_id > 0 && $course && $batch): ?>
                     Batch and Course Info 
                    <div class="batch-info">
                        <div>
                            <i class="fas fa-layer-group"></i>
                            <strong>Adding questions for:</strong> 
                            <?php echo htmlspecialchars($course['code'] . ' - ' . $course['name']); ?>
                            <strong>| Batch:</strong> <?php echo htmlspecialchars($batch['name']); ?>
                            (<?php echo htmlspecialchars($course['program_name'] . ' - ' . $course['department_name']); ?>)
                        </div>
                        <a href="?assessment_id=<?php echo $assessment_id; ?>" style="color: var(--primary-color);">
                            <i class="fas fa-arrow-left"></i> Change Selection
                        </a>
                    </div>

                     Questions Container 
                    <div class="questions-container">
                        <div class="questions-header">
                            <h3><i class="fas fa-question-circle"></i> Questions for Batch <?php echo htmlspecialchars($batch['name']); ?> (<?php echo count($questions); ?>)</h3>
                            <button class="add-question-btn" onclick="openModal('addQuestionModal')">
                                <i class="fas fa-plus"></i> Add Question
                            </button>
                        </div>

                        <?php if (!empty($questions)): ?>
                            <?php foreach ($questions as $index => $question): ?>
                                <div class="question-item">
                                    <div class="question-header">
                                        <div style="display: flex; align-items: center; gap: 15px;">
                                            <span class="question-number"><?php echo $index + 1; ?></span>
                                            <span class="question-type <?php echo $question['question_type']; ?>">
                                                <?php echo str_replace('_', ' ', ucfirst($question['question_type'])); ?>
                                            </span>
                                            <span class="question-marks"><?php echo $question['marks']; ?> marks</span>
                                        </div>
                                        <div class="question-actions">
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this question?')">
                                                <input type="hidden" name="question_id" value="<?php echo $question['id']; ?>">
                                                <input type="hidden" name="assessment_id" value="<?php echo $assessment_id; ?>">
                                                <input type="hidden" name="course_id" value="<?php echo $selected_course_id; ?>">
                                                <input type="hidden" name="batch_id" value="<?php echo $selected_batch_id; ?>">
                                                <button type="submit" name="delete_question" class="btn btn-sm btn-danger">
                                                    <i class="fas fa-trash"></i> Delete
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                    
                                    <div class="question-text">
                                        <?php echo nl2br(htmlspecialchars($question['question_text'])); ?>
                                    </div>
                                    
                                    <?php if ($question['question_type'] === 'mcq' && !empty($question['options'])): ?>
                                        <div class="question-options">
                                            <?php 
                                            $options = json_decode($question['options'], true);
                                            $option_labels = ['A', 'B', 'C', 'D', 'E'];
                                            ?>
                                            <?php foreach ($options as $opt_index => $option): ?>
                                                <div class="option-item">
                                                    <strong><?php echo $option_labels[$opt_index]; ?>.</strong> <?php echo htmlspecialchars($option); ?>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <?php if (!empty($question['correct_answer'])): ?>
                                        <div class="correct-answer">
                                            <strong>Correct Answer:</strong> <?php echo htmlspecialchars($question['correct_answer']); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="empty-state">
                                <i class="fas fa-question-circle"></i>
                                <h3>No Questions Added</h3>
                                <p>Start by adding questions to this assessment for batch <?php echo htmlspecialchars($batch['name']); ?>.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

     Add Question Modal 
    <div id="addQuestionModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Add New Question</h2>
                <span class="close" onclick="closeModal('addQuestionModal')">&times;</span>
            </div>
            
            <form method="POST" id="addQuestionForm">
                <input type="hidden" name="assessment_id" value="<?php echo $assessment_id; ?>">
                <input type="hidden" name="course_id" value="<?php echo $selected_course_id; ?>">
                <input type="hidden" name="batch_id" value="<?php echo $selected_batch_id; ?>">

                <div class="form-group">
                    <label for="question_type">Question Type *</label>
                    <select name="question_type" id="question_type" required onchange="toggleQuestionOptions()">
                        <option value="">Select Type</option>
                        <option value="mcq">Multiple Choice (MCQ)</option>
                        <option value="true_false">True/False</option>
                        <option value="short_answer">Short Answer</option>
                        <option value="essay">Essay</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="question_text">Question Text *</label>
                    <textarea name="question_text" id="question_text" required placeholder="Enter your question here..."></textarea>
                </div>
                
                <div class="form-group">
                    <label for="marks">Marks *</label>
                    <input type="number" name="marks" id="marks" required min="0.5" step="0.5" placeholder="1">
                </div>
                
                 MCQ Options 
                <div id="mcqOptions" class="options-container" style="display: none;">
                    <label>Answer Options *</label>
                    <div id="optionsContainer">
                        <div class="option-input">
                            <input type="text" name="options[]" placeholder="Option A">
                            <button type="button" class="btn-remove-option" onclick="removeOption(this)">Remove</button>
                        </div>
                        <div class="option-input">
                            <input type="text" name="options[]" placeholder="Option B">
                            <button type="button" class="btn-remove-option" onclick="removeOption(this)">Remove</button>
                        </div>
                    </div>
                    <button type="button" class="btn-add-option" onclick="addOption()">Add Option</button>
                </div>
                
                <div class="form-group">
                    <label for="correct_answer">Correct Answer *</label>
                    <input type="text" name="correct_answer" id="correct_answer" required placeholder="Enter the correct answer">
                    <small id="answerHelp" style="color: var(--text-muted); font-size: 0.8rem;"></small>
                </div>
                
                <div class="form-group" style="margin-top: 30px;">
                    <button type="submit" name="add_question" class="btn btn-primary" style="width: 100%; padding: 12px;">
                        <i class="fas fa-plus"></i> Add Question
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
    <script>
        // PHP variables passed to JavaScript
        const ASSESSMENT_ID = <?php echo $assessment_id; ?>;
        const SELECTED_DEPARTMENT_ID = <?php echo $selected_department_id; ?>;
        const SELECTED_PROGRAM_ID = <?php echo $selected_program_id; ?>;
        const SELECTED_BATCH_ID = <?php echo $selected_batch_id; ?>;
        const SELECTED_COURSE_ID = <?php echo $selected_course_id; ?>;

        // Function to update URL and reload page for selection
        function updateSelection(paramName, value) {
            let url = new URL(window.location.href);
            url.searchParams.set('assessment_id', ASSESSMENT_ID);

            if (paramName === 'department_id') {
                url.searchParams.set('department_id', value);
                url.searchParams.delete('program_id');
                url.searchParams.delete('batch_id');
                url.searchParams.delete('course_id');
            } else if (paramName === 'program_id') {
                url.searchParams.set('department_id', SELECTED_DEPARTMENT_ID);
                url.searchParams.set('program_id', value);
                url.searchParams.delete('batch_id');
                url.searchParams.delete('course_id');
            } else if (paramName === 'batch_id') {
                url.searchParams.set('department_id', SELECTED_DEPARTMENT_ID);
                url.searchParams.set('program_id', SELECTED_PROGRAM_ID);
                url.searchParams.set('batch_id', value);
                url.searchParams.delete('course_id');
            } else if (paramName === 'course_id') {
                url.searchParams.set('department_id', SELECTED_DEPARTMENT_ID);
                url.searchParams.set('program_id', SELECTED_PROGRAM_ID);
                url.searchParams.set('batch_id', SELECTED_BATCH_ID);
                url.searchParams.set('course_id', value);
            }
            window.location.href = url.toString();
        }
        
        // Modal functionality
        function openModal(modalId) {
            document.getElementById(modalId).style.display = 'block';
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
        
        // Toggle question options based on type
        function toggleQuestionOptions() {
            const questionType = document.getElementById('question_type').value;
            const mcqOptions = document.getElementById('mcqOptions');
            const correctAnswer = document.getElementById('correct_answer');
            const answerHelp = document.getElementById('answerHelp');
            
            if (questionType === 'mcq') {
                mcqOptions.style.display = 'block';
                correctAnswer.placeholder = 'Enter option letter (A, B, C, etc.)';
                answerHelp.textContent = 'Enter the letter of the correct option (A, B, C, D, etc.)';
            } else {
                mcqOptions.style.display = 'none';
                if (questionType === 'true_false') {
                    correctAnswer.placeholder = 'True or False';
                    answerHelp.textContent = 'Enter "True" or "False"';
                } else {
                    correctAnswer.placeholder = 'Enter the correct answer';
                    answerHelp.textContent = 'Enter the expected answer or keywords';
                }
            }
        }
        
        // Add option for MCQ
        function addOption() {
            const container = document.getElementById('optionsContainer');
            const optionCount = container.children.length;
            const optionLabels = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
            
            if (optionCount < 8) {
                const optionDiv = document.createElement('div');
                optionDiv.className = 'option-input';
                optionDiv.innerHTML = `
                    <input type="text" name="options[]" placeholder="Option ${optionLabels[optionCount]}">
                    <button type="button" class="btn-remove-option" onclick="removeOption(this)">Remove</button>
                `;
                container.appendChild(optionDiv);
            }
        }
        
        // Remove option for MCQ
        function removeOption(button) {
            const container = document.getElementById('optionsContainer');
            if (container.children.length > 2) {
                button.parentElement.remove();
            }
        }
        
        // Form validation
        document.getElementById('addQuestionForm').addEventListener('submit', function(e) {
            const questionType = document.getElementById('question_type').value;
            
            if (questionType === 'mcq') {
                const options = document.querySelectorAll('#optionsContainer input[name="options[]"]');
                let filledOptions = 0;
                
                options.forEach(option => {
                    if (option.value.trim() !== '') {
                        filledOptions++;
                    }
                });
                
                if (filledOptions < 2) {
                    e.preventDefault();
                    alert('Please provide at least 2 options for MCQ questions.');
                    return;
                }
            }
        });

        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            toggleQuestionOptions();
        });
    </script>
</body>
</html>
