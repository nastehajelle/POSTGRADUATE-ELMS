<?php
session_start();
include_once '../config/init.php';

// Define is_instructor() if not already defined
if (!function_exists('is_instructor')) {
    function is_instructor() {
        return isset($_SESSION['role']) && $_SESSION['role'] === 'instructor';
    }
}

// Check if user is logged in and is an instructor
if (!is_logged_in() || !is_instructor()) {
    header("Location: ../auth/login.php");
    exit();
}

$instructor_id = $_SESSION['user_id'];
$message = '';
$error = '';

// Get instructor's department info
try {
    $instructor_query = "SELECT i.*, u.full_name, u.email 
                         FROM instructors i
                         INNER JOIN users u ON i.user_id = u.id
                         WHERE i.user_id = ?";
    $instructor_stmt = $conn->prepare($instructor_query);
    $instructor_stmt->execute([$instructor_id]);
    $instructor_info = $instructor_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$instructor_info) {
        $error = "Instructor information not found.";
    }
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}

// Handle review submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_review'])) {
    $thesis_id = $_POST['thesis_id'];
    $review_status = $_POST['review_status'];
    $overall_score = $_POST['overall_score'] ?? null;
    $content_score = $_POST['content_score'] ?? null;
    $methodology_score = $_POST['methodology_score'] ?? null;
    $presentation_score = $_POST['presentation_score'] ?? null;
    $comments = trim($_POST['comments']);
    $feedback = trim($_POST['feedback']);
    $suggestions = trim($_POST['suggestions']);

    if (empty($review_status) || empty($comments)) {
        $_SESSION['error'] = "Please provide review status and comments.";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }

    try {
        $conn->beginTransaction();

        // Insert or update review (ON DUPLICATE KEY)
        $review_query = "INSERT INTO thesis_reviews (
                            thesis_id, reviewer_id, review_date, status,
                            overall_score, content_score, methodology_score, presentation_score,
                            comments, feedback, suggestions, created_at
                        ) VALUES (?, ?, NOW(), ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                        ON DUPLICATE KEY UPDATE
                            review_date = NOW(),
                            status = VALUES(status),
                            overall_score = VALUES(overall_score),
                            content_score = VALUES(content_score),
                            methodology_score = VALUES(methodology_score),
                            presentation_score = VALUES(presentation_score),
                            comments = VALUES(comments),
                            feedback = VALUES(feedback),
                            suggestions = VALUES(suggestions),
                            updated_at = NOW()";

        $stmt = $conn->prepare($review_query);
        $stmt->execute([
            $thesis_id,
            $instructor_id,
            $review_status,
            $overall_score,
            $content_score,
            $methodology_score,
            $presentation_score,
            $comments,
            $feedback,
            $suggestions
        ]);

        // Update thesis status
        $update_thesis = "UPDATE thesis SET status = ?, updated_at = NOW() WHERE id = ?";
        $stmt2 = $conn->prepare($update_thesis);
        $stmt2->execute([$review_status, $thesis_id]);

        $conn->commit();

        $_SESSION['message'] = "Review submitted successfully!";
        // Redirect si page refresh uusan u galin duplicate
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    } catch (PDOException $e) {
        $conn->rollBack();
        $_SESSION['error'] = "Error submitting review: " . $e->getMessage();
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}

// Show messages
$message = $_SESSION['message'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['message'], $_SESSION['error']);


// Get thesis assignments for this instructor
$assigned_thesis = [];
$reviewed_thesis = [];

try {
    // Get assigned thesis (where instructor is supervisor)
    $assigned_query = "SELECT t.*, u.full_name as student_name, u.email as student_email,
                       p.name as program_name, d.name as department_name,
                       tr.status as review_status, tr.review_date
                       FROM thesis t
                       INNER JOIN users u ON t.student_id = u.id
                       INNER JOIN programs p ON t.program_id = p.id
                       INNER JOIN departments d ON t.department_id = d.id
                       LEFT JOIN thesis_reviews tr ON t.id = tr.thesis_id AND tr.reviewer_id = ?
                       WHERE t.supervisor_id = ?
                       ORDER BY t.submission_date DESC";
    $assigned_stmt = $conn->prepare($assigned_query);
    $assigned_stmt->execute([$instructor_id, $instructor_id]);
    $assigned_thesis = $assigned_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Separate reviewed and unreviewed from assigned
    foreach ($assigned_thesis as $thesis) {
        if ($thesis['review_status']) {
            $reviewed_thesis[] = $thesis;
        }
    }

} catch (PDOException $e) {
    $error = "Error fetching thesis data: " . $e->getMessage();
}

// Get statistics
$total_assigned = count($assigned_thesis);
$total_reviewed = count($reviewed_thesis);
$total_unreviewed = $total_assigned - $total_reviewed;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thesis Review - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link rel="stylesheet" href="../assets/css/thesis.css">
    <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/instructor-sidebar.php'; ?>
        
        <div class="admin-content">
            <!-- Improved header section with better styling -->
            <div class="admin-header">
                <div class="admin-header-content">
                    <div class="header-title-section">
                        <h1><i class="fas fa-clipboard-check"></i> Thesis Review</h1>
                        <p class="header-subtitle">Review and evaluate student thesis submissions</p>
                    </div>
                    <div class="header-actions">
                        <a href="thesis-report.php" class="btn btn-outline-primary">
                            <i class="fas fa-chart-bar"></i> Generate Report
                        </a>
                        <a href="thesis-export.php" class="btn btn-outline-secondary">
                            <i class="fas fa-download"></i> Export Data
                        </a>
                    </div>
                </div>
            </div>

            <?php if ($message): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <!-- Redesigned overview cards with better styling and proper icons -->
            <div class="stats-overview">
                <div class="stat-card assigned-card">
                    <div class="stat-icon">
                        <i class="fas fa-user-tie"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo $total_assigned; ?></div>
                        <div class="stat-label">Assigned to Me</div>
                        <div class="stat-description">Thesis supervising</div>
                    </div>
                </div>
                
                <div class="stat-card pending-card">
                    <div class="stat-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo $total_unreviewed; ?></div>
                        <div class="stat-label">Pending Review</div>
                        <div class="stat-description"><?php echo $total_unreviewed > 0 ? 'Action needed' : 'Up to date'; ?></div>
                    </div>
                </div>
                
                <div class="stat-card completed-card">
                    <div class="stat-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo $total_reviewed; ?></div>
                        <div class="stat-label">Completed Reviews</div>
                        <div class="stat-description">Reviews finished</div>
                    </div>
                </div>
            </div>

            <!-- Improved tabs navigation with better styling -->
            <div class="content-tabs">
                <div class="tabs-header">
                    <button class="tab-button active" onclick="showTab('assigned')">
                        <i class="fas fa-user-tie"></i>
                        <span>My Assigned Thesis</span>
                        <span class="tab-count"><?php echo $total_assigned; ?></span>
                    </button>
                    <button class="tab-button" onclick="showTab('reviewed')">
                        <i class="fas fa-check-circle"></i>
                        <span>Completed Reviews</span>
                        <span class="tab-count"><?php echo $total_reviewed; ?></span>
                    </button>
                </div>

                <!-- Improved table styling and layout -->
                <div class="tabs-content">
                    <!-- Assigned Thesis Tab -->
                    <div id="assigned-tab" class="tab-panel active">
                        <div class="data-table-container">
                            <div class="table-header">
                                <h3>Thesis Assigned to Me</h3>
                            </div>
                            <div class="table-content">
                                <?php if (!empty($assigned_thesis)): ?>
                                    <table class="data-table">
                                        <thead>
                                            <tr>
                                                <th>Student</th>
                                                <th>Thesis Title</th>
                                                <th>Program</th>
                                                <th>Submission Date</th>
                                                <th>Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($assigned_thesis as $thesis): ?>
                                            <tr>
                                                <td>
                                                    <div class="student-info">
                                                        <div class="student-name"><?php echo htmlspecialchars($thesis['student_name']); ?></div>
                                                        <div class="student-email"><?php echo htmlspecialchars($thesis['student_email']); ?></div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="thesis-title"><?php echo htmlspecialchars($thesis['title']); ?></div>
                                                    <div class="thesis-keywords">
                                                        <small><?php echo htmlspecialchars($thesis['keywords']); ?></small>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="program-info">
                                                        <div><?php echo htmlspecialchars($thesis['program_name']); ?></div>
                                                        <small><?php echo htmlspecialchars($thesis['department_name']); ?></small>
                                                    </div>
                                                </td>
                                                <td><?php echo date('M d, Y', strtotime($thesis['submission_date'])); ?></td>
                                                <td>
                                                    <span class="status-badge status-<?php echo $thesis['status']; ?>">
                                                        <?php echo ucwords(str_replace('_', ' ', $thesis['status'])); ?>
                                                    </span>
                                                    <?php if ($thesis['review_status']): ?>
                                                        <br><small>Reviewed: <?php echo date('M d, Y', strtotime($thesis['review_date'])); ?></small>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <div class="action-buttons">
                                                        <button class="btn btn-sm btn-info" onclick="viewThesis(<?php echo $thesis['id']; ?>)">
                                                            <i class="fas fa-eye"></i> View
                                                        </button>
                                                        <a href="../<?php echo htmlspecialchars($thesis['file_path']); ?>" 
                                                           class="btn btn-sm btn-secondary" download>
                                                            <i class="fas fa-download"></i> Download
                                                        </a>
                                                        <?php if (!$thesis['review_status']): ?>
                                                        <button class="btn btn-sm btn-primary" onclick="reviewThesis(<?php echo $thesis['id']; ?>)">
                                                            <i class="fas fa-edit"></i> Review
                                                        </button>
                                                        <?php else: ?>
                                                        <button class="btn btn-sm btn-warning" onclick="reviewThesis(<?php echo $thesis['id']; ?>)">
                                                            <i class="fas fa-edit"></i> Edit Review
                                                        </button>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <div class="no-data">
                                        <i class="fas fa-user-tie"></i>
                                        <h3>No Thesis Assigned</h3>
                                        <p>You don't have any thesis assignments yet.</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Reviewed Thesis Tab -->
                    <div id="reviewed-tab" class="tab-panel">
                        <div class="data-table-container">
                            <div class="table-header">
                                <h3>Completed Reviews</h3>
                            </div>
                            <div class="table-content">
                                <?php if (!empty($reviewed_thesis)): ?>
                                    <table class="data-table">
                                        <thead>
                                            <tr>
                                                <th>Student</th>
                                                <th>Thesis Title</th>
                                                <th>Review Status</th>
                                                <th>Review Date</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($reviewed_thesis as $thesis): ?>
                                            <tr>
                                                <td>
                                                    <div class="student-info">
                                                        <div class="student-name"><?php echo htmlspecialchars($thesis['student_name']); ?></div>
                                                        <div class="student-email"><?php echo htmlspecialchars($thesis['student_email']); ?></div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="thesis-title"><?php echo htmlspecialchars($thesis['title']); ?></div>
                                                </td>
                                                <td>
                                                    <span class="status-badge status-<?php echo $thesis['review_status']; ?>">
                                                        <?php echo ucwords(str_replace('_', ' ', $thesis['review_status'])); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo date('M d, Y', strtotime($thesis['review_date'])); ?></td>
                                                <td>
                                                    <div class="action-buttons">
                                                        <button class="btn btn-sm btn-info" onclick="viewThesis(<?php echo $thesis['id']; ?>)">
                                                            <i class="fas fa-eye"></i> View
                                                        </button>
                                                        <button class="btn btn-sm btn-warning" onclick="reviewThesis(<?php echo $thesis['id']; ?>)">
                                                            <i class="fas fa-edit"></i> Edit Review
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <div class="no-data">
                                        <i class="fas fa-check-circle"></i>
                                        <h3>No Completed Reviews</h3>
                                        <p>You haven't completed any thesis reviews yet.</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Review Modal -->
    <div id="reviewModal" class="modal">
        <div class="modal-content modal-large">
            <div class="modal-header">
                <h3>Review Thesis</h3>
                <span class="close" onclick="closeReviewModal()">&times;</span>
            </div>
            <form method="POST" id="reviewForm">
                <input type="hidden" name="thesis_id" id="review_thesis_id">
                <div class="modal-body">
                    <div class="review-form-grid">
                        <div class="form-section">
                            <h4>Review Decision</h4>
                            <div class="form-group">
                                <label for="review_status">Status *</label>
                                <select id="review_status" name="review_status" required>
                                    <option value="">Select Status</option>
                                    <option value="approved">Approved</option>
                                    <option value="rejected">Rejected</option>
                                    <option value="revision_required">Revision Required</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-section">
                            <h4>Scoring (Optional)</h4>
                            <div class="scores-grid">
                                <div class="form-group">
                                    <label for="overall_score">Overall Score (0-5)</label>
                                    <input type="number" id="overall_score" name="overall_score" 
                                           min="0" max="5" step="0.1">
                                </div>
                                <div class="form-group">
                                    <label for="content_score">Content (0-5)</label>
                                    <input type="number" id="content_score" name="content_score" 
                                           min="0" max="5" step="0.1">
                                </div>
                                <div class="form-group">
                                    <label for="methodology_score">Methodology (0-5)</label>
                                    <input type="number" id="methodology_score" name="methodology_score" 
                                           min="0" max="5" step="0.1">
                                </div>
                                <div class="form-group">
                                    <label for="presentation_score">Presentation (0-5)</label>
                                    <input type="number" id="presentation_score" name="presentation_score" 
                                           min="0" max="5" step="0.1">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="comments">Comments *</label>
                        <textarea id="comments" name="comments" rows="4" required 
                                  placeholder="Provide your overall comments on the thesis..."></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="feedback">Detailed Feedback</label>
                        <textarea id="feedback" name="feedback" rows="6" 
                                  placeholder="Provide detailed feedback on content, methodology, writing quality, etc..."></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="suggestions">Suggestions for Improvement</label>
                        <textarea id="suggestions" name="suggestions" rows="4" 
                                  placeholder="Provide specific suggestions for improvement..."></textarea>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeReviewModal()">Cancel</button>
                    <button type="submit" name="submit_review" class="btn btn-primary">
                        <i class="fas fa-save"></i> Submit Review
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- View Modal -->
    <div id="viewModal" class="modal">
        <div class="modal-content modal-large">
            <div class="modal-header">
                <h3>Thesis Details</h3>
                <span class="close" onclick="closeViewModal()">&times;</span>
            </div>
            <div class="modal-body" id="thesisDetails">
                <!-- Content will be loaded dynamically -->
            </div>
        </div>
    </div>

    <script src="../assets/js/theme.js"></script>
    <script>
        function showTab(tabName) {
            // Hide all tabs
            document.querySelectorAll('.tab-panel').forEach(tab => {
                tab.classList.remove('active');
            });
            document.querySelectorAll('.tab-button').forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Show selected tab
            document.getElementById(tabName + '-tab').classList.add('active');
            event.target.classList.add('active');
        }

        function reviewThesis(thesisId) {
            document.getElementById('review_thesis_id').value = thesisId;
            
            // Load existing review data if available
            fetch('ajax/get-review-data.php?thesis_id=' + thesisId)
                .then(response => response.json())
                .then(data => {
                    if (data.review) {
                        document.getElementById('review_status').value = data.review.status || '';
                        document.getElementById('overall_score').value = data.review.overall_score || '';
                        document.getElementById('content_score').value = data.review.content_score || '';
                        document.getElementById('methodology_score').value = data.review.methodology_score || '';
                        document.getElementById('presentation_score').value = data.review.presentation_score || '';
                        document.getElementById('comments').value = data.review.comments || '';
                        document.getElementById('feedback').value = data.review.feedback || '';
                        document.getElementById('suggestions').value = data.review.suggestions || '';
                    }
                    document.getElementById('reviewModal').style.display = 'block';
                })
                .catch(error => {
                    console.error('Error:', error);
                    document.getElementById('reviewModal').style.display = 'block';
                });
        }

        function closeReviewModal() {
            document.getElementById('reviewModal').style.display = 'none';
            document.getElementById('reviewForm').reset();
        }

        function viewThesis(thesisId) {
            fetch('ajax/get-thesis-details.php?id=' + thesisId)
                .then(response => response.text())
                .then(data => {
                    document.getElementById('thesisDetails').innerHTML = data;
                    document.getElementById('viewModal').style.display = 'block';
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error loading thesis details');
                });
        }

        function closeViewModal() {
            document.getElementById('viewModal').style.display = 'none';
        }

        // Close modals when clicking outside
        window.onclick = function(event) {
            const reviewModal = document.getElementById('reviewModal');
            const viewModal = document.getElementById('viewModal');
            
            if (event.target === reviewModal) {
                reviewModal.style.display = 'none';
            }
            if (event.target === viewModal) {
                viewModal.style.display = 'none';
            }
        }
    </script>
</body>
</html>
