<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is an instructor
if (!is_logged_in() || !is_instructor()) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$instructor_id = $_SESSION['user_id'];

try {
    // Get all events for the instructor's calendar
    $events_query = "
        SELECT 'Assessment' as type, title, start_time as date, type as subtype, 'assessment' as css_class
        FROM assessments
        WHERE created_by = ? AND start_time >= DATE_SUB(NOW(), INTERVAL 1 MONTH)
        
        UNION ALL
        
        SELECT 'Live Class' as type, title, scheduled_time as date, 'live_class' as subtype, 'live-class' as css_class
        FROM live_classes lc
        INNER JOIN course c ON lc.course_id = c.id
        WHERE c.instructor_id = ? AND lc.scheduled_time >= DATE_SUB(NOW(), INTERVAL 1 MONTH)
        
        UNION ALL
        
        SELECT 'Academic Event' as type, title, 
               CONCAT(event_date, ' ', COALESCE(start_time, '00:00:00')) as date, 
               event_type as subtype, 'academic-event' as css_class
        FROM academic_events
        WHERE event_date >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH) AND status = 'Active'
        
        UNION ALL
        
        SELECT 'Assignment Due' as type, CONCAT('Due: ', title) as title, end_time as date, 'assignment' as subtype, 'assignment' as css_class
        FROM assessments
        WHERE created_by = ? AND type IN ('assignment', 'project') AND end_time >= DATE_SUB(NOW(), INTERVAL 1 MONTH)
        
        ORDER BY date ASC
    ";
    
    $events_stmt = $conn->prepare($events_query);
    $events_stmt->execute([$instructor_id, $instructor_id, $instructor_id]);
    $events = $events_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format events for FullCalendar
    $formatted_events = [];
    foreach ($events as $event) {
        $formatted_events[] = [
            'title' => $event['title'],
            'date' => $event['date'],
            'type' => $event['type'],
            'subtype' => $event['subtype'],
            'className' => $event['css_class']
        ];
    }
    
    header('Content-Type: application/json');
    echo json_encode($formatted_events);
    
} catch (PDOException $e) {
    error_log("Error fetching calendar events: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Database error']);
}
?>
