<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is an instructor
if (!is_logged_in() || !is_instructor()) {
    header("Location: ../auth/login.php");
    exit();
}

$instructor_id = $_SESSION['user_id'];
$assessment_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$assessment = null;
$questions = [];
$message = '';
$messageType = '';

if ($assessment_id <= 0) {
    header("Location: assessments.php");
    exit();
}

try {
    // Get assessment details and verify access
    $assessment_query = "SELECT a.*, c.name as course_name, c.code as course_code,
                                d.name as department_name, p.name as program_name,
                                u.full_name as creator_name
                         FROM assessments a
                         LEFT JOIN course c ON a.course_id = c.id
                         LEFT JOIN departments d ON a.department_id = d.id
                         LEFT JOIN programs p ON a.program_id = p.id
                         LEFT JOIN users u ON a.created_by = u.id
                         WHERE a.id = ? 
                         AND (a.created_by = ? OR (a.type = 'exam' AND (c.instructor_id = ? OR a.course_id IS NULL)))";
    $assessment_stmt = $conn->prepare($assessment_query);
    $assessment_stmt->execute([$assessment_id, $instructor_id, $instructor_id]);
    $assessment = $assessment_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$assessment) {
        header("Location: assessments.php");
        exit();
    }

    // Get all questions for this assessment (from all courses if it's an exam)
    if ($assessment['type'] === 'exam') {
        // For exams, get questions from all courses that match the assessment scope
        $questions_query = "SELECT aq.*, c.name as course_name, c.code as course_code
                           FROM assessment_questions aq
                           LEFT JOIN course c ON aq.course_id = c.id
                           WHERE aq.assessment_id = ?
                           ORDER BY aq.course_id, aq.id";
        $questions_stmt = $conn->prepare($questions_query);
        $questions_stmt->execute([$assessment_id]);
    } else {
        // For other assessments, get questions from instructor's courses only
        $questions_query = "SELECT aq.*, c.name as course_name, c.code as course_code
                           FROM assessment_questions aq
                           LEFT JOIN course c ON aq.course_id = c.id
                           WHERE aq.assessment_id = ? AND c.instructor_id = ?
                           ORDER BY aq.course_id, aq.id";
        $questions_stmt = $conn->prepare($questions_query);
        $questions_stmt->execute([$assessment_id, $instructor_id]);
    }
    
    $questions = $questions_stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log("Error fetching assessment: " . $e->getMessage());
    $message = "Error loading assessment.";
    $messageType = "danger";
}

// Function to get assessment scope display
function getAssessmentScope($assessment) {
    if ($assessment['program_id'] && $assessment['program_name']) {
        return $assessment['program_name'] . ' Program';
    } elseif ($assessment['department_id'] && $assessment['department_name']) {
        return $assessment['department_name'] . ' Department';
    } else {
        return 'System-wide';
    }
}

// Calculate total marks from questions
$total_question_marks = array_sum(array_column($questions, 'marks'));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Preview Assessment - <?php echo htmlspecialchars($assessment['title'] ?? ''); ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <?php echo FONT_AWESOME_CSS; ?>
    <style>
        .preview-container {
            max-width: 900px;
            margin: 0 auto;
        }

        .preview-header {
            background: var(--card-bg);
            padding: 25px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
            border-left: 4px solid var(--primary-color);
        }

        .assessment-title {
            font-size: 2rem;
            font-weight: 700;
            color: var(--text-color);
            margin-bottom: 10px;
        }

        .assessment-subtitle {
            color: var(--text-muted);
            font-size: 1.1rem;
            margin-bottom: 20px;
        }

        .assessment-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .info-item {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .info-label {
            font-size: 0.9rem;
            color: var(--text-muted);
            font-weight: 500;
        }

        .info-value {
            font-size: 1.1rem;
            color: var(--text-color);
            font-weight: 600;
        }

        .instructions-section {
            background: var(--card-bg);
            padding: 25px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
        }

        .instructions-title {
            font-size: 1.3rem;
            font-weight: 600;
            color: var(--text-color);
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .instructions-content {
            color: var(--text-color);
            line-height: 1.6;
            font-size: 1rem;
        }

        .questions-section {
            background: var(--card-bg);
            border-radius: 12px;
            box-shadow: var(--shadow);
            overflow: hidden;
        }

        .section-header {
            background: var(--bg-secondary);
            padding: 20px 25px;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .section-title {
            font-size: 1.4rem;
            font-weight: 600;
            color: var(--text-color);
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .question-item {
            padding: 30px 25px;
            border-bottom: 1px solid var(--border-light);
        }

        .question-item:last-child {
            border-bottom: none;
        }

        .question-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 20px;
        }

        .question-number {
            background: var(--primary-color);
            color: white;
            padding: 10px 15px;
            border-radius: 25px;
            font-weight: 600;
            font-size: 1rem;
        }

        .question-meta {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .question-type-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 500;
            text-transform: uppercase;
        }

        .question-type-badge.mcq { background: #dbeafe; color: #1d4ed8; }
        .question-type-badge.true_false { background: #d1fae5; color: #047857; }
        .question-type-badge.short_answer { background: #fef3c7; color: #b45309; }
        .question-type-badge.essay { background: #fee2e2; color: #b91c1c; }

        .question-marks {
            background: var(--bg-secondary);
            color: var(--text-color);
            padding: 6px 12px;
            border-radius: 15px;
            font-size: 0.9rem;
            font-weight: 500;
        }

        .course-badge {
            background: #e0e7ff;
            color: #4338ca;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 500;
        }

        .question-text {
            font-size: 1.2rem;
            color: var(--text-color);
            margin-bottom: 20px;
            line-height: 1.7;
            font-weight: 500;
        }

        .answer-options {
            margin: 20px 0;
        }

        .option-item {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            margin-bottom: 10px;
            background: var(--bg-light);
            border-radius: 8px;
            border: 2px solid transparent;
            transition: all 0.2s;
        }

        .option-item:hover {
            border-color: var(--primary-color);
            background: var(--hover-bg);
        }

        .option-letter {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 30px;
            height: 30px;
            background: var(--primary-color);
            color: white;
            border-radius: 50%;
            font-weight: 600;
            margin-right: 15px;
            font-size: 0.9rem;
        }

        .option-text {
            flex: 1;
            font-size: 1rem;
            color: var(--text-color);
        }

        .answer-input {
            width: 100%;
            padding: 15px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-size: 1rem;
            background: var(--input-bg);
            color: var(--text-color);
            resize: vertical;
            min-height: 50px;
        }

        .answer-input:focus {
            outline: none;
            border-color: var(--primary-color);
        }

        .true-false-options {
            display: flex;
            gap: 20px;
            margin: 20px 0;
        }

        .tf-option {
            flex: 1;
            padding: 15px;
            background: var(--bg-light);
            border: 2px solid var(--border-color);
            border-radius: 8px;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s;
            font-weight: 500;
        }

        .tf-option:hover {
            border-color: var(--primary-color);
            background: var(--hover-bg);
        }

        .preview-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid var(--border-color);
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
        }

        .btn-primary {
            background: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            text-decoration: none;
        }

        .btn-secondary {
            background: var(--bg-secondary);
            color: var(--text-color);
            border: 1px solid var(--border-color);
        }

        .btn-secondary:hover {
            background: var(--hover-bg);
            text-decoration: none;
        }

        .btn-warning {
            background: #f59e0b;
            color: white;
        }

        .btn-warning:hover {
            background: #d97706;
            text-decoration: none;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-muted);
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.3;
        }

        .marks-summary {
            background: var(--bg-light);
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .marks-warning {
            color: #ef4444;
            font-weight: 600;
        }

        .marks-success {
            color: #10b981;
            font-weight: 600;
        }

        .preview-notice {
            background: #dbeafe;
            color: #1e40af;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #3b82f6;
        }

        .preview-notice i {
            margin-right: 8px;
        }

        @media (max-width: 768px) {
            .assessment-info {
                grid-template-columns: 1fr;
            }
            
            .question-header {
                flex-direction: column;
                gap: 15px;
            }
            
            .question-meta {
                flex-wrap: wrap;
            }
            
            .true-false-options {
                flex-direction: column;
            }
            
            .preview-actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/instructor-sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="preview-container">
                <div class="admin-header">
                    <h1>Assessment Preview</h1>
                    <a href="assessments.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Assessments
                    </a>
                </div>
                
                <?php if (!empty($message)): ?>
                    <div class="message <?php echo $messageType; ?>">
                        <?php echo $message; ?>
                    </div>
                <?php endif; ?>

                <!-- Preview Notice -->
                <div class="preview-notice">
                    <i class="fas fa-eye"></i>
                    <strong>Preview Mode:</strong> This is how students will see the assessment. All form elements are disabled for preview purposes.
                </div>

                <?php if ($assessment): ?>
                    <!-- Assessment Header -->
                    <div class="preview-header">
                        <h1 class="assessment-title"><?php echo htmlspecialchars($assessment['title']); ?></h1>
                        <p class="assessment-subtitle">
                            <?php echo ucfirst($assessment['type']); ?> • <?php echo getAssessmentScope($assessment); ?>
                        </p>
                        
                        <div class="assessment-info">
                            <div class="info-item">
                                <span class="info-label">Total Marks</span>
                                <span class="info-value"><?php echo $assessment['total_marks']; ?> marks</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Pass Marks</span>
                                <span class="info-value"><?php echo $assessment['pass_marks']; ?> marks</span>
                            </div>
                            <?php if ($assessment['duration_minutes'] > 0): ?>
                            <div class="info-item">
                                <span class="info-label">Duration</span>
                                <span class="info-value"><?php echo $assessment['duration_minutes']; ?> minutes</span>
                            </div>
                            <?php endif; ?>
                            <div class="info-item">
                                <span class="info-label">Attempts Allowed</span>
                                <span class="info-value"><?php echo $assessment['attempts_allowed']; ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Start Time</span>
                                <span class="info-value"><?php echo date('M j, Y g:i A', strtotime($assessment['start_time'])); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">End Time</span>
                                <span class="info-value"><?php echo date('M j, Y g:i A', strtotime($assessment['end_time'])); ?></span>
                            </div>
                        </div>
                    </div>

                    <!-- Instructions -->
                    <?php if (!empty($assessment['instructions'])): ?>
                    <div class="instructions-section">
                        <h2 class="instructions-title">
                            <i class="fas fa-info-circle"></i>
                            Instructions
                        </h2>
                        <div class="instructions-content">
                            <?php echo nl2br(htmlspecialchars($assessment['instructions'])); ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Questions -->
                    <div class="questions-section">
                        <div class="section-header">
                            <h2 class="section-title">
                                <i class="fas fa-question-circle"></i>
                                Questions (<?php echo count($questions); ?>)
                            </h2>
                        </div>

                        <!-- Marks Summary -->
                        <div class="marks-summary">
                            <span>Questions Total: <?php echo $total_question_marks; ?> marks</span>
                            <?php if ($total_question_marks != $assessment['total_marks']): ?>
                                <span class="marks-warning">
                                    <i class="fas fa-exclamation-triangle"></i>
                                    Marks mismatch detected!
                                </span>
                            <?php else: ?>
                                <span class="marks-success">
                                    <i class="fas fa-check-circle"></i>
                                    Marks are balanced
                                </span>
                            <?php endif; ?>
                        </div>

                        <?php if (!empty($questions)): ?>
                            <?php foreach ($questions as $index => $question): ?>
                                <div class="question-item">
                                    <div class="question-header">
                                        <span class="question-number">Question <?php echo $index + 1; ?></span>
                                        <div class="question-meta">
                                            <span class="question-type-badge <?php echo $question['question_type']; ?>">
                                                <?php echo ucfirst(str_replace('_', ' ', $question['question_type'])); ?>
                                            </span>
                                            <span class="question-marks"><?php echo $question['marks']; ?> marks</span>
                                            <?php if ($question['course_name']): ?>
                                                <span class="course-badge">
                                                    <?php echo htmlspecialchars($question['course_code']); ?>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    
                                    <div class="question-text">
                                        <?php echo nl2br(htmlspecialchars($question['question_text'])); ?>
                                    </div>

                                    <?php if ($question['question_type'] === 'mcq'): ?>
                                        <?php $options = json_decode($question['options'], true); ?>
                                        <div class="answer-options">
                                            <?php foreach ($options as $optIndex => $option): ?>
                                                <div class="option-item">
                                                    <span class="option-letter"><?php echo chr(65 + $optIndex); ?></span>
                                                    <span class="option-text"><?php echo htmlspecialchars($option); ?></span>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php elseif ($question['question_type'] === 'true_false'): ?>
                                        <div class="true-false-options">
                                            <div class="tf-option">
                                                <i class="fas fa-check"></i> True
                                            </div>
                                            <div class="tf-option">
                                                <i class="fas fa-times"></i> False
                                            </div>
                                        </div>
                                    <?php elseif ($question['question_type'] === 'short_answer'): ?>
                                        <input type="text" class="answer-input" placeholder="Enter your answer here..." disabled>
                                    <?php elseif ($question['question_type'] === 'essay'): ?>
                                        <textarea class="answer-input" rows="6" placeholder="Write your essay here..." disabled></textarea>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="empty-state">
                                <i class="fas fa-question-circle"></i>
                                <h3>No Questions Available</h3>
                                <p>This assessment doesn't have any questions yet. Add questions to make it available to students.</p>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Preview Actions -->
                    <div class="preview-actions">
                        <a href="assessments.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Back to Assessments
                        </a>
                        
                        <?php if ($assessment['created_by'] == $instructor_id && $assessment['type'] !== 'exam'): ?>
                            <a href="edit-assessment.php?id=<?php echo $assessment['id']; ?>" class="btn btn-warning">
                                <i class="fas fa-edit"></i> Edit Assessment
                            </a>
                        <?php endif; ?>
                        
                        <a href="manage-questions.php?assessment_id=<?php echo $assessment['id']; ?>" class="btn btn-primary">
                            <i class="fas fa-question-circle"></i> Manage Questions
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
</body>
</html>
