<?php
session_start();
include_once '../config/init.php';

if (!function_exists('is_instructor')) {
    function is_instructor() {
        return isset($_SESSION['role']) && $_SESSION['role'] === 'instructor';
    }
}

// Check if user is logged in and is instructor
if (!is_logged_in() || !is_instructor()) {
    header("Location: ../auth/login.php");
    exit();
}

$instructor_id = $_SESSION['user_id']; // Changed from $admin_id to $instructor_id for clarity
$message = '';
$messageType = '';

// Check for messages from redirects
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    $messageType = $_SESSION['message_type'];
    unset($_SESSION['message'], $_SESSION['message_type']);
}

// Process AJAX requests
if (isset($_POST['ajax']) && $_POST['ajax'] == 1) {
    header('Content-Type: application/json');

    try {
        if ($_POST['action'] == 'get_programs') {
            $programs_query = "SELECT id, name FROM programs ORDER BY name";
            $programs_stmt = $conn->prepare($programs_query);
            $programs_stmt->execute();
            $programs = $programs_stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['success' => true, 'data' => $programs]);
        } elseif ($_POST['action'] == 'get_batches') {
            $program_id = sanitize_input($_POST['program_id']);
            $batches_query = "SELECT id, name, year FROM batch WHERE program_id = ? ORDER BY year DESC, name";
            $batches_stmt = $conn->prepare($batches_query);
            $batches_stmt->execute([$program_id]);
            $batches = $batches_stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['success' => true, 'data' => $batches]);
        } elseif ($_POST['action'] == 'get_courses') {
            $program_id = sanitize_input($_POST['program_id']);
            $batch_id = sanitize_input($_POST['batch_id']);
            // Only show courses taught by the current instructor for the selected program and batch
            $courses_query = "SELECT c.id, c.code, c.name 
                              FROM course c
                              WHERE c.program_id = ? AND c.batch_id = ? AND c.status = 'active' AND c.instructor_id = ?
                              ORDER BY c.name";
            $courses_stmt = $conn->prepare($courses_query);
            $courses_stmt->execute([$program_id, $batch_id, $instructor_id]);
            $courses = $courses_stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['success' => true, 'data' => $courses]);
        } elseif ($_POST['action'] == 'get_students') {
            $course_id = sanitize_input($_POST['course_id']); // sax - waa course_id, ma ahan batch_id
            $attendance_date = sanitize_input($_POST['attendance_date']);

            // Hel batch_id ka socda course
            $batch_query = "SELECT batch_id FROM course WHERE id = ?";
            $batch_stmt = $conn->prepare($batch_query);
            $batch_stmt->execute([$course_id]);
            $batch_id = $batch_stmt->fetchColumn();

            if ($batch_id) {
                // Fetch students in the same batch
                $students_query = "
                    SELECT DISTINCT 
                           u.id, 
                           u.full_name, 
                           e.student_id AS unique_student_id
                    FROM users u
                    INNER JOIN enrollment e ON u.id = e.user_id
                    INNER JOIN course c ON e.course_id = c.id
                    INNER JOIN batch b ON c.batch_id = b.id
                    WHERE u.role = 'student' 
                      AND b.id = ? 
                      AND u.status = 'active'
                    ORDER BY u.full_name
                ";
                $students_stmt = $conn->prepare($students_query);
                $students_stmt->execute([$batch_id]);
                $students = $students_stmt->fetchAll(PDO::FETCH_ASSOC);
            } else {
                $students = [];
            }

            // Get existing attendance for this course + date
            $existing_attendance = [];
            $attendance_query = "SELECT student_id, status FROM attendance WHERE course_id = ? AND date = ?";
            $attendance_stmt = $conn->prepare($attendance_query);
            $attendance_stmt->execute([$course_id, $attendance_date]);
            $attendance_records = $attendance_stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($attendance_records as $record) {
                $existing_attendance[$record['student_id']] = $record['status'];
            }

            echo json_encode(['success' => true, 'data' => $students, 'attendance' => $existing_attendance]);
        } elseif ($_POST['action'] == 'take_attendance') {
            $course_id = (int)$_POST['course_id'];
            $attendance_date = $_POST['attendance_date']; // Renamed from 'date' for consistency
            $attendance_data = $_POST['attendance'] ?? [];
            
            // Log the data being processed for debugging
            error_log("Processing attendance for course_id: $course_id, date: $attendance_date, student count: " . count($attendance_data));

            // Validate required data
            if (empty($course_id) || empty($attendance_date) || empty($attendance_data)) {
                throw new Exception("Missing required data: course_id, attendance_date, or attendance data");
            }
            
            // Begin transaction
            $conn->beginTransaction();
            
            // Delete existing attendance for this date and course - only if instructor owns the course
            $delete_query = "DELETE a FROM attendance a 
                           JOIN course c ON a.course_id = c.id 
                           WHERE a.course_id = ? AND a.date = ? AND c.instructor_id = ?";
            $delete_stmt = $conn->prepare($delete_query);
            $delete_stmt->execute([$course_id, $attendance_date, $instructor_id]);
            
            // Insert new attendance records for students - FIXED: Added 'remarks' and 'updated_at'
            $insert_query = "INSERT INTO attendance (student_id, course_id, date, status, remarks, created_at, updated_at) VALUES (?, ?, ?, ?, ?, NOW(), NOW())";
            $insert_stmt = $conn->prepare($insert_query);
            
            foreach ($attendance_data as $student_id_att => $status) {
                // For now, 'remarks' is an empty string as there's no input field for it.
                // You can add an input field for remarks in the future if needed.
                $insert_stmt->execute([$student_id_att, $course_id, $attendance_date, $status, '']); 
            }
            
            $conn->commit();
            echo json_encode(['success' => true, 'message' => "Student attendance recorded successfully!"]); // Updated message
        } else {
            throw new Exception("Invalid AJAX action");
        }
    } catch(Exception $e) {
        if ($conn->inTransaction()) {
            $conn->rollBack();
        }
        error_log("AJAX Error in attendance.php: " . $e->getMessage()); // Added error logging
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit();
}

// Initial data for dropdowns (only programs needed on page load)
try {
    $programs_query = "SELECT id, name FROM programs ORDER BY name";
    $programs_stmt = $conn->prepare($programs_query);
    $programs_stmt->execute();
    $all_programs = $programs_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $all_programs = [];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Attendance - Benadir University LMS</title> <!-- Updated title -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/attendance.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/instructor-sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>Student Attendance Management</h1> <!-- Updated heading -->
               
            </div>
            
            <!-- Alert Messages -->
            <?php if (!empty($message)): ?>
                <div class="alert alert-<?php echo $messageType === 'success' ? 'success' : 'error'; ?>">
                    <i class="fas fa-<?php echo $messageType === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                    <span><?php echo htmlspecialchars($message); ?></span>
                </div>
            <?php endif; ?>
            <div id="alertContainer"></div>
          
            <!-- Selection Controls -->
            <div class="attendance-controls">
                <div class="control-group">
                    <label for="programSelect">Program:</label>
                    <select id="programSelect">
                        <option value="">Select Program</option>
                        <?php foreach ($all_programs as $program): ?>
                            <option value="<?php echo $program['id']; ?>"><?php echo $program['name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="control-group">
                    <label for="batchSelect">Batch:</label>
                    <select id="batchSelect" disabled>
                        <option value="">Select Batch</option>
                    </select>
                </div>
                <div class="control-group">
                    <label for="courseSelect">Course:</label>
                    <select id="courseSelect" disabled>
                        <option value="">Select Course</option>
                    </select>
                </div>
                <div class="control-group">
                    <label for="attendanceDate">Date:</label>
                    <input type="date" id="attendanceDate" name="attendanceDate" value="<?php echo date('Y-m-d'); ?>">
                </div>
            </div>
            
            <!-- Student Attendance Form -->
            <div id="studentAttendanceFormContainer" class="attendance-form-container hidden"> <!-- Updated ID -->
                <form method="POST" id="studentAttendanceForm"> <!-- Updated ID -->
                    <input type="hidden" name="action" value="take_attendance">
                    <input type="hidden" id="form_course_id" name="course_id">
                    <input type="hidden" id="form_attendance_date" name="attendance_date"> <!-- Renamed from form_date -->
                    
                    <div class="attendance-header">
                        <h3>Take Student Attendance</h3> <!-- Updated heading -->
                        <div class="attendance-actions">
                            <button type="button" class="btn btn-sm btn-success" onclick="markAllPresent()">Mark All Present</button>
                            <button type="button" class="btn btn-sm btn-danger" onclick="markAllAbsent()">Mark All Absent</button>
                            <button type="submit" class="btn btn-primary">Save Attendance</button>
                        </div>
                    </div>
                    
                    <div class="attendance-table">
                        <table id="studentAttendanceTable"> <!-- Updated ID -->
                            <thead>
                                <tr>
                                    <th>Student Name</th> <!-- Updated header -->
                                    <th>Student ID</th>   <!-- Updated header -->
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Students will be loaded here via JavaScript -->
                            </tbody>
                        </table>
                    </div>
                </form>
            </div>
            
            <div id="emptyState" class="empty-state">
                <i class="fas fa-chalkboard-teacher"></i>
                <h3>Select Program, Batch, and Course</h3>
                <p>Please select a program, batch, and course to manage student attendance.</p>
            </div>
        </div>
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const programSelect = document.getElementById('programSelect');
        const batchSelect = document.getElementById('batchSelect');
        const courseSelect = document.getElementById('courseSelect');
        const attendanceDateInput = document.getElementById('attendanceDate');
        const studentAttendanceFormContainer = document.getElementById('studentAttendanceFormContainer'); // Updated ID
        const studentAttendanceTableBody = document.querySelector('#studentAttendanceTable tbody'); // Updated ID
        const emptyState = document.getElementById('emptyState');
        const studentAttendanceForm = document.getElementById('studentAttendanceForm'); // Updated ID

        // Function to show alert messages
        function showAlert(message, type = 'success') {
            const alertContainer = document.getElementById('alertContainer');
            if (!alertContainer) {
                console.error('Alert container not found!');
                return;
            }
            const alert = document.createElement('div');
            alert.className = `alert alert-${type}`;
            alert.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i> <span>${message}</span>`; // Added icon
            alertContainer.innerHTML = ''; // Clear previous alerts
            alertContainer.appendChild(alert);
            setTimeout(() => {
                alert.remove();
            }, 5000);
        }

        // Load batches based on selected program
        async function loadBatches(programId, selectedBatchId = '') {
            batchSelect.innerHTML = '<option value="">Loading Batches...</option>';
            batchSelect.disabled = true;
            courseSelect.innerHTML = '<option value="">Select Course</option>';
            courseSelect.disabled = true;
            studentAttendanceFormContainer.classList.add('hidden'); // Updated ID
            emptyState.classList.remove('hidden');

            if (!programId) {
                batchSelect.innerHTML = '<option value="">Select Batch</option>';
                return;
            }

            try {
                const formData = new FormData();
                formData.append('ajax', 1);
                formData.append('action', 'get_batches');
                formData.append('program_id', programId);

                const response = await fetch('attendance.php', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();

                if (data.success) {
                    let options = '<option value="">Select Batch</option>';
                    if (data.data.length > 0) {
                        data.data.forEach(batch => {
                            const selected = selectedBatchId && batch.id == selectedBatchId ? 'selected' : '';
                            options += `<option value="${batch.id}" ${selected}>${batch.name} (${batch.year})</option>`;
                        });
                    } else {
                        options = '<option value="">No batches available</option>';
                    }
                    batchSelect.innerHTML = options;
                    batchSelect.disabled = false;
                } else {
                    showAlert(data.message, 'danger');
                    batchSelect.innerHTML = '<option value="">Error loading batches</option>';
                }
            } catch (error) {
                console.error('Error loading batches:', error);
                showAlert('An error occurred while loading batches.', 'danger');
                batchSelect.innerHTML = '<option value="">Error loading batches</option>';
            }
        }

        // Load courses based on selected program and batch
        async function loadCourses(programId, batchId, selectedCourseId = '') {
            courseSelect.innerHTML = '<option value="">Loading Courses...</option>';
            courseSelect.disabled = true;
            studentAttendanceFormContainer.classList.add('hidden'); // Updated ID
            emptyState.classList.remove('hidden');

            if (!programId || !batchId) {
                courseSelect.innerHTML = '<option value="">Select Course</option>';
                return;
            }

            try {
                const formData = new FormData();
                formData.append('ajax', 1);
                formData.append('action', 'get_courses');
                formData.append('program_id', programId);
                formData.append('batch_id', batchId);

                const response = await fetch('attendance.php', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();

                if (data.success) {
                    let options = '<option value="">Select Course</option>';
                    if (data.data.length > 0) {
                        data.data.forEach(course => {
                            const selected = selectedCourseId && course.id == selectedCourseId ? 'selected' : '';
                            options += `<option value="${course.id}" ${selected}>${course.code} - ${course.name}</option>`;
                        });
                    } else {
                        options = '<option value="">No courses available for this instructor in this batch/program</option>'; // Updated message
                    }
                    courseSelect.innerHTML = options;
                    courseSelect.disabled = false;
                } else {
                    showAlert(data.message, 'danger');
                    courseSelect.innerHTML = '<option value="">Error loading courses</option>';
                }
            } catch (error) {
                console.error('Error loading courses:', error);
                showAlert('An error occurred while loading courses.', 'danger');
                courseSelect.innerHTML = '<option value="">Error loading courses</option>';
            }
        }

        // Load students and their attendance for the selected course and date
        async function loadStudents(courseId, attendanceDate) { // Renamed from loadInstructors
            studentAttendanceTableBody.innerHTML = '<tr><td colspan="3" class="text-center">Loading Students...</td></tr>'; // Updated ID and text
            studentAttendanceFormContainer.classList.add('hidden'); // Updated ID
            emptyState.classList.remove('hidden');

            if (!courseId || !attendanceDate) {
                studentAttendanceTableBody.innerHTML = '<tr><td colspan="3" class="text-center">Select a course and date to view students.</td></tr>'; // Updated ID and text
                return;
            }

            try {
                const formData = new FormData();
                formData.append('ajax', 1);
                formData.append('action', 'get_students'); // Updated action
                formData.append('course_id', courseId);
                formData.append('attendance_date', attendanceDate); // Renamed from 'date'

                const response = await fetch('attendance.php', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();

                if (data.success) {
                    studentAttendanceTableBody.innerHTML = ''; // Updated ID
                    if (data.data.length > 0) {
                        data.data.forEach(student => { // Changed from instructor to student
                            const existingStatus = data.attendance[student.id] || '';
                            const row = `
                                <tr>
                                    <td>${student.full_name}</td>
                                    <td>${student.unique_student_id}</td> <!-- Displaying unique_student_id -->
                                    <td>
                                        <div class="attendance-options">
                                            <label class="attendance-option present">
                                                <input type="radio" name="attendance[${student.id}]" value="present" 
                                                       ${existingStatus === 'present' ? 'checked' : ''}>
                                                <span class="checkmark"></span>
                                                Present
                                            </label>
                                            <label class="attendance-option absent">
                                                <input type="radio" name="attendance[${student.id}]" value="absent"
                                                       ${existingStatus === 'absent' ? 'checked' : ''}>
                                                <span class="checkmark"></span>
                                                Absent
                                            </label>
                                            <label class="attendance-option late">
                                                <input type="radio" name="attendance[${student.id}]" value="late"
                                                       ${existingStatus === 'late' ? 'checked' : ''}>
                                                <span class="checkmark"></span>
                                                Late
                                            </label>
                                            <label class="attendance-option excused">
                                                <input type="radio" name="attendance[${student.id}]" value="excused"
                                                       ${existingStatus === 'excused' ? 'checked' : ''}>
                                                <span class="checkmark"></span>
                                                Excused
                                            </label>
                                        </div>
                                    </td>
                                </tr>
                            `;
                            studentAttendanceTableBody.insertAdjacentHTML('beforeend', row); // Updated ID
                        });
                        studentAttendanceFormContainer.classList.remove('hidden'); // Updated ID
                        emptyState.classList.add('hidden');
                        document.getElementById('form_course_id').value = courseId;
                        document.getElementById('form_attendance_date').value = attendanceDate; // Renamed ID
                    } else {
                        studentAttendanceTableBody.innerHTML = '<tr><td colspan="3" class="text-center">No students found for this course.</td></tr>'; // Updated ID and text
                        studentAttendanceFormContainer.classList.add('hidden'); // Updated ID
                        emptyState.classList.remove('hidden');
                    }
                } else {
                    showAlert(data.message, 'danger');
                    studentAttendanceTableBody.innerHTML = '<tr><td colspan="3" class="text-center">Error loading students.</td></tr>'; // Updated ID and text
                }
            } catch (error) {
                console.error('Error loading students:', error); // Updated text
                showAlert('An error occurred while loading students.', 'danger'); // Updated text
                studentAttendanceTableBody.innerHTML = '<tr><td colspan="3" class="text-center">Error loading students.</td></tr>'; // Updated ID and text
            }
        }

        // Event Listeners for dropdowns and date picker
        programSelect.addEventListener('change', function() {
            loadBatches(this.value);
            courseSelect.innerHTML = '<option value="">Select Course</option>'; // Clear courses
            courseSelect.disabled = true;
            studentAttendanceFormContainer.classList.add('hidden'); // Updated ID
            emptyState.classList.remove('hidden');
        });

        batchSelect.addEventListener('change', function() {
            loadCourses(programSelect.value, this.value);
            studentAttendanceFormContainer.classList.add('hidden'); // Updated ID
            emptyState.classList.remove('hidden');
        });

        courseSelect.addEventListener('change', function() {
            loadStudents(this.value, attendanceDateInput.value); // Renamed function call
        });

        attendanceDateInput.addEventListener('change', function() {
            loadStudents(courseSelect.value, this.value); // Renamed function call
        });

        // Mark all present/absent functions
        window.markAllPresent = function() {
            const presentRadios = document.querySelectorAll('input[type="radio"][value="present"]');
            presentRadios.forEach(radio => {
                radio.checked = true;
            });
        }
        
        window.markAllAbsent = function() {
            const absentRadios = document.querySelectorAll('input[type="radio"][value="absent"]');
            absentRadios.forEach(radio => {
                radio.checked = true;
            });
        }

        // Form validation and submission - FIXED: Always send ajax=1 and action=take_attendance
        studentAttendanceForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const saveBtn = this.querySelector('button[type="submit"]');
            saveBtn.disabled = true;
            saveBtn.textContent = 'Saving...';

            // Create FormData from the form
            const formData = new FormData(this);
            
            // CRITICAL FIX: Always ensure ajax=1 and action=take_attendance are included
            formData.set('ajax', '1');
            formData.set('action', 'take_attendance');
            
            // Debug: Log what we're sending
            console.log('Sending attendance data:');
            for (let [key, value] of formData.entries()) {
                console.log(key, value);
            }
            
            try {
                const response = await fetch('attendance.php', {
                    method: 'POST',
                    body: formData
                });
                
                // Check if response is ok
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                
                // Get response text first to check if it's valid JSON
                const responseText = await response.text();
                console.log('Raw response:', responseText);
                
                let data;
                try {
                    data = JSON.parse(responseText);
                } catch (jsonError) {
                    console.error('Invalid JSON response:', responseText);
                    throw new Error('Server returned invalid JSON response');
                }

                if (data.success) {
                    showAlert(data.message, 'success');
                    // Reload students to show updated attendance status
                    loadStudents(courseSelect.value, attendanceDateInput.value);
                } else {
                    showAlert(data.message, 'danger');
                }
            } catch (error) {
                console.error('Error saving attendance:', error);
                showAlert('An error occurred while saving attendance: ' + error.message, 'danger');
            } finally {
                saveBtn.disabled = false;
                saveBtn.textContent = 'Save Attendance';
            }
        });

        // Initial load: if a program/batch/course is pre-selected (e.g., from a redirect), load subsequent data
        // This part is commented out as the page will always load with "Select Program" initially.
        // If you need to pre-select values based on URL parameters, you'd add logic here.
        // const initialProgramId = programSelect.value;
        // if (initialProgramId) {
        //     loadBatches(initialProgramId, '<?php //echo $selected_batch_id; ?>');
        //     // Further nested calls for courses and students if needed
        // }
    });
    </script>
    
    <script src="../assets/js/theme.js"></script>
</body>
</html>
