<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is an instructor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'instructor') {
    header('Location: ../login.php');
    exit();
}

$instructor_id = $_SESSION['user_id'];

if (isset($_POST['ajax']) && $_POST['ajax'] == '1') {
    header('Content-Type: application/json');
    
    if ($_POST['action'] == 'get_messages') {
        $student_id = (int)$_POST['student_id'];
        
        try {
            // Get messages for the selected student
            $messages_query = "SELECT c.*, u.full_name as sender_name, u.profile_photo as sender_photo
                              FROM chats c
                              JOIN users u ON c.sender_id = u.id
                              WHERE (c.sender_id = ? AND c.receiver_id = ?) OR (c.sender_id = ? AND c.receiver_id = ?)
                              ORDER BY c.created_at ASC";
            
            $messages_stmt = $conn->prepare($messages_query);
            $messages_stmt->execute([$instructor_id, $student_id, $student_id, $instructor_id]);
            $messages = $messages_stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Get student info
            $student_query = "SELECT u.id, u.full_name, u.email, u.profile_photo
                             FROM users u
                             JOIN enrollment e ON u.id = e.user_id
                             JOIN batch b ON e.batch_id = b.id
                             JOIN course c ON c.batch_id = b.id
                             WHERE u.id = ? AND c.instructor_id = ? AND u.role = 'student'
                             LIMIT 1";
            
            $student_stmt = $conn->prepare($student_query);
            $student_stmt->execute([$student_id, $instructor_id]);
            $student = $student_stmt->fetch(PDO::FETCH_ASSOC);
            
            // Mark messages as read
            $mark_read_query = "UPDATE chats SET is_read = 1 WHERE sender_id = ? AND receiver_id = ?";
            $mark_read_stmt = $conn->prepare($mark_read_query);
            $mark_read_stmt->execute([$student_id, $instructor_id]);
            
            echo json_encode([
                'success' => true,
                'messages' => $messages,
                'student' => $student
            ]);
            
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['ajax'])) {
    $student_id = (int)$_POST['student_id'];
    $message = trim($_POST['message']);
    $attachment_path = null;
    $attachment_mime_type = null;
    
    // Handle file upload
    if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../uploads/chat/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $file_extension = pathinfo($_FILES['attachment']['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '.' . $file_extension;
        $attachment_path = 'uploads/chat/' . $filename;
        
        if (move_uploaded_file($_FILES['attachment']['tmp_name'], $upload_dir . $filename)) {
            $attachment_mime_type = $_FILES['attachment']['type'];
        }
    }
    
    if (!empty($message) || $attachment_path) {
        try {
            $insert_query = "INSERT INTO chats (sender_id, receiver_id, message, attachment_path, attachment_mime_type, created_at) 
                            VALUES (?, ?, ?, ?, ?, NOW())";
            $insert_stmt = $conn->prepare($insert_query);
            $insert_stmt->execute([$instructor_id, $student_id, $message, $attachment_path, $attachment_mime_type]);
            
            // Return JSON response for AJAX requests
            if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
                header('Content-Type: application/json');
                echo json_encode(['success' => true]);
                exit();
            }
            
        } catch (Exception $e) {
            if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
                exit();
            }
        }
    }
    
    // Redirect back to the same student
    header("Location: chats.php?student_id=" . $student_id);
    exit();
}

$selected_student_id = isset($_GET['student_id']) ? (int)$_GET['student_id'] : null;

// Get instructor's students for chat list
try {
    $students_query = "SELECT DISTINCT u.id, u.full_name, u.email, u.profile_photo,
                      b.name as batch_name, b.id as batch_id,
                      (SELECT COUNT(*) FROM chats WHERE sender_id = u.id AND receiver_id = ? AND is_read = 0) as unread_count,
                      (SELECT created_at FROM chats WHERE (sender_id = u.id AND receiver_id = ?) OR (sender_id = ? AND receiver_id = u.id) ORDER BY created_at DESC LIMIT 1) as last_message_time
                      FROM users u
                      JOIN enrollment e ON u.id = e.user_id
                      JOIN batch b ON e.batch_id = b.id
                      JOIN course c ON c.batch_id = b.id
                      WHERE c.instructor_id = ? AND u.role = 'student' AND u.status = 'active'
                      ORDER BY u.full_name ASC";
    
    $students_stmt = $conn->prepare($students_query);
    $students_stmt->execute([$instructor_id, $instructor_id, $instructor_id, $instructor_id]);
    $students = $students_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // If no student selected, select the first one
    if (!$selected_student_id && count($students) > 0) {
        $selected_student_id = $students[0]['id'];
    }
    
    // Get selected student info
    $selected_student = null;
    if ($selected_student_id) {
        foreach ($students as $student) {
            if ($student['id'] == $selected_student_id) {
                $selected_student = $student;
                break;
            }
        }
    }
    
    // Get chat messages for selected student
    $messages = [];
    if ($selected_student_id) {
        $messages_query = "SELECT c.*, u.full_name as sender_name, u.profile_photo as sender_photo
                          FROM chats c
                          JOIN users u ON c.sender_id = u.id
                          WHERE (c.sender_id = ? AND c.receiver_id = ?) OR (c.sender_id = ? AND c.receiver_id = ?)
                          ORDER BY c.created_at ASC";
        
        $messages_stmt = $conn->prepare($messages_query);
        $messages_stmt->execute([$instructor_id, $selected_student_id, $selected_student_id, $instructor_id]);
        $messages = $messages_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Mark messages as read
        $mark_read_query = "UPDATE chats SET is_read = 1 WHERE sender_id = ? AND receiver_id = ?";
        $mark_read_stmt = $conn->prepare($mark_read_query);
        $mark_read_stmt->execute([$selected_student_id, $instructor_id]);
    }
    
} catch(PDOException $e) {
    error_log("Error fetching chat data: " . $e->getMessage());
    $students = [];
    $messages = [];
}

// Handle AJAX requests
if (isset($_POST['ajax'])) {
    header('Content-Type: application/json');
    
    if ($_POST['action'] === 'send_message') {
        $receiver_id = (int)$_POST['receiver_id'];
        $message = trim($_POST['message']);
        $attachment_path = null;
        $attachment_mime_type = null;
        
        // Handle file upload
        if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../uploads/chat_attachments/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            $file_extension = pathinfo($_FILES['attachment']['name'], PATHINFO_EXTENSION);
            $filename = 'chat_' . uniqid() . '.' . $file_extension;
            $attachment_path = $upload_dir . $filename;
            $attachment_mime_type = $_FILES['attachment']['type'];
            
            if (!move_uploaded_file($_FILES['attachment']['tmp_name'], $attachment_path)) {
                echo json_encode(['success' => false, 'message' => 'Failed to upload file']);
                exit();
            }
            
            // Store relative path
            $attachment_path = 'uploads/chat_attachments/' . $filename;
        }
        
        if (!empty($message) || $attachment_path) {
            try {
                $insert_query = "INSERT INTO chats (sender_id, receiver_id, message, attachment_path, attachment_mime_type, created_at) 
                               VALUES (?, ?, ?, ?, ?, NOW())";
                $insert_stmt = $conn->prepare($insert_query);
                $insert_stmt->execute([$instructor_id, $receiver_id, $message, $attachment_path, $attachment_mime_type]);
                
                echo json_encode(['success' => true]);
            } catch(PDOException $e) {
                echo json_encode(['success' => false, 'message' => 'Failed to send message']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Message cannot be empty']);
        }
        exit();
    }
    
    if ($_POST['action'] === 'get_messages') {
        $student_id = (int)$_POST['student_id'];
        
        try {
            $messages_query = "SELECT c.*, u.full_name as sender_name, u.profile_photo as sender_photo
                              FROM chats c
                              JOIN users u ON c.sender_id = u.id
                              WHERE (c.sender_id = ? AND c.receiver_id = ?) OR (c.sender_id = ? AND c.receiver_id = ?)
                              ORDER BY c.created_at ASC";
            
            $messages_stmt = $conn->prepare($messages_query);
            $messages_stmt->execute([$instructor_id, $student_id, $student_id, $instructor_id]);
            $messages = $messages_stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Mark messages as read
            $mark_read_query = "UPDATE chats SET is_read = 1 WHERE sender_id = ? AND receiver_id = ?";
            $mark_read_stmt = $conn->prepare($mark_read_query);
            $mark_read_stmt->execute([$student_id, $instructor_id]);
            
            echo json_encode(['success' => true, 'messages' => $messages]);
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Failed to fetch messages']);
        }
        exit();
    }
    
    // New AJAX action to get new messages
    if ($_POST['action'] === 'get_new_messages') {
        $student_id = (int)$_POST['student_id'];
        $last_check = $_POST['last_check'];
        
        try {
            $new_messages_query = "SELECT c.*, u.full_name as sender_name, u.profile_photo as sender_photo
                                  FROM chats c
                                  JOIN users u ON c.sender_id = u.id
                                  WHERE (c.sender_id = ? AND c.receiver_id = ?) OR (c.sender_id = ? AND c.receiver_id = ?)
                                  AND c.created_at > ?
                                  ORDER BY c.created_at ASC";
            
            $new_messages_stmt = $conn->prepare($new_messages_query);
            $new_messages_stmt->execute([$instructor_id, $student_id, $student_id, $instructor_id, $last_check]);
            $new_messages = $new_messages_stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $timestamp = date('Y-m-d H:i:s');
            
            echo json_encode(['success' => true, 'messages' => $new_messages, 'timestamp' => $timestamp]);
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Failed to fetch new messages']);
        }
        exit();
    }
    
    // New AJAX action to mark typing status
    if ($_POST['action'] === 'mark_typing') {
        $student_id = (int)$_POST['chat_partner_id'];
        
        try {
            $typing_query = "INSERT INTO typing_status (user_id, is_typing) VALUES (?, 1) ON DUPLICATE KEY UPDATE is_typing = 1";
            $typing_stmt = $conn->prepare($typing_query);
            $typing_stmt->execute([$student_id]);
            
            echo json_encode(['success' => true]);
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Failed to mark typing status']);
        }
        exit();
    }
    
    // New AJAX action to get typing status
    if ($_POST['action'] === 'get_typing_status') {
        try {
            $typing_status_query = "SELECT user_id FROM typing_status WHERE is_typing = 1";
            $typing_status_stmt = $conn->prepare($typing_status_query);
            $typing_status_stmt->execute();
            $typing_users = $typing_status_stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode(['success' => true, 'typing_users' => $typing_users]);
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Failed to fetch typing status']);
        }
        exit();
    }
    
    // New AJAX action to update online status
    if ($_POST['action'] === 'update_online_status') {
        try {
            $online_status_query = "INSERT INTO online_status (user_id, is_online) VALUES (?, 1) ON DUPLICATE KEY UPDATE is_online = 1";
            $online_status_stmt = $conn->prepare($online_status_query);
            $online_status_stmt->execute([$instructor_id]);
            
            echo json_encode(['success' => true]);
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Failed to update online status']);
        }
        exit();
    }
    
    // New AJAX action to clear typing status
    if ($_POST['action'] === 'clear_typing') {
        $student_id = (int)$_POST['chat_partner_id'];
        
        try {
            $clear_typing_query = "UPDATE typing_status SET is_typing = 0 WHERE user_id = ?";
            $clear_typing_stmt = $conn->prepare($clear_typing_query);
            $clear_typing_stmt->execute([$student_id]);
            
            echo json_encode(['success' => true]);
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Failed to clear typing status']);
        }
        exit();
    }
    
    // New AJAX action to check typing status
    if ($_POST['action'] === 'check_typing') {
        $student_id = (int)$_POST['chat_partner_id'];
        
        try {
            $check_typing_query = "SELECT is_typing FROM typing_status WHERE user_id = ?";
            $check_typing_stmt = $conn->prepare($check_typing_query);
            $check_typing_stmt->execute([$student_id]);
            $typing_status = $check_typing_stmt->fetch(PDO::FETCH_ASSOC);
            
            echo json_encode(['success' => true, 'is_typing' => $typing_status['is_typing'] ?? 0]);
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Failed to check typing status']);
        }
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chats - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <?php echo FONT_AWESOME_CSS; ?>
    <style>
        .chat-container {
            display: flex;
            height: calc(100vh - 120px);
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .chat-sidebar {
            width: 300px;
            border-right: 1px solid #e0e0e0;
            background: #f8f9fa;
            display: flex;
            flex-direction: column;
        }
        
        .chat-sidebar-header {
            padding: 20px;
            border-bottom: 1px solid #e0e0e0;
            background: #fff;
        }
        
        .chat-sidebar-header h3 {
            margin: 0;
            color: #333;
            font-size: 18px;
        }
        
        .students-list {
            flex: 1;
            overflow-y: auto;
        }
        
        .student-item {
            padding: 15px 20px;
            border-bottom: 1px solid #e0e0e0;
            cursor: pointer;
            transition: background-color 0.2s;
            position: relative;
        }
        
        .student-item:hover {
            background: #e9ecef;
        }
        
        .student-item.active {
            background: #007bff;
            color: white;
        }
        
        .student-item.active .student-name,
        .student-item.active .student-course {
            color: white;
        }
        
        .student-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #ddd;
            display: inline-block;
            vertical-align: middle;
            margin-right: 12px;
            object-fit: cover;
        }
        
        .student-info {
            display: inline-block;
            vertical-align: middle;
            width: calc(100% - 60px);
        }
        
        .student-name {
            font-weight: 600;
            color: #333;
            margin: 0;
            font-size: 14px;
        }
        
        .student-course {
            color: #666;
            font-size: 12px;
            margin: 2px 0 0 0;
        }
        
        .unread-badge {
            position: absolute;
            top: 10px;
            right: 15px;
            background: #dc3545;
            color: white;
            border-radius: 10px;
            padding: 2px 6px;
            font-size: 11px;
            font-weight: bold;
        }
        
        .chat-main {
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        
        .chat-header {
            padding: 20px;
            border-bottom: 1px solid #e0e0e0;
            background: #fff;
            display: flex;
            align-items: center;
        }
        
        .chat-header-avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            margin-right: 15px;
            object-fit: cover;
        }
        
        .chat-header-info h3 {
            margin: 0;
            color: #333;
            font-size: 18px;
        }
        
        .chat-header-info p {
            margin: 2px 0 0 0;
            color: #666;
            font-size: 14px;
        }
        
        .chat-messages {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            background: #f8f9fa;
        }
        
        .message {
            margin-bottom: 15px;
            display: flex;
            align-items: flex-start;
        }
        
        .message.sent {
            flex-direction: row-reverse;
        }
        
        .message-avatar {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            margin: 0 10px;
            object-fit: cover;
        }
        
        .message-content {
            max-width: 70%;
            background: #fff;
            padding: 12px 16px;
            border-radius: 18px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        
        .message.sent .message-content {
            background: #007bff;
            color: white;
        }
        
        .message-text {
            margin: 0;
            line-height: 1.4;
        }
        
        .message-attachment {
            margin-top: 8px;
        }
        
        .message-attachment a {
            color: #007bff;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            padding: 8px 12px;
            background: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #e0e0e0;
        }
        
        .message.sent .message-attachment a {
            color: white;
            background: rgba(255,255,255,0.2);
            border-color: rgba(255,255,255,0.3);
        }
        
        .message-time {
            font-size: 11px;
            color: #999;
            margin-top: 5px;
        }
        
        .message.sent .message-time {
            color: rgba(255,255,255,0.8);
        }
        
        .chat-input {
            padding: 20px;
            border-top: 1px solid #e0e0e0;
            background: #fff;
        }
        
        .chat-input-form {
            display: flex;
            align-items: flex-end;
            gap: 10px;
        }
        
        .chat-input-wrapper {
            flex: 1;
            position: relative;
        }
        
        .chat-input-field {
            width: 100%;
            padding: 12px 50px 12px 16px;
            border: 1px solid #ddd;
            border-radius: 25px;
            resize: none;
            font-family: inherit;
            font-size: 14px;
            max-height: 100px;
            min-height: 44px;
        }
        
        .chat-input-field:focus {
            outline: none;
            border-color: #007bff;
        }
        
        .attachment-btn {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #666;
            cursor: pointer;
            padding: 5px;
        }
        
        .attachment-btn:hover {
            color: #007bff;
        }
        
        .send-btn {
            background: #007bff;
            color: white;
            border: none;
            border-radius: 50%;
            width: 44px;
            height: 44px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background-color 0.2s;
        }
        
        .send-btn:hover {
            background: #0056b3;
        }
        
        .send-btn:disabled {
            background: #ccc;
            cursor: not-allowed;
        }
        
        .no-chat-selected {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100%;
            color: #666;
            font-size: 18px;
        }
        
        .attachment-preview {
            margin-top: 10px;
            padding: 8px 12px;
            background: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #e0e0e0;
            display: none;
        }
        
        .attachment-preview-content {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .attachment-info {
            display: flex;
            align-items: center;
        }
        
        .attachment-info i {
            margin-right: 8px;
            color: #666;
        }
        
        .remove-attachment {
            background: none;
            border: none;
            color: #dc3545;
            cursor: pointer;
            padding: 2px 5px;
        }
        
        /* Added typing indicator animation styles */
        .typing-indicator .message-content {
            background: #f1f3f4 !important;
            padding: 8px 16px !important;
        }
        
        .typing-animation {
            display: flex;
            align-items: center;
            gap: 4px;
            height: 20px;
        }
        
        .typing-animation span {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #999;
            animation: typing 1.4s infinite ease-in-out;
        }
        
        .typing-animation span:nth-child(1) {
            animation-delay: -0.32s;
        }
        
        .typing-animation span:nth-child(2) {
            animation-delay: -0.16s;
        }
        
        @keyframes typing {
            0%, 80%, 100% {
                transform: scale(0.8);
                opacity: 0.5;
            }
            40% {
                transform: scale(1);
                opacity: 1;
            }
        }
        
        .student-item.has-unread {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
        }
        
        .student-item.online::after {
            content: '';
            position: absolute;
            top: 15px;
            left: 45px;
            width: 12px;
            height: 12px;
            background: #28a745;
            border: 2px solid white;
            border-radius: 50%;
        }
        
        @media (max-width: 768px) {
            .chat-container {
                flex-direction: column;
                height: calc(100vh - 80px);
            }
            
            .chat-sidebar {
                width: 100%;
                height: 200px;
            }
            
            .students-list {
                display: flex;
                overflow-x: auto;
                overflow-y: hidden;
            }
            
            .student-item {
                min-width: 200px;
                border-right: 1px solid #e0e0e0;
                border-bottom: none;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/instructor-sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>Chats</h1>
                <div class="admin-header-right">
                    <span class="chat-count"><?php echo count($students); ?> students</span>
                </div>
            </div>
            
            <div class="chat-container">
                <div class="chat-sidebar">
                    <div class="chat-sidebar-header">
                        <h3>Students</h3>
                    </div>
                    <div class="students-list">
                        <?php foreach ($students as $student): ?>
                        <div class="student-item <?php echo $student['id'] == $selected_student_id ? 'active' : ''; ?>" 
                             data-student-id="<?php echo $student['id']; ?>"
                             onclick="selectStudent(<?php echo $student['id']; ?>)">
                            <img src="<?php echo $student['profile_photo'] ?: '../assets/images/default-avatar.png'; ?>" 
                                 alt="<?php echo $student['full_name']; ?>" class="student-avatar">
                            <div class="student-info">
                                <p class="student-name"><?php echo $student['full_name']; ?></p>
                            </div>
                            <?php if ($student['unread_count'] > 0): ?>
                            <span class="unread-badge"><?php echo $student['unread_count']; ?></span>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                        
                        <?php if (count($students) === 0): ?>
                        <div style="padding: 20px; text-align: center; color: #666;">
                            No students found
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="chat-main">
                    <?php if ($selected_student): ?>
                    <div class="chat-header">
                        <img src="<?php echo $selected_student['profile_photo'] ?: '../assets/images/default-avatar.png'; ?>" 
                             alt="<?php echo $selected_student['full_name']; ?>" class="chat-header-avatar">
                        <div class="chat-header-info">
                            <h3><?php echo $selected_student['full_name']; ?></h3>
                        </div>
                    </div>
                    
                    <div class="chat-messages" id="chatMessages">
                        <?php foreach ($messages as $message): ?>
                        <div class="message <?php echo $message['sender_id'] == $instructor_id ? 'sent' : 'received'; ?>">
                            <img src="<?php echo $message['sender_photo'] ?: '../assets/images/default-avatar.png'; ?>" 
                                 alt="<?php echo $message['sender_name']; ?>" class="message-avatar">
                            <div class="message-content">
                                <?php if (!empty($message['message'])): ?>
                                <p class="message-text"><?php echo nl2br(htmlspecialchars($message['message'])); ?></p>
                                <?php endif; ?>
                                
                                <?php if ($message['attachment_path']): ?>
                                <div class="message-attachment">
                                    <a href="../<?php echo $message['attachment_path']; ?>" target="_blank">
                                        <i class="fas fa-paperclip"></i>
                                        <?php echo basename($message['attachment_path']); ?>
                                    </a>
                                </div>
                                <?php endif; ?>
                                
                                <div class="message-time">
                                    <?php echo date('M d, Y H:i', strtotime($message['created_at'])); ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="chat-input">
                        <!-- Updated message form to use AJAX and current student ID -->
                        <form id="messageForm" class="message-form" method="POST" enctype="multipart/form-data">
                            <input type="hidden" id="studentIdInput" name="student_id" value="<?php echo $selected_student_id; ?>">
                            <div class="message-input-container">
                                <textarea id="messageInput" name="message" placeholder="Type your message..." rows="1"></textarea>
                                <input type="file" id="attachmentInput" name="attachment" style="display: none;" accept="*/*">
                                <button type="button" class="attachment-btn" onclick="document.getElementById('attachmentInput').click()">
                                    <i class="fas fa-paperclip"></i>
                                </button>
                                <button type="submit" class="send-btn">
                                    <i class="fas fa-paper-plane"></i>
                                </button>
                            </div>
                            <div id="attachmentPreview" class="attachment-preview" style="display: none;"></div>
                        </form>
                    </div>
                    <?php else: ?>
                    <div class="no-chat-selected">
                        <p>Select a student to start chatting</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    let currentStudentId = <?php echo $selected_student_id ?: 'null'; ?>;
    let messagePolling;
    let typingTimeout;
    let lastMessageCheck = '<?php echo date('Y-m-d H:i:s'); ?>';
    let isTyping = false;
    const displayedMessageIds = new Set();
    
    function selectStudent(studentId) {
        if (studentId === currentStudentId) return;
        
        // Clear typing status for previous chat
        if (currentStudentId) {
            clearTypingStatus();
        }
        
        // Update URL
        window.history.pushState({}, '', `chats.php?student_id=${studentId}`);
        
        // Update UI
        document.querySelectorAll('.student-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-student-id="${studentId}"]`).classList.add('active');
        
        displayedMessageIds.clear();
        
        // Load messages
        loadMessages(studentId);
        currentStudentId = studentId;
        
        document.getElementById('studentIdInput').value = studentId;
        
        // Reset last message check time
        lastMessageCheck = new Date().toISOString().slice(0, 19).replace('T', ' ');
    }
    
    function loadMessages(studentId) {
        const formData = new FormData();
        formData.append('ajax', '1');
        formData.append('action', 'get_messages');
        formData.append('student_id', studentId);
        
        fetch('chats.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateChatMessages(data.messages, data.student);
            }
        })
        .catch(error => console.error('Error:', error));
    }
    
    function updateChatMessages(messages, student) {
        // Update chat header
        const chatHeader = document.querySelector('.chat-header');
        if (chatHeader && student) {
            chatHeader.innerHTML = `
                <img src="${student.profile_photo || '../assets/images/default-avatar.png'}" 
                     alt="${student.full_name}" class="chat-header-avatar">
                <div class="chat-header-info">
                    <h3>${student.full_name}</h3>
                    <p>${student.course_name}</p>
                </div>
            `;
        }
        
        // Update messages
        const chatMessages = document.getElementById('chatMessages');
        if (chatMessages) {
            chatMessages.innerHTML = '';
            displayedMessageIds.clear();
            
            const instructorId = <?php echo $instructor_id; ?>;
            
            messages.forEach(message => {
                displayedMessageIds.add(message.id);
                
                const messageDiv = document.createElement('div');
                messageDiv.className = `message ${message.sender_id == instructorId ? 'sent' : 'received'}`;
                messageDiv.setAttribute('data-message-id', message.id);
                
                let attachmentHtml = '';
                if (message.attachment_path) {
                    attachmentHtml = `
                        <div class="message-attachment">
                            <a href="../${message.attachment_path}" target="_blank">
                                <i class="fas fa-paperclip"></i>
                                ${message.attachment_path.split('/').pop()}
                            </a>
                        </div>
                    `;
                }
                
                messageDiv.innerHTML = `
                    <img src="${message.sender_photo || '../assets/images/default-avatar.png'}" 
                         alt="${message.sender_name}" class="message-avatar">
                    <div class="message-content">
                        ${message.message ? `<p class="message-text">${message.message.replace(/\n/g, '<br>')}</p>` : ''}
                        ${attachmentHtml}
                        <div class="message-time">
                            ${new Date(message.created_at).toLocaleDateString('en-US', {
                                month: 'short', day: 'numeric', year: 'numeric',
                                hour: '2-digit', minute: '2-digit'
                            })}
                        </div>
                    </div>
                `;
                
                chatMessages.appendChild(messageDiv);
            });
            
            // Scroll to bottom
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
    }
    
    document.getElementById('messageForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (!currentStudentId) {
            alert('Please select a student first');
            return;
        }
        
        const formData = new FormData(this);
        const messageInput = document.getElementById('messageInput');
        const message = messageInput.value.trim();
        
        if (!message && !formData.get('attachment').name) {
            return;
        }
        
        // Send message via AJAX
        fetch('chats.php', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Clear form
                messageInput.value = '';
                messageInput.style.height = 'auto';
                document.getElementById('attachmentInput').value = '';
                document.getElementById('attachmentPreview').style.display = 'none';
                
                // This prevents duplicate messages when sending
                // loadMessages(currentStudentId);
            } else {
                alert('Error sending message: ' + (data.error || 'Unknown error'));
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error sending message');
        });
    });

    document.getElementById('messageInput').addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 100) + 'px';
        
        // Mark as typing when user types
        if (this.value.trim() && currentStudentId) {
            markTyping();
        }
    });
    
    if (currentStudentId) {
        // Check for new messages every 2 seconds
        messagePolling = setInterval(checkNewMessages, 2000);
        
        // Check typing status every 1 second
        setInterval(checkTypingStatus, 1000);
        
        // Update online status every 30 seconds
        setInterval(updateOnlineStatus, 30000);
        
        // Initial online status update
        updateOnlineStatus();
    }
    
    // Cleanup on page unload
    window.addEventListener('beforeunload', function() {
        if (messagePolling) {
            clearInterval(messagePolling);
        }
        clearTypingStatus();
    });
    
    function checkNewMessages() {
        if (!currentStudentId) return;
        
        const formData = new FormData();
        formData.append('action', 'get_new_messages');
        formData.append('chat_partner_id', currentStudentId);
        formData.append('last_check', lastMessageCheck);
        
        fetch('../api/chat-realtime.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success && data.messages.length > 0) {
                appendNewMessages(data.messages);
                lastMessageCheck = data.timestamp;
            }
        })
        .catch(error => console.error('Error checking new messages:', error));
    }
    
    function appendNewMessages(messages) {
        const chatMessages = document.getElementById('chatMessages');
        const instructorId = <?php echo $instructor_id; ?>;
        let hasNewMessages = false;
        
        messages.forEach(message => {
            // Skip if message already displayed
            if (displayedMessageIds.has(message.id)) {
                return;
            }
            
            displayedMessageIds.add(message.id);
            hasNewMessages = true;
            
            const messageDiv = document.createElement('div');
            messageDiv.className = `message ${message.sender_id == instructorId ? 'sent' : 'received'}`;
            messageDiv.setAttribute('data-message-id', message.id);
            
            let attachmentHtml = '';
            if (message.attachment_path) {
                attachmentHtml = `
                    <div class="message-attachment">
                        <a href="../${message.attachment_path}" target="_blank">
                            <i class="fas fa-paperclip"></i>
                            ${message.attachment_path.split('/').pop()}
                        </a>
                    </div>
                `;
            }
            
            messageDiv.innerHTML = `
                <img src="${message.sender_photo || '../assets/images/default-avatar.png'}" 
                     alt="${message.sender_name}" class="message-avatar">
                <div class="message-content">
                    ${message.message ? `<p class="message-text">${message.message.replace(/\n/g, '<br>')}</p>` : ''}
                    ${attachmentHtml}
                    <div class="message-time">
                        ${new Date(message.created_at).toLocaleDateString('en-US', {
                            month: 'short', day: 'numeric', year: 'numeric',
                            hour: '2-digit', minute: '2-digit'
                        })}
                    </div>
                </div>
            `;
            
            chatMessages.appendChild(messageDiv);
        });
        
        if (hasNewMessages) {
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
    }
    
    function markTyping() {
        if (!currentStudentId || isTyping) return;
        
        isTyping = true;
        const formData = new FormData();
        formData.append('action', 'mark_typing');
        formData.append('chat_partner_id', currentStudentId);
        
        fetch('../api/chat-realtime.php', {
            method: 'POST',
            body: formData
        });
        
        // Clear typing after 3 seconds of inactivity
        clearTimeout(typingTimeout);
        typingTimeout = setTimeout(() => {
            clearTypingStatus();
        }, 3000);
    }
    
    function clearTypingStatus() {
        if (!isTyping) return;
        
        isTyping = false;
        const formData = new FormData();
        formData.append('action', 'clear_typing');
        formData.append('chat_partner_id', currentStudentId);
        
        fetch('../api/chat-realtime.php', {
            method: 'POST',
            body: formData
        });
    }
    
    function checkTypingStatus() {
        if (!currentStudentId) return;
        
        const formData = new FormData();
        formData.append('action', 'check_typing');
        formData.append('chat_partner_id', currentStudentId);
        
        fetch('../api/chat-realtime.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            const typingIndicator = document.getElementById('typingIndicator');
            if (data.is_typing) {
                typingIndicator.style.display = 'block';
            } else {
                typingIndicator.style.display = 'none';
            }
        })
        .catch(error => console.error('Error checking typing status:', error));
    }
    
    function updateOnlineStatus() {
        const formData = new FormData();
        formData.append('action', 'update_online_status');
        
        fetch('../api/chat-realtime.php', {
            method: 'POST',
            body: formData
        });
    }
    
    // File attachment preview
    document.getElementById('attachmentInput').addEventListener('change', function() {
        const file = this.files[0];
        const preview = document.getElementById('attachmentPreview');
        
        if (file) {
            preview.innerHTML = `
                <div class="attachment-preview-item">
                    <i class="fas fa-paperclip"></i>
                    <span>${file.name}</span>
                    <button type="button" onclick="clearAttachment()" class="remove-attachment">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            `;
            preview.style.display = 'block';
        } else {
            preview.style.display = 'none';
        }
    });
    
    function clearAttachment() {
        document.getElementById('attachmentInput').value = '';
        document.getElementById('attachmentPreview').style.display = 'none';
    }
    </script>
</body>
</html>
