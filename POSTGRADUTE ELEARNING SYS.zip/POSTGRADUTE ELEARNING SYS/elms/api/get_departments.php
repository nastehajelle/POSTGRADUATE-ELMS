<?php
header('Content-Type: application/json');
include_once '../config/init.php';

if (!isset($_GET['department_id']) || empty($_GET['department_id'])) {
    echo json_encode([]);
    exit;
}

$department_id = sanitize_input($_GET['department_id']);

try {
    $query = "SELECT id, name FROM programs WHERE department_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->execute([$department_id]);
    
    $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($departments);
} catch(PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>
