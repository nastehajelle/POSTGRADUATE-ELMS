<?php
session_start();
include_once '../config/init.php';
include_once '../includes/thesis-notifications.php';

// Check if user is logged in
if (!is_logged_in()) {
    http_response_code(401);
    exit(json_encode(['error' => 'Unauthorized']));
}

$user_id = $_SESSION['user_id'];
$action = $_GET['action'] ?? $_POST['action'] ?? '';

switch ($action) {
    case 'get_notifications':
        $limit = $_GET['limit'] ?? 20;
        $offset = $_GET['offset'] ?? 0;
        $notifications = getThesisNotifications($conn, $user_id, $limit, $offset);
        echo json_encode(['notifications' => $notifications]);
        break;

    case 'get_unread_count':
        $count = getUnreadThesisNotificationsCount($conn, $user_id);
        echo json_encode(['count' => $count]);
        break;

    case 'mark_as_read':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $notification_id = $_POST['notification_id'] ?? 0;
            $success = markThesisNotificationAsRead($conn, $notification_id, $user_id);
            echo json_encode(['success' => $success]);
        }
        break;

    case 'mark_all_as_read':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            try {
                $query = "UPDATE thesis_notifications SET is_read = 1, updated_at = NOW() WHERE recipient_id = ? AND is_read = 0";
                $stmt = $conn->prepare($query);
                $success = $stmt->execute([$user_id]);
                echo json_encode(['success' => $success]);
            } catch (PDOException $e) {
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
            }
        }
        break;

    case 'send_custom_notification':
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && is_admin()) {
            $thesis_id = $_POST['thesis_id'] ?? null;
            $recipient_ids = $_POST['recipient_ids'] ?? [];
            $title = $_POST['title'] ?? '';
            $message = $_POST['message'] ?? '';
            $type = $_POST['type'] ?? 'general';

            if (empty($recipient_ids) || empty($title) || empty($message)) {
                echo json_encode(['success' => false, 'error' => 'Missing required fields']);
                break;
            }

            $success = sendBulkThesisNotification($conn, $recipient_ids, $user_id, $type, $title, $message, $thesis_id);
            echo json_encode(['success' => $success]);
        } else {
            http_response_code(403);
            echo json_encode(['error' => 'Access denied']);
        }
        break;

    case 'delete_notification':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $notification_id = $_POST['notification_id'] ?? 0;
            try {
                $query = "DELETE FROM thesis_notifications WHERE id = ? AND recipient_id = ?";
                $stmt = $conn->prepare($query);
                $success = $stmt->execute([$notification_id, $user_id]);
                echo json_encode(['success' => $success]);
            } catch (PDOException $e) {
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
            }
        }
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Invalid action']);
}
?>
