<?php
include_once '../config/init.php';

if (isset($_GET['department_id'])) {
    $department_id = $_GET['department_id'];

    $stmt = $conn->prepare("SELECT id, name FROM programs WHERE department_id = ?");
    $stmt->execute([$department_id]);
    $programs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($programs);
    exit;
}
?>
