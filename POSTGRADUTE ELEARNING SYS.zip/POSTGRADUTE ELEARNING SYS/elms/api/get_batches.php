<?php
session_start();
include_once '../config/init.php';

header('Content-Type: application/json');

// Check if user is logged in and is admin (optional, but good practice for API endpoints)
if (!is_logged_in() || !is_admin()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

if (isset($_GET['program_id']) && !empty($_GET['program_id'])) {
    $program_id = sanitize_input($_GET['program_id']);

    try {
        // Fetch batches associated with the given program_id
        $query = "SELECT id, name, year FROM batch WHERE program_id = ? ORDER BY year DESC, name ASC";
        $stmt = $conn->prepare($query);
        $stmt->execute([$program_id]);
        $batches = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode(['success' => true, 'data' => $batches]);

    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error fetching batches: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Program ID is required.']);
}
?>
