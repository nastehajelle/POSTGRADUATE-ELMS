<?php
session_start();
require_once '../config/init.php';
require_once '../config/database.php';

// Check if user is logged in and is an instructor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'instructor') {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Not authenticated or unauthorized']);
    exit();
}

// Check if question ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Question ID is required']);
    exit();
}

$question_id = (int)$_GET['id'];
$instructor_id = $_SESSION['user_id'];

try {
    // Verify instructor has access to this question (by checking assessment ownership/access)
    $check_access_query = "SELECT aq.* FROM assessment_questions aq
                           JOIN assessments a ON aq.assessment_id = a.id
                           LEFT JOIN course c ON (a.program_id = c.program_id OR a.department_id = c.department_id)
                           WHERE aq.id = ? AND (a.created_by = ? OR (a.type = 'exam' AND c.instructor_id = ?))";
    $check_access_stmt = $conn->prepare($check_access_query);
    $check_access_stmt->execute([$question_id, $instructor_id, $instructor_id]);
    $question = $check_access_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$question) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Question not found or unauthorized access']);
        exit();
    }
    
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'question' => $question]);
    
} catch (PDOException $e) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
