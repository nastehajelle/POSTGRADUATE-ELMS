<?php
session_start();
require_once '../config/database.php';
require_once '../config/init.php';

// Check if user is logged in
if (!is_logged_in()) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Authentication required']);
    exit;
}

// Check if course ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Course ID is required']);
    exit;
}

$course_id = (int)$_GET['id'];

try {
    // First, check if the course table has the required columns
    $columns = $conn->query("DESCRIBE course");
    $column_names = [];
    while ($column = $columns->fetch(PDO::FETCH_ASSOC)) {
        $column_names[] = $column['Field'];
    }
    
    // If batch_id or instructor_id columns don't exist, add them
    if (!in_array('batch_id', $column_names) || !in_array('instructor_id', $column_names)) {
        $alter_queries = [];
        
        if (!in_array('batch_id', $column_names)) {
            $alter_queries[] = "ALTER TABLE course ADD COLUMN batch_id INT NULL";
            $alter_queries[] = "ALTER TABLE course ADD CONSTRAINT fk_course_batch FOREIGN KEY (batch_id) REFERENCES batch(id) ON DELETE SET NULL";
        }
        
        if (!in_array('instructor_id', $column_names)) {
            $alter_queries[] = "ALTER TABLE course ADD COLUMN instructor_id INT NULL";
            $alter_queries[] = "ALTER TABLE course ADD CONSTRAINT fk_course_instructor FOREIGN KEY (instructor_id) REFERENCES users(id) ON DELETE SET NULL";
        }
        
        foreach ($alter_queries as $query) {
            $conn->exec($query);
        }
        
        // Log the changes
        error_log("Added missing columns to course table: " . implode(", ", $alter_queries));
    }
    
    // Now check if enrollment table has course_id column
    $check_enrollment = $conn->query("SHOW TABLES LIKE 'enrollment'");
    if ($check_enrollment->rowCount() > 0) {
        $enrollment_columns = $conn->query("DESCRIBE enrollment");
        $enrollment_column_names = [];
        while ($column = $enrollment_columns->fetch(PDO::FETCH_ASSOC)) {
            $enrollment_column_names[] = $column['Field'];
        }
        
        // If course_id column doesn't exist in enrollment table, add it
        if (!in_array('course_id', $enrollment_column_names)) {
            // First add the column
            $conn->exec("ALTER TABLE enrollment ADD COLUMN course_id INT NULL");
            
            // Then try to add the foreign key constraint with proper error handling
            try {
                $conn->exec("ALTER TABLE enrollment ADD CONSTRAINT fk_enrollment_course FOREIGN KEY (course_id) REFERENCES course(id) ON DELETE SET NULL");
                error_log("Added course_id column and foreign key constraint to enrollment table");
            } catch (PDOException $fkError) {
                // Log the error but continue - the column is still usable even without the constraint
                error_log("Added course_id column but failed to add foreign key: " . $fkError->getMessage());
            }
        }
    }

    // Check if enrollment table exists and what columns it has
    $enrollment_exists = false;
    
    try {
        $check_table = $conn->query("SHOW TABLES LIKE 'enrollment'");
        if ($check_table->rowCount() > 0) {
            $enrollment_exists = true;
            
            // Verify that course_id exists in the enrollment table
            $columns = $conn->query("DESCRIBE enrollment");
            $column_names = [];
            while ($column = $columns->fetch(PDO::FETCH_ASSOC)) {
                $column_names[] = $column['Field'];
            }
            
            if (!in_array('course_id', $column_names)) {
                // Log this situation for debugging
                error_log("course_id column not found in enrollment table. Available columns: " . implode(", ", $column_names));
                
                // Disable enrollment checks to prevent errors
                $enrollment_exists = false;
            }
        }
    } catch (PDOException $e) {
        // If there's an error, disable enrollment checks
        $enrollment_exists = false;
        error_log("Error checking enrollment table: " . $e->getMessage());
    }

    // Get course details
    $query = "SELECT c.*, d.name as department_name, p.name as program_name, s.name as semester_name,
             b.name as batch_name, CONCAT(u.full_name, ' (', u.email, ')') as instructor_name
             FROM course c
             LEFT JOIN departments d ON c.department_id = d.id
             LEFT JOIN programs p ON c.program_id = p.id
             LEFT JOIN semester s ON c.semester_id = s.id
             LEFT JOIN batch b ON c.batch_id = b.id
             LEFT JOIN users u ON c.instructor_id = u.id
             WHERE c.id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->execute([$course_id]);
    
    if ($stmt->rowCount() === 0) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Course not found']);
        exit;
    }
    
    $course = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Get enrollment count if the table exists
    $enrollment_count = 0;
    if ($enrollment_exists) {
        try {
            // First, ensure course_id is populated for existing enrollments
            $update_query = "UPDATE enrollment e 
                        JOIN course c ON e.batch_id = c.batch_id 
                        SET e.course_id = c.id 
                        WHERE e.course_id IS NULL AND c.id = ?";
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->execute([$course_id]);
        
            // Now count enrollments
            $enroll_query = "SELECT COUNT(*) as count FROM enrollment WHERE course_id = ?";
            $enroll_stmt = $conn->prepare($enroll_query);
            $enroll_stmt->execute([$course_id]);
            $enrollment_count = $enroll_stmt->fetch(PDO::FETCH_ASSOC)['count'];
        } catch (PDOException $e) {
            // If there's an error, log it and use 0 as the enrollment count
            error_log("Error counting enrollments: " . $e->getMessage());
            $enrollment_count = 0;
        }
    }
    
    $course['enrollment_count'] = $enrollment_count;
    
    // Format dates
    $course['created_at'] = !empty($course['created_at']) ? date('F j, Y, g:i a', strtotime($course['created_at'])) : 'N/A';
    $course['updated_at'] = !empty($course['updated_at']) ? date('F j, Y, g:i a', strtotime($course['updated_at'])) : 'N/A';
    
    // Return course details
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'data' => $course]);
    
} catch (PDOException $e) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
