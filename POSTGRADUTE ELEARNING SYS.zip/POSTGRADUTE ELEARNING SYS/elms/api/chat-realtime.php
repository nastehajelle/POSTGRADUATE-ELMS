<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in
if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];

header('Content-Type: application/json');

// Handle different actions
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'get_new_messages':
        getNewMessages($conn, $user_id, $user_role);
        break;
        
    case 'mark_typing':
        markTyping($conn, $user_id);
        break;
        
    case 'get_typing_status':
        getTypingStatus($conn, $user_id);
        break;
        
    case 'update_online_status':
        updateOnlineStatus($conn, $user_id);
        break;
        
    case 'get_unread_counts':
        getUnreadCounts($conn, $user_id, $user_role);
        break;
        
    default:
        http_response_code(400);
        echo json_encode(['error' => 'Invalid action']);
}

function getNewMessages($conn, $user_id, $user_role) {
    $last_check = $_POST['last_check'] ?? date('Y-m-d H:i:s', strtotime('-1 hour'));
    $chat_partner_id = (int)($_POST['chat_partner_id'] ?? 0);
    
    if (!$chat_partner_id) {
        echo json_encode(['success' => false, 'error' => 'No chat partner specified']);
        return;
    }
    
    try {
        // Get new messages since last check
        $query = "SELECT c.*, u.full_name as sender_name, u.profile_photo as sender_photo
                  FROM chats c
                  JOIN users u ON c.sender_id = u.id
                  WHERE ((c.sender_id = ? AND c.receiver_id = ?) OR (c.sender_id = ? AND c.receiver_id = ?))
                  AND c.created_at > ?
                  ORDER BY c.created_at ASC";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([$user_id, $chat_partner_id, $chat_partner_id, $user_id, $last_check]);
        $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Mark received messages as read
        $mark_read_query = "UPDATE chats SET is_read = 1 WHERE sender_id = ? AND receiver_id = ? AND is_read = 0";
        $mark_read_stmt = $conn->prepare($mark_read_query);
        $mark_read_stmt->execute([$chat_partner_id, $user_id]);
        
        echo json_encode([
            'success' => true,
            'messages' => $messages,
            'timestamp' => date('Y-m-d H:i:s')
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Database error']);
    }
}

function markTyping($conn, $user_id) {
    $chat_partner_id = (int)($_POST['chat_partner_id'] ?? 0);
    
    if (!$chat_partner_id) {
        echo json_encode(['success' => false]);
        return;
    }
    
    try {
        // Create typing_status table if it doesn't exist
        $create_table = "CREATE TABLE IF NOT EXISTS typing_status (
            user_id INT PRIMARY KEY,
            chat_partner_id INT,
            is_typing TINYINT(1) DEFAULT 0,
            last_typing TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (chat_partner_id) REFERENCES users(id) ON DELETE CASCADE
        )";
        $conn->exec($create_table);
        
        // Update typing status
        $query = "INSERT INTO typing_status (user_id, chat_partner_id, is_typing, last_typing) 
                  VALUES (?, ?, 1, NOW()) 
                  ON DUPLICATE KEY UPDATE 
                  chat_partner_id = VALUES(chat_partner_id),
                  is_typing = 1, 
                  last_typing = NOW()";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([$user_id, $chat_partner_id]);
        
        echo json_encode(['success' => true]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Database error']);
    }
}

function getTypingStatus($conn, $user_id) {
    try {
        // Get who is typing to this user (expired after 3 seconds)
        $query = "SELECT ts.user_id, u.full_name 
                  FROM typing_status ts
                  JOIN users u ON ts.user_id = u.id
                  WHERE ts.chat_partner_id = ? 
                  AND ts.is_typing = 1 
                  AND ts.last_typing > DATE_SUB(NOW(), INTERVAL 3 SECOND)";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([$user_id]);
        $typing_users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Clear old typing statuses
        $clear_query = "UPDATE typing_status 
                       SET is_typing = 0 
                       WHERE last_typing < DATE_SUB(NOW(), INTERVAL 3 SECOND)";
        $conn->exec($clear_query);
        
        echo json_encode([
            'success' => true,
            'typing_users' => $typing_users
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Database error']);
    }
}

function updateOnlineStatus($conn, $user_id) {
    try {
        // Create online_status table if it doesn't exist
        $create_table = "CREATE TABLE IF NOT EXISTS online_status (
            user_id INT PRIMARY KEY,
            is_online TINYINT(1) DEFAULT 1,
            last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )";
        $conn->exec($create_table);
        
        // Update online status
        $query = "INSERT INTO online_status (user_id, is_online, last_seen) 
                  VALUES (?, 1, NOW()) 
                  ON DUPLICATE KEY UPDATE 
                  is_online = 1, 
                  last_seen = NOW()";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([$user_id]);
        
        echo json_encode(['success' => true]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Database error']);
    }
}

function getUnreadCounts($conn, $user_id, $user_role) {
    try {
        if ($user_role === 'instructor') {
            // Get unread counts from students
            $query = "SELECT c.sender_id, COUNT(*) as unread_count
                      FROM chats c
                      JOIN users u ON c.sender_id = u.id
                      JOIN enrollment e ON u.id = e.user_id
                      JOIN course co ON (e.course_id = co.id OR e.batch_id = co.batch_id)
                      WHERE co.instructor_id = ? 
                      AND c.receiver_id = ? 
                      AND c.is_read = 0
                      AND u.role = 'student'
                      GROUP BY c.sender_id";
        } else {
            // Get unread counts from instructors
            $query = "SELECT c.sender_id, COUNT(*) as unread_count
                      FROM chats c
                      JOIN users u ON c.sender_id = u.id
                      JOIN course co ON u.id = co.instructor_id
                      JOIN enrollment e ON (e.course_id = co.id OR e.batch_id = co.batch_id)
                      WHERE e.user_id = ? 
                      AND c.receiver_id = ? 
                      AND c.is_read = 0
                      AND u.role = 'instructor'
                      GROUP BY c.sender_id";
        }
        
        $stmt = $conn->prepare($query);
        $stmt->execute([$user_id, $user_id]);
        $unread_counts = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'unread_counts' => $unread_counts
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Database error']);
    }
}
?>
