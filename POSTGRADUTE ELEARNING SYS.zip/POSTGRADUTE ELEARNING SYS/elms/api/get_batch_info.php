<?php
header('Content-Type: application/json');
include_once '../config/init.php';

// Check if user is logged in
session_start();
if (!is_logged_in()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

// Get batch ID from request
if (!isset($_GET['batch_id'])) {
    echo json_encode(['success' => false, 'message' => 'Batch ID is required']);
    exit();
}

$batch_id = sanitize_input($_GET['batch_id']);

try {
    // Get batch information
    $query = "SELECT id, name, year FROM batch WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->execute([$batch_id]);
    
    if ($stmt->rowCount() > 0) {
        $batch = $stmt->fetch(PDO::FETCH_ASSOC);
        echo json_encode(['success' => true, 'data' => $batch]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Batch not found']);
    }
} catch(Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
