<?php
session_start();
require_once '../config/init.php';
require_once '../config/database.php';

// Check if user is logged in and is an instructor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'instructor') {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Not authenticated or unauthorized']);
    exit();
}

// Check if assessment ID is provided
if (!isset($_GET['assessment_id']) || empty($_GET['assessment_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Assessment ID is required']);
    exit();
}

$assessment_id = (int)$_GET['assessment_id'];
$instructor_id = $_SESSION['user_id'];

try {
    // Verify instructor has access to this assessment (either created it or it's an exam assigned to their course)
    $check_access_query = "SELECT a.id FROM assessments a 
                           LEFT JOIN course c ON (a.program_id = c.program_id OR a.department_id = c.department_id)
                           WHERE a.id = ? AND (a.created_by = ? OR (a.type = 'exam' AND c.instructor_id = ?))";
    $check_access_stmt = $conn->prepare($check_access_query);
    $check_access_stmt->execute([$assessment_id, $instructor_id, $instructor_id]);
    if (!$check_access_stmt->fetch()) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Unauthorized access to assessment questions']);
        exit();
    }

    $stmt = $conn->prepare("SELECT * FROM assessment_questions WHERE assessment_id = ? ORDER BY id ASC");
    $stmt->execute([$assessment_id]);
    $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'questions' => $questions]);
    
} catch (PDOException $e) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
