<?php
session_start();
require_once '../config/init.php';
require_once '../config/database.php';

// Check if user is logged in and is an instructor
if (!is_logged_in() || !is_instructor()) {
    $_SESSION['message'] = "Unauthorized access.";
    $_SESSION['message_type'] = "error";
    header('Location: ../auth/login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $course_id = isset($_POST['course_id']) ? (int)$_POST['course_id'] : 0;
    $title = sanitize_input($_POST['title']);
    $description = sanitize_input($_POST['description']);
    $uploaded_by = $_SESSION['user_id'];

    // Validate inputs
    if (empty($course_id) || empty($title) || !isset($_FILES['material_file'])) {
        $_SESSION['message'] = "All required fields (Course, Title, File) must be filled.";
        $_SESSION['message_type'] = "error";
        header('Location: ../instructor/course-materials.php' . ($course_id > 0 ? "?course_id=" . $course_id : ""));
        exit();
    }

    // Verify instructor is assigned to the selected course
    try {
        $check_course_stmt = $conn->prepare("SELECT id FROM course WHERE id = ? AND instructor_id = ?");
        $check_course_stmt->execute([$course_id, $uploaded_by]);
        if (!$check_course_stmt->fetch()) {
            $_SESSION['message'] = "You are not authorized to upload materials for this course.";
            $_SESSION['message_type'] = "error";
            header('Location: ../instructor/course-materials.php');
            exit();
        }
    } catch (PDOException $e) {
        $_SESSION['message'] = "Database error during course verification: " . $e->getMessage();
        $_SESSION['message_type'] = "error";
        header('Location: ../instructor/course-materials.php');
        exit();
    }

    $target_dir = "../uploads/materials/";
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $file_name = basename($_FILES["material_file"]["name"]);
    $target_file = $target_dir . uniqid() . "_" . $file_name; // Add unique ID to prevent overwrites
    $uploadOk = 1;
    $fileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Determine material type based on file extension
    $material_type = 'other';
    $allowed_types = [];

    switch ($fileType) {
        case 'pdf':
            $material_type = 'document';
            $allowed_types = ['pdf'];
            break;
        case 'doc':
        case 'docx':
        case 'xls':
        case 'xlsx':
        case 'ppt':
        case 'pptx':
            $material_type = 'document';
            $allowed_types = ['doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx'];
            break;
        case 'mp4':
        case 'avi':
        case 'mov':
            $material_type = 'video';
            $allowed_types = ['mp4', 'avi', 'mov'];
            break;
        case 'mp3':
        case 'wav':
            $material_type = 'audio';
            $allowed_types = ['mp3', 'wav'];
            break;
        case 'jpg':
        case 'jpeg':
        case 'png':
        case 'gif':
            $material_type = 'image';
            $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
            break;
        case 'zip':
        case 'rar':
            $material_type = 'archive';
            $allowed_types = ['zip', 'rar'];
            break;
        default:
            $material_type = 'other';
            $allowed_types = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx', 'zip', 'rar', 'jpg', 'jpeg', 'png', 'mp4', 'mp3', 'avi', 'mov', 'wav', 'gif']; // Comprehensive list for validation
            break;
    }

    // Check file size (e.g., 50MB max)
    if ($_FILES["material_file"]["size"] > 50 * 1024 * 1024) {
        $_SESSION['message'] = "Sorry, your file is too large. Max 50MB.";
        $uploadOk = 0;
    }

    // Allow certain file formats (you can customize this)
    if (!in_array($fileType, $allowed_types)) {
        $_SESSION['message'] = "Sorry, only " . implode(', ', array_unique($allowed_types)) . " files are allowed.";
        $uploadOk = 0;
    }

    if ($uploadOk == 0) {
        $_SESSION['message_type'] = "error";
        header('Location: ../instructor/course-materials.php' . ($course_id > 0 ? "?course_id=" . $course_id : ""));
        exit();
    } else {
        if (move_uploaded_file($_FILES["material_file"]["tmp_name"], $target_file)) {
            $db_file_path = str_replace('../', '', $target_file); // Path to store in DB

            try {
                $stmt = $conn->prepare("INSERT INTO course_materials (course_id, title, description, material_type, file_path, uploaded_by, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
                if ($stmt->execute([$course_id, $title, $description, $material_type, $db_file_path, $uploaded_by])) {
                    $_SESSION['message'] = "The file ". htmlspecialchars($file_name). " has been uploaded.";
                    $_SESSION['message_type'] = "success";
                } else {
                    $_SESSION['message'] = "Error saving file info to database.";
                    $_SESSION['message_type'] = "error";
                    // If DB insert fails, delete the uploaded file
                    unlink($target_file);
                }
            } catch (PDOException $e) {
                $_SESSION['message'] = "Database error: " . $e->getMessage();
                $_SESSION['message_type'] = "error";
                unlink($target_file);
            }
        } else {
            $_SESSION['message'] = "Sorry, there was an error uploading your file.";
            $_SESSION['message_type'] = "error";
        }
    }
    header('Location: ../instructor/course-materials.php' . ($course_id > 0 ? "?course_id=" . $course_id : ""));
    exit();
}
?>
