<?php
header('Content-Type: application/json');
include_once '../config/init.php';

// Check if user is logged in and is admin
session_start();
if (!is_logged_in() || !is_admin()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['student_id']) || !isset($data['batch_id']) || empty($data['batch_id'])) {
    echo json_encode(['success' => false, 'message' => 'Missing required parameters. Batch selection is required.']);
    exit();
}

$student_id = $data['student_id'];
$batch_id = $data['batch_id'];

try {
    // Begin transaction
    $conn->beginTransaction();
    
    // Get program and department information for student ID generation and check department match
    // We only need the batch's program_id and department_id for the department match check.
    // The generate_student_id function now only needs batch_id.
    $enrollment_query = "SELECT 
                            e.program_id, 
                            e.department_id, 
                            p.department_id as batch_dept_id,
                            b.program_id as batch_program_id
                         FROM enrollment e
                         JOIN batch b ON b.id = ?
                         JOIN programs p ON b.program_id = p.id
                         WHERE e.user_id = ?";

    $enrollment_stmt = $conn->prepare($enrollment_query);
    $enrollment_stmt->execute([$batch_id, $student_id]);
    $enrollment_info = $enrollment_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$enrollment_info) {
        throw new Exception("Enrollment information not found for student or batch.");
    }

    // Check if student's department matches batch's department
    if ($enrollment_info['department_id'] != $enrollment_info['batch_dept_id']) {
        throw new Exception("Student's department does not match the batch's department.");
    }
    
    // Generate student ID using the new format
    // The generate_student_id function now only requires batch_id and the connection
    $generated_student_id = generate_student_id($batch_id, $conn);
    
    // Update enrollment with batch_id and generated student_id
    $enrollment_update_query = "UPDATE enrollment SET batch_id = ?, student_id = ? WHERE user_id = ?";
    $enrollment_update_stmt = $conn->prepare($enrollment_update_query);
    $enrollment_update_stmt->execute([$batch_id, $generated_student_id, $student_id]);
    
    // Update user status to active
    $user_query = "UPDATE users SET status = 'active' WHERE id = ?";
    $user_stmt = $conn->prepare($user_query);
    $user_stmt->execute([$student_id]);
    
    // Commit transaction
    $conn->commit();
    
    echo json_encode(['success' => true, 'message' => 'Student approved successfully', 'student_id' => $generated_student_id]);
} catch(Exception $e) {
    // Rollback transaction on error
    if ($conn->inTransaction()) {
        $conn->rollBack();
    }
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
