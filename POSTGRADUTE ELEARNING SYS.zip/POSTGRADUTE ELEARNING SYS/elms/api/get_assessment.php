<?php
session_start();
include_once '../config/init.php';
include_once '../config/database.php';

header('Content-Type: application/json');

// Check if user is logged in and is instructor
if (!is_logged_in() || !is_instructor()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$instructor_id = $_SESSION['user_id'];
$assessment_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$assessment_id) {
    echo json_encode(['success' => false, 'message' => 'Assessment ID required']);
    exit();
}

try {
    $query = "SELECT * FROM assessments WHERE id = ? AND created_by = ?";
    $stmt = $conn->prepare($query);
    $stmt->execute([$assessment_id, $instructor_id]);
    $assessment = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($assessment) {
        echo json_encode(['success' => true, 'assessment' => $assessment]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Assessment not found']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error']);
}
?>
