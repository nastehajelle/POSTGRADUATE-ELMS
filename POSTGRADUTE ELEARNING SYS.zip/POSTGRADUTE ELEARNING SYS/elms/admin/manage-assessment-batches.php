<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is an admin
if (!is_logged_in() || !is_admin()) {
    header("Location: ../auth/login.php");
    exit();
}

$assessment_id = isset($_GET['assessment_id']) ? intval($_GET['assessment_id']) : 0;
$assessment = null;
$batch_questions = [];
$message = '';
$messageType = '';

if ($assessment_id <= 0) {
    header("Location: assessments_admin.php");
    exit();
}

try {
    // Get assessment details
    $assessment_query = "SELECT a.*, 
                                d.name as department_name, 
                                p.name as program_name,
                                u.full_name as creator_name
                         FROM assessments a
                         LEFT JOIN departments d ON a.department_id = d.id
                         LEFT JOIN programs p ON a.program_id = p.id
                         LEFT JOIN users u ON a.created_by = u.id
                         WHERE a.id = ?";
    $assessment_stmt = $conn->prepare($assessment_query);
    $assessment_stmt->execute([$assessment_id]);
    $assessment = $assessment_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$assessment) {
        header("Location: assessments_admin.php");
        exit();
    }

    // Get batch-wise question statistics
    $batch_stats_query = "SELECT 
                            b.id as batch_id,
                            b.name as batch_name,
                            p.name as program_name,
                            d.name as department_name,
                            COUNT(DISTINCT aq.id) as question_count,
                            COUNT(DISTINCT aq.course_id) as course_count,
                            SUM(aq.marks) as total_marks,
                            COUNT(DISTINCT ar.student_id) as submission_count,
                            GROUP_CONCAT(DISTINCT CONCAT(c.code, ' - ', c.name) SEPARATOR ', ') as courses
                          FROM batch b
                          JOIN programs p ON b.program_id = p.id
                          JOIN departments d ON p.department_id = d.id
                          LEFT JOIN assessment_questions aq ON b.id = aq.batch_id AND aq.assessment_id = ?
                          LEFT JOIN course c ON aq.course_id = c.id
                          LEFT JOIN assessment_results ar ON ar.assessment_id = ? AND ar.student_id IN (
                              SELECT e.user_id FROM enrollment e WHERE e.batch_id = b.id
                          )
                          WHERE b.status = 'active'";
    
    // Filter by assessment scope
    $batch_params = [$assessment_id, $assessment_id];
    if ($assessment['program_id']) {
        $batch_stats_query .= " AND p.id = ?";
        $batch_params[] = $assessment['program_id'];
    } elseif ($assessment['department_id']) {
        $batch_stats_query .= " AND d.id = ?";
        $batch_params[] = $assessment['department_id'];
    }
    
    $batch_stats_query .= " GROUP BY b.id, b.name, p.name, d.name ORDER BY d.name, p.name, b.name";
    
    $batch_stats_stmt = $conn->prepare($batch_stats_query);
    $batch_stats_stmt->execute($batch_params);
    $batch_questions = $batch_stats_stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log("Error fetching assessment batch data: " . $e->getMessage());
    $message = "Error loading assessment batch information.";
    $messageType = "danger";
}

// Function to get assessment scope display
function getAssessmentScope($assessment) {
    if ($assessment['program_id'] && $assessment['program_name']) {
        return $assessment['program_name'] . ' Program';
    } elseif ($assessment['department_id'] && $assessment['department_name']) {
        return $assessment['department_name'] . ' Department';
    } else {
        return 'System-wide';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Assessment Batches - <?php echo htmlspecialchars($assessment['title'] ?? ''); ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <?php echo FONT_AWESOME_CSS; ?>
    <style>
        .assessment-info {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
            border-left: 4px solid var(--primary-color);
        }

        .assessment-meta {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }

        .meta-item {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .meta-label {
            font-size: 0.85rem;
            color: var(--text-muted);
            font-weight: 500;
        }

        .meta-value {
            font-size: 1rem;
            color: var(--text-color);
            font-weight: 600;
        }

        .batches-grid {
            display: grid;
            gap: 20px;
            margin-top: 20px;
        }

        .batch-card {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 20px;
            box-shadow: var(--shadow);
            border-left: 4px solid #8b5cf6;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .batch-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }

        .batch-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }

        .batch-title {
            font-size: 1.3rem;
            font-weight: 600;
            color: var(--text-color);
            margin: 0 0 8px 0;
        }

        .batch-program {
            color: var(--text-muted);
            font-size: 0.9rem;
        }

        .batch-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 15px;
            margin: 15px 0;
            padding: 15px;
            background: var(--bg-light);
            border-radius: 8px;
        }

        .stat-item {
            display: flex;
            flex-direction: column;
            gap: 2px;
            text-align: center;
        }

        .stat-value {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary-color);
        }

        .stat-label {
            font-size: 0.8rem;
            color: var(--text-muted);
            font-weight: 500;
        }

        .batch-courses {
            margin: 15px 0;
            padding: 10px;
            background: var(--bg-secondary);
            border-radius: 6px;
            font-size: 0.9rem;
            color: var(--text-muted);
        }

        .batch-actions {
            display: flex;
            gap: 10px;
            margin-top: 20px;
            flex-wrap: wrap;
        }

        .btn-action {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-primary {
            background: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            color: white;
            text-decoration: none;
        }

        .btn-success {
            background: #10b981;
            color: white;
        }

        .btn-success:hover {
            background: #059669;
            color: white;
            text-decoration: none;
        }

        .btn-warning {
            background: #f59e0b;
            color: white;
        }

        .btn-warning:hover {
            background: #d97706;
            color: white;
            text-decoration: none;
        }

        .status-indicator {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 500;
        }

        .status-ready {
            background: #d1fae5;
            color: #047857;
        }

        .status-partial {
            background: #fef3c7;
            color: #b45309;
        }

        .status-empty {
            background: #fee2e2;
            color: #b91c1c;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-muted);
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.3;
        }

        .batch-notice {
            background: #f3e8ff;
            color: #7c3aed;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #8b5cf6;
        }

        .batch-notice i {
            margin-right: 8px;
        }

        @media (max-width: 768px) {
            .assessment-meta {
                grid-template-columns: 1fr;
            }
            
            .batch-stats {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .batch-actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>Manage Assessment Batches</h1>
                <a href="assessments_admin.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Assessments
                </a>
            </div>
            
            <?php if (!empty($message)): ?>
                <div class="message <?php echo $messageType; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <?php if ($assessment): ?>
                 Assessment Information 
                <div class="assessment-info">
                    <h2><?php echo htmlspecialchars($assessment['title']); ?></h2>
                    <p style="color: var(--text-muted); margin: 5px 0 0 0;">
                        <i class="fas fa-tag"></i> <?php echo ucfirst($assessment['type']); ?>
                    </p>
                    <div class="assessment-meta">
                        <div class="meta-item">
                            <span class="meta-label">Type</span>
                            <span class="meta-value"><?php echo ucfirst($assessment['type']); ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Scope</span>
                            <span class="meta-value"><?php echo getAssessmentScope($assessment); ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Created By</span>
                            <span class="meta-value"><?php echo htmlspecialchars($assessment['creator_name']); ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Total Marks</span>
                            <span class="meta-value"><?php echo $assessment['total_marks']; ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Start Time</span>
                            <span class="meta-value"><?php echo date('M j, Y g:i A', strtotime($assessment['start_time'])); ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">End Time</span>
                            <span class="meta-value"><?php echo date('M j, Y g:i A', strtotime($assessment['end_time'])); ?></span>
                        </div>
                    </div>
                </div>

                 Batch Notice 
                <div class="batch-notice">
                    <i class="fas fa-layer-group"></i>
                    <strong>Batch Management:</strong> This view shows all batches within the assessment scope and their question status. Each batch must have its own set of questions created by instructors.
                </div>

                 Batches Grid 
                <div class="batches-grid">
                    <?php if (!empty($batch_questions)): ?>
                        <?php foreach ($batch_questions as $batch): ?>
                            <?php
                            $status_class = 'status-empty';
                            $status_text = 'No Questions';
                            
                            if ($batch['question_count'] > 0) {
                                if ($batch['total_marks'] >= ($assessment['total_marks'] * 0.8)) {
                                    $status_class = 'status-ready';
                                    $status_text = 'Ready';
                                } else {
                                    $status_class = 'status-partial';
                                    $status_text = 'Partial';
                                }
                            }
                            ?>
                            <div class="batch-card">
                                <div class="batch-header">
                                    <div>
                                        <h3 class="batch-title"><?php echo htmlspecialchars($batch['batch_name']); ?></h3>
                                        <p class="batch-program">
                                            <?php echo htmlspecialchars($batch['program_name'] . ' - ' . $batch['department_name']); ?>
                                        </p>
                                    </div>
                                    <span class="status-indicator <?php echo $status_class; ?>">
                                        <?php echo $status_text; ?>
                                    </span>
                                </div>
                                
                                <div class="batch-stats">
                                    <div class="stat-item">
                                        <span class="stat-value"><?php echo $batch['question_count']; ?></span>
                                        <span class="stat-label">Questions</span>
                                    </div>
                                    <div class="stat-item">
                                        <span class="stat-value"><?php echo $batch['course_count']; ?></span>
                                        <span class="stat-label">Courses</span>
                                    </div>
                                    <div class="stat-item">
                                        <span class="stat-value"><?php echo $batch['total_marks'] ?? 0; ?></span>
                                        <span class="stat-label">Total Marks</span>
                                    </div>
                                    <div class="stat-item">
                                        <span class="stat-value"><?php echo $batch['submission_count']; ?></span>
                                        <span class="stat-label">Submissions</span>
                                    </div>
                                </div>
                                
                                <?php if (!empty($batch['courses'])): ?>
                                    <div class="batch-courses">
                                        <strong>Courses with Questions:</strong> <?php echo htmlspecialchars($batch['courses']); ?>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="batch-actions">
                                    <a href="view-batch-questions.php?assessment_id=<?php echo $assessment_id; ?>&batch_id=<?php echo $batch['batch_id']; ?>" class="btn-action btn-primary">
                                        <i class="fas fa-eye"></i> View Questions
                                    </a>
                                    
                                    <?php if ($batch['submission_count'] > 0): ?>
                                        <a href="view-batch-results.php?assessment_id=<?php echo $assessment_id; ?>&batch_id=<?php echo $batch['batch_id']; ?>" class="btn-action btn-success">
                                            <i class="fas fa-chart-bar"></i> View Results
                                        </a>
                                    <?php endif; ?>
                                    
                                    <a href="export-batch-report.php?assessment_id=<?php echo $assessment_id; ?>&batch_id=<?php echo $batch['batch_id']; ?>" class="btn-action btn-warning">
                                        <i class="fas fa-download"></i> Export Report
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-layer-group"></i>
                            <h3>No Batches Found</h3>
                            <p>No batches found within the scope of this assessment. Please check the assessment configuration.</p>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
</body>
</html>
