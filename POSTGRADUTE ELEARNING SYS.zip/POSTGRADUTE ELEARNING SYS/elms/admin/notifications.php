<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is admin
if (!is_logged_in() || !is_admin()) {
    header("Location: ../auth/login.php");
    exit();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'create':
                $title = sanitize_input($_POST['title']);
                $message = sanitize_input($_POST['message']);
                $type = sanitize_input($_POST['type']);
                $priority = sanitize_input($_POST['priority']);
                $target_audience = sanitize_input($_POST['target_audience']);
                
                try {
                    $query = "INSERT INTO notifications (title, message, type, priority, target_audience, created_by, created_at) 
                             VALUES (?, ?, ?, ?, ?, ?, NOW())";
                    $stmt = $conn->prepare($query);
                    $stmt->execute([$title, $message, $type, $priority, $target_audience, $_SESSION['user_id']]);
                    
                    $_SESSION['success_message'] = "Notification posted successfully!";
                } catch (PDOException $e) {
                    $_SESSION['error_message'] = "Error creating notification: " . $e->getMessage();
                }
                
                // Redirect to prevent duplicate submission
                header("Location: notifications.php");
                exit();
                break;
                
            case 'delete':
                $notification_id = (int)$_POST['notification_id'];
                try {
                    $delete_notification = "DELETE FROM notifications WHERE id = ?";
                    $stmt = $conn->prepare($delete_notification);
                    $stmt->execute([$notification_id]);
                    
                    $_SESSION['success_message'] = "Notification deleted successfully!";
                } catch (PDOException $e) {
                    $_SESSION['error_message'] = "Error deleting notification: " . $e->getMessage();
                }
                
                // Redirect to prevent duplicate submission
                header("Location: notifications.php");
                exit();
                break;
                
            case 'toggle_status':
                $notification_id = (int)$_POST['notification_id'];
                try {
                    $toggle_query = "UPDATE notifications SET is_active = NOT is_active WHERE id = ?";
                    $stmt = $conn->prepare($toggle_query);
                    $stmt->execute([$notification_id]);
                    
                    $_SESSION['success_message'] = "Notification status updated successfully!";
                } catch (PDOException $e) {
                    $_SESSION['error_message'] = "Error updating notification: " . $e->getMessage();
                }
                
                // Redirect to prevent duplicate submission
                header("Location: notifications.php");
                exit();
                break;
        }
    }
}

// Get messages from session and clear them
$success_message = $_SESSION['success_message'] ?? null;
$error_message = $_SESSION['error_message'] ?? null;
unset($_SESSION['success_message'], $_SESSION['error_message']);

// Get all notifications
try {
    $notifications_query = "SELECT n.*, 
                           COALESCE(u.full_name, 'Admin User') as created_by_name
                           FROM notifications n 
                           LEFT JOIN users u ON n.created_by = u.id 
                           ORDER BY n.created_at DESC";
    
    $notifications_stmt = $conn->prepare($notifications_query);
    $notifications_stmt->execute();
    $notifications = $notifications_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // If there's still an error, let's try without the JOIN
    try {
        $simple_query = "SELECT n.*, 'Admin User' as created_by_name FROM notifications n ORDER BY n.created_at DESC";
        $notifications_stmt = $conn->prepare($simple_query);
        $notifications_stmt->execute();
        $notifications = $notifications_stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e2) {
        $error_message = "Error fetching notifications: " . $e2->getMessage();
        $notifications = [];
    }
}

// Get notification statistics - Fixed version
try {
    // First, let's check if the table exists and get basic count
    $basic_count_query = "SELECT COUNT(*) as total FROM notifications";
    $basic_stmt = $conn->prepare($basic_count_query);
    $basic_stmt->execute();
    $basic_result = $basic_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($basic_result && $basic_result['total'] > 0) {
        // Table exists and has data, now get detailed stats
        $stats_query = "SELECT 
                        COUNT(*) as total_notifications,
                        COUNT(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 1 END) as this_week,
                        COUNT(CASE WHEN priority = 'high' THEN 1 END) as high_priority,
                        COUNT(CASE WHEN is_active = 1 OR is_active IS NULL THEN 1 END) as active_notifications
                        FROM notifications";
        $stats_stmt = $conn->prepare($stats_query);
        $stats_stmt->execute();
        $stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);
        
        // Debug: Let's also check what's actually in the database
        $debug_query = "SELECT id, title, priority, is_active, created_at FROM notifications LIMIT 5";
        $debug_stmt = $conn->prepare($debug_query);
        $debug_stmt->execute();
        $debug_results = $debug_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // If stats are still zero but we have notifications, there might be a data issue
        if ($stats['total_notifications'] == 0 && count($notifications) > 0) {
            // Fallback: calculate stats from the notifications array
            $stats['total_notifications'] = count($notifications);
            $stats['active_notifications'] = count(array_filter($notifications, function($n) {
                return $n['is_active'] == 1 || $n['is_active'] === null;
            }));
            $stats['high_priority'] = count(array_filter($notifications, function($n) {
                return $n['priority'] === 'high';
            }));
            $stats['this_week'] = count(array_filter($notifications, function($n) {
                return strtotime($n['created_at']) >= strtotime('-7 days');
            }));
        }
    } else {
        // No data in table
        $stats = ['total_notifications' => 0, 'this_week' => 0, 'high_priority' => 0, 'active_notifications' => 0];
    }
} catch (PDOException $e) {
    // If there's an error with the stats query, calculate from the notifications array
    if (!empty($notifications)) {
        $stats = [
            'total_notifications' => count($notifications),
            'active_notifications' => count(array_filter($notifications, function($n) {
                return $n['is_active'] == 1 || $n['is_active'] === null;
            })),
            'high_priority' => count(array_filter($notifications, function($n) {
                return $n['priority'] === 'high';
            })),
            'this_week' => count(array_filter($notifications, function($n) {
                return strtotime($n['created_at']) >= strtotime('-7 days');
            }))
        ];
    } else {
        $stats = ['total_notifications' => 0, 'this_week' => 0, 'high_priority' => 0, 'active_notifications' => 0];
    }
}

// Ensure stats array has all required keys
$stats = array_merge([
    'total_notifications' => 0, 
    'this_week' => 0, 
    'high_priority' => 0, 
    'active_notifications' => 0
], $stats ?? []);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications - Benadir LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/notifications.css">
    <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
    <div class="admin-container">
        <?php include '../includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1><i class="fas fa-bullhorn"></i> Notification Center</h1>
                <div class="admin-header-right">
                    <button class="btn btn-primary" onclick="openCreateModal()">
                        <i class="fas fa-plus"></i> Post Announcement
                    </button>
                    <div class="admin-profile">
                        <img src="../assets/images/default-avatar.png" alt="Admin">
                        <span><?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Admin'); ?></span>
                    </div>
                </div>
            </div>

            <?php if ($success_message): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo htmlspecialchars($success_message); ?>
                </div>
            <?php endif; ?>

            <?php if ($error_message): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo htmlspecialchars($error_message); ?>
                </div>
            <?php endif; ?>

            <!-- Debug Information (remove in production) -->
            <?php if (isset($debug_results) && !empty($debug_results)): ?>
                <div class="alert alert-info" style="margin-bottom: 20px;">
                    <strong>Debug Info:</strong> Found <?php echo count($notifications); ?> notifications in display, 
                    Stats query returned: Total=<?php echo $stats['total_notifications']; ?>, 
                    Active=<?php echo $stats['active_notifications']; ?>, 
                    High Priority=<?php echo $stats['high_priority']; ?>, 
                    This Week=<?php echo $stats['this_week']; ?>
                </div>
            <?php endif; ?>

            <!-- Statistics Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-bullhorn"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php echo $stats['total_notifications']; ?></h3>
                        <p>Total Announcements</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-eye"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php echo $stats['active_notifications']; ?></h3>
                        <p>Active Announcements</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-calendar-week"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php echo $stats['this_week']; ?></h3>
                        <p>This Week</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php echo $stats['high_priority']; ?></h3>
                        <p>High Priority</p>
                    </div>
                </div>
            </div>

            <!-- Notifications List -->
            <div class="content-card">
                <div class="card-header">
                    <h2><i class="fas fa-list"></i> All Announcements</h2>
                </div>
                <div class="card-content">
                    <?php if (empty($notifications)): ?>
                        <div class="empty-state">
                            <i class="fas fa-bullhorn"></i>
                            <h3>No announcements yet</h3>
                            <p>Create your first announcement to keep everyone informed.</p>
                        </div>
                    <?php else: ?>
                        <div class="notifications-list">
                            <?php foreach ($notifications as $notification): ?>
                                <div class="notification-item priority-<?php echo $notification['priority']; ?> <?php echo $notification['is_active'] ? 'active' : 'inactive'; ?>">
                                    <div class="notification-header">
                                        <div class="notification-title-section">
                                            <h3><?php echo htmlspecialchars($notification['title']); ?></h3>
                                            <div class="notification-badges">
                                                <span class="type-badge type-<?php echo $notification['type']; ?>">
                                                    <?php echo ucfirst($notification['type']); ?>
                                                </span>
                                                <span class="priority-badge priority-<?php echo ucfirst($notification['priority']); ?>">
                                                    <?php echo ucfirst($notification['priority']); ?>
                                                </span>
                                                <?php if (!$notification['is_active']): ?>
                                                    <span class="status-badge inactive">Inactive</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="notification-actions">
                                            <button class="btn btn-sm btn-secondary" onclick="toggleNotificationStatus(<?php echo $notification['id']; ?>)">
                                                <i class="fas fa-<?php echo $notification['is_active'] ? 'eye-slash' : 'eye'; ?>"></i>
                                            </button>
                                            <button class="btn btn-sm btn-danger" onclick="deleteNotification(<?php echo $notification['id']; ?>)">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="notification-content">
                                        <p><?php echo nl2br(htmlspecialchars($notification['message'])); ?></p>
                                    </div>
                                    <div class="notification-meta">
                                        <div class="meta-item">
                                            <i class="fas fa-users"></i>
                                            <span>Audience: <?php echo ucfirst($notification['target_audience']); ?></span>
                                        </div>
                                        <div class="meta-item">
                                            <i class="fas fa-user"></i>
                                            <span>By: <?php echo htmlspecialchars($notification['created_by_name'] ?? 'Unknown User'); ?></span>
                                        </div>
                                        <div class="meta-item">
                                            <i class="fas fa-clock"></i>
                                            <span><?php echo date('M j, Y g:i A', strtotime($notification['created_at'])); ?></span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Create Notification Modal -->
    <div id="createModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2><i class="fas fa-plus"></i> Create New Announcement</h2>
                <span class="close" onclick="closeCreateModal()">&times;</span>
            </div>
            <form method="POST" class="modal-form">
                <input type="hidden" name="action" value="create">
                
                <div class="form-group">
                    <label for="title">Announcement Title</label>
                    <input type="text" id="title" name="title" required placeholder="Enter announcement title">
                </div>
                
                <div class="form-group">
                    <label for="message">Message</label>
                    <textarea id="message" name="message" rows="4" required placeholder="Enter your announcement message"></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="type">Type</label>
                        <select id="type" name="type" required>
                            <option value="">Select Type</option>
                            <option value="general">General Announcement</option>
                            <option value="academic">Academic Notice</option>
                            <option value="event">Event</option>
                            <option value="urgent">Urgent Notice</option>
                            <option value="maintenance">System Maintenance</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="priority">Priority</label>
                        <select id="priority" name="priority" required>
                            <option value="low">Low</option>
                            <option value="medium" selected>Medium</option>
                            <option value="high">High</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="target_audience">Target Audience</label>
                    <select id="target_audience" name="target_audience" required>
                        <option value="">Select Audience</option>
                        <option value="all">All Users</option>
                        <option value="students">Students Only</option>
                        <option value="instructors">Instructors Only</option>
                    </select>
                </div>
                
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="closeCreateModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-bullhorn"></i> Post Announcement
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2><i class="fas fa-trash"></i> Delete Announcement</h2>
                <span class="close" onclick="closeDeleteModal()">&times;</span>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this announcement? This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeDeleteModal()">Cancel</button>
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="notification_id" id="deleteNotificationId">
                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Include global theme script -->
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/notifications.js"></script>
</body>
</html>
