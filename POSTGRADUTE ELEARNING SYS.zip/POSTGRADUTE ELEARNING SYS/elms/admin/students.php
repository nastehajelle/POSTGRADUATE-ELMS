<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is admin
if (!is_logged_in() || !is_admin()) {
    header("Location: ../auth/login.php");
    exit();
}

// Get all students with their details
$students_query = "SELECT u.id, u.full_name, u.email, u.phone, u.gender, u.status, u.created_at, 
               e.student_id, p.name as program_name, d.name as department_name, b.name as batch_name, b.year as batch_year,
               s.registration_date
               FROM users u 
               LEFT JOIN enrollment e ON u.id = e.user_id 
               LEFT JOIN programs p ON e.program_id = p.id 
               LEFT JOIN departments d ON e.department_id = d.id 
               LEFT JOIN batch b ON e.batch_id = b.id
               LEFT JOIN students s ON u.id = s.user_id
               WHERE u.role = 'student'
               ORDER BY u.created_at DESC";
$students_stmt = $conn->prepare($students_query);
$students_stmt->execute();
$students = $students_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all programs for filtering
$programs_query = "SELECT id, name FROM programs ORDER BY name";
$programs_stmt = $conn->prepare($programs_query);
$programs_stmt->execute();
$programs = $programs_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all departments for filtering
$departments_query = "SELECT d.id, d.name, d.program_id, p.name as program_name 
                     FROM departments d 
                     JOIN programs p ON d.program_id = p.id 
                     ORDER BY p.name, d.name";
$departments_stmt = $conn->prepare($departments_query);
$departments_stmt->execute();
$departments = $departments_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all batches for filtering
$batches_query = "SELECT id, name, year FROM batch ORDER BY year DESC, name";
$batches_stmt = $conn->prepare($batches_query);
$batches_stmt->execute();
$batches = $batches_stmt->fetchAll(PDO::FETCH_ASSOC);

// Group departments by program for easier access in JavaScript
$departments_by_program = [];
foreach ($departments as $department) {
    if (!isset($departments_by_program[$department['program_id']])) {
        $departments_by_program[$department['program_id']] = [];
    }
    $departments_by_program[$department['program_id']][] = [
        'id' => $department['id'],
        'name' => $department['name']
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Students - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/modal.css">
    <link rel="stylesheet" href="../assets/css/users.css">
    <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>Manage Students</h1>
                
                <div class="admin-header-right">
                    <button class="btn btn-primary" id="addStudentBtn" onclick="window.location.href='users.php?role=student'">Add New Student</button>
                </div>
            </div>
            
            <div id="alertContainer"></div>
            
            <!-- Filter Controls -->
            <div class="filter-controls">
                <div class="filter-item">
                    <label for="programFilter">Program:</label>
                    <select id="programFilter">
                        <option value="">All Programs</option>
                        <?php foreach ($programs as $program): ?>
                            <option value="<?php echo $program['id']; ?>"><?php echo $program['name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="filter-item">
                    <label for="departmentFilter">Department:</label>
                    <select id="departmentFilter">
                        <option value="">All Departments</option>
                        <!-- Will be populated based on selected program -->
                    </select>
                </div>
                <div class="filter-item">
                    <label for="batchFilter">Batch:</label>
                    <select id="batchFilter">
                        <option value="">All Batches</option>
                        <?php foreach ($batches as $batch): ?>
                            <option value="<?php echo $batch['id']; ?>"><?php echo $batch['name'] . ' (' . $batch['year'] . ')'; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="filter-item">
                    <label for="statusFilter">Status:</label>
                    <select id="statusFilter">
                        <option value="">All Status</option>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
                <div class="filter-item">
                    <label for="searchInput">Search:</label>
                    <input type="text" id="searchInput" placeholder="Name, Email, ID...">
                </div>
            </div>
            
            <!-- Students List -->
            <div class="card">
                <div class="card-body">
                    <table class="data-table" id="studentsTable">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Program / Department</th>
                                <th>Batch</th>
                                <th>Student ID</th>
                                <th>Status</th>
                                <th>Registration Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($students) > 0): ?>
                                <?php foreach ($students as $student): ?>
                                <tr data-program="<?php echo $student['program_name']; ?>" 
                                    data-department="<?php echo $student['department_name']; ?>" 
                                    data-batch="<?php echo $student['batch_name']; ?>" 
                                    data-status="<?php echo $student['status']; ?>"
                                    data-program-id="<?php echo isset($student['program_id']) ? $student['program_id'] : ''; ?>"
                                    data-department-id="<?php echo isset($student['department_id']) ? $student['department_id'] : ''; ?>"
                                    data-batch-id="<?php echo isset($student['batch_id']) ? $student['batch_id'] : ''; ?>">
                                    <td><?php echo $student['full_name']; ?></td>
                                    <td><?php echo $student['email']; ?></td>
                                    <td><?php echo $student['program_name'] . ' / ' . $student['department_name']; ?></td>
                                    <td><?php echo $student['batch_name'] ? $student['batch_name'] . ' (' . $student['batch_year'] . ')' : 'Not Assigned'; ?></td>
                                    <td><?php echo $student['student_id'] ? $student['student_id'] : 'Not Assigned'; ?></td>
                                    <td>
                                        <span class="status-badge <?php echo $student['status']; ?>">
                                            <?php echo ucfirst($student['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo $student['registration_date'] ? date('Y-m-d', strtotime($student['registration_date'])) : date('Y-m-d', strtotime($student['created_at'])); ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-info view-student-btn" data-id="<?php echo $student['id']; ?>">View</button>
                                        <button class="btn btn-sm btn-primary edit-student-btn" data-id="<?php echo $student['id']; ?>">Edit</button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center">No students found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- View Student Modal -->
    <div id="viewModalBackdrop" class="modal-backdrop"></div>
    <div id="viewModalContainer" class="modal-container">
        <div class="modal-header">
            <h2>Student Details</h2>
            <button class="modal-close" id="closeViewModal">&times;</button>
        </div>
        <div class="modal-body">
            <div id="studentDetails">
                <div class="user-detail-row">
                    <strong>Full Name:</strong>
                    <span id="view_full_name"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Email:</strong>
                    <span id="view_email"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Phone:</strong>
                    <span id="view_phone"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Gender:</strong>
                    <span id="view_gender"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Status:</strong>
                    <span id="view_status"></span>
                </div>
                <h3 class="section-title">Academic Information</h3>
                <div class="user-detail-row">
                    <strong>Program:</strong>
                    <span id="view_program"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Department:</strong>
                    <span id="view_department"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Batch:</strong>
                    <span id="view_batch"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Student ID:</strong>
                    <span id="view_student_id"></span>
                </div>
                <h3 class="section-title">Personal Information</h3>
                <div class="user-detail-row">
                    <strong>Mother's Name:</strong>
                    <span id="view_mother_name"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Date of Birth:</strong>
                    <span id="view_date_of_birth"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Place of Birth:</strong>
                    <span id="view_place_of_birth"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Nationality:</strong>
                    <span id="view_nationality"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Marital Status:</strong>
                    <span id="view_marital_status"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Emergency Contact:</strong>
                    <span id="view_emergency_contact"></span>
                </div>
                <h3 class="section-title">Academic Background</h3>
                <div class="user-detail-row">
                    <strong>Bachelor Institution:</strong>
                    <span id="view_bachelor_institution"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Bachelor Specialization:</strong>
                    <span id="view_bachelor_specialization"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Bachelor Location:</strong>
                    <span id="view_bachelor_location"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Bachelor Year:</strong>
                    <span id="view_bachelor_year"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Application Type:</strong>
                    <span id="view_application_type"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Language of Instruction:</strong>
                    <span id="view_language_of_instruction"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Parent Associated with University:</strong>
                    <span id="view_parent_associated"></span>
                </div>
                <div class="user-detail-row" id="parent_name_row" style="display: none;">
                    <strong>Parent Name:</strong>
                    <span id="view_parent_name"></span>
                </div>
                <div class="user-detail-row">
                    <strong>Registration Date:</strong>
                    <span id="view_registration_date"></span>
                </div>
                <div id="view_documents" class="hidden">
                    <h3 class="section-title">Documents</h3>
                    <div id="view_documents_list"></div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" id="closeViewBtn">Close</button>
            <button class="btn btn-primary" id="editStudentBtn">Edit Student</button>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // DOM Elements
        const alertContainer = document.getElementById('alertContainer');
        const viewModalBackdrop = document.getElementById('viewModalBackdrop');
        const viewModalContainer = document.getElementById('viewModalContainer');
        
        // Filter elements
        const programFilter = document.getElementById('programFilter');
        const departmentFilter = document.getElementById('departmentFilter');
        const batchFilter = document.getElementById('batchFilter');
        const statusFilter = document.getElementById('statusFilter');
        const searchInput = document.getElementById('searchInput');
        
        // Departments data from PHP
        const departmentsByProgram = <?php echo json_encode($departments_by_program); ?>;
        
        // Show alert message
        function showAlert(message, type = 'success') {
            const alert = document.createElement('div');
            alert.className = `alert alert-${type}`;
            alert.textContent = message;
            
            alertContainer.appendChild(alert);
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                alert.remove();
            }, 5000);
        }
        
        // Open view modal
        function openViewModal() {
            viewModalBackdrop.classList.add('show');
            viewModalContainer.classList.add('show');
        }

        // Close view modal
        function closeViewModal() {
            viewModalBackdrop.classList.remove('show');
            viewModalContainer.classList.remove('show');
        }
        
        // Populate departments dropdown based on selected program
        function populateDepartments(programId, departmentId = '') {
            departmentFilter.innerHTML = '<option value="">All Departments</option>';
            
            if (programId && departmentsByProgram[programId]) {
                departmentsByProgram[programId].forEach(department => {
                    const option = document.createElement('option');
                    option.value = department.id;
                    option.textContent = department.name;
                    
                    if (departmentId && department.id == departmentId) {
                        option.selected = true;
                    }
                    
                    departmentFilter.appendChild(option);
                });
            }
        }
        
        // Close view modal
        document.getElementById('closeViewModal').addEventListener('click', closeViewModal);
        document.getElementById('closeViewBtn').addEventListener('click', closeViewModal);

        // Close view modal when clicking on backdrop
        viewModalBackdrop.addEventListener('click', closeViewModal);
        
        // View student button click
        document.querySelectorAll('.view-student-btn').forEach(button => {
            button.addEventListener('click', function() {
                const userId = this.getAttribute('data-id');
                
                // Set loading state
                button.disabled = true;
                button.innerHTML = 'Loading...';
                
                // Fetch user data
                const formData = new FormData();
                formData.append('ajax', 1);
                formData.append('action', 'get');
                formData.append('user_id', userId);
                
                fetch('users.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    button.disabled = false;
                    button.innerHTML = 'View';
                    
                    if (data.success) {
                        const student = data.data;
                        
                        // Fill view modal with student data
                        document.getElementById('view_full_name').textContent = student.full_name;
                        document.getElementById('view_email').textContent = student.email;
                        document.getElementById('view_phone').textContent = student.phone;
                        document.getElementById('view_gender').textContent = student.gender.charAt(0).toUpperCase() + student.gender.slice(1);
                        
                        // Set status with badge
                        const statusBadge = document.createElement('span');
                        statusBadge.className = `status-badge ${student.status}`;
                        statusBadge.textContent = student.status.charAt(0).toUpperCase() + student.status.slice(1);
                        document.getElementById('view_status').innerHTML = '';
                        document.getElementById('view_status').appendChild(statusBadge);
                        
                        // Get program and department names from the table
                        const studentRow = document.querySelector(`tr [data-id="${userId}"]`).closest('tr');
                        const programDept = studentRow.cells[2].textContent.trim();
                        const [program, department] = programDept.split(' / ');
                        
                        document.getElementById('view_program').textContent = program || 'Not assigned';
                        document.getElementById('view_department').textContent = department || 'Not assigned';
                        
                        // Get batch information
                        document.getElementById('view_batch').textContent = studentRow.cells[3].textContent.trim();
                        
                        // Set student ID
                        document.getElementById('view_student_id').textContent = student.student_id || 'Not assigned';
                        
                        // Display document if any
                        const viewDocuments = document.getElementById('view_documents');
                        const viewDocumentsList = document.getElementById('view_documents_list');
                        viewDocumentsList.innerHTML = '';

                        if (student.degree_document) {
                            viewDocuments.classList.remove('hidden');
                            
                            const docList = document.createElement('ul');
                            docList.className = 'documents-list';
                            
                            const listItem = document.createElement('li');
                            const link = document.createElement('a');
                            link.href = student.degree_document;
                            
                            // Extract filename from path
                            const fileName = student.degree_document.split('/').pop();
                            link.textContent = fileName;
                            link.target = '_blank';
                            
                            listItem.appendChild(link);
                            docList.appendChild(listItem);
                            
                            viewDocumentsList.appendChild(docList);
                        } else {
                            viewDocuments.classList.add('hidden');
                        }
                        
                        // Fill additional student details with proper database values
                        document.getElementById('view_mother_name').textContent = student.mother_name || 'Not specified';
                        document.getElementById('view_date_of_birth').textContent = student.date_of_birth ? 
                            new Date(student.date_of_birth).toLocaleDateString() : 'Not specified';
                        document.getElementById('view_place_of_birth').textContent = student.place_of_birth || 'Not specified';
                        document.getElementById('view_nationality').textContent = student.nationality || 'Not specified';
                        document.getElementById('view_marital_status').textContent = student.marital_status || 'Not specified';
                        document.getElementById('view_emergency_contact').textContent = student.emergency_contact_name || 'Not specified';
                        document.getElementById('view_bachelor_institution').textContent = student.bachelor_institution || 'Not specified';
                        document.getElementById('view_bachelor_specialization').textContent = student.bachelor_specialization || 'Not specified';
                        document.getElementById('view_bachelor_location').textContent = student.bachelor_location || 'Not specified';
                        document.getElementById('view_bachelor_year').textContent = student.bachelor_year || 'Not specified';
                        document.getElementById('view_application_type').textContent = student.application_type || 'Not specified';
                        document.getElementById('view_language_of_instruction').textContent = student.language_of_instruction || 'Not specified';
                        document.getElementById('view_parent_associated').textContent = student.parent_associated_with_uni == 1 ? 'Yes' : 'No';

                        // Show parent name if associated
                        if (student.parent_associated_with_uni == 1 && student.parent_name) {
                            document.getElementById('view_parent_name').textContent = student.parent_name;
                            document.getElementById('parent_name_row').style.display = 'flex';
                        } else {
                            document.getElementById('parent_name_row').style.display = 'none';
                        }

                        document.getElementById('view_registration_date').textContent = student.registration_date ? 
                            new Date(student.registration_date).toLocaleDateString() : 
                            new Date(student.created_at).toLocaleDateString();
                        
                        // Set up edit button
                        document.getElementById('editStudentBtn').onclick = function() {
                            window.location.href = `users.php?action=edit&id=${userId}`;
                        };
                        
                        // Open view modal
                        openViewModal();
                    } else {
                        showAlert(data.message || 'Error loading student data', 'error');
                    }
                })
                .catch(error => {
                    button.disabled = false;
                    button.innerHTML = 'View';
                    console.error('Error:', error);
                    showAlert('Error loading student data', 'error');
                });
            });
        });
        
        // Edit student button click
        document.querySelectorAll('.edit-student-btn').forEach(button => {
            button.addEventListener('click', function() {
                const userId = this.getAttribute('data-id');
                window.location.href = `users.php?action=edit&id=${userId}`;
            });
        });
        
        // Populate departments when program changes
        programFilter.addEventListener('change', function() {
            populateDepartments(this.value);
            filterTable();
        });

        // Filter table when department changes
        departmentFilter.addEventListener('change', filterTable);
        
        // Filter table when batch changes
        batchFilter.addEventListener('change', filterTable);
        
        // Filter table when status changes
        statusFilter.addEventListener('change', filterTable);
        
        // Filter table when search input changes
        searchInput.addEventListener('input', filterTable);
        
        // Filter functionality
        function filterTable() {
            const programFilterValue = programFilter.value;
            const departmentFilterValue = departmentFilter.value;
            const batchFilterValue = batchFilter.value;
            const statusFilterValue = statusFilter.value.toLowerCase();
            const searchValue = searchInput.value.toLowerCase();
            
            const rows = document.querySelectorAll('#studentsTable tbody tr');
            
            rows.forEach(row => {
                const programId = row.getAttribute('data-program-id');
                const departmentId = row.getAttribute('data-department-id');
                const batchId = row.getAttribute('data-batch-id');
                const status = row.getAttribute('data-status').toLowerCase();
                const text = row.textContent.toLowerCase();
                
                const programMatch = !programFilterValue || programId === programFilterValue;
                const departmentMatch = !departmentFilterValue || departmentId === departmentFilterValue;
                const batchMatch = !batchFilterValue || batchId === batchFilterValue;
                const statusMatch = !statusFilterValue || status === statusFilterValue;
                const searchMatch = !searchValue || text.includes(searchValue);
                
                if (programMatch && departmentMatch && batchMatch && statusMatch && searchMatch) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }
    });
    </script>
</body>
</html>
