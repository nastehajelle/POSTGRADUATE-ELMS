<?php
session_start();
require_once '../config/init.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

$message = '';
$message_type = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        try {
            switch ($_POST['action']) {
                case 'create_academic_year':
                    $name = trim($_POST['name']);
                    $start_date = $_POST['start_date'];
                    $end_date = $_POST['end_date'];
                    $status = isset($_POST['is_active']) ? 'active' : 'inactive';
                    
                    if ($status === 'active') {
                        // Deactivate all other academic years
                        $stmt = $conn->prepare("UPDATE academic_year SET status = 'inactive'");
                        $stmt->execute();
                    }
                    
                    $stmt = $conn->prepare("INSERT INTO academic_year (name, start_date, end_date, status) VALUES (?, ?, ?, ?)");
                    if ($stmt->execute([$name, $start_date, $end_date, $status])) {
                        $_SESSION['message'] = 'Academic year created successfully!';
                        $_SESSION['message_type'] = 'success';
                    } else {
                        $_SESSION['message'] = 'Error creating academic year.';
                        $_SESSION['message_type'] = 'error';
                    }
                    break;
                    
                case 'edit_academic_year':
                    $id = $_POST['academic_year_id'];
                    $name = trim($_POST['name']);
                    $start_date = $_POST['start_date'];
                    $end_date = $_POST['end_date'];
                    $status = isset($_POST['is_active']) ? 'active' : 'inactive';
                    
                    if ($status === 'active') {
                        // Deactivate all other academic years
                        $stmt = $conn->prepare("UPDATE academic_year SET status = 'inactive'");
                        $stmt->execute();
                    }
                    
                    $stmt = $conn->prepare("UPDATE academic_year SET name = ?, start_date = ?, end_date = ?, status = ? WHERE id = ?");
                    if ($stmt->execute([$name, $start_date, $end_date, $status, $id])) {
                        $_SESSION['message'] = 'Academic year updated successfully!';
                        $_SESSION['message_type'] = 'success';
                    } else {
                        $_SESSION['message'] = 'Error updating academic year.';
                        $_SESSION['message_type'] = 'error';
                    }
                    break;
                    
                case 'delete_academic_year':
                    $id = $_POST['academic_year_id'];
                    $stmt = $conn->prepare("DELETE FROM academic_year WHERE id = ?");
                    if ($stmt->execute([$id])) {
                        $_SESSION['message'] = 'Academic year deleted successfully!';
                        $_SESSION['message_type'] = 'success';
                    } else {
                        $_SESSION['message'] = 'Error deleting academic year.';
                        $_SESSION['message_type'] = 'error';
                    }
                    break;
                    
                case 'create_semester':
                    $academic_year_id = $_POST['academic_year_id'];
                    $name = trim($_POST['name']);
                    $start_date = $_POST['start_date'];
                    $end_date = $_POST['end_date'];
                    $status = isset($_POST['is_active']) ? 'active' : 'inactive';
                    
                    if ($status === 'active') {
                        // Deactivate all other semesters
                        $stmt = $conn->prepare("UPDATE semester SET status = 'inactive'");
                        $stmt->execute();
                    }
                    
                    $stmt = $conn->prepare("INSERT INTO semester (academic_year_id, name, start_date, end_date, status) VALUES (?, ?, ?, ?, ?)");
                    if ($stmt->execute([$academic_year_id, $name, $start_date, $end_date, $status])) {
                        $_SESSION['message'] = 'Semester created successfully!';
                        $_SESSION['message_type'] = 'success';
                    } else {
                        $_SESSION['message'] = 'Error creating semester.';
                        $_SESSION['message_type'] = 'error';
                    }
                    break;
                    
                case 'edit_semester':
                    $id = $_POST['semester_id'];
                    $name = trim($_POST['name']);
                    $start_date = $_POST['start_date'];
                    $end_date = $_POST['end_date'];
                    $status = isset($_POST['is_active']) ? 'active' : 'inactive';
                    
                    if ($status === 'active') {
                        // Deactivate all other semesters
                        $stmt = $conn->prepare("UPDATE semester SET status = 'inactive'");
                        $stmt->execute();
                    }
                    
                    $stmt = $conn->prepare("UPDATE semester SET name = ?, start_date = ?, end_date = ?, status = ? WHERE id = ?");
                    if ($stmt->execute([$name, $start_date, $end_date, $status, $id])) {
                        $_SESSION['message'] = 'Semester updated successfully!';
                        $_SESSION['message_type'] = 'success';
                    } else {
                        $_SESSION['message'] = 'Error updating semester.';
                        $_SESSION['message_type'] = 'error';
                    }
                    break;
                    
                case 'delete_semester':
                    $id = $_POST['semester_id'];
                    $stmt = $conn->prepare("DELETE FROM semester WHERE id = ?");
                    if ($stmt->execute([$id])) {
                        $_SESSION['message'] = 'Semester deleted successfully!';
                        $_SESSION['message_type'] = 'success';
                    } else {
                        $_SESSION['message'] = 'Error deleting semester.';
                        $_SESSION['message_type'] = 'error';
                    }
                    break;
                    
                case 'set_active_academic_year':
                    $id = $_POST['academic_year_id'];
                    // Deactivate all academic years
                    $stmt = $conn->prepare("UPDATE academic_year SET status = 'inactive'");
                    $stmt->execute();
                    // Activate selected academic year
                    $stmt = $conn->prepare("UPDATE academic_year SET status = 'active' WHERE id = ?");
                    if ($stmt->execute([$id])) {
                        $_SESSION['message'] = 'Academic year set as active!';
                        $_SESSION['message_type'] = 'success';
                    } else {
                        $_SESSION['message'] = 'Error setting academic year as active.';
                        $_SESSION['message_type'] = 'error';
                    }
                    break;
                    
                case 'set_active_semester':
                    $id = $_POST['semester_id'];
                    // Deactivate all semesters
                    $stmt = $conn->prepare("UPDATE semester SET status = 'inactive'");
                    $stmt->execute();
                    // Activate selected semester
                    $stmt = $conn->prepare("UPDATE semester SET status = 'active' WHERE id = ?");
                    if ($stmt->execute([$id])) {
                        $_SESSION['message'] = 'Semester set as active!';
                        $_SESSION['message_type'] = 'success';
                    } else {
                        $_SESSION['message'] = 'Error setting semester as active.';
                        $_SESSION['message_type'] = 'error';
                    }
                    break;
            }
        } catch (PDOException $e) {
            $_SESSION['message'] = 'Database error: ' . $e->getMessage();
            $_SESSION['message_type'] = 'error';
        } catch (Exception $e) {
            $_SESSION['message'] = 'Error: ' . $e->getMessage();
            $_SESSION['message_type'] = 'error';
        }
    }
    
    // Redirect to prevent form resubmission
    header('Location: academic-year.php');
    exit();
}

// Get session messages
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    $message_type = $_SESSION['message_type'];
    unset($_SESSION['message'], $_SESSION['message_type']);
}

// Fetch academic years
try {
    $stmt = $conn->query("SELECT * FROM academic_year ORDER BY start_date DESC");
    $academic_years = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $academic_years = [];
    $message = 'Error fetching academic years: ' . $e->getMessage();
    $message_type = 'error';
}

// Fetch semesters
try {
    $stmt = $conn->query("SELECT * FROM semester ORDER BY start_date DESC");
    $semesters = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $semesters = [];
    $message = 'Error fetching semesters: ' . $e->getMessage();
    $message_type = 'error';
}
?>

<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Academic Year Management - Benadir University</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/academic-year.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="admin-container">
        <?php include '../includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1><i class="fas fa-calendar-alt"></i> Academic Year Management</h1>
                <div class="admin-header-right">
                    <button class="btn btn-primary" onclick="openModal('createAcademicYearModal')">
                        <i class="fas fa-plus"></i> Add Academic Year
                    </button>
                </div>
            </div>

            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message_type; ?>">
                    <i class="fas fa-<?php echo $message_type === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <!-- Academic Years Section -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">Academic Years</h2>
                    <button class="btn btn-sm btn-primary" onclick="openModal('createAcademicYearModal')">
                        <i class="fas fa-plus"></i> Add New
                    </button>
                </div>
                <div class="card-body">
                    <?php if (empty($academic_years)): ?>
                        <div class="empty-state">
                            <i class="fas fa-calendar-alt"></i>
                            <h3>No Academic Years Found</h3>
                            <p>Start by creating your first academic year.</p>
                        </div>
                    <?php else: ?>
                        <div class="table-container">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($academic_years as $year): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($year['name']); ?></td>
                                            <td><?php echo date('M d, Y', strtotime($year['start_date'])); ?></td>
                                            <td><?php echo date('M d, Y', strtotime($year['end_date'])); ?></td>
                                            <td>
                                                <span class="status-badge <?php echo $year['status'] === 'active' ? 'status-active' : 'status-inactive'; ?>">
                                                    <?php echo ucfirst($year['status']); ?>
                                                </span>
                                            </td>
                                            <td class="actions">
                                                <?php if ($year['status'] !== 'active'): ?>
                                                    <form method="POST" style="display: inline;">
                                                        <input type="hidden" name="action" value="set_active_academic_year">
                                                        <input type="hidden" name="academic_year_id" value="<?php echo $year['id']; ?>">
                                                        <button type="submit" class="btn btn-sm btn-success" title="Set as Active">
                                                            <i class="fas fa-check"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                                <button class="btn btn-sm btn-primary" onclick="editAcademicYear(<?php echo htmlspecialchars(json_encode($year)); ?>)">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button class="btn btn-sm btn-danger" onclick="deleteAcademicYear(<?php echo $year['id']; ?>, '<?php echo htmlspecialchars($year['name']); ?>')">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Semesters Section -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">Semesters</h2>
                    <button class="btn btn-sm btn-primary" onclick="openModal('createSemesterModal')">
                        <i class="fas fa-plus"></i> Add New
                    </button>
                </div>
                <div class="card-body">
                    <?php if (empty($semesters)): ?>
                        <div class="empty-state">
                            <i class="fas fa-layer-group"></i>
                            <h3>No Semesters Found</h3>
                            <p>Start by creating your first semester.</p>
                        </div>
                    <?php else: ?>
                        <div class="table-container">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Academic Year</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($semesters as $semester): 
                                        // Get academic year name
                                        $academic_year_name = '';
                                        foreach ($academic_years as $year) {
                                            if ($year['id'] == $semester['academic_year_id']) {
                                                $academic_year_name = $year['name'];
                                                break;
                                            }
                                        }
                                    ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($semester['name']); ?></td>
                                            <td><?php echo htmlspecialchars($academic_year_name); ?></td>
                                            <td><?php echo date('M d, Y', strtotime($semester['start_date'])); ?></td>
                                            <td><?php echo date('M d, Y', strtotime($semester['end_date'])); ?></td>
                                            <td>
                                                <span class="status-badge <?php echo $semester['status'] === 'active' ? 'status-active' : 'status-inactive'; ?>">
                                                    <?php echo ucfirst($semester['status']); ?>
                                                </span>
                                            </td>
                                            <td class="actions">
                                                <?php if ($semester['status'] !== 'active'): ?>
                                                    <form method="POST" style="display: inline;">
                                                        <input type="hidden" name="action" value="set_active_semester">
                                                        <input type="hidden" name="semester_id" value="<?php echo $semester['id']; ?>">
                                                        <button type="submit" class="btn btn-sm btn-success" title="Set as Active">
                                                            <i class="fas fa-check"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                                <button class="btn btn-sm btn-primary" onclick="editSemester(<?php echo htmlspecialchars(json_encode($semester)); ?>)">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button class="btn btn-sm btn-danger" onclick="deleteSemester(<?php echo $semester['id']; ?>, '<?php echo htmlspecialchars($semester['name']); ?>')">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Create Academic Year Modal -->
    <div id="createAcademicYearModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-plus"></i> Create Academic Year</h3>
                <span class="close" onclick="closeModal('createAcademicYearModal')">&times;</span>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="create_academic_year">
                <div class="form-group">
                    <label for="name">Academic Year Name *</label>
                    <input type="text" id="name" name="name" required placeholder="e.g., 2024-2025">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="start_date">Start Date *</label>
                        <input type="date" id="start_date" name="start_date" required>
                    </div>
                    <div class="form-group">
                        <label for="end_date">End Date *</label>
                        <input type="date" id="end_date" name="end_date" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" name="is_active">
                        Set as Active Academic Year
                    </label>
                    <small>Note: Setting this as active will deactivate all other academic years.</small>
                </div>
                <div class="modal-actions">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('createAcademicYearModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create Academic Year</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Academic Year Modal -->
    <div id="editAcademicYearModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-edit"></i> Edit Academic Year</h3>
                <span class="close" onclick="closeModal('editAcademicYearModal')">&times;</span>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="edit_academic_year">
                <input type="hidden" id="edit_academic_year_id" name="academic_year_id">
                <div class="form-group">
                    <label for="edit_name">Academic Year Name *</label>
                    <input type="text" id="edit_name" name="name" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="edit_start_date">Start Date *</label>
                        <input type="date" id="edit_start_date" name="start_date" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_end_date">End Date *</label>
                        <input type="date" id="edit_end_date" name="end_date" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" id="edit_is_active" name="is_active">
                        Set as Active Academic Year
                    </label>
                </div>
                <div class="modal-actions">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('editAcademicYearModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Academic Year</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Create Semester Modal -->
    <div id="createSemesterModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-plus"></i> Create Semester</h3>
                <span class="close" onclick="closeModal('createSemesterModal')">&times;</span>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="create_semester">
                <div class="form-group">
                    <label for="academic_year_id">Academic Year *</label>
                    <select id="academic_year_id" name="academic_year_id" required class="form-control">
                        <option value="">Select Academic Year</option>
                        <?php foreach ($academic_years as $year): ?>
                            <option value="<?php echo $year['id']; ?>"><?php echo htmlspecialchars($year['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="semester_name">Semester Name *</label>
                    <input type="text" id="semester_name" name="name" required placeholder="e.g., Fall 2024, Spring 2025">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="semester_start_date">Start Date *</label>
                        <input type="date" id="semester_start_date" name="start_date" required>
                    </div>
                    <div class="form-group">
                        <label for="semester_end_date">End Date *</label>
                        <input type="date" id="semester_end_date" name="end_date" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" name="is_active">
                        Set as Active Semester
                    </label>
                    <small>Note: Setting this as active will deactivate all other semesters.</small>
                </div>
                <div class="modal-actions">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('createSemesterModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create Semester</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Semester Modal -->
    <div id="editSemesterModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-edit"></i> Edit Semester</h3>
                <span class="close" onclick="closeModal('editSemesterModal')">&times;</span>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="edit_semester">
                <input type="hidden" id="edit_semester_id" name="semester_id">
                <div class="form-group">
                    <label for="edit_semester_name">Semester Name *</label>
                    <input type="text" id="edit_semester_name" name="name" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="edit_semester_start_date">Start Date *</label>
                        <input type="date" id="edit_semester_start_date" name="start_date" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_semester_end_date">End Date *</label>
                        <input type="date" id="edit_semester_end_date" name="end_date" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" id="edit_semester_is_active" name="is_active">
                        Set as Active Semester
                    </label>
                </div>
                <div class="modal-actions">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('editSemesterModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Semester</button>
                </div>
            </form>
        </div>
    </div>

    <script src="../assets/js/theme.js"></script>
    <script>
        // Initialize theme on page load
        document.addEventListener('DOMContentLoaded', function() {
            initializeTheme();
        });

        // Modal functions
        function openModal(modalId) {
            document.getElementById(modalId).style.display = 'block';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        // Edit academic year
        function editAcademicYear(year) {
            document.getElementById('edit_academic_year_id').value = year.id;
            document.getElementById('edit_name').value = year.name;
            document.getElementById('edit_start_date').value = year.start_date;
            document.getElementById('edit_end_date').value = year.end_date;
            document.getElementById('edit_is_active').checked = year.status === 'active';
            openModal('editAcademicYearModal');
        }

        // Delete academic year confirmation
        function deleteAcademicYear(id, name) {
            if (confirm('Are you sure you want to delete the academic year "' + name + '"?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.style.display = 'none';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'delete_academic_year';
                
                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'academic_year_id';
                idInput.value = id;
                
                form.appendChild(actionInput);
                form.appendChild(idInput);
                document.body.appendChild(form);
                form.submit();
            }
        }

        // Edit semester
        function editSemester(semester) {
            document.getElementById('edit_semester_id').value = semester.id;
            document.getElementById('edit_semester_name').value = semester.name;
            document.getElementById('edit_semester_start_date').value = semester.start_date;
            document.getElementById('edit_semester_end_date').value = semester.end_date;
            document.getElementById('edit_semester_is_active').checked = semester.status === 'active';
            openModal('editSemesterModal');
        }

        // Delete semester confirmation
        function deleteSemester(id, name) {
            if (confirm('Are you sure you want to delete the semester "' + name + '"?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.style.display = 'none';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'delete_semester';
                
                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'semester_id';
                idInput.value = id;
                
                form.appendChild(actionInput);
                form.appendChild(idInput);
                document.body.appendChild(form);
                form.submit();
            }
        }

        // Close modals when clicking outside
        window.onclick = function(event) {
            if (event.target.className === 'modal') {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html>
