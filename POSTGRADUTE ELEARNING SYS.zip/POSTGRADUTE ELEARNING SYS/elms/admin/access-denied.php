<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in
if (!is_logged_in()) {
    header("Location: ../auth/login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Access Denied - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <div class="header-left">
                    <h1>
                        <i class="fas fa-exclamation-triangle"></i>
                        Access Denied
                    </h1>
                </div>
            </div>

            <div class="card">
                <div class="card-body text-center">
                    <div style="padding: 40px;">
                        <i class="fas fa-lock" style="font-size: 4rem; color: var(--danger-color); margin-bottom: 20px;"></i>
                        <h2>Access Denied</h2>
                        <p style="color: var(--secondary-color); margin-bottom: 30px;">
                            You don't have permission to access this feature. Please contact your system administrator if you believe this is an error.
                        </p>
                        
                        <div style="display: flex; gap: 15px; justify-content: center;">
                            <button onclick="history.back()" class="btn btn-secondary">
                                <i class="fas fa-arrow-left"></i> Go Back
                            </button>
                            <a href="dashboard.php" class="btn btn-primary">
                                <i class="fas fa-home"></i> Dashboard
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="../assets/js/theme.js"></script>
</body>
</html>
