<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is an admin
if (!is_logged_in() || !is_admin()) {
    header("Location: ../auth/login.php");
    exit();
}

// Handle supervisor assignment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_supervisor'])) {
    $thesis_id = $_POST['thesis_id'];
    $supervisor_id = $_POST['supervisor_id'];
    $admin_id = $_SESSION['user_id'];

    try {
        $conn->beginTransaction();

        // Get thesis info for notifications
        $thesis_query = "SELECT student_id, title FROM thesis WHERE id = ?";
        $thesis_stmt = $conn->prepare($thesis_query);
        $thesis_stmt->execute([$thesis_id]);
        $thesis_info = $thesis_stmt->fetch(PDO::FETCH_ASSOC);

        // Update thesis with supervisor
        $update_query = "UPDATE thesis SET supervisor_id = ?, assigned_by = ?, status = 'under_review', updated_at = NOW() WHERE id = ?";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->execute([$supervisor_id, $admin_id, $thesis_id]);

        // Add to thesis committee as supervisor
        $committee_query = "INSERT INTO thesis_committee (thesis_id, member_id, role, assigned_date, assigned_by, created_at) 
                           VALUES (?, ?, 'supervisor', NOW(), ?, NOW())
                           ON DUPLICATE KEY UPDATE assigned_date = NOW(), assigned_by = VALUES(assigned_by)";
        $committee_stmt = $conn->prepare($committee_query);
        $committee_stmt->execute([$thesis_id, $supervisor_id, $admin_id]);

        // Send notifications
        include_once '../includes/thesis-notifications.php';
        notifySupervisorAssignment($conn, $thesis_id, $supervisor_id, $thesis_info['student_id'], $admin_id, $thesis_info['title']);

        $conn->commit();

        // Use session message and redirect
        $_SESSION['success_message'] = "Supervisor assigned successfully!";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();

    } catch (PDOException $e) {
        $conn->rollBack();
        $_SESSION['error_message'] = "Error assigning supervisor: " . $e->getMessage();
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}

// Handle bulk actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_action'])) {
    $action = $_POST['bulk_action'];
    $selected_thesis = $_POST['selected_thesis'] ?? [];

    if (empty($selected_thesis)) {
        $_SESSION['error_message'] = "Please select at least one thesis.";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    } else {
        try {
            $conn->beginTransaction();
            include_once '../includes/thesis-notifications.php';
            $admin_id = $_SESSION['user_id'];

            foreach ($selected_thesis as $thesis_id) {
                $thesis_query = "SELECT student_id, title, status FROM thesis WHERE id = ?";
                $thesis_stmt = $conn->prepare($thesis_query);
                $thesis_stmt->execute([$thesis_id]);
                $thesis_info = $thesis_stmt->fetch(PDO::FETCH_ASSOC);

                $old_status = $thesis_info['status'];

                switch ($action) {
                    case 'approve':
                        $update_query = "UPDATE thesis SET status = 'approved', updated_at = NOW() WHERE id = ?";
                        $new_status = 'approved';
                        break;
                    case 'reject':
                        $update_query = "UPDATE thesis SET status = 'rejected', updated_at = NOW() WHERE id = ?";
                        $new_status = 'rejected';
                        break;
                    case 'pending':
                        $update_query = "UPDATE thesis SET status = 'pending', updated_at = NOW() WHERE id = ?";
                        $new_status = 'pending';
                        break;
                    default:
                        continue 2;
                }

                $update_stmt = $conn->prepare($update_query);
                $update_stmt->execute([$thesis_id]);

                if ($old_status !== $new_status) {
                    notifyStatusChange($conn, $thesis_id, $thesis_info['student_id'], $admin_id, $old_status, $new_status, $thesis_info['title']);
                }
            }

            $conn->commit();
            $_SESSION['success_message'] = "Bulk action completed successfully!";
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();

        } catch (PDOException $e) {
            $conn->rollBack();
            $_SESSION['error_message'] = "Error performing bulk action: " . $e->getMessage();
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
        }
    }
}

// Get session messages for display
$message = $_SESSION['success_message'] ?? '';
$error = $_SESSION['error_message'] ?? '';
unset($_SESSION['success_message'], $_SESSION['error_message']);

// Get statistics and thesis data
try {
    $stats_query = "SELECT 
                    COUNT(*) as total_thesis,
                    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_count,
                    SUM(CASE WHEN status = 'under_review' THEN 1 ELSE 0 END) as under_review_count,
                    SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved_count,
                    SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected_count,
                    SUM(CASE WHEN supervisor_id IS NULL THEN 1 ELSE 0 END) as unassigned_count
                    FROM thesis";
    $stats_stmt = $conn->prepare($stats_query);
    $stats_stmt->execute();
    $stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);

    $thesis_query = "
    SELECT 
        t.*, 
        u.full_name as student_name, 
        u.email as student_email,
        p.name as program_name, 
        d.name as department_name,
        s.full_name as supervisor_name, 
        a.full_name as assigned_by_name,
        MAX(tr.status) as review_status,
        MAX(tr.review_date) as review_date
    FROM thesis t
    INNER JOIN users u ON t.student_id = u.id
    INNER JOIN programs p ON t.program_id = p.id
    INNER JOIN departments d ON t.department_id = d.id
    LEFT JOIN users s ON t.supervisor_id = s.id
    LEFT JOIN users a ON t.assigned_by = a.id
    LEFT JOIN thesis_reviews tr ON t.id = tr.thesis_id
    GROUP BY t.id
    ORDER BY t.submission_date DESC
    ";
    $thesis_stmt = $conn->prepare($thesis_query);
    $thesis_stmt->execute();
    $all_thesis = $thesis_stmt->fetchAll(PDO::FETCH_ASSOC);

    $instructors_query = "SELECT u.id, u.full_name, i.specialization, 
                          COUNT(t.id) as thesis_count
                          FROM users u
                          INNER JOIN instructors i ON u.id = i.user_id
                          LEFT JOIN thesis t ON u.id = t.supervisor_id
                          WHERE u.status = 'active'
                          GROUP BY u.id, u.full_name, i.specialization
                          ORDER BY thesis_count ASC, u.full_name ASC";
    $instructors_stmt = $conn->prepare($instructors_query);
    $instructors_stmt->execute();
    $available_instructors = $instructors_stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
    $stats = ['total_thesis' => 0, 'pending_count' => 0, 'under_review_count' => 0, 'approved_count' => 0, 'rejected_count' => 0, 'unassigned_count' => 0];
    $all_thesis = [];
    $available_instructors = [];
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thesis Management - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link rel="stylesheet" href="../assets/css/thesis.css">
    <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <div class="admin-header-left">
                    <h1>Thesis Management</h1>
                    <p class="welcome-message">Manage all thesis submissions, assignments, and reviews</p>
                </div>
                <div class="admin-header-right">
                    <div class="header-actions">
                        <button class="btn btn-primary" onclick="generateReport()">
                            <i class="fas fa-chart-bar"></i> Generate Report
                        </button>
                        <button class="btn btn-secondary" onclick="exportData()">
                            <i class="fas fa-download"></i> Export Data
                        </button>
                    </div>
                </div>
            </div>

            <?php if ($message): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <!-- Statistics Overview -->
            <div class="dashboard-overview">
                <div class="overview-card total-thesis">
                    <div class="overview-icon">
                        <i class="fas fa-graduation-cap"></i>
                    </div>
                    <div class="overview-details">
                        <h3>Total Thesis</h3>
                        <p class="overview-count"><?php echo $stats['total_thesis']; ?></p>
                        <div class="overview-trend neutral">
                            <span>All Submissions</span>
                        </div>
                    </div>
                </div>
                
                <div class="overview-card pending-thesis">
                    <div class="overview-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="overview-details">
                        <h3>Pending</h3>
                        <p class="overview-count"><?php echo $stats['pending_count']; ?></p>
                        <div class="overview-trend <?php echo $stats['pending_count'] > 0 ? 'warning' : 'positive'; ?>">
                            <span><?php echo $stats['pending_count'] > 0 ? 'Needs Action' : 'All Clear'; ?></span>
                        </div>
                    </div>
                </div>
                
                <div class="overview-card under-review">
                    <div class="overview-icon">
                        <i class="fas fa-search"></i>
                    </div>
                    <div class="overview-details">
                        <h3>Under Review</h3>
                        <p class="overview-count"><?php echo $stats['under_review_count']; ?></p>
                        <div class="overview-trend info">
                            <span>In Progress</span>
                        </div>
                    </div>
                </div>
                
                <div class="overview-card approved-thesis">
                    <div class="overview-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="overview-details">
                        <h3>Approved</h3>
                        <p class="overview-count"><?php echo $stats['approved_count']; ?></p>
                        <div class="overview-trend positive">
                            <span>Completed</span>
                        </div>
                    </div>
                </div>
                
                <div class="overview-card rejected-thesis">
                    <div class="overview-icon">
                        <i class="fas fa-times-circle"></i>
                    </div>
                    <div class="overview-details">
                        <h3>Rejected</h3>
                        <p class="overview-count"><?php echo $stats['rejected_count']; ?></p>
                        <div class="overview-trend negative">
                            <span>Not Approved</span>
                        </div>
                    </div>
                </div>
                
                <div class="overview-card unassigned-thesis">
                    <div class="overview-icon">
                        <i class="fas fa-user-slash"></i>
                    </div>
                    <div class="overview-details">
                        <h3>Unassigned</h3>
                        <p class="overview-count"><?php echo $stats['unassigned_count']; ?></p>
                        <div class="overview-trend <?php echo $stats['unassigned_count'] > 0 ? 'warning' : 'positive'; ?>">
                            <span><?php echo $stats['unassigned_count'] > 0 ? 'Need Supervisor' : 'All Assigned'; ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Filters and Search -->
            <div class="filters-section">
                <div class="filters-container">
                    <div class="search-box">
                        <input type="text" id="searchInput" placeholder="Search by student name, thesis title, or keywords...">
                        <i class="fas fa-search"></i>
                    </div>
                    <div class="filter-controls">
                        <select id="statusFilter">
                            <option value="">All Status</option>
                            <option value="pending">Pending</option>
                            <option value="under_review">Under Review</option>
                            <option value="approved">Approved</option>
                            <option value="rejected">Rejected</option>
                            <option value="revision_required">Revision Required</option>
                        </select>
                        <select id="programFilter">
                            <option value="">All Programs</option>
                            <?php
                            $programs_query = "SELECT DISTINCT p.id, p.name FROM programs p INNER JOIN thesis t ON p.id = t.program_id ORDER BY p.name";
                            $programs_stmt = $conn->prepare($programs_query);
                            $programs_stmt->execute();
                            $programs = $programs_stmt->fetchAll(PDO::FETCH_ASSOC);
                            foreach ($programs as $program):
                            ?>
                                <option value="<?php echo htmlspecialchars($program['name']); ?>"><?php echo htmlspecialchars($program['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <select id="supervisorFilter">
                            <option value="">All Supervisors</option>
                            <option value="unassigned">Unassigned</option>
                            <?php foreach ($available_instructors as $instructor): ?>
                                <option value="<?php echo htmlspecialchars($instructor['full_name']); ?>"><?php echo htmlspecialchars($instructor['full_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Bulk Actions -->
            <div class="bulk-actions-section">
                <form method="POST" id="bulkForm">
                    <div class="bulk-controls">
                        <div class="bulk-select">
                            <input type="checkbox" id="selectAll">
                            <label for="selectAll">Select All</label>
                        </div>
                        <div class="bulk-actions">
                            <select name="bulk_action" id="bulkAction">
                                <option value="">Bulk Actions</option>
                                <option value="approve">Approve Selected</option>
                                <option value="reject">Reject Selected</option>
                                <option value="pending">Mark as Pending</option>
                            </select>
                            <button type="submit" class="btn btn-primary" id="applyBulk" disabled>Apply</button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Thesis Table -->
            <div class="data-table-container">
                <div class="table-header">
                    <h3>All Thesis Submissions</h3>
                    <div class="table-actions">
                        <button class="btn btn-sm btn-secondary" onclick="refreshTable()">
                            <i class="fas fa-sync-alt"></i> Refresh
                        </button>
                    </div>
                </div>
                <div class="table-content">
                    <?php if (!empty($all_thesis)): ?>
                        <table class="data-table" id="thesisTable">
                            <thead>
                                <tr>
                                    <th><input type="checkbox" id="headerCheckbox"></th>
                                    <th>Student</th>
                                    <th>Thesis Title</th>
                                    <th>Program</th>
                                    <th>Submission Date</th>
                                    <th>Status</th>
                                    <th>Supervisor</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($all_thesis as $thesis): ?>
                                <tr data-status="<?php echo $thesis['status']; ?>" 
                                    data-program="<?php echo htmlspecialchars($thesis['program_name']); ?>"
                                    data-supervisor="<?php echo htmlspecialchars($thesis['supervisor_name'] ?? 'unassigned'); ?>">
                                    <td>
                                        <input type="checkbox" name="selected_thesis[]" value="<?php echo $thesis['id']; ?>" class="thesis-checkbox">
                                    </td>
                                    <td>
                                        <div class="student-info">
                                            <div class="student-name"><?php echo htmlspecialchars($thesis['student_name']); ?></div>
                                            <div class="student-email"><?php echo htmlspecialchars($thesis['student_email']); ?></div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="thesis-title"><?php echo htmlspecialchars($thesis['title']); ?></div>
                                        <div class="thesis-keywords">
                                            <small><?php echo htmlspecialchars(substr($thesis['keywords'], 0, 50)) . (strlen($thesis['keywords']) > 50 ? '...' : ''); ?></small>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="program-info">
                                            <div><?php echo htmlspecialchars($thesis['program_name']); ?></div>
                                            <small><?php echo htmlspecialchars($thesis['department_name']); ?></small>
                                        </div>
                                    </td>
                                    <td><?php echo date('M d, Y', strtotime($thesis['submission_date'])); ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo $thesis['status']; ?>">
                                            <?php echo ucwords(str_replace('_', ' ', $thesis['status'])); ?>
                                        </span>
                                        <?php if ($thesis['review_status']): ?>
                                            <br><small>Review: <?php echo ucwords(str_replace('_', ' ', $thesis['review_status'])); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($thesis['supervisor_name']): ?>
                                            <div class="supervisor-info">
                                                <div><?php echo htmlspecialchars($thesis['supervisor_name']); ?></div>
                                                <?php if ($thesis['assigned_by_name']): ?>
                                                    <small>Assigned by: <?php echo htmlspecialchars($thesis['assigned_by_name']); ?></small>
                                                <?php endif; ?>
                                            </div>
                                        <?php else: ?>
                                            <span class="unassigned-label">Not Assigned</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <button class="btn btn-sm btn-info" onclick="viewThesis(<?php echo $thesis['id']; ?>)">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <a href="../<?php echo htmlspecialchars($thesis['file_path']); ?>" 
                                               class="btn btn-sm btn-secondary" download>
                                                <i class="fas fa-download"></i>
                                            </a>
                                            <?php if (!$thesis['supervisor_id']): ?>
                                            <button class="btn btn-sm btn-primary" onclick="assignSupervisor(<?php echo $thesis['id']; ?>)">
                                                <i class="fas fa-user-plus"></i>
                                            </button>
                                            <?php else: ?>
                                            <button class="btn btn-sm btn-warning" onclick="reassignSupervisor(<?php echo $thesis['id']; ?>)">
                                                <i class="fas fa-user-edit"></i>
                                            </button>
                                            <?php endif; ?>
                                            <div class="dropdown">
                                                <button class="btn btn-sm btn-secondary dropdown-toggle" onclick="toggleDropdown(this)">
                                                    <i class="fas fa-ellipsis-v"></i>
                                                </button>
                                                <div class="dropdown-menu">
                                                    <a href="#" onclick="changeStatus(<?php echo $thesis['id']; ?>, 'approved')">Mark Approved</a>
                                                    <a href="#" onclick="changeStatus(<?php echo $thesis['id']; ?>, 'rejected')">Mark Rejected</a>
                                                    <a href="#" onclick="changeStatus(<?php echo $thesis['id']; ?>, 'pending')">Mark Pending</a>
                                                    <a href="#" onclick="deleteThesis(<?php echo $thesis['id']; ?>)" class="text-danger">Delete</a>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="no-data">
                            <i class="fas fa-graduation-cap"></i>
                            <h3>No Thesis Submissions</h3>
                            <p>No thesis submissions have been made yet.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Assign Supervisor Modal -->
    <div id="assignModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Assign Supervisor</h3>
                <span class="close" onclick="closeAssignModal()">&times;</span>
            </div>
            <form method="POST" id="assignForm">
                <input type="hidden" name="thesis_id" id="assign_thesis_id">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="supervisor_id">Select Supervisor *</label>
                        <select id="supervisor_id" name="supervisor_id" required>
                            <option value="">Choose Supervisor</option>
                            <?php foreach ($available_instructors as $instructor): ?>
                                <option value="<?php echo $instructor['id']; ?>">
                                    <?php echo htmlspecialchars($instructor['full_name']); ?> 
                                    (<?php echo htmlspecialchars($instructor['specialization']); ?>) 
                                    - <?php echo $instructor['thesis_count']; ?> thesis
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="supervisor-workload" id="supervisorWorkload">
                        <!-- Workload info will be loaded here -->
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeAssignModal()">Cancel</button>
                    <button type="submit" name="assign_supervisor" class="btn btn-primary">
                        <i class="fas fa-user-plus"></i> Assign Supervisor
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- View Thesis Modal -->
    <div id="viewModal" class="modal">
        <div class="modal-content modal-large">
            <div class="modal-header">
                <h3>Thesis Details</h3>
                <span class="close" onclick="closeViewModal()">&times;</span>
            </div>
            <div class="modal-body" id="thesisDetails">
                <!-- Content will be loaded dynamically -->
            </div>
        </div>
    </div>

    <script src="../assets/js/theme.js"></script>
    <script>
        // Table filtering and search
        document.getElementById('searchInput').addEventListener('input', filterTable);
        document.getElementById('statusFilter').addEventListener('change', filterTable);
        document.getElementById('programFilter').addEventListener('change', filterTable);
        document.getElementById('supervisorFilter').addEventListener('change', filterTable);

        function filterTable() {
            const searchTerm = document.getElementById('searchInput').value.toLowerCase();
            const statusFilter = document.getElementById('statusFilter').value;
            const programFilter = document.getElementById('programFilter').value;
            const supervisorFilter = document.getElementById('supervisorFilter').value;
            
            const rows = document.querySelectorAll('#thesisTable tbody tr');
            
            rows.forEach(row => {
                const studentName = row.querySelector('.student-name').textContent.toLowerCase();
                const thesisTitle = row.querySelector('.thesis-title').textContent.toLowerCase();
                const keywords = row.querySelector('.thesis-keywords').textContent.toLowerCase();
                const status = row.dataset.status;
                const program = row.dataset.program;
                const supervisor = row.dataset.supervisor;
                
                const matchesSearch = searchTerm === '' || 
                    studentName.includes(searchTerm) || 
                    thesisTitle.includes(searchTerm) || 
                    keywords.includes(searchTerm);
                
                const matchesStatus = statusFilter === '' || status === statusFilter;
                const matchesProgram = programFilter === '' || program === programFilter;
                const matchesSupervisor = supervisorFilter === '' || 
                    (supervisorFilter === 'unassigned' && supervisor === 'unassigned') ||
                    (supervisorFilter !== 'unassigned' && supervisor === supervisorFilter);
                
                if (matchesSearch && matchesStatus && matchesProgram && matchesSupervisor) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }

        // Bulk actions
        document.getElementById('selectAll').addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('.thesis-checkbox');
            checkboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
            updateBulkActions();
        });

        document.addEventListener('change', function(e) {
            if (e.target.classList.contains('thesis-checkbox')) {
                updateBulkActions();
            }
        });

        function updateBulkActions() {
            const checkedBoxes = document.querySelectorAll('.thesis-checkbox:checked');
            const applyButton = document.getElementById('applyBulk');
            applyButton.disabled = checkedBoxes.length === 0;
        }

        // Modal functions
        function assignSupervisor(thesisId) {
            document.getElementById('assign_thesis_id').value = thesisId;
            document.getElementById('assignModal').style.display = 'block';
        }

        function reassignSupervisor(thesisId) {
            assignSupervisor(thesisId);
        }

        function closeAssignModal() {
            document.getElementById('assignModal').style.display = 'none';
            document.getElementById('assignForm').reset();
        }

        function viewThesis(thesisId) {
            fetch('ajax/get-admin-thesis-details.php?id=' + thesisId)
                .then(response => response.text())
                .then(data => {
                    document.getElementById('thesisDetails').innerHTML = data;
                    document.getElementById('viewModal').style.display = 'block';
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error loading thesis details');
                });
        }

        function closeViewModal() {
            document.getElementById('viewModal').style.display = 'none';
        }

        function changeStatus(thesisId, status) {
            if (confirm('Are you sure you want to change the status to ' + status + '?')) {
                // Create form and submit
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="bulk_action" value="${status}">
                    <input type="hidden" name="selected_thesis[]" value="${thesisId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        function deleteThesis(thesisId) {
            if (confirm('Are you sure you want to delete this thesis? This action cannot be undone.')) {
                // Implement delete functionality
                alert('Delete functionality would be implemented here');
            }
        }

        function toggleDropdown(button) {
            const dropdown = button.nextElementSibling;
            dropdown.classList.toggle('show');
        }

        function generateReport() {
            window.open('reports/thesis-report.php', '_blank');
        }

        function exportData() {
            window.open('exports/thesis-export.php', '_blank');
        }

        function refreshTable() {
            location.reload();
        }

        // Close dropdowns when clicking outside
        document.addEventListener('click', function(e) {
            if (!e.target.matches('.dropdown-toggle')) {
                const dropdowns = document.querySelectorAll('.dropdown-menu');
                dropdowns.forEach(dropdown => {
                    dropdown.classList.remove('show');
                });
            }
        });

        // Close modals when clicking outside
        window.onclick = function(event) {
            const assignModal = document.getElementById('assignModal');
            const viewModal = document.getElementById('viewModal');
            
            if (event.target === assignModal) {
                assignModal.style.display = 'none';
            }
            if (event.target === viewModal) {
                viewModal.style.display = 'none';
            }
        }
    </script>
</body>
</html>
