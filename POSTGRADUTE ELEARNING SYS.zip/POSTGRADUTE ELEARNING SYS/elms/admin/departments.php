<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is admin
if (!is_logged_in() || !is_admin()) {
    header("Location: ../auth/login.php");
    exit();
}

// Process AJAX requests
if (isset($_POST['ajax']) && $_POST['ajax'] == 1) {
    header('Content-Type: application/json');
    
    try {
        if ($_POST['action'] == 'add' || $_POST['action'] == 'edit') {
            // Sanitize input
            $program_name = sanitize_input($_POST['department_name']);
            $program_code = sanitize_input($_POST['department_code']);
            $description = sanitize_input($_POST['description']);
            $status = sanitize_input($_POST['status']);
            
            // Validate input
            if (empty($program_name) || empty($program_code)) {
                throw new Exception("Please fill in all required fields");
            }
            
            // Begin transaction
            $conn->beginTransaction();
            
            if ($_POST['action'] == 'edit' && !empty($_POST['department_id'])) {
                // Update existing program
                $department_id = sanitize_input($_POST['department_id']);
                
                // Check if code already exists (excluding current program)
                $check_query = "SELECT COUNT(*) as count FROM departments WHERE code = ? AND id != ?";
                $check_stmt = $conn->prepare($check_query);
                $check_stmt->execute([$program_code, $department_id]);
                $count = $check_stmt->fetch(PDO::FETCH_ASSOC)['count'];
                
                if ($count > 0) {
                    throw new Exception("Program code already exists");
                }
                
                $query = "UPDATE departments SET name = ?, code = ?, description = ?, status = ?, updated_at = NOW() WHERE id = ?";
                $stmt = $conn->prepare($query);
                $stmt->execute([$program_name, $program_code, $description, $status, $department_id]);
                $message = "Program updated successfully";
            } else {
                // Check if code already exists
                $check_query = "SELECT COUNT(*) as count FROM departments WHERE code = ?";
                $check_stmt = $conn->prepare($check_query);
                $check_stmt->execute([$program_code]);
                $count = $check_stmt->fetch(PDO::FETCH_ASSOC)['count'];
                
                if ($count > 0) {
                    throw new Exception("Program code already exists");
                }
                
                // Create new program
                $query = "INSERT INTO departments (name, code, description, status, created_at) 
                          VALUES (?, ?, ?, ?, NOW())";
                $stmt = $conn->prepare($query);
                $stmt->execute([$program_name, $program_code, $description, $status]);
                $message = "Program created successfully";
            }
            
            // Commit transaction
            $conn->commit();
            
            echo json_encode(['success' => true, 'message' => $message]);
        } 

        elseif ($_POST['action'] == 'delete' && !empty($_POST['department_id'])) {
    $department_id = sanitize_input($_POST['department_id']);

    // Check if department is used by any program
    $check_query = "SELECT COUNT(*) as count FROM programs WHERE department_id = ?";
    $check_stmt = $conn->prepare($check_query);
    $check_stmt->execute([$department_id]);
    $count = $check_stmt->fetch(PDO::FETCH_ASSOC)['count'];

    if ($count > 0) {
        throw new Exception("Cannot delete department because it is associated with programs");
    }

    $query = "DELETE FROM departments WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->execute([$department_id]);

    echo json_encode(['success' => true, 'message' => "Department deleted successfully"]);
}


        elseif ($_POST['action'] == 'get' && !empty($_POST['department_id'])) {
            $department_id = sanitize_input($_POST['department_id']);
            $query = "SELECT * FROM departments WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->execute([$department_id]);
            
            if ($stmt->rowCount() > 0) {
                $program = $stmt->fetch(PDO::FETCH_ASSOC);
                echo json_encode(['success' => true, 'data' => $program]);
            } else {
                throw new Exception("Program not found");
            }
        }
        else {
            throw new Exception("Invalid action");
        }
    } catch(Exception $e) {
        // Rollback transaction if necessary
        if ($conn->inTransaction()) {
            $conn->rollBack();
        }
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit();
}

// Get all programs for listing
$programs_query = "SELECT * FROM departments ORDER BY name ASC";
$programs_stmt = $conn->prepare($programs_query);
$programs_stmt->execute();
$programs = $programs_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get department counts for each program
$program_stats = [];
foreach ($programs as $program) {
    // Count departments
    $dept_query = "SELECT COUNT(*) as dept_count FROM programs WHERE department_id = ?";
    $dept_stmt = $conn->prepare($dept_query);
    $dept_stmt->execute([$program['id']]);
    $dept_count = $dept_stmt->fetch(PDO::FETCH_ASSOC)['dept_count'];
    
    // Count students
    $student_query = "SELECT COUNT(*) as student_count FROM enrollment WHERE department_id = ?";
    $student_stmt = $conn->prepare($student_query);
    $student_stmt->execute([$program['id']]);
    $student_count = $student_stmt->fetch(PDO::FETCH_ASSOC)['student_count'];
    
    $program_stats[$program['id']] = [
        'programs' => $dept_count,
        'students' => $student_count
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Departments - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/modal.css">
    <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>Manage Department</h1>
                
                <div class="admin-header-right">
                    <button class="btn btn-primary" id="addProgramBtn">Add New department</button>
                </div>
            </div>
            
            <div id="alertContainer"></div>
            
            <!-- Programs List -->
            <div class="card">
                <div class="card-body">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>department Name</th>
                                <th>Code</th>
                                <th>programs</th>
                                <th>Students</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($programs) > 0): ?>
                                <?php foreach ($programs as $program): ?>
                                <tr>
                                    <td><?php echo $program['name']; ?></td>
                                    <td><?php echo $program['code']; ?></td>
                                    <td><?php echo $program_stats[$program['id']]['programs']; ?></td>
                                    <td><?php echo $program_stats[$program['id']]['students']; ?></td>
                                    <td>
                                        <span class="status-badge <?php echo $program['status']; ?>">
                                            <?php echo ucfirst($program['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-primary edit-program-btn" data-id="<?php echo $program['id']; ?>">Edit</button>
                                        <button class="btn btn-sm btn-danger delete-department-btn" data-id="<?php echo $program['id']; ?>">Delete</button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center">No departments found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Program Modal -->
    <div id="programModalBackdrop" class="modal-backdrop"></div>
    <div id="programModalContainer" class="modal-container">
        <div class="modal-header">
            <h2 id="programModalTitle">Add New department</h2>
            <button class="modal-close" id="closeProgramModal">&times;</button>
        </div>
        <div class="modal-body">
            <form id="programForm">
                <input type="hidden" id="department_id" name="department_id">
                <input type="hidden" id="form_action" name="action" value="add">
                <input type="hidden" name="ajax" value="1">
                
                <div class="form-row">
                    <label for="department_name">department Name <span class="required">*</span></label>
                    <input type="text" id="department_name" name="department_name" required>
                </div>
                
                <div class="form-row">
                    <label for="department_code">department Code <span class="required">*</span></label>
                    <input type="text" id="department_code" name="department_code" required>
                    <small>A unique code for the department (e.g., MSIT, MBA)</small>
                </div>
                
                <div class="form-row">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="4"></textarea>
                </div>
                
                <div class="form-row">
                    <label for="status">Status</label>
                    <select id="status" name="status" required>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" id="cancelProgramBtn">Cancel</button>
            <button class="btn btn-primary" id="saveProgramBtn">Save department</button>
        </div>
    </div>
    
    <!-- Delete Modal -->
    <div id="deleteModalBackdrop" class="modal-backdrop"></div>
    <div id="deleteModalContainer" class="modal-container">
        <div class="modal-header">
            <h2>Delete department</h2>
            <button class="modal-close" id="closeDeleteModal">&times;</button>
        </div>
        <div class="modal-body">
            <p>Are you sure you want to delete this department? This action cannot be undone.</p>
            <p class="text-danger"><strong>Note:</strong> departments with associated programs or student enrollments cannot be deleted.</p>
            <input type="hidden" id="delete_department_id">
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" id="cancelDeleteBtn">Cancel</button>
            <button class="btn btn-danger" id="confirmDeleteBtn">Delete</button>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // DOM Elements
        const alertContainer = document.getElementById('alertContainer');
        const programModalBackdrop = document.getElementById('programModalBackdrop');
        const programModalContainer = document.getElementById('programModalContainer');
        const deleteModalBackdrop = document.getElementById('deleteModalBackdrop');
        const deleteModalContainer = document.getElementById('deleteModalContainer');
        const programForm = document.getElementById('programForm');
        const programModalTitle = document.getElementById('programModalTitle');
        const saveProgramBtn = document.getElementById('saveProgramBtn');
        
        // Show alert message
        function showAlert(message, type = 'success') {
            const alert = document.createElement('div');
            alert.className = `alert alert-${type}`;
            alert.textContent = message;
            
            alertContainer.appendChild(alert);
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                alert.remove();
            }, 5000);
        }
        
        // Open program modal
        function openProgramModal() {
            programModalBackdrop.classList.add('show');
            programModalContainer.classList.add('show');
        }
        
        // Close program modal
        function closeProgramModal() {
            programModalBackdrop.classList.remove('show');
            programModalContainer.classList.remove('show');
        }
        
        // Open delete modal
        function openDeleteModal() {
            deleteModalBackdrop.classList.add('show');
            deleteModalContainer.classList.add('show');
        }
        
        // Close delete modal
        function closeDeleteModal() {
            deleteModalBackdrop.classList.remove('show');
            deleteModalContainer.classList.remove('show');
        }
        
        // Add Program button click
        document.getElementById('addProgramBtn').addEventListener('click', function() {
            // Reset form
            programForm.reset();
            document.getElementById('department_id').value = '';
            document.getElementById('form_action').value = 'add';
            
            // Update modal title and button
            programModalTitle.textContent = 'Add New department';
            saveProgramBtn.textContent = 'Create department';
            
            // Open modal
            openProgramModal();
        });
        
        // Close program modal
        document.getElementById('closeProgramModal').addEventListener('click', closeProgramModal);
        document.getElementById('cancelProgramBtn').addEventListener('click', closeProgramModal);
        
        // Close program modal when clicking on backdrop
        programModalBackdrop.addEventListener('click', closeProgramModal);
        
        // Close delete modal
        document.getElementById('closeDeleteModal').addEventListener('click', closeDeleteModal);
        document.getElementById('cancelDeleteBtn').addEventListener('click', closeDeleteModal);
        
        // Close delete modal when clicking on backdrop
        deleteModalBackdrop.addEventListener('click', closeDeleteModal);
        
        // Edit program button click
        document.querySelectorAll('.edit-program-btn').forEach(button => {
            button.addEventListener('click', function() {
                const programId = this.getAttribute('data-id');
                
                // Set loading state
                button.disabled = true;
                button.innerHTML = 'Loading...';
                
                // Fetch program data
                const formData = new FormData();
                formData.append('ajax', 1);
                formData.append('action', 'get');
                formData.append('department_id', programId);
                
                fetch('departments.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    button.disabled = false;
                    button.innerHTML = 'Edit';
                    
                    if (data.success) {
                        const program = data.data;
                        
                        // Fill form with program data
                        document.getElementById('department_id').value = program.id;
                        document.getElementById('form_action').value = 'edit';
                        document.getElementById('department_name').value = program.name;
                        document.getElementById('department_code').value = program.code;
                        document.getElementById('description').value = program.description;
                        document.getElementById('status').value = program.status;
                        
                        // Update modal title and button
                        programModalTitle.textContent = 'Edit department';
                        saveProgramBtn.textContent = 'Update department';
                        
                        // Open modal
                        openProgramModal();
                    } else {
                        showAlert(data.message, 'danger');
                    }
                })
                .catch(error => {
                    button.disabled = false;
                    button.innerHTML = 'Edit';
                    showAlert('An error occurred while fetching department data.', 'danger');
                });
            });
        });
        
        // Delete program button click
        document.querySelectorAll('.delete-department-btn').forEach(button => {
            button.addEventListener('click', function() {
                const programId = this.getAttribute('data-id');
                document.getElementById('delete_department_id').value = programId;
                
                // Open delete modal
                openDeleteModal();
            });
        });
        
        // Save program form
        saveProgramBtn.addEventListener('click', function() {
            // Check form validity
            if (!programForm.checkValidity()) {
                programForm.reportValidity();
                return;
            }
            
            // Disable button and show loading
            saveProgramBtn.disabled = true;
            saveProgramBtn.textContent = 'Saving...';
            
            // Prepare form data
            const formData = new FormData(programForm);
            
            // Send AJAX request
            fetch('departments.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                saveProgramBtn.disabled = false;
                saveProgramBtn.textContent = document.getElementById('form_action').value === 'add' ? 'Create Program' : 'Update Program';
                
                if (data.success) {
                    // Close modal and show success message
                    closeProgramModal();
                    showAlert(data.message, 'success');
                    
                    // Reload page after a short delay
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);
                } else {
                    // Show error
                    showAlert(data.message, 'danger');
                }
            })
            .catch(error => {
                saveProgramBtn.disabled = false;
                saveProgramBtn.textContent = document.getElementById('form_action').value === 'add' ? 'Create Program' : 'Update Program';
                showAlert('An error occurred while submitting the form.', 'danger');
            });
        });
        
        // Confirm delete program
        document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
            const programId = document.getElementById('delete_department_id').value;
            const button = this;
            
            // Disable button and show loading
            button.disabled = true;
            button.textContent = 'Deleting...';
            
            const formData = new FormData();
            formData.append('ajax', 1);
            formData.append('action', 'delete');
            formData.append('department_id', programId);
            
            fetch('departments.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                button.disabled = false;
                button.textContent = 'Delete';
                
                if (data.success) {
                    // Close modal and show success message
                    closeDeleteModal();
                    showAlert(data.message, 'success');
                    
                    // Reload page after a short delay
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);
                } else {
                    // Show error
                    showAlert(data.message, 'danger');
                }
            })
            .catch(error => {
                button.disabled = false;
                button.textContent = 'Delete';
                showAlert('An error occurred while deleting the department.', 'danger');
            });
        });
    });
    </script>
</body>
</html>
