<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is admin
if (!is_logged_in() || !is_admin()) {
    header("Location: ../auth/login.php");
    exit();
}

// Initialize variables
$message = '';
$messageType = '';

// Check for messages from redirects
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    $messageType = $_SESSION['message_type'];
    unset($_SESSION['message'], $_SESSION['message_type']);
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        // Create new event
        if ($_POST['action'] === 'create_event') {
            $title = sanitize_input($_POST['title']);
            $description = sanitize_input($_POST['description']);
            $event_date = sanitize_input($_POST['event_date']);
            $start_time = sanitize_input($_POST['start_time']);
            $end_time = sanitize_input($_POST['end_time']);
            $event_type = sanitize_input($_POST['event_type']);
            $location = sanitize_input($_POST['location']);
            $status = sanitize_input($_POST['status']);
            $created_by = $_SESSION['user_id'];
            
            try {
                $stmt = $conn->prepare("INSERT INTO academic_events (title, description, event_date, start_time, end_time, event_type, location, status, created_by, created_at) 
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
                
                if ($stmt->execute([$title, $description, $event_date, $start_time, $end_time, $event_type, $location, $status, $created_by])) {
                    $_SESSION['message'] = "Academic event created successfully!";
                    $_SESSION['message_type'] = "success";
                } else {
                    $_SESSION['message'] = "Error creating academic event.";
                    $_SESSION['message_type'] = "error";
                }
            } catch (PDOException $e) {
                $_SESSION['message'] = "Database error: " . $e->getMessage();
                $_SESSION['message_type'] = "error";
            }
            
            header('Location: academic-events.php');
            exit();
        }
        
        // Update event
        if ($_POST['action'] === 'update_event') {
            $event_id = sanitize_input($_POST['event_id']);
            $title = sanitize_input($_POST['title']);
            $description = sanitize_input($_POST['description']);
            $event_date = sanitize_input($_POST['event_date']);
            $start_time = sanitize_input($_POST['start_time']);
            $end_time = sanitize_input($_POST['end_time']);
            $event_type = sanitize_input($_POST['event_type']);
            $location = sanitize_input($_POST['location']);
            $status = sanitize_input($_POST['status']);
            
            try {
                $stmt = $conn->prepare("UPDATE academic_events SET title = ?, description = ?, event_date = ?, start_time = ?, end_time = ?, event_type = ?, location = ?, status = ?, updated_at = NOW() WHERE id = ?");
                
                if ($stmt->execute([$title, $description, $event_date, $start_time, $end_time, $event_type, $location, $status, $event_id])) {
                    $_SESSION['message'] = "Academic event updated successfully!";
                    $_SESSION['message_type'] = "success";
                } else {
                    $_SESSION['message'] = "Error updating academic event.";
                    $_SESSION['message_type'] = "error";
                }
            } catch (PDOException $e) {
                $_SESSION['message'] = "Database error: " . $e->getMessage();
                $_SESSION['message_type'] = "error";
            }
            
            header('Location: academic-events.php');
            exit();
        }
        
        // Delete event
        if ($_POST['action'] === 'delete_event' && isset($_POST['event_id'])) {
            $event_id = sanitize_input($_POST['event_id']);
            
            try {
                $stmt = $conn->prepare("DELETE FROM academic_events WHERE id = ?");
                
                if ($stmt->execute([$event_id])) {
                    $_SESSION['message'] = "Academic event deleted successfully!";
                    $_SESSION['message_type'] = "success";
                } else {
                    $_SESSION['message'] = "Error deleting academic event.";
                    $_SESSION['message_type'] = "error";
                }
            } catch (PDOException $e) {
                $_SESSION['message'] = "Database error: " . $e->getMessage();
                $_SESSION['message_type'] = "error";
            }
            
            header('Location: academic-events.php');
            exit();
        }
    }
}

// Get all academic events
try {
    $events_query = "SELECT ae.*, u.full_name as created_by_name 
                    FROM academic_events ae 
                    LEFT JOIN users u ON ae.created_by = u.id 
                    ORDER BY ae.event_date DESC, ae.start_time DESC";
    $events_stmt = $conn->prepare($events_query);
    $events_stmt->execute();
    $events = $events_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $events = [];
    $message = "Error loading events: " . $e->getMessage();
    $messageType = "error";
}

// Get upcoming events
$upcoming_events = array_filter($events, function($event) {
    return strtotime($event['event_date']) >= strtotime(date('Y-m-d'));
});

// Get past events
$past_events = array_filter($events, function($event) {
    return strtotime($event['event_date']) < strtotime(date('Y-m-d'));
});
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Academic Events - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/academic-year.css">
    <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="page-header">
                <div class="header-content">
                    <div class="header-left">
                        <h1 class="page-title">
                            <i class="fas fa-calendar-alt"></i>
                            Academic Events Management
                        </h1>
                    </div>
                    <div class="header-actions">
                        <button class="btn btn-primary" id="addEventBtn">
                            <i class="fas fa-plus"></i>
                            Add Academic Event
                        </button>
                    </div>
                </div>
            </div>

            <!-- Alert Messages -->
            <?php if (!empty($message)): ?>
                <div class="alert alert-<?php echo $messageType === 'success' ? 'success' : 'error'; ?>">
                    <i class="fas fa-<?php echo $messageType === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                    <span><?php echo htmlspecialchars($message); ?></span>
                </div>
            <?php endif; ?>

            <!-- Events Sections -->
            <div class="content-sections">
                <!-- Upcoming Events -->
                <div class="section-card">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fas fa-calendar-plus"></i>
                            Upcoming Events
                        </h2>
                        <span class="section-count"><?php echo count($upcoming_events); ?> events</span>
                    </div>
                    
                    <div class="table-container">
                        <?php if (count($upcoming_events) > 0): ?>
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Event Title</th>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Type</th>
                                        <th>Location</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($upcoming_events as $event): ?>
                                    <tr>
                                        <td class="event-title"><?php echo htmlspecialchars($event['title']); ?></td>
                                        <td><?php echo date('M d, Y', strtotime($event['event_date'])); ?></td>
                                        <td>
                                            <?php if ($event['start_time'] && $event['end_time']): ?>
                                                <?php echo date('g:i A', strtotime($event['start_time'])); ?> - 
                                                <?php echo date('g:i A', strtotime($event['end_time'])); ?>
                                            <?php else: ?>
                                                All Day
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="event-type-badge event-type-<?php echo strtolower($event['event_type']); ?>">
                                                <?php echo ucfirst(str_replace('_', ' ', $event['event_type'])); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($event['location'] ?? 'TBA'); ?></td>
                                        <td>
                                            <span class="status-badge status-<?php echo strtolower($event['status']); ?>">
                                                <?php echo ucfirst($event['status']); ?>
                                            </span>
                                        </td>
                                        <td class="actions-cell">
                                            <button class="btn btn-sm btn-primary edit-btn" data-id="<?php echo $event['id']; ?>">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button class="btn btn-sm btn-danger delete-btn" data-id="<?php echo $event['id']; ?>">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <div class="empty-state">
                                <i class="fas fa-calendar-plus"></i>
                                <h3>No Upcoming Events</h3>
                                <p>There are no upcoming academic events scheduled.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Past Events -->
                <div class="section-card">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fas fa-history"></i>
                            Past Events
                        </h2>
                        <span class="section-count"><?php echo count($past_events); ?> events</span>
                    </div>
                    
                    <div class="table-container">
                        <?php if (count($past_events) > 0): ?>
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Event Title</th>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Type</th>
                                        <th>Location</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($past_events as $event): ?>
                                    <tr>
                                        <td class="event-title"><?php echo htmlspecialchars($event['title']); ?></td>
                                        <td><?php echo date('M d, Y', strtotime($event['event_date'])); ?></td>
                                        <td>
                                            <?php if ($event['start_time'] && $event['end_time']): ?>
                                                <?php echo date('g:i A', strtotime($event['start_time'])); ?> - 
                                                <?php echo date('g:i A', strtotime($event['end_time'])); ?>
                                            <?php else: ?>
                                                All Day
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="event-type-badge event-type-<?php echo strtolower($event['event_type']); ?>">
                                                <?php echo ucfirst(str_replace('_', ' ', $event['event_type'])); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($event['location'] ?? 'TBA'); ?></td>
                                        <td>
                                            <span class="status-badge status-<?php echo strtolower($event['status']); ?>">
                                                <?php echo ucfirst($event['status']); ?>
                                            </span>
                                        </td>
                                        <td class="actions-cell">
                                            <button class="btn btn-sm btn-primary edit-btn" data-id="<?php echo $event['id']; ?>">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button class="btn btn-sm btn-danger delete-btn" data-id="<?php echo $event['id']; ?>">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <div class="empty-state">
                                <i class="fas fa-history"></i>
                                <h3>No Past Events</h3>
                                <p>There are no past academic events recorded.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add/Edit Event Modal -->
    <div id="eventModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modalTitle">Add Academic Event</h2>
                <button class="modal-close" id="closeModal">&times;</button>
            </div>
            <div class="modal-body">
                <form id="eventForm" method="POST">
                    <input type="hidden" name="action" id="formAction" value="create_event">
                    <input type="hidden" name="event_id" id="eventId">
                    
                    <div class="form-grid">
                        <div class="form-group full-width">
                            <label for="title">Event Title <span class="required">*</span></label>
                            <input type="text" id="title" name="title" required>
                        </div>
                        
                        <div class="form-group full-width">
                            <label for="description">Description</label>
                            <textarea id="description" name="description" rows="3"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="event_date">Event Date <span class="required">*</span></label>
                            <input type="date" id="event_date" name="event_date" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="event_type">Event Type <span class="required">*</span></label>
                            <select id="event_type" name="event_type" required>
                                <option value="">Select Type</option>
                                <option value="holiday">Holiday</option>
                                <option value="registration_deadline">Registration Deadline</option>
                                <option value="orientation">Orientation</option>
                                <option value="midterm_exam">Midterm Exam</option>
                                <option value="final_exam">Final Exam</option>
                                <option value="graduation">Graduation</option>
                                <option value="conference">Conference</option>
                                <option value="workshop">Workshop</option>
                                <option value="meeting">Meeting</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="start_time">Start Time</label>
                            <input type="time" id="start_time" name="start_time">
                        </div>
                        
                        <div class="form-group">
                            <label for="end_time">End Time</label>
                            <input type="time" id="end_time" name="end_time">
                        </div>
                        
                        <div class="form-group">
                            <label for="location">Location</label>
                            <input type="text" id="location" name="location" placeholder="Event location">
                        </div>
                        
                        <div class="form-group">
                            <label for="status">Status <span class="required">*</span></label>
                            <select id="status" name="status" required>
                                <option value="active">Active</option>
                                <option value="cancelled">Cancelled</option>
                                <option value="postponed">Postponed</option>
                            </select>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" id="cancelBtn">Cancel</button>
                <button type="submit" form="eventForm" class="btn btn-primary" id="saveBtn">Save Event</button>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Delete Event</h2>
                <button class="modal-close" id="closeDeleteModal">&times;</button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this academic event? This action cannot be undone.</p>
                <form id="deleteForm" method="POST">
                    <input type="hidden" name="action" value="delete_event">
                    <input type="hidden" name="event_id" id="deleteEventId">
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" id="cancelDeleteBtn">Cancel</button>
                <button type="submit" form="deleteForm" class="btn btn-danger" id="confirmDeleteBtn">Delete</button>
            </div>
        </div>
    </div>

    <style>
    /* Event Type Badges */
    .event-type-badge {
        padding: 4px 8px;
        border-radius: 12px;
        font-size: 0.75rem;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    
    .event-type-holiday {
        background: rgba(239, 68, 68, 0.1);
        color: #dc2626;
    }
    
    .event-type-registration_deadline {
        background: rgba(245, 158, 11, 0.1);
        color: #d97706;
    }
    
    .event-type-orientation {
        background: rgba(59, 130, 246, 0.1);
        color: #2563eb;
    }
    
    .event-type-midterm_exam {
        background: rgba(168, 85, 247, 0.1);
        color: #7c3aed;
    }
    
    .event-type-final_exam {
        background: rgba(239, 68, 68, 0.1);
        color: #dc2626;
    }
    
    .event-type-graduation {
        background: rgba(34, 197, 94, 0.1);
        color: #16a34a;
    }
    
    .event-type-conference,
    .event-type-workshop,
    .event-type-meeting,
    .event-type-other {
        background: rgba(107, 114, 128, 0.1);
        color: #6b7280;
    }
    
    .event-title {
        font-weight: 600;
        color: var(--text-color);
    }
    </style>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Modal elements
        const eventModal = document.getElementById('eventModal');
        const deleteModal = document.getElementById('deleteModal');
        const addEventBtn = document.getElementById('addEventBtn');
        const closeModal = document.getElementById('closeModal');
        const closeDeleteModal = document.getElementById('closeDeleteModal');
        const cancelBtn = document.getElementById('cancelBtn');
        const cancelDeleteBtn = document.getElementById('cancelDeleteBtn');
        
        // Form elements
        const eventForm = document.getElementById('eventForm');
        const modalTitle = document.getElementById('modalTitle');
        const formAction = document.getElementById('formAction');
        const eventId = document.getElementById('eventId');
        const saveBtn = document.getElementById('saveBtn');
        
        // Show modal
        function showModal(modal) {
            modal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
        
        // Hide modal
        function hideModal(modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
        
        // Reset form
        function resetForm() {
            eventForm.reset();
            formAction.value = 'create_event';
            eventId.value = '';
            modalTitle.textContent = 'Add Academic Event';
            saveBtn.textContent = 'Save Event';
        }
        
        // Add event button
        addEventBtn.addEventListener('click', function() {
            resetForm();
            showModal(eventModal);
        });
        
        // Close modal buttons
        closeModal.addEventListener('click', () => hideModal(eventModal));
        closeDeleteModal.addEventListener('click', () => hideModal(deleteModal));
        cancelBtn.addEventListener('click', () => hideModal(eventModal));
        cancelDeleteBtn.addEventListener('click', () => hideModal(deleteModal));
        
        // Close modal when clicking outside
        window.addEventListener('click', function(event) {
            if (event.target === eventModal) {
                hideModal(eventModal);
            }
            if (event.target === deleteModal) {
                hideModal(deleteModal);
            }
        });
        
        // Edit buttons
        document.querySelectorAll('.edit-btn').forEach(button => {
            button.addEventListener('click', function() {
                const eventId = this.getAttribute('data-id');
                
                // Fetch event data
                fetch(`../api/get_academic_event.php?id=${eventId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            const event = data.event;
                            
                            // Fill form with event data
                            document.getElementById('eventId').value = event.id;
                            document.getElementById('formAction').value = 'update_event';
                            document.getElementById('title').value = event.title;
                            document.getElementById('description').value = event.description || '';
                            document.getElementById('event_date').value = event.event_date;
                            document.getElementById('start_time').value = event.start_time || '';
                            document.getElementById('end_time').value = event.end_time || '';
                            document.getElementById('event_type').value = event.event_type;
                            document.getElementById('location').value = event.location || '';
                            document.getElementById('status').value = event.status;
                            
                            // Update modal
                            modalTitle.textContent = 'Edit Academic Event';
                            saveBtn.textContent = 'Update Event';
                            
                            showModal(eventModal);
                        } else {
                            alert('Error loading event data');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Error loading event data');
                    });
            });
        });
        
        // Delete buttons
        document.querySelectorAll('.delete-btn').forEach(button => {
            button.addEventListener('click', function() {
                const eventId = this.getAttribute('data-id');
                document.getElementById('deleteEventId').value = eventId;
                showModal(deleteModal);
            });
        });
    });
    </script>
    
    <script src="../assets/js/theme.js"></script>
</body>
</html>
