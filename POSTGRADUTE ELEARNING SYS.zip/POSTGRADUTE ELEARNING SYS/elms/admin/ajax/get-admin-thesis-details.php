<?php
session_start();
include_once '../../config/init.php';

// Check if user is logged in and is an admin
if (!is_logged_in() || !is_admin()) {
    http_response_code(403);
    exit('Access denied');
}

$thesis_id = $_GET['id'] ?? 0;

try {
    // Get comprehensive thesis details
    $query = "SELECT t.*, u.full_name as student_name, u.email as student_email, u.phone as student_phone,
              p.name as program_name, d.name as department_name,
              s.full_name as supervisor_name, s.email as supervisor_email,
              a.full_name as assigned_by_name,
              tr.status as review_status, tr.comments, tr.feedback, tr.suggestions,
              tr.review_date, tr.overall_score, tr.content_score, tr.methodology_score, 
              tr.presentation_score, tr.reviewer_id,
              ay.name as academic_year_name, sem.name as semester_name
              FROM thesis t
              INNER JOIN users u ON t.student_id = u.id
              INNER JOIN programs p ON t.program_id = p.id
              INNER JOIN departments d ON t.department_id = d.id
              LEFT JOIN users s ON t.supervisor_id = s.id
              LEFT JOIN users a ON t.assigned_by = a.id
              LEFT JOIN thesis_reviews tr ON t.id = tr.thesis_id
              LEFT JOIN academic_year ay ON t.academic_year_id = ay.id
              LEFT JOIN semester sem ON t.semester_id = sem.id
              WHERE t.id = ?";
    $stmt = $conn->prepare($query);
    $stmt->execute([$thesis_id]);
    $thesis = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$thesis) {
        echo '<div class="alert alert-danger">Thesis not found.</div>';
        exit;
    }

    // Get committee members
    $committee_query = "SELECT tc.*, u.full_name, u.email, tc.role 
                        FROM thesis_committee tc
                        INNER JOIN users u ON tc.member_id = u.id
                        WHERE tc.thesis_id = ? AND tc.status = 'active'
                        ORDER BY tc.role";
    $committee_stmt = $conn->prepare($committee_query);
    $committee_stmt->execute([$thesis_id]);
    $committee_members = $committee_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get revision history
    $revision_query = "SELECT * FROM thesis_revisions WHERE thesis_id = ? ORDER BY version_number DESC";
    $revision_stmt = $conn->prepare($revision_query);
    $revision_stmt->execute([$thesis_id]);
    $revisions = $revision_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get notifications history
    $notifications_query = "SELECT tn.*, u.full_name as sender_name 
                           FROM thesis_notifications tn
                           LEFT JOIN users u ON tn.sender_id = u.id
                           WHERE tn.thesis_id = ?
                           ORDER BY tn.created_at DESC";
    $notifications_stmt = $conn->prepare($notifications_query);
    $notifications_stmt->execute([$thesis_id]);
    $notifications = $notifications_stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo '<div class="alert alert-danger">Database error: ' . htmlspecialchars($e->getMessage()) . '</div>';
    exit;
}
?>

<div class="admin-thesis-details">
    <!-- Student and Academic Information -->
    <div class="detail-section">
        <h4>Student & Academic Information</h4>
        <div class="detail-grid">
            <div class="detail-item">
                <label>Student Name:</label>
                <span><?php echo htmlspecialchars($thesis['student_name']); ?></span>
            </div>
            <div class="detail-item">
                <label>Email:</label>
                <span><?php echo htmlspecialchars($thesis['student_email']); ?></span>
            </div>
            <div class="detail-item">
                <label>Phone:</label>
                <span><?php echo htmlspecialchars($thesis['student_phone'] ?? 'N/A'); ?></span>
            </div>
            <div class="detail-item">
                <label>Program:</label>
                <span><?php echo htmlspecialchars($thesis['program_name']); ?></span>
            </div>
            <div class="detail-item">
                <label>Department:</label>
                <span><?php echo htmlspecialchars($thesis['department_name']); ?></span>
            </div>
            <div class="detail-item">
                <label>Academic Year:</label>
                <span><?php echo htmlspecialchars($thesis['academic_year_name'] ?? 'N/A'); ?></span>
            </div>
            <div class="detail-item">
                <label>Semester:</label>
                <span><?php echo htmlspecialchars($thesis['semester_name'] ?? 'N/A'); ?></span>
            </div>
        </div>
    </div>

    <!-- Thesis Information -->
    <div class="detail-section">
        <h4>Thesis Information</h4>
        <div class="detail-grid">
            <div class="detail-item">
                <label>Title:</label>
                <span><?php echo htmlspecialchars($thesis['title']); ?></span>
            </div>
            <div class="detail-item">
                <label>Status:</label>
                <span class="status-badge status-<?php echo $thesis['status']; ?>">
                    <?php echo ucwords(str_replace('_', ' ', $thesis['status'])); ?>
                </span>
            </div>
            <div class="detail-item">
                <label>Submission Date:</label>
                <span><?php echo date('M d, Y H:i A', strtotime($thesis['submission_date'])); ?></span>
            </div>
            <div class="detail-item">
                <label>File Type:</label>
                <span><?php echo strtoupper($thesis['file_type']); ?></span>
            </div>
            <div class="detail-item">
                <label>File Size:</label>
                <span><?php echo round($thesis['file_size'] / 1024 / 1024, 2); ?> MB</span>
            </div>
        </div>
    </div>

    <!-- Supervision Information -->
    <div class="detail-section">
        <h4>Supervision Information</h4>
        <div class="supervision-info">
            <?php if ($thesis['supervisor_name']): ?>
                <div class="supervisor-details">
                    <div class="detail-item">
                        <label>Supervisor:</label>
                        <span><?php echo htmlspecialchars($thesis['supervisor_name']); ?></span>
                    </div>
                    <div class="detail-item">
                        <label>Supervisor Email:</label>
                        <span><?php echo htmlspecialchars($thesis['supervisor_email']); ?></span>
                    </div>
                    <div class="detail-item">
                        <label>Assigned By:</label>
                        <span><?php echo htmlspecialchars($thesis['assigned_by_name'] ?? 'System'); ?></span>
                    </div>
                </div>
            <?php else: ?>
                <div class="no-supervisor">
                    <i class="fas fa-user-slash"></i>
                    <span>No supervisor assigned</span>
                    <button class="btn btn-sm btn-primary" onclick="closeViewModal(); assignSupervisor(<?php echo $thesis['id']; ?>)">
                        <i class="fas fa-user-plus"></i> Assign Supervisor
                    </button>
                </div>
            <?php endif; ?>
        </div>

        <?php if (!empty($committee_members)): ?>
        <div class="committee-section">
            <h5>Committee Members</h5>
            <div class="committee-list">
                <?php foreach ($committee_members as $member): ?>
                <div class="committee-member">
                    <div class="member-info">
                        <span class="member-name"><?php echo htmlspecialchars($member['full_name']); ?></span>
                        <span class="member-role"><?php echo ucwords(str_replace('_', ' ', $member['role'])); ?></span>
                    </div>
                    <div class="member-email"><?php echo htmlspecialchars($member['email']); ?></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Abstract and Keywords -->
    <div class="detail-section">
        <h4>Abstract</h4>
        <div class="abstract-content">
            <?php echo nl2br(htmlspecialchars($thesis['abstract'])); ?>
        </div>
    </div>

    <div class="detail-section">
        <h4>Keywords</h4>
        <div class="keywords-list">
            <?php 
            $keywords = explode(',', $thesis['keywords']);
            foreach ($keywords as $keyword): 
            ?>
                <span class="keyword-tag"><?php echo trim(htmlspecialchars($keyword)); ?></span>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Review Information -->
    <?php if ($thesis['review_status']): ?>
    <div class="detail-section">
        <h4>Review Information</h4>
        <div class="review-content">
            <div class="review-header">
                <span class="review-status status-<?php echo $thesis['review_status']; ?>">
                    <?php echo ucwords(str_replace('_', ' ', $thesis['review_status'])); ?>
                </span>
                <span class="review-date">
                    Reviewed on <?php echo date('M d, Y', strtotime($thesis['review_date'])); ?>
                </span>
            </div>
            
            <?php if ($thesis['overall_score']): ?>
            <div class="scores-grid">
                <div class="score-item">
                    <label>Overall Score:</label>
                    <span class="score"><?php echo $thesis['overall_score']; ?>/5.00</span>
                </div>
                <div class="score-item">
                    <label>Content:</label>
                    <span class="score"><?php echo $thesis['content_score'] ?? 'N/A'; ?>/5.00</span>
                </div>
                <div class="score-item">
                    <label>Methodology:</label>
                    <span class="score"><?php echo $thesis['methodology_score'] ?? 'N/A'; ?>/5.00</span>
                </div>
                <div class="score-item">
                    <label>Presentation:</label>
                    <span class="score"><?php echo $thesis['presentation_score'] ?? 'N/A'; ?>/5.00</span>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($thesis['comments']): ?>
            <div class="review-comments">
                <h5>Comments:</h5>
                <p><?php echo nl2br(htmlspecialchars($thesis['comments'])); ?></p>
            </div>
            <?php endif; ?>
            
            <?php if ($thesis['feedback']): ?>
            <div class="review-feedback">
                <h5>Detailed Feedback:</h5>
                <p><?php echo nl2br(htmlspecialchars($thesis['feedback'])); ?></p>
            </div>
            <?php endif; ?>

            <?php if ($thesis['suggestions']): ?>
            <div class="review-suggestions">
                <h5>Suggestions:</h5>
                <p><?php echo nl2br(htmlspecialchars($thesis['suggestions'])); ?></p>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Revision History -->
    <?php if (!empty($revisions)): ?>
    <div class="detail-section">
        <h4>Revision History</h4>
        <div class="revisions-list">
            <?php foreach ($revisions as $revision): ?>
            <div class="revision-item">
                <div class="revision-header">
                    <span class="version">Version <?php echo $revision['version_number']; ?></span>
                    <span class="upload-date"><?php echo date('M d, Y H:i A', strtotime($revision['upload_date'])); ?></span>
                </div>
                <?php if ($revision['revision_notes']): ?>
                <div class="revision-notes">
                    <?php echo nl2br(htmlspecialchars($revision['revision_notes'])); ?>
                </div>
                <?php endif; ?>
                <div class="revision-actions">
                    <a href="../<?php echo htmlspecialchars($revision['file_path']); ?>" 
                       class="btn btn-sm btn-secondary" download>
                        <i class="fas fa-download"></i> Download
                    </a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Notifications History -->
    <?php if (!empty($notifications)): ?>
    <div class="detail-section">
        <h4>Notifications History</h4>
        <div class="notifications-history">
            <?php foreach ($notifications as $notification): ?>
            <div class="notification-item">
                <div class="notification-header">
                    <span class="notification-type"><?php echo ucwords(str_replace('_', ' ', $notification['type'])); ?></span>
                    <span class="notification-date"><?php echo date('M d, Y H:i A', strtotime($notification['created_at'])); ?></span>
                </div>
                <div class="notification-title"><?php echo htmlspecialchars($notification['title']); ?></div>
                <div class="notification-message"><?php echo htmlspecialchars($notification['message']); ?></div>
                <?php if ($notification['sender_name']): ?>
                <div class="notification-sender">Sent by: <?php echo htmlspecialchars($notification['sender_name']); ?></div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Action Buttons -->
    <div class="detail-actions">
        <a href="../<?php echo htmlspecialchars($thesis['file_path']); ?>" 
           class="btn btn-primary" download>
            <i class="fas fa-download"></i> Download Thesis
        </a>
        <?php if (!$thesis['supervisor_id']): ?>
        <button class="btn btn-success" onclick="closeViewModal(); assignSupervisor(<?php echo $thesis['id']; ?>)">
            <i class="fas fa-user-plus"></i> Assign Supervisor
        </button>
        <?php else: ?>
        <button class="btn btn-warning" onclick="closeViewModal(); reassignSupervisor(<?php echo $thesis['id']; ?>)">
            <i class="fas fa-user-edit"></i> Reassign Supervisor
        </button>
        <?php endif; ?>
        <button class="btn btn-info" onclick="sendNotification(<?php echo $thesis['id']; ?>)">
            <i class="fas fa-bell"></i> Send Notification
        </button>
    </div>
</div>
