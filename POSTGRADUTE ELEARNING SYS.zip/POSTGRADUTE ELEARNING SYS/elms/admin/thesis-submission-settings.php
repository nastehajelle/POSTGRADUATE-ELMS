<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is an admin
if (!is_logged_in() || !is_admin()) {
    header("Location: ../auth/login.php");
    exit();
}

$message = $_SESSION['settings_message'] ?? '';
$error = $_SESSION['settings_error'] ?? '';

// Clear session messages after displaying
unset($_SESSION['settings_message']);
unset($_SESSION['settings_error']);

$edit_mode = false;
$edit_data = null;
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    try {
        $edit_query = "SELECT tss.*, ay.name as academic_year_name, s.name as semester_name
                      FROM thesis_submission_settings tss
                      INNER JOIN academic_year ay ON tss.academic_year_id = ay.id
                      INNER JOIN semester s ON tss.semester_id = s.id
                      WHERE tss.id = ?";
        $edit_stmt = $conn->prepare($edit_query);
        $edit_stmt->execute([$edit_id]);
        $edit_data = $edit_stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($edit_data) {
            $edit_mode = true;
        }
    } catch (PDOException $e) {
        $_SESSION['settings_error'] = "Error loading settings for edit: " . $e->getMessage();
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $academic_year_id = $_POST['academic_year_id'];
    $semester_id = $_POST['semester_id'];
    $submission_mode = $_POST['submission_mode'];
    $submission_deadline = $_POST['submission_deadline'] ?? null;
    $late_submission_allowed = isset($_POST['late_submission_allowed']) ? 1 : 0;
    $late_submission_penalty = $_POST['late_submission_penalty'] ?? null;
    $max_submissions = $_POST['max_submissions_per_student'] ?? 1;
    $admin_id = $_SESSION['user_id'];
    
    $edit_id = $_POST['edit_id'] ?? null;

    try {
        $conn->beginTransaction();

        if ($edit_id) {
            $update_query = "UPDATE thesis_submission_settings SET 
                            academic_year_id = ?, semester_id = ?, submission_mode = ?, 
                            submission_deadline = ?, late_submission_allowed = ?, 
                            late_submission_penalty = ?, max_submissions_per_student = ?, 
                            updated_at = NOW()
                            WHERE id = ?";
            $stmt = $conn->prepare($update_query);
            $stmt->execute([$academic_year_id, $semester_id, $submission_mode, $submission_deadline, 
                           $late_submission_allowed, $late_submission_penalty, $max_submissions, $edit_id]);
            $_SESSION['settings_message'] = "Submission settings updated successfully!";
        } else {
            // Check if settings already exist for this academic year/semester
            $check_query = "SELECT id FROM thesis_submission_settings WHERE academic_year_id = ? AND semester_id = ?";
            $check_stmt = $conn->prepare($check_query);
            $check_stmt->execute([$academic_year_id, $semester_id]);
            $existing = $check_stmt->fetch(PDO::FETCH_ASSOC);

            if ($existing) {
                // Update existing settings
                $update_query = "UPDATE thesis_submission_settings SET 
                                submission_mode = ?, submission_deadline = ?, 
                                late_submission_allowed = ?, late_submission_penalty = ?,
                                max_submissions_per_student = ?, updated_at = NOW()
                                WHERE id = ?";
                $stmt = $conn->prepare($update_query);
                $stmt->execute([$submission_mode, $submission_deadline, $late_submission_allowed, 
                               $late_submission_penalty, $max_submissions, $existing['id']]);
                $_SESSION['settings_message'] = "Submission settings updated successfully!";
            } else {
                // Insert new settings
                $insert_query = "INSERT INTO thesis_submission_settings 
                                (academic_year_id, semester_id, submission_mode, submission_deadline,
                                 late_submission_allowed, late_submission_penalty, max_submissions_per_student, created_by)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($insert_query);
                $stmt->execute([$academic_year_id, $semester_id, $submission_mode, $submission_deadline,
                               $late_submission_allowed, $late_submission_penalty, $max_submissions, $admin_id]);
                $_SESSION['settings_message'] = "Submission settings created successfully!";
            }
        }

        $conn->commit();
        
        header("Location: " . $_SERVER['PHP_SELF'] . "?success=1");
        exit();
        
    } catch (PDOException $e) {
        $conn->rollBack();
        $_SESSION['settings_error'] = "Error saving settings: " . $e->getMessage();
        
        header("Location: " . $_SERVER['PHP_SELF'] . "?error=1");
        exit();
    }
}

// Get academic years and semesters
try {
    $academic_years_query = "SELECT * FROM academic_year ORDER BY start_date DESC";
    $academic_years = $conn->query($academic_years_query)->fetchAll(PDO::FETCH_ASSOC);

    $semesters_query = "SELECT s.*, ay.name as academic_year_name 
                       FROM semester s 
                       INNER JOIN academic_year ay ON s.academic_year_id = ay.id 
                       ORDER BY ay.start_date DESC, s.start_date ASC";
    $semesters = $conn->query($semesters_query)->fetchAll(PDO::FETCH_ASSOC);

    // Get existing settings
    $settings_query = "SELECT tss.*, ay.name as academic_year_name, s.name as semester_name
                      FROM thesis_submission_settings tss
                      INNER JOIN academic_year ay ON tss.academic_year_id = ay.id
                      INNER JOIN semester s ON tss.semester_id = s.id
                      ORDER BY ay.start_date DESC, s.start_date ASC";
    $existing_settings = $conn->query($settings_query)->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
    $academic_years = [];
    $semesters = [];
    $existing_settings = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thesis Submission Settings - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link rel="stylesheet" href="../assets/css/thesis.css">
    <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <div class="admin-header-left">
                    <h1>Thesis Submission Settings</h1>
                    <p class="welcome-message">
                        <?php if ($edit_mode): ?>
                            Editing settings for <?php echo htmlspecialchars($edit_data['academic_year_name'] . ' - ' . $edit_data['semester_name']); ?>
                        <?php else: ?>
                            Configure submission modes and deadlines for each academic session
                        <?php endif; ?>
                    </p>
                </div>
                <?php if ($edit_mode): ?>
                    <!-- Add cancel edit button -->
                    <div class="admin-header-right">
                        <a href="<?php echo $_SERVER['PHP_SELF']; ?>" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Cancel Edit
                        </a>
                    </div>
                <?php endif; ?>
            </div>

            <?php if ($message): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <!-- Settings Form -->
            <div class="form-container">
                <div class="form-header">
                    <h3><?php echo $edit_mode ? 'Edit Submission Settings' : 'Configure Submission Settings'; ?></h3>
                    <p><?php echo $edit_mode ? 'Update thesis submission settings for this academic session' : 'Set up thesis submission modes and deadlines for academic sessions'; ?></p>
                </div>
                
                <form method="POST" class="settings-form">
                    <?php if ($edit_mode): ?>
                        <!-- Add hidden field for edit ID -->
                        <input type="hidden" name="edit_id" value="<?php echo $edit_data['id']; ?>">
                    <?php endif; ?>
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="academic_year_id">Academic Year *</label>
                            <select id="academic_year_id" name="academic_year_id" required>
                                <option value="">Select Academic Year</option>
                                <?php foreach ($academic_years as $year): ?>
                                <option value="<?php echo $year['id']; ?>" 
                                        <?php echo ($edit_mode && $edit_data['academic_year_id'] == $year['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($year['name']); ?> 
                                    (<?php echo date('M Y', strtotime($year['start_date'])); ?> - <?php echo date('M Y', strtotime($year['end_date'])); ?>)
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="semester_id">Semester *</label>
                            <select id="semester_id" name="semester_id" required>
                                <option value="">Select Semester</option>
                                <?php foreach ($semesters as $semester): ?>
                                <option value="<?php echo $semester['id']; ?>" 
                                        data-academic-year="<?php echo $semester['academic_year_id']; ?>"
                                        <?php echo ($edit_mode && $edit_data['semester_id'] == $semester['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($semester['name']); ?> 
                                    (<?php echo htmlspecialchars($semester['academic_year_name']); ?>)
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="submission_mode">Submission Mode *</label>
                        <div class="radio-group">
                            <div class="radio-option">
                                <input type="radio" id="deadline_based" name="submission_mode" value="deadline_based" 
                                       <?php echo ($edit_mode && $edit_data['submission_mode'] == 'deadline_based') ? 'checked' : ''; ?> required>
                                <label for="deadline_based">
                                    <strong>Deadline-Based Submission</strong>
                                    <span class="radio-description">Students can only submit within a specified deadline</span>
                                </label>
                            </div>
                            <div class="radio-option">
                                <input type="radio" id="open_submission" name="submission_mode" value="open_submission" 
                                       <?php echo ($edit_mode && $edit_data['submission_mode'] == 'open_submission') ? 'checked' : ''; ?> required>
                                <label for="open_submission">
                                    <strong>Open Submission</strong>
                                    <span class="radio-description">Students can submit at any time without deadline restrictions</span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="deadline-settings" id="deadlineSettings" 
                         style="display: <?php echo ($edit_mode && $edit_data['submission_mode'] == 'deadline_based') ? 'block' : 'none'; ?>;">
                        <div class="form-group">
                            <label for="submission_deadline">Submission Deadline</label>
                            <input type="datetime-local" id="submission_deadline" name="submission_deadline"
                                   value="<?php echo $edit_mode && $edit_data['submission_deadline'] ? date('Y-m-d\TH:i', strtotime($edit_data['submission_deadline'])) : ''; ?>">
                            <small>Set the final deadline for thesis submissions</small>
                        </div>

                        <div class="form-group">
                            <div class="checkbox-group">
                                <input type="checkbox" id="late_submission_allowed" name="late_submission_allowed"
                                       <?php echo ($edit_mode && $edit_data['late_submission_allowed']) ? 'checked' : ''; ?>>
                                <label for="late_submission_allowed">Allow late submissions</label>
                            </div>
                        </div>

                        <div class="form-group" id="penaltyGroup" 
                             style="display: <?php echo ($edit_mode && $edit_data['late_submission_allowed']) ? 'block' : 'none'; ?>;">
                            <label for="late_submission_penalty">Late Submission Penalty (%)</label>
                            <input type="number" id="late_submission_penalty" name="late_submission_penalty" 
                                   min="0" max="100" step="0.1" placeholder="e.g., 5.0"
                                   value="<?php echo $edit_mode ? $edit_data['late_submission_penalty'] : ''; ?>">
                            <small>Percentage penalty applied to late submissions</small>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="max_submissions_per_student">Maximum Submissions per Student</label>
                        <input type="number" id="max_submissions_per_student" name="max_submissions_per_student" 
                               min="1" max="10" required
                               value="<?php echo $edit_mode ? $edit_data['max_submissions_per_student'] : '1'; ?>">
                        <small>How many times a student can submit/resubmit their thesis</small>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> <?php echo $edit_mode ? 'Update Settings' : 'Save Settings'; ?>
                        </button>
                        <button type="reset" class="btn btn-secondary">
                            <i class="fas fa-undo"></i> Reset Form
                        </button>
                    </div>
                </form>
            </div>

            <!-- Existing Settings -->
            <div class="data-table-container">
                <div class="table-header">
                    <h3>Current Submission Settings</h3>
                    <p>Overview of configured submission settings for all academic sessions</p>
                </div>
                <div class="table-content">
                    <?php if (!empty($existing_settings)): ?>
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Academic Year</th>
                                    <th>Semester</th>
                                    <th>Submission Mode</th>
                                    <th>Deadline</th>
                                    <th>Late Submissions</th>
                                    <th>Max Submissions</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($existing_settings as $setting): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($setting['academic_year_name']); ?></td>
                                    <td><?php echo htmlspecialchars($setting['semester_name']); ?></td>
                                    <td>
                                        <span class="mode-badge mode-<?php echo $setting['submission_mode']; ?>">
                                            <?php echo ucwords(str_replace('_', ' ', $setting['submission_mode'])); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($setting['submission_deadline']): ?>
                                            <?php echo date('M d, Y H:i', strtotime($setting['submission_deadline'])); ?>
                                        <?php else: ?>
                                            <span class="text-muted">No Deadline</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($setting['late_submission_allowed']): ?>
                                            <span class="status-badge status-approved">Allowed</span>
                                            <?php if ($setting['late_submission_penalty']): ?>
                                                <br><small><?php echo $setting['late_submission_penalty']; ?>% penalty</small>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="status-badge status-rejected">Not Allowed</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo $setting['max_submissions_per_student']; ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo $setting['status']; ?>">
                                            <?php echo ucwords($setting['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <!-- Replace placeholder with actual edit link -->
                                        <a href="<?php echo $_SERVER['PHP_SELF']; ?>?edit=<?php echo $setting['id']; ?>" 
                                           class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="no-data">
                            <i class="fas fa-cog"></i>
                            <h3>No Settings Configured</h3>
                            <p>Configure submission settings for academic sessions using the form above.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="../assets/js/theme.js"></script>
    <script>
        // Show/hide deadline settings based on submission mode
        document.querySelectorAll('input[name="submission_mode"]').forEach(radio => {
            radio.addEventListener('change', function() {
                const deadlineSettings = document.getElementById('deadlineSettings');
                const submissionDeadline = document.getElementById('submission_deadline');
                
                if (this.value === 'deadline_based') {
                    deadlineSettings.style.display = 'block';
                    submissionDeadline.required = true;
                } else {
                    deadlineSettings.style.display = 'none';
                    submissionDeadline.required = false;
                    submissionDeadline.value = '';
                }
            });
        });

        // Show/hide penalty field based on late submission checkbox
        document.getElementById('late_submission_allowed').addEventListener('change', function() {
            const penaltyGroup = document.getElementById('penaltyGroup');
            penaltyGroup.style.display = this.checked ? 'block' : 'none';
        });

        // Filter semesters based on selected academic year
        document.getElementById('academic_year_id').addEventListener('change', function() {
            const selectedYear = this.value;
            const semesterSelect = document.getElementById('semester_id');
            const semesterOptions = semesterSelect.querySelectorAll('option');
            
            semesterOptions.forEach(option => {
                if (option.value === '') {
                    option.style.display = 'block';
                    return;
                }
                
                const academicYear = option.dataset.academicYear;
                option.style.display = (academicYear === selectedYear) ? 'block' : 'none';
            });
            
            <?php if (!$edit_mode): ?>
            semesterSelect.value = '';
            <?php endif; ?>
        });

        // Trigger academic year filter on page load for edit mode
        <?php if ($edit_mode): ?>
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('academic_year_id').dispatchEvent(new Event('change'));
        });
        <?php endif; ?>
    </script>
</body>
</html>
