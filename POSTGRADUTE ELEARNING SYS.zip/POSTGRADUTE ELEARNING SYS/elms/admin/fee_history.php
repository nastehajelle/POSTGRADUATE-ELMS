<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is admin
if (!is_logged_in() || !is_admin()) {
    header("Location: ../auth/login.php");
    exit();
}

// Get program ID from URL
$program_id = isset($_GET['program_id']) ? sanitize_input($_GET['program_id']) : null;

if (!$program_id) {
    header("Location: programs.php");
    exit();
}

// Get program details
$program_query = "SELECT p.name, p.code, d.name as department_name 
                  FROM programs p 
                  JOIN departments d ON p.department_id = d.id 
                  WHERE p.id = ?";
$program_stmt = $conn->prepare($program_query);
$program_stmt->execute([$program_id]);
$program = $program_stmt->fetch(PDO::FETCH_ASSOC);

if (!$program) {
    header("Location: programs.php");
    exit();
}

// Get fee history
$history_query = "SELECT pfh.*, u.full_name as changed_by_name 
                  FROM program_fee_history pfh 
                  JOIN users u ON pfh.changed_by = u.id 
                  WHERE pfh.program_id = ? 
                  ORDER BY pfh.changed_at DESC";
$history_stmt = $conn->prepare($history_query);
$history_stmt->execute([$program_id]);
$fee_history = $history_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fee History - <?php echo $program['name']; ?> - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>Fee History</h1>
                <div class="breadcrumb">
                    <a href="programs.php">Programs</a> > 
                    <span><?php echo $program['name']; ?> (<?php echo $program['code']; ?>)</span>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h3>Program: <?php echo $program['name']; ?> (<?php echo $program['code']; ?>)</h3>
                    <p>Department: <?php echo $program['department_name']; ?></p>
                </div>
                <div class="card-body">
                    <?php if (count($fee_history) > 0): ?>
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Previous Fee</th>
                                    <th>New Fee</th>
                                    <th>Changed By</th>
                                    <th>Reason</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($fee_history as $history): ?>
                                <tr>
                                    <td><?php echo date('Y-m-d H:i:s', strtotime($history['changed_at'])); ?></td>
                                    <td><?php echo $history['old_fee'] ? '$' . number_format($history['old_fee'], 2) : 'Not set'; ?></td>
                                    <td><?php echo $history['new_fee'] ? '$' . number_format($history['new_fee'], 2) : 'Not set'; ?></td>
                                    <td><?php echo $history['changed_by_name']; ?></td>
                                    <td><?php echo $history['reason']; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p class="text-center">No fee history found for this program.</p>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="admin-actions">
                <a href="programs.php" class="btn btn-secondary">Back to Programs</a>
            </div>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
</body>
</html>
