<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is admin
if (!is_logged_in() || !is_admin()) {
    header("Location: ../auth/login.php");
    exit();
}

// Process AJAX requests
if (isset($_POST['ajax']) && $_POST['ajax'] == 1) {
    header('Content-Type: application/json');
    
    try {
        if ($_POST['action'] == 'toggle_status' && !empty($_POST['batch_id'])) {
            $batch_id = sanitize_input($_POST['batch_id']);
            
            // Get current status
            $status_query = "SELECT status FROM batch WHERE id = ?";
            $status_stmt = $conn->prepare($status_query);
            $status_stmt->execute([$batch_id]);
            $current_status = $status_stmt->fetch(PDO::FETCH_ASSOC)['status'];
            
            // Toggle status
            $new_status = ($current_status === 'active') ? 'inactive' : 'active';
            
            // Update batch status
            $update_query = "UPDATE batch SET status = ?, updated_at = NOW() WHERE id = ?";
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->execute([$new_status, $batch_id]);
            
            echo json_encode([
                'success' => true, 
                'message' => "Batch status updated to " . ucfirst($new_status),
                'new_status' => $new_status
            ]);
        }
        elseif ($_POST['action'] == 'add' || $_POST['action'] == 'edit') {
            // Sanitize input
            $batch_name = sanitize_input($_POST['batch_name']);
            $batch_year = sanitize_input($_POST['batch_year']);
            $program_id = sanitize_input($_POST['program_id']);
            $status = sanitize_input($_POST['status']);
            
            // Validate input
            if (empty($batch_name) || empty($batch_year) || empty($program_id)) {
                throw new Exception("Please fill in all required fields");
            }
            
            // Begin transaction
            $conn->beginTransaction();
            
            if ($_POST['action'] == 'edit' && !empty($_POST['batch_id'])) {
                // Update existing batch
                $batch_id = sanitize_input($_POST['batch_id']);
                $query = "UPDATE batch SET name = ?, year = ?, program_id = ?, status = ?, updated_at = NOW() WHERE id = ?";
             $stmt = $conn->prepare($query);
                $stmt->execute([$batch_name, $batch_year, $program_id, $status, $batch_id]);
                $message = "Batch updated successfully";
            } else {
                // Create new batch
                // Uniqueness of batch_name is now also enforced by a UNIQUE constraint on the database.
                $query = "INSERT INTO batch (name, year, program_id, start_date, end_date, status, created_at) 
                          VALUES (?, ?, ?, ?, ?, ?, NOW())";
                $start_date = $batch_year . '-09-01'; // Default start date (September 1st)
                $end_date = ($batch_year + 2) . '-08-31'; // Default end date (2 years later, August 31st)
                $stmt = $conn->prepare($query);
                $stmt->execute([$batch_name, $batch_year, $program_id, $start_date, $end_date, $status]);
                $message = "Batch created successfully";
            }
            
            // Commit transaction
            $conn->commit();
            
            echo json_encode(['success' => true, 'message' => $message]);
        } 
        elseif ($_POST['action'] == 'generate_batch_name' && !empty($_POST['program_id'])) {
            $program_id = sanitize_input($_POST['program_id']);

            // Get program code
            $program_query = "SELECT code FROM programs WHERE id = ?";
            $program_stmt = $conn->prepare($program_query);
            $program_stmt->execute([$program_id]);
            $program = $program_stmt->fetch(PDO::FETCH_ASSOC);

            if (!$program) {
                throw new Exception("Program not found.");
            }

          $program_code = $program['code'];

// Find the last batch number for this program code
// The batch name format is <program_code>02<batch_number> (e.g., IM0205)
$last_batch_query = "SELECT name FROM batch 
                     WHERE program_id = ? AND name LIKE ? 
                     ORDER BY name DESC LIMIT 1";
$search_pattern = $program_code . '02%';
$last_batch_stmt = $conn->prepare($last_batch_query);
$last_batch_stmt->execute([$program_id, $search_pattern]);
$last_batch = $last_batch_stmt->fetch(PDO::FETCH_ASSOC);

$next_batch_number = 1; // Default starting batch number

if ($last_batch) {
    $last_batch_name = $last_batch['name'];
    // Extract the numeric part (last two digits)
    // Assuming the format '<PROGRAM_CODE>02<BATCH_NUMBER>'
    // e.g., IM0205, SE0210
    $numeric_part = substr($last_batch_name, -2);
    $next_batch_number = intval($numeric_part) + 1;
}

// Format the next batch number with leading zeros if necessary (e.g., 01, 02)
$formatted_batch_number = sprintf("%02d", $next_batch_number);

// Generate batch name (no default M prefix anymore)
$generated_batch_name = $program_code . '02' . $formatted_batch_number;

echo json_encode(['success' => true, 'batch_name' => $generated_batch_name]);

        }
        elseif ($_POST['action'] == 'delete' && !empty($_POST['batch_id'])) {
            $batch_id = sanitize_input($_POST['batch_id']);
            
            // Check if batch is being used
            $check_query = "SELECT COUNT(*) as count FROM enrollment WHERE batch_id = ?";
            $check_stmt = $conn->prepare($check_query);
            $check_stmt->execute([$batch_id]);
            $count = $check_stmt->fetch(PDO::FETCH_ASSOC)['count'];
            
            if ($count > 0) {
                throw new Exception("Cannot delete batch because it is associated with enrollments");
            } else {
                $query = "DELETE FROM batch WHERE id = ?";
                $stmt = $conn->prepare($query);
                $stmt->execute([$batch_id]);
                echo json_encode(['success' => true, 'message' => "Batch deleted successfully"]);
            }
        }
        elseif ($_POST['action'] == 'get' && !empty($_POST['batch_id'])) {
            $batch_id = sanitize_input($_POST['batch_id']);
            $query = "SELECT * FROM batch WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->execute([$batch_id]);
            
            if ($stmt->rowCount() > 0) {
                $batch = $stmt->fetch(PDO::FETCH_ASSOC);
                echo json_encode(['success' => true, 'data' => $batch]);
            } else {
                throw new Exception("Batch not found");
            }
        }
        else {
            throw new Exception("Invalid action");
        }
    } catch(Exception $e) {
        // Rollback transaction if necessary
        if ($conn->inTransaction()) {
            $conn->rollBack();
        }
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit();
}

$programs_query = "SELECT p.id as program_id, p.name as program_name FROM programs p ORDER BY p.name ASC";
$stmt = $conn->prepare($programs_query);
$stmt->execute();
$programs = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all batches for listing

$batches_query = "SELECT DISTINCT b.id, b.name, b.year, b.status, 
                d.name AS department_name, 
                p.name AS program_name
FROM batch b
LEFT JOIN programs p ON b.program_id = p.id
LEFT JOIN departments d ON d.id = p.department_id
ORDER BY b.year DESC, b.name ASC
";

$batches_stmt = $conn->prepare($batches_query);
$batches_stmt->execute();
$batches = $batches_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Batches - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/modal.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>Manage Batches</h1>
                
                <div class="admin-header-right">
                    <button class="btn btn-primary" id="addBatchBtn">Add New Batch</button>
                </div>
            </div>
            
            <div id="alertContainer"></div>
            
            <!-- Batches List -->
            <div class="card">
                <div class="card-body">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Batch Name</th>
                                <th>Year</th>
                                <th>Department</th>
                                <th>Program</th>
                                <th>Status</th>
                                <th>Actions</th>
                                <th>Enrollment</th>  <!-- New column for enrollment -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($batches) > 0): ?>
                                <?php foreach ($batches as $batch): ?>
                                <tr>
                                    <td><?php echo $batch['name']; ?></td>
                                    <td><?php echo $batch['year']; ?></td>
                                    <td><?php echo $batch['department_name']; ?></td>
                                    <td><?php echo $batch['program_name']; ?></td>
                                    <td>
                                        <span class="status-badge <?php echo $batch['status']; ?>">
                                            <?php echo ucfirst($batch['status']); ?>
                                        </span>
                                        <!-- Added toggle status button -->
                                        <button class="btn btn-xs btn-outline toggle-status-btn" 
                                                data-id="<?php echo $batch['id']; ?>" 
                                                data-status="<?php echo $batch['status']; ?>"
                                                title="Toggle Status">
                                            <i class="fas fa-toggle-<?php echo $batch['status'] === 'active' ? 'on' : 'off'; ?>"></i>
                                        </button>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-primary edit-batch-btn" data-id="<?php echo $batch['id']; ?>">Edit</button>
                                        <button class="btn btn-sm btn-danger delete-batch-btn" data-id="<?php echo $batch['id']; ?>">Delete</button>
                                    </td>
                                    <td>
                                        <a href="view_students.php?batch_id=<?php echo $batch['id']; ?>" class="btn btn-sm btn-info">View Students</a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center">No batches found</td>  <!-- Updated colspan -->
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Batch Modal -->
    <div id="batchModalBackdrop" class="modal-backdrop"></div>
    <div id="batchModalContainer" class="modal-container">
        <div class="modal-header">
            <h2 id="batchModalTitle">Add New Batch</h2>
            <button class="modal-close" id="closeBatchModal">&times;</button>
        </div>
        <div class="modal-body">
            <form id="batchForm">
                <input type="hidden" id="batch_id" name="batch_id">
                <input type="hidden" id="form_action" name="action" value="add">
                <input type="hidden" name="ajax" value="1">
                
                <div class="form-row">
                    <label for="program_id">Program</label>
                    <select id="program_id" name="program_id" required>
                        <option value="">Select program</option>
                        <?php foreach ($programs as $program): ?>
                            <option value="<?php echo $program['program_id']; ?>">
                                <?php echo $program['program_name']; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-row">
                    <label for="batch_name">Batch Name</label>
                    <input type="text" id="batch_name" name="batch_name" required readonly>
                </div>
                
                <div class="form-row">
                    <label for="batch_year">Year</label>
                    <input type="text" id="batch_year" name="batch_year" required>
                </div>
                
                <div class="form-row">
                    <label for="status">Status</label>
                    <select id="status" name="status" required>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" id="cancelBatchBtn">Cancel</button>
            <button class="btn btn-primary" id="saveBatchBtn">Save Batch</button>
        </div>
    </div>
    
    <!-- Delete Modal -->
    <div id="deleteModalBackdrop" class="modal-backdrop"></div>
    <div id="deleteModalContainer" class="modal-container">
        <div class="modal-header">
            <h2>Delete Batch</h2>
            <button class="modal-close" id="closeDeleteModal">&times;</button>
        </div>
        <div class="modal-body">
            <p>Are you sure you want to delete this batch? This action cannot be undone.</p>
            <p class="text-danger"><strong>Note:</strong> Batches with enrolled students cannot be deleted.</p>
            <input type="hidden" id="delete_batch_id">
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" id="cancelDeleteBtn">Cancel</button>
            <button class="btn btn-danger" id="confirmDeleteBtn">Delete</button>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // DOM Elements
        const alertContainer = document.getElementById('alertContainer');
        const batchModalBackdrop = document.getElementById('batchModalBackdrop');
        const batchModalContainer = document.getElementById('batchModalContainer');
        const deleteModalBackdrop = document.getElementById('deleteModalBackdrop');
        const deleteModalContainer = document.getElementById('deleteModalContainer');
        const batchForm = document.getElementById('batchForm');
        const batchModalTitle = document.getElementById('batchModalTitle');
        const saveBatchBtn = document.getElementById('saveBatchBtn');
        const programSelect = document.getElementById('program_id');
        const batchNameInput = document.getElementById('batch_name');
        
        // Show alert message
        function showAlert(message, type = 'success') {
            const alert = document.createElement('div');
            alert.className = `alert alert-${type}`;
            alert.textContent = message;
            
            alertContainer.appendChild(alert);
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                alert.remove();
            }, 5000);
        }
        
        // Open batch modal
        function openBatchModal() {
            batchModalBackdrop.classList.add('show');
            batchModalContainer.classList.add('show');
        }
        
        // Close batch modal
        function closeBatchModal() {
            batchModalBackdrop.classList.remove('show');
            batchModalContainer.classList.remove('show');
        }
        
        // Open delete modal
        function openDeleteModal() {
            deleteModalBackdrop.classList.add('show');
            deleteModalContainer.classList.add('show');
        }
        
        // Close delete modal
        function closeDeleteModal() {
            deleteModalBackdrop.classList.remove('show');
            deleteModalContainer.classList.remove('show');
        }
        
        // Close batch modal when clicking on backdrop
        batchModalBackdrop.addEventListener('click', closeBatchModal);
        
        // Close delete modal when clicking on backdrop
        deleteModalBackdrop.addEventListener('click', closeDeleteModal);
        
        // Add Batch button click
        document.getElementById('addBatchBtn').addEventListener('click', function() {
            // Reset form
            batchForm.reset();
            document.getElementById('batch_id').value = '';
            document.getElementById('form_action').value = 'add';
            
            // Update modal title and button
            batchModalTitle.textContent = 'Add New Batch';
            saveBatchBtn.textContent = 'Create Batch';
            
            // Clear batch name and enable program selection for new batch
            batchNameInput.value = '';
            programSelect.disabled = false;
            
            // Open modal
            openBatchModal();
        });
        
        // Close batch modal
        document.getElementById('closeBatchModal').addEventListener('click', closeBatchModal);
        document.getElementById('cancelBatchBtn').addEventListener('click', closeBatchModal);
        
        // Edit batch button click
        document.querySelectorAll('.edit-batch-btn').forEach(button => {
            button.addEventListener('click', function() {
                const batchId = this.getAttribute('data-id');
                
                // Set loading state
                button.disabled = true;
                button.innerHTML = 'Loading...';
                
                // Fetch batch data
                const formData = new FormData();
                formData.append('ajax', 1);
                formData.append('action', 'get');
                formData.append('batch_id', batchId);
                
                fetch('batches.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    button.disabled = false;
                    button.innerHTML = 'Edit';
                    
                    if (data.success) {
                        const batch = data.data;
                        
                        // Fill form with batch data
                        document.getElementById('batch_id').value = batch.id;
                        document.getElementById('form_action').value = 'edit';
                        batchNameInput.value = batch.name; // Keep existing name
                        document.getElementById('batch_year').value = batch.year;
                        document.getElementById('program_id').value = batch.program_id;
                        document.getElementById('status').value = batch.status;
                        
                        // Disable program selection when editing
                        programSelect.disabled = true;

                        // Update modal title and button
                        batchModalTitle.textContent = 'Edit Batch';
                        saveBatchBtn.textContent = 'Update Batch';
                        
                        // Open modal
                        openBatchModal();
                    } else {
                        showAlert(data.message, 'danger');
                    }
                })
                .catch(error => {
                    button.disabled = false;
                    button.innerHTML = 'Edit';
                    showAlert('An error occurred while fetching batch data.', 'danger');
                });
            });
        });
        
        // Delete batch button click
        document.querySelectorAll('.delete-batch-btn').forEach(button => {
            button.addEventListener('click', function() {
                const batchId = this.getAttribute('data-id');
                document.getElementById('delete_batch_id').value = batchId;
                
                // Open delete modal
                openDeleteModal();
            });
        });
        
        // Event listener for program selection change to generate batch name
        programSelect.addEventListener('change', function() {
            if (document.getElementById('form_action').value === 'add') {
                const selectedProgramId = this.value;
                if (selectedProgramId) {
                    const formData = new FormData();
                    formData.append('ajax', 1);
                    formData.append('action', 'generate_batch_name');
                    formData.append('program_id', selectedProgramId);

                    fetch('batches.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            batchNameInput.value = data.batch_name;
                        } else {
                            showAlert(data.message, 'danger');
                            batchNameInput.value = ''; // Clear if generation fails
                        }
                    })
                    .catch(error => {
                        showAlert('An error occurred while generating batch name.', 'danger');
                        batchNameInput.value = '';
                    });
                } else {
                    batchNameInput.value = ''; // Clear if no program selected
                }
            }
        });

        // Save batch form
        saveBatchBtn.addEventListener('click', function() {
            // Re-enable program select temporarily for form submission if in edit mode
            const isEditing = document.getElementById('form_action').value === 'edit';
            if (isEditing) {
                programSelect.disabled = false;
            }

            // Check form validity
            if (!batchForm.checkValidity()) {
                batchForm.reportValidity();
                if (isEditing) { // Re-disable if still in edit mode after validation
                    programSelect.disabled = true;
                }
                return;
            }
            
            // Disable button and show loading
            saveBatchBtn.disabled = true;
            saveBatchBtn.textContent = 'Saving...';
            
            // Prepare form data
            const formData = new FormData(batchForm);
            
            // Send AJAX request
            fetch('batches.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                saveBatchBtn.disabled = false;
                saveBatchBtn.textContent = document.getElementById('form_action').value === 'add' ? 'Create Batch' : 'Update Batch';
                if (isEditing) { // Re-disable if in edit mode after submission
                    programSelect.disabled = true;
                }
                
                if (data.success) {
                    // Close modal and show success message
                    closeBatchModal();
                    showAlert(data.message, 'success');
                    
                    // Reload page after a short delay
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);
                } else {
                    // Show error
                    showAlert(data.message, 'danger');
                }
            })
            .catch(error => {
                saveBatchBtn.disabled = false;
                saveBatchBtn.textContent = document.getElementById('form_action').value === 'add' ? 'Create Batch' : 'Update Batch';
                showAlert('An error occurred while submitting the form.', 'danger');
                if (isEditing) { // Re-disable if in edit mode after error
                    programSelect.disabled = true;
                }
            });
        });
        
        // Confirm delete batch
        document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
            const batchId = document.getElementById('delete_batch_id').value;
            const button = this;
            
            // Disable button and show loading
            button.disabled = true;
            button.textContent = 'Deleting...';
            
            const formData = new FormData();
            formData.append('ajax', 1);
            formData.append('action', 'delete');
            formData.append('batch_id', batchId);
            
            fetch('batches.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                button.disabled = false;
                button.textContent = 'Delete';
                
                if (data.success) {
                    // Close modal and show success message
                    closeDeleteModal();
                    showAlert(data.message, 'success');
                    
                    // Reload page after a short delay
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);
                } else {
                    // Show error
                    showAlert(data.message, 'danger');
                }
            })
            .catch(error => {
                button.disabled = false;
                button.textContent = 'Delete';
                showAlert('An error occurred while deleting the batch.', 'danger');
            });
        });
        
        // Toggle batch status
        document.querySelectorAll('.toggle-status-btn').forEach(button => {
            button.addEventListener('click', function() {
                const batchId = this.getAttribute('data-id');
                const currentStatus = this.getAttribute('data-status');
                const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
                
                // Set loading state
                button.disabled = true;
                button.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
                
                const formData = new FormData();
                formData.append('ajax', 1);
                formData.append('action', 'toggle_status');
                formData.append('batch_id', batchId);
                
                fetch('batches.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Update button and status badge
                        button.setAttribute('data-status', data.new_status);
                        button.innerHTML = `<i class="fas fa-toggle-${data.new_status === 'active' ? 'on' : 'off'}"></i>`;
                        
                        // Update status badge
                        const statusBadge = button.parentElement.querySelector('.status-badge');
                        statusBadge.className = `status-badge ${data.new_status}`;
                        statusBadge.textContent = data.new_status.charAt(0).toUpperCase() + data.new_status.slice(1);
                        
                        showAlert(data.message, 'success');
                    } else {
                        showAlert(data.message, 'danger');
                    }
                    
                    button.disabled = false;
                })
                .catch(error => {
                    button.disabled = false;
                    button.innerHTML = `<i class="fas fa-toggle-${currentStatus === 'active' ? 'on' : 'off'}"></i>`;
                    showAlert('An error occurred while updating batch status.', 'danger');
                });
            });
        });
    });
    </script>
</body>
</html>
