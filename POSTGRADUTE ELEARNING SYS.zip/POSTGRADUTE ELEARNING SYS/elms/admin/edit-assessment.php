<?php
session_start();
include_once '../config/init.php';

// Set default timezone
date_default_timezone_set('Africa/Mogadishu');

// Check if user is logged in and is an admin
if (!is_logged_in() || !is_admin()) {
    header("Location: ../auth/login.php");
    exit();
}

$assessment_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$assessment = null;
$message = '';
$messageType = '';

if ($assessment_id <= 0) {
    header("Location: assessments.php");
    exit();
}

// Get departments and programs for dropdowns
$departments = [];
$programs = [];

try {
    $departments_query = "SELECT id, name, code FROM departments WHERE status = 'active' ORDER BY name";
    $departments_stmt = $conn->prepare($departments_query);
    $departments_stmt->execute();
    $departments = $departments_stmt->fetchAll(PDO::FETCH_ASSOC);

    $programs_query = "SELECT id, name, code, department_id FROM programs WHERE status = 'active' ORDER BY name";
    $programs_stmt = $conn->prepare($programs_query);
    $programs_stmt->execute();
    $programs = $programs_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching dropdown data: " . $e->getMessage());
}

// Get assessment details
try {
    $assessment_query = "SELECT a.*, d.name as department_name, p.name as program_name, c.name as course_name 
                        FROM assessments a
                        LEFT JOIN departments d ON a.department_id = d.id
                        LEFT JOIN programs p ON a.program_id = p.id
                        LEFT JOIN course c ON a.course_id = c.id
                        WHERE a.id = ?";
    $assessment_stmt = $conn->prepare($assessment_query);
    $assessment_stmt->execute([$assessment_id]);
    $assessment = $assessment_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$assessment) {
        $message = "Assessment not found.";
        $messageType = "danger";
    }
} catch (PDOException $e) {
    error_log("Error fetching assessment: " . $e->getMessage());
    $message = "Error loading assessment.";
    $messageType = "danger";
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_assessment']) && $assessment) {
    $title = sanitize_input($_POST['title']);
    $description = sanitize_input($_POST['description']);
    $type = sanitize_input($_POST['type']);
    $scope = sanitize_input($_POST['scope']);
    $department_id = ($scope === 'department' && !empty($_POST['department_id'])) ? intval($_POST['department_id']) : null;
    $program_id = ($scope === 'program' && !empty($_POST['program_id'])) ? intval($_POST['program_id']) : null;
    $total_marks = intval($_POST['total_marks']);
    $pass_marks = intval($_POST['pass_marks']);
    $start_time = sanitize_input($_POST['start_time']);
    $end_time = sanitize_input($_POST['end_time']);
    $duration_minutes = intval($_POST['duration_minutes']);
    $instructions = sanitize_input($_POST['instructions']);
    $randomize_questions = isset($_POST['randomize_questions']) ? 1 : 0;
    $attempts_allowed = intval($_POST['attempts_allowed']);
    $status = sanitize_input($_POST['status']);

    if (!empty($title) && !empty($type) && $total_marks > 0 && $pass_marks >= 0) {
        try {
            $update_query = "UPDATE assessments SET 
                            type = ?, title = ?, description = ?, department_id = ?, program_id = ?, 
                            total_marks = ?, pass_marks = ?, start_time = ?, end_time = ?, 
                            duration_minutes = ?, instructions = ?, randomize_questions = ?, 
                            attempts_allowed = ?, status = ?
                            WHERE id = ?";
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->execute([
                $type, $title, $description, $department_id, $program_id, $total_marks, $pass_marks,
                $start_time, $end_time, $duration_minutes, $instructions, $randomize_questions,
                $attempts_allowed, $status, $assessment_id
            ]);

            $message = "Assessment updated successfully!";
            $messageType = "success";
            
            // Refresh assessment data
            $assessment_stmt->execute([$assessment_id]);
            $assessment = $assessment_stmt->fetch(PDO::FETCH_ASSOC);
            
        } catch (PDOException $e) {
            error_log("Error updating assessment: " . $e->getMessage());
            $message = "Error updating assessment. Please try again.";
            $messageType = "danger";
        }
    } else {
        $message = "Please fill in all required fields correctly.";
        $messageType = "danger";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Assessment - <?php echo htmlspecialchars($assessment['title'] ?? ''); ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <?php echo FONT_AWESOME_CSS; ?>
    <style>
        .edit-container {
            max-width: 800px;
            margin: 0 auto;
        }

        .assessment-header {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
            border-left: 4px solid var(--primary-color);
        }

        .form-container {
            background: var(--card-bg);
            padding: 30px;
            border-radius: 12px;
            box-shadow: var(--shadow);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--text-color);
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            font-size: 0.9rem;
            background: var(--input-bg);
            color: var(--text-color);
            transition: border-color 0.2s;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--primary-color);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-top: 10px;
        }

        .checkbox-group input[type="checkbox"] {
            width: auto;
        }

        .scope-options {
            display: none;
            margin-top: 15px;
            padding: 15px;
            background: var(--bg-light);
            border-radius: 6px;
        }

        .scope-options.active {
            display: block;
        }

        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid var(--border-color);
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            font-size: 0.9rem;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
        }

        .btn-primary {
            background: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
        }

        .btn-secondary {
            background: var(--bg-secondary);
            color: var(--text-color);
            border: 1px solid var(--border-color);
        }

        .btn-secondary:hover {
            background: var(--hover-bg);
            text-decoration: none;
        }

        .btn-danger {
            background: #ef4444;
            color: white;
        }

        .btn-danger:hover {
            background: #dc2626;
        }

        .warning-box {
            background: #fef3c7;
            color: #92400e;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #f59e0b;
        }

        .warning-box i {
            margin-right: 8px;
        }

        .info-box {
            background: #dbeafe;
            color: #1e40af;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #3b82f6;
        }

        .info-box i {
            margin-right: 8px;
        }

        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .form-actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="edit-container">
                <div class="admin-header">
                    <h1>Edit Assessment</h1>
                    <a href="assessments.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Assessments
                    </a>
                </div>
                
                <?php if (!empty($message)): ?>
                    <div class="message <?php echo $messageType; ?>">
                        <?php echo $message; ?>
                    </div>
                <?php endif; ?>

                <?php if ($assessment): ?>
                     Assessment Header 
                    <div class="assessment-header">
                        <h2><?php echo htmlspecialchars($assessment['title']); ?></h2>
                        <p style="color: var(--text-muted); margin: 5px 0 0 0;">
                            <i class="fas fa-tag"></i> <?php echo ucfirst($assessment['type']); ?>
                            <?php if ($assessment['course_name']): ?>
                                | <i class="fas fa-book"></i> <?php echo htmlspecialchars($assessment['course_name']); ?>
                            <?php elseif ($assessment['program_name']): ?>
                                | <i class="fas fa-graduation-cap"></i> <?php echo htmlspecialchars($assessment['program_name']); ?>
                            <?php elseif ($assessment['department_name']): ?>
                                | <i class="fas fa-building"></i> <?php echo htmlspecialchars($assessment['department_name']); ?>
                            <?php endif; ?>
                        </p>
                    </div>

                     Warning Box 
                    <div class="warning-box">
                        <i class="fas fa-exclamation-triangle"></i>
                        <strong>Important:</strong> Changes to assessment settings will affect all future attempts. Students who have already submitted will not be affected.
                    </div>

                     Edit Form 
                    <div class="form-container">
                        <form method="POST">
                            <div class="form-group">
                                <label for="type">Assessment Type *</label>
                                <select name="type" id="type" required>
                                    <option value="">Select Type</option>
                                    <option value="exam" <?php echo ($assessment['type'] === 'exam') ? 'selected' : ''; ?>>Exam</option>
                                    <option value="quiz" <?php echo ($assessment['type'] === 'quiz') ? 'selected' : ''; ?>>Quiz</option>
                                    <option value="assignment" <?php echo ($assessment['type'] === 'assignment') ? 'selected' : ''; ?>>Assignment</option>
                                    <option value="project" <?php echo ($assessment['type'] === 'project') ? 'selected' : ''; ?>>Project</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="title">Assessment Title *</label>
                                <input type="text" name="title" id="title" required 
                                       value="<?php echo htmlspecialchars($assessment['title']); ?>"
                                       placeholder="Enter assessment title">
                            </div>
                            
                            <div class="form-group">
                                <label for="scope">Assessment Scope *</label>
                                <select name="scope" id="scope" required onchange="toggleScopeOptions()">
                                    <option value="">Select Scope</option>
                                    <option value="general" <?php echo (!$assessment['department_id'] && !$assessment['program_id']) ? 'selected' : ''; ?>>System-wide (All Students)</option>
                                    <option value="department" <?php echo ($assessment['department_id'] && !$assessment['program_id']) ? 'selected' : ''; ?>>Department-specific</option>
                                    <option value="program" <?php echo ($assessment['program_id']) ? 'selected' : ''; ?>>Program-specific</option>
                                </select>
                            </div>

                             Department Scope Options 
                            <div id="departmentScope" class="scope-options">
                                <div class="form-group">
                                    <label for="department_id">Select Department *</label>
                                    <select name="department_id" id="department_id">
                                        <option value="">Choose Department</option>
                                        <?php foreach ($departments as $dept): ?>
                                            <option value="<?php echo $dept['id']; ?>" <?php echo ($assessment['department_id'] == $dept['id']) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($dept['name'] . ' (' . $dept['code'] . ')'); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                             Program Scope Options 
                            <div id="programScope" class="scope-options">
                                <div class="form-group">
                                    <label for="program_department_id">Department *</label>
                                    <select name="program_department_id" id="program_department_id" onchange="filterPrograms()">
                                        <option value="">Choose Department First</option>
                                        <?php foreach ($departments as $dept): ?>
                                            <option value="<?php echo $dept['id']; ?>">
                                                <?php echo htmlspecialchars($dept['name'] . ' (' . $dept['code'] . ')'); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="program_id">Select Program *</label>
                                    <select name="program_id" id="program_id">
                                        <option value="">Choose Department First</option>
                                        <?php foreach ($programs as $prog): ?>
                                            <option value="<?php echo $prog['id']; ?>" data-department="<?php echo $prog['department_id']; ?>" <?php echo ($assessment['program_id'] == $prog['id']) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($prog['name'] . ' (' . $prog['code'] . ')'); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="description">Description</label>
                                <textarea name="description" id="description" 
                                          placeholder="Enter assessment description"><?php echo htmlspecialchars($assessment['description']); ?></textarea>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="total_marks">Total Marks *</label>
                                    <input type="number" name="total_marks" id="total_marks" required min="1" 
                                           value="<?php echo $assessment['total_marks']; ?>" placeholder="100">
                                </div>
                                <div class="form-group">
                                    <label for="pass_marks">Pass Marks *</label>
                                    <input type="number" name="pass_marks" id="pass_marks" required min="0" 
                                           value="<?php echo $assessment['pass_marks']; ?>" placeholder="60">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="start_time">Start Time *</label>
                                    <input type="datetime-local" name="start_time" id="start_time" required
                                           value="<?php echo date('Y-m-d\TH:i', strtotime($assessment['start_time'])); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="end_time">End Time *</label>
                                    <input type="datetime-local" name="end_time" id="end_time" required
                                           value="<?php echo date('Y-m-d\TH:i', strtotime($assessment['end_time'])); ?>">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="duration_minutes">Duration (Minutes)</label>
                                    <input type="number" name="duration_minutes" id="duration_minutes" min="0" 
                                           value="<?php echo $assessment['duration_minutes']; ?>" placeholder="60">
                                    <small style="color: var(--text-muted);">Leave 0 for no time limit</small>
                                </div>
                                <div class="form-group">
                                    <label for="attempts_allowed">Attempts Allowed</label>
                                    <input type="number" name="attempts_allowed" id="attempts_allowed" min="1" 
                                           value="<?php echo $assessment['attempts_allowed']; ?>" placeholder="1">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="status">Status *</label>
                                <select name="status" id="status" required>
                                    <option value="active" <?php echo ($assessment['status'] === 'active') ? 'selected' : ''; ?>>Active</option>
                                    <option value="inactive" <?php echo ($assessment['status'] === 'inactive') ? 'selected' : ''; ?>>Inactive</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="instructions">Instructions</label>
                                <textarea name="instructions" id="instructions" 
                                          placeholder="Enter instructions for students"><?php echo htmlspecialchars($assessment['instructions']); ?></textarea>
                            </div>
                            
                            <div class="checkbox-group">
                                <input type="checkbox" name="randomize_questions" id="randomize_questions" 
                                       <?php echo $assessment['randomize_questions'] ? 'checked' : ''; ?>>
                                <label for="randomize_questions">Randomize question order</label>
                            </div>
                            
                            <div class="form-actions">
                                <button type="submit" name="update_assessment" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Update Assessment
                                </button>
                                
                                <a href="assessments.php" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancel
                                </a>
                                
                                <a href="manage-assessment-batches.php?assessment_id=<?php echo $assessment['id']; ?>" class="btn btn-secondary">
                                    <i class="fas fa-layer-group"></i> Manage Batches
                                </a>
                            </div>
                        </form>
                    </div>
                <?php else: ?>
                    <div class="info-box">
                        <i class="fas fa-info-circle"></i>
                        Assessment not found.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
    <script>
        // Store programs data for filtering
        const programsData = <?php echo json_encode($programs); ?>;
        
        // Initialize scope options on page load
        document.addEventListener('DOMContentLoaded', function() {
            toggleScopeOptions();
            
            // Set program department if program is selected
            const programId = document.getElementById('program_id').value;
            if (programId) {
                const program = programsData.find(p => p.id == programId);
                if (program) {
                    document.getElementById('program_department_id').value = program.department_id;
                    filterPrograms();
                }
            }
        });
        
        // Toggle scope options
        function toggleScopeOptions() {
            const scope = document.getElementById('scope').value;
            const departmentScope = document.getElementById('departmentScope');
            const programScope = document.getElementById('programScope');
            
            // Hide all scope options
            departmentScope.classList.remove('active');
            programScope.classList.remove('active');
            
            // Show relevant scope options
            if (scope === 'department') {
                departmentScope.classList.add('active');
                document.getElementById('department_id').required = true;
                document.getElementById('program_department_id').required = false;
                document.getElementById('program_id').required = false;
            } else if (scope === 'program') {
                programScope.classList.add('active');
                document.getElementById('department_id').required = false;
                document.getElementById('program_department_id').required = true;
                document.getElementById('program_id').required = true;
            } else {
                document.getElementById('department_id').required = false;
                document.getElementById('program_department_id').required = false;
                document.getElementById('program_id').required = false;
            }
        }
        
        // Filter programs based on selected department
        function filterPrograms() {
            const departmentId = document.getElementById('program_department_id').value;
            const programSelect = document.getElementById('program_id');
            const currentProgramId = programSelect.value;
            
            // Clear existing options
            programSelect.innerHTML = '<option value="">Choose Program</option>';
            
            if (departmentId) {
                // Filter programs for selected department
                const filteredPrograms = programsData.filter(program => 
                    program.department_id == departmentId
                );
                
                // Add filtered programs to select
                filteredPrograms.forEach(program => {
                    const option = document.createElement('option');
                    option.value = program.id;
                    option.textContent = program.name + ' (' + program.code + ')';
                    if (program.id == currentProgramId) {
                        option.selected = true;
                    }
                    programSelect.appendChild(option);
                });
            }
        }
        
        // Update pass marks when total marks change
        document.getElementById('total_marks').addEventListener('input', function() {
            const totalMarks = parseInt(this.value);
            const currentPassMarks = parseInt(document.getElementById('pass_marks').value);
            if (totalMarks > 0 && (currentPassMarks === 0 || currentPassMarks > totalMarks)) {
                const passMarks = Math.floor(totalMarks * 0.6); // 60% pass rate
                document.getElementById('pass_marks').value = passMarks;
            }
        });
        
        // Validate end time is after start time
        document.getElementById('end_time').addEventListener('change', function() {
            const startTime = new Date(document.getElementById('start_time').value);
            const endTime = new Date(this.value);
            
            if (endTime <= startTime) {
                alert('End time must be after start time');
                this.value = '';
            }
        });
        
        // Validate pass marks don't exceed total marks
        document.getElementById('pass_marks').addEventListener('input', function() {
            const totalMarks = parseInt(document.getElementById('total_marks').value);
            const passMarks = parseInt(this.value);
            
            if (passMarks > totalMarks) {
                alert('Pass marks cannot exceed total marks');
                this.value = totalMarks;
            }
        });
    </script>
</body>
</html>
