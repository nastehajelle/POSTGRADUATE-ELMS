<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is admin
if (!is_logged_in() || !is_admin()) {
  header("Location: ../auth/login.php");
  exit();
}

// Process AJAX requests
if (isset($_POST['ajax']) && $_POST['ajax'] == 1) {
  header('Content-Type: application/json');
  
  try {
      if ($_POST['action'] == 'add' || $_POST['action'] == 'edit') {
          // Begin transaction
          $conn->beginTransaction();
          
          // Sanitize input
          $full_name = sanitize_input($_POST['full_name']);
          $email = sanitize_input($_POST['email']);
          $phone = sanitize_input($_POST['phone']);
          $gender = sanitize_input($_POST['gender']);
          $role = sanitize_input($_POST['role']);
          $status = sanitize_input($_POST['status']);
          
          // Validate input
          if (empty($full_name) || empty($email) || empty($phone) || empty($gender) || empty($role)) {
              throw new Exception("Please fill in all required fields");
          }
          
          if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
              throw new Exception("Please enter a valid email address");
          }
          
          // Check if email already exists (for new users)
          if ($_POST['action'] == 'add') {
              $check_query = "SELECT COUNT(*) as count FROM users WHERE email = ?";
              $check_stmt = $conn->prepare($check_query);
              $check_stmt->execute([$email]);
              $count = $check_stmt->fetch(PDO::FETCH_ASSOC)['count'];
              
              if ($count > 0) {
                  throw new Exception("Email address already exists");
              }
              
              // Generate password for new user
              $password = password_hash('password123', PASSWORD_DEFAULT);
          }
          
          // Handle student-specific fields
          $program_id = null;
          $department_id = null;
          $batch_id = null;
          $student_id_generated = null; // Initialize student ID variable

          $instructor_specialization = null;
          
          if ($role == 'instructor') {
              $instructor_specialization = isset($_POST['instructor_specialization']) ? sanitize_input($_POST['instructor_specialization']) : null;
          }

          if ($role == 'student') {
              if (empty($_POST['program_id']) || empty($_POST['department_id']) || empty($_POST['batch_id'])) {
                  throw new Exception("Please select program, department, and batch for student");
              }
              
              $program_id = sanitize_input($_POST['program_id']);
              $department_id = sanitize_input($_POST['department_id']);
              $batch_id = sanitize_input($_POST['batch_id']);
              
              // Get additional student fields
              $mother_name = isset($_POST['mother_name']) ? sanitize_input($_POST['mother_name']) : null;
              $date_of_birth = isset($_POST['date_of_birth']) ? sanitize_input($_POST['date_of_birth']) : null;
              $place_of_birth = isset($_POST['place_of_birth']) ? sanitize_input($_POST['place_of_birth']) : null;
              $nationality = isset($_POST['nationality']) ? sanitize_input($_POST['nationality']) : null;
              $marital_status = isset($_POST['marital_status']) ? sanitize_input($_POST['marital_status']) : null;
              $bachelor_institution = isset($_POST['bachelor_institution']) ? sanitize_input($_POST['bachelor_institution']) : null;
              $bachelor_specialization = isset($_POST['bachelor_specialization']) ? sanitize_input($_POST['bachelor_specialization']) : null;
              $bachelor_location = isset($_POST['bachelor_location']) ? sanitize_input($_POST['bachelor_location']) : null;
              $bachelor_year = isset($_POST['bachelor_year']) ? sanitize_input($_POST['bachelor_year']) : null;
              $application_type = isset($_POST['application_type']) ? sanitize_input($_POST['application_type']) : null;
              $language_of_instruction = isset($_POST['language_of_instruction']) ? sanitize_input($_POST['language_of_instruction']) : null;
              $emergency_contact_name = isset($_POST['emergency_contact_name']) ? sanitize_input($_POST['emergency_contact_name']) : null;
              $parent_associated_with_uni = isset($_POST['parent_associated_with_uni']) ? 1 : 0;
              $parent_name = isset($_POST['parent_name']) ? sanitize_input($_POST['parent_name']) : null;

              // Generate student ID here, before inserting/updating enrollment
              $student_id_generated = generate_student_id($batch_id, $conn);
          }
          
          if ($_POST['action'] == 'edit' && !empty($_POST['user_id'])) {
              // Update existing user
              $user_id = sanitize_input($_POST['user_id']);
              
              // Update user record
              $query = "UPDATE users SET full_name = ?, email = ?, phone = ?, gender = ?, role = ?, status = ?, updated_at = NOW() WHERE id = ?";
              $stmt = $conn->prepare($query);
              $stmt->execute([$full_name, $email, $phone, $gender, $role, $status, $user_id]);
              
              if ($role == 'instructor') {
                  // Check if instructor record exists
                  $check_instructor = "SELECT COUNT(*) as count FROM instructors WHERE user_id = ?";
                  $check_stmt = $conn->prepare($check_instructor);
                  $check_stmt->execute([$user_id]);
                  $has_instructor = $check_stmt->fetch(PDO::FETCH_ASSOC)['count'] > 0;
                  
                  if ($has_instructor) {
                      // Update instructor record
                      $update_instructor = "UPDATE instructors SET specialization = ?, updated_at = NOW() WHERE user_id = ?";
                      $update_stmt = $conn->prepare($update_instructor);
                      $update_stmt->execute([$instructor_specialization, $user_id]);
                  } else {
                      // Create instructor record
                      $insert_instructor = "INSERT INTO instructors (user_id, specialization, created_at) VALUES (?, ?, NOW())";
                      $insert_stmt = $conn->prepare($insert_instructor);
                      $insert_stmt->execute([$user_id, $instructor_specialization]);
                  }
              }
              
              // Handle student data if role is student
              if ($role == 'student') {
                  // Check if enrollment record exists
                  $check_enrollment = "SELECT COUNT(*) as count FROM enrollment WHERE user_id = ?";
                  $check_stmt = $conn->prepare($check_enrollment);
                  $check_stmt->execute([$user_id]);
                  $has_enrollment = $check_stmt->fetch(PDO::FETCH_ASSOC)['count'] > 0;
                  
                  if ($has_enrollment) {
                      // Update enrollment, including student_id
                      $update_enrollment = "UPDATE enrollment SET program_id = ?, department_id = ?, batch_id = ?, student_id = ? WHERE user_id = ?";
                      $update_stmt = $conn->prepare($update_enrollment);
                      $update_stmt->execute([$program_id, $department_id, $batch_id, $student_id_generated, $user_id]);
                  } else {
                      // Create enrollment, including student_id
                      $insert_enrollment = "INSERT INTO enrollment (user_id, program_id, department_id, batch_id, student_id, created_at) VALUES (?, ?, ?, ?, ?, NOW())";
                      $insert_stmt = $conn->prepare($insert_enrollment);
                      $insert_stmt->execute([$user_id, $program_id, $department_id, $batch_id, $student_id_generated]);
                  }
                  
                  // Check if student record exists
                  $check_student = "SELECT COUNT(*) as count FROM students WHERE user_id = ?";
                  $check_stmt = $conn->prepare($check_student);
                  $check_stmt->execute([$user_id]);
                  $has_student = $check_stmt->fetch(PDO::FETCH_ASSOC)['count'] > 0;
                  
                  if ($has_student) {
                      // Update student record
                      $update_student = "UPDATE students SET 
                          mother_name = ?, 
                          date_of_birth = ?, 
                          place_of_birth = ?, 
                          nationality = ?, 
                          marital_status = ?, 
                          bachelor_institution = ?, 
                          bachelor_specialization = ?, 
                          bachelor_location = ?, 
                          bachelor_year = ?, 
                          application_type = ?, 
                          language_of_instruction = ?, 
                          emergency_contact_name = ?, 
                          parent_associated_with_uni = ?, 
                          parent_name = ?, 
                          updated_at = NOW() 
                          WHERE user_id = ?";
                      $update_stmt = $conn->prepare($update_student);
                      $update_stmt->execute([
                          $mother_name, 
                          $date_of_birth, 
                          $place_of_birth, 
                          $nationality, 
                          $marital_status, 
                          $bachelor_institution, 
                          $bachelor_specialization, 
                          $bachelor_location, 
                          $bachelor_year, 
                          $application_type, 
                          $language_of_instruction, 
                          $emergency_contact_name, 
                          $parent_associated_with_uni, 
                          $parent_name, 
                          $user_id
                      ]);
                  } else {
                      // Create student record
                      $insert_student = "INSERT INTO students (
                          user_id, 
                          mother_name, 
                          date_of_birth, 
                          place_of_birth, 
                          nationality, 
                          marital_status, 
                          bachelor_institution, 
                          bachelor_specialization, 
                          bachelor_location, 
                          bachelor_year, 
                          application_type, 
                          language_of_instruction, 
                          emergency_contact_name, 
                          parent_associated_with_uni, 
                          parent_name, 
                          created_at
                      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
                      $insert_stmt = $conn->prepare($insert_student);
                      $insert_stmt->execute([
                          $user_id, 
                          $mother_name, 
                          $date_of_birth, 
                          $place_of_birth, 
                          $nationality, 
                          $marital_status, 
                          $bachelor_institution, 
                          $bachelor_specialization, 
                          $bachelor_location, 
                          $bachelor_year, 
                          $application_type, 
                          $language_of_instruction, 
                          $emergency_contact_name, 
                          $parent_associated_with_uni, 
                          $parent_name
                      ]);
                  }
              }
              
              $message = "User updated successfully";
          } else {
              // Create new user
              $query = "INSERT INTO users (full_name, email, password, phone, gender, role, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
              $stmt = $conn->prepare($query);
              $stmt->execute([$full_name, $email, $password, $phone, $gender, $role, $status]);
              
              $user_id = $conn->lastInsertId();
              
              if ($role == 'instructor') {
                  // Create instructor record
                  $insert_instructor = "INSERT INTO instructors (user_id, specialization, created_at) VALUES (?, ?, NOW())";
                  $insert_stmt = $conn->prepare($insert_instructor);
                  $insert_stmt->execute([$user_id, $instructor_specialization]);
              }
              
              // Handle student data if role is student
              if ($role == 'student') {
                  // Insert enrollment with generated student_id
                  $insert_enrollment = "INSERT INTO enrollment (user_id, program_id, department_id, batch_id, student_id, created_at) VALUES (?, ?, ?, ?, ?, NOW())";
                  $insert_stmt = $conn->prepare($insert_enrollment);
                  $insert_stmt->execute([$user_id, $program_id, $department_id, $batch_id, $student_id_generated]);
                  
                  // Create student record with additional fields
                  $insert_student = "INSERT INTO students (
                      user_id, 
                      mother_name, 
                      date_of_birth, 
                      place_of_birth, 
                      nationality, 
                      marital_status, 
                      bachelor_institution, 
                      bachelor_specialization, 
                      bachelor_location, 
                      bachelor_year, 
                      application_type, 
                      language_of_instruction, 
                      emergency_contact_name, 
                      parent_associated_with_uni, 
                      parent_name, 
                      created_at
                  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
                  $insert_stmt = $conn->prepare($insert_student);
                  $insert_stmt->execute([
                      $user_id, 
                      $mother_name, 
                      $date_of_birth, 
                      $place_of_birth, 
                      $nationality, 
                      $marital_status, 
                      $bachelor_institution, 
                      $bachelor_specialization, 
                      $bachelor_location, 
                      $bachelor_year, 
                      $application_type, 
                      $language_of_instruction, 
                      $emergency_contact_name, 
                      $parent_associated_with_uni, 
                      $parent_name
                  ]);
              }
              
              $message = "User created successfully";
          }
          
          // Handle document upload if file is provided
          if ($role == 'student' && isset($_FILES['documents']) && !empty($_FILES['documents']['name'][0])) {
              $upload_dir = "../uploads/documents/";
              
              // Create directory if it doesn't exist
              if (!file_exists($upload_dir)) {
                  mkdir($upload_dir, 0777, true);
              }
              
              $allowed_types = ['application/pdf', 'image/jpeg', 'image/png'];
              $max_size = 5 * 1024 * 1024; // 5MB
              
              // We'll only use the first document
              if ($_FILES['documents']['error'][0] == 0) {
                  $file_name = $_FILES['documents']['name'][0];
                  $file_size = $_FILES['documents']['size'][0];
                  $file_type = $_FILES['documents']['type'][0];
                  $file_tmp = $_FILES['documents']['tmp_name'][0];
                  
                  // Validate file type and size
                  if (!in_array($file_type, $allowed_types)) {
                      throw new Exception("Invalid file type. Only PDF, JPEG, and PNG files are allowed.");
                  }
                  
                  if ($file_size > $max_size) {
                      throw new Exception("File size exceeds the limit of 5MB.");
                  }
                  
                  // Generate unique filename
                  $new_file_name = $user_id . '_' . time() . '_' . $file_name;
                  $destination = $upload_dir . $new_file_name;
                  
                  // Move uploaded file
                  if (move_uploaded_file($file_tmp, $destination)) {
                      // Check if student record exists
                      $check_student = "SELECT COUNT(*) as count FROM students WHERE user_id = ?";
                      $check_stmt = $conn->prepare($check_student);
                      $check_stmt->execute([$user_id]);
                      $has_student = $check_stmt->fetch(PDO::FETCH_ASSOC)['count'] > 0;
                      
                      if ($has_student) {
                          // Update student record
                          $update_student = "UPDATE students SET degree_document = ?, updated_at = NOW() WHERE user_id = ?";
                          $update_stmt = $conn->prepare($update_student);
                          $update_stmt->execute([$destination, $user_id]);
                      } else {
                          // Create student record
                          $insert_student = "INSERT INTO students (user_id, degree_document, created_at) VALUES (?, ?, NOW())";
                          $insert_stmt = $conn->prepare($insert_student);
                          $insert_stmt->execute([$user_id, $destination]);
                      }
                  } else {
                      throw new Exception("Failed to upload document.");
                  }
              }
          }
          
          // Commit transaction
          $conn->commit();
          
          echo json_encode(['success' => true, 'message' => $message]);
      } 
      elseif ($_POST['action'] == 'delete' && !empty($_POST['user_id'])) {
          $user_id = sanitize_input($_POST['user_id']);
          
          // Begin transaction
          $conn->beginTransaction();
          
          // Delete enrollment record if exists
          $delete_enrollment = "DELETE FROM enrollment WHERE user_id = ?";
          $delete_enrollment_stmt = $conn->prepare($delete_enrollment);
          $delete_enrollment_stmt->execute([$user_id]);
          
          $delete_instructor = "DELETE FROM instructors WHERE user_id = ?";
          $delete_instructor_stmt = $conn->prepare($delete_instructor);
          $delete_instructor_stmt->execute([$user_id]);
          
          // Delete student record if exists
          $delete_student = "DELETE FROM students WHERE user_id = ?";
          $delete_student_stmt = $conn->prepare($delete_student);
          $delete_student_stmt->execute([$user_id]);
          
          // Delete user
          $delete_user = "DELETE FROM users WHERE id = ?";
          $delete_user_stmt = $conn->prepare($delete_user);
          $delete_user_stmt->execute([$user_id]);
          
          // Commit transaction
          $conn->commit();
          
          echo json_encode(['success' => true, 'message' => "User deleted successfully"]);
      }
      elseif ($_POST['action'] == 'get' && !empty($_POST['user_id'])) {
          $user_id = sanitize_input($_POST['user_id']);
          
          // Get user data with all student details
          $user_query = "SELECT u.*, e.program_id, e.department_id, e.batch_id, e.student_id,
                        s.mother_name, s.date_of_birth, s.place_of_birth, s.nationality, s.marital_status,
                        s.bachelor_institution, s.bachelor_specialization, s.bachelor_location, s.bachelor_year,
                        s.application_type, s.language_of_instruction, s.emergency_contact_name,
                        s.parent_associated_with_uni, s.parent_name, s.degree_document, s.registration_date,
                        i.specialization as instructor_specialization
                        FROM users u 
                        LEFT JOIN enrollment e ON u.id = e.user_id 
                        LEFT JOIN students s ON u.id = s.user_id
                        LEFT JOIN instructors i ON u.id = i.user_id
                        WHERE u.id = ?";
          $user_stmt = $conn->prepare($user_query);
          $user_stmt->execute([$user_id]);
          
          if ($user_stmt->rowCount() > 0) {
              $user = $user_stmt->fetch(PDO::FETCH_ASSOC);
              
              // Get document if user is student
              if ($user['role'] == 'student' && $user['degree_document']) {
                  $user['document'] = $user['degree_document'];
              }
              
              echo json_encode(['success' => true, 'data' => $user]);
          } else {
              throw new Exception("User not found");
          }
      }
      else {
          throw new Exception("Invalid action");
      }
  } catch(Exception $e) {
      // Rollback transaction if necessary
      if ($conn->inTransaction()) {
          $conn->rollBack();
      }
      echo json_encode(['success' => false, 'message' => $e->getMessage()]);
  }
  exit();
}

// Get all users for listing with student details
$users_query = "SELECT u.id, u.full_name, u.email, u.phone, u.gender, u.role, u.status, u.created_at, 
               e.student_id, p.name as program_name, d.name as department_name
               FROM users u 
               LEFT JOIN enrollment e ON u.id = e.user_id 
               LEFT JOIN programs p ON e.program_id = p.id 
               LEFT JOIN departments d ON e.department_id = d.id 
               ORDER BY u.created_at DESC";
$users_stmt = $conn->prepare($users_query);
$users_stmt->execute();
$users = $users_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all departments for dropdown
$all_departments_query = "SELECT id, name FROM departments ORDER BY name";
$all_departments_stmt = $conn->prepare($all_departments_query);
$all_departments_stmt->execute();
$all_departments = $all_departments_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all programs, including their associated department_id
$all_programs_query = "SELECT id, name, department_id FROM programs ORDER BY name";
$all_programs_stmt = $conn->prepare($all_programs_query);
$all_programs_stmt->execute();
$all_programs = $all_programs_stmt->fetchAll(PDO::FETCH_ASSOC);

// Create a map of department_id to programs for JavaScript
$programs_by_department = [];
foreach ($all_programs as $program) {
    if (!isset($programs_by_department[$program['department_id']])) {
        $programs_by_department[$program['department_id']] = [];
    }
    $programs_by_department[$program['department_id']][] = [
        'id' => $program['id'],
        'name' => $program['name']
    ];
}

// Create a map of program_id to department_id for JavaScript (still useful for batches)
$program_to_department_map = [];
foreach ($all_programs as $program) {
    $program_to_department_map[$program['id']] = $program['department_id'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Users - Benadir University LMS</title>
  <link rel="stylesheet" href="../assets/css/style.css">
  <link rel="stylesheet" href="../assets/css/admin.css">
  <link rel="stylesheet" href="../assets/css/modal.css">
  <link rel="stylesheet" href="../assets/css/users.css">
  <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
  <div class="admin-container">
      <?php include_once '../includes/sidebar.php'; ?>
      
      <div class="admin-content">
          <div class="admin-header">
              <h1>Manage Users</h1>
              
              <div class="admin-header-right">
                  <button class="btn btn-primary" id="addUserBtn">Add New User</button>
              </div>
          </div>
          
          <div id="alertContainer"></div>
          
          <!-- Filter Controls -->
          <div class="filter-controls">
              <div class="filter-item">
                  <label for="roleFilter">Role:</label>
                  <select id="roleFilter">
                      <option value="">All Roles</option>
                      <option value="admin">Admin</option>
                      <option value="instructor">Instructor</option>
                      <option value="student">Student</option>
                  </select>
              </div>
              <div class="filter-item">
                  <label for="statusFilter">Status:</label>
                  <select id="statusFilter">
                      <option value="">All Status</option>
                      <option value="active">Active</option>
                      <option value="inactive">Inactive</option>
                  </select>
              </div>
              <div class="filter-item">
                  <label for="searchInput">Search:</label>
                  <input type="text" id="searchInput" placeholder="Name, Email, ID...">
              </div>
          </div>
          
          <!-- Users List -->
          <div class="card">
              <div class="card-body">
                  <table class="data-table" id="usersTable">
                      <thead>
                          <tr>
                              <th>Name</th>
<th>Email</th>
<th>Role</th>
<th>Status</th>
<th>Program</th>
<th>Student ID</th>
<th>Actions</th>
                          </tr>
                      </thead>
                      <tbody>
                          <?php if (count($users) > 0): ?>
                              <?php foreach ($users as $user): ?>
                              <tr data-role="<?php echo $user['role']; ?>" data-status="<?php echo $user['status']; ?>">
                                  <td><?php echo $user['full_name']; ?></td>
<td><?php echo $user['email']; ?></td>
<td>
    <span class="role-badge <?php echo $user['role']; ?>">
        <?php echo ucfirst($user['role']); ?>
    </span>
</td>
                                  <td>
                                      <span class="status-badge <?php echo $user['status']; ?>">
                                          <?php echo ucfirst($user['status']); ?>
                                      </span>
                                  </td>
                                  <td>
                                      <?php if ($user['role'] == 'student'): ?>
                                          <?php echo $user['program_name']; ?>
                                      <?php else: ?>
                                          -
                                      <?php endif; ?>
                                  </td>
                                  <td>
                                      <?php if ($user['role'] == 'student'): ?>
                                          <?php echo $user['student_id'] ? $user['student_id'] : 'Not Assigned'; ?>
                                      <?php else: ?>
                                          -
                                      <?php endif; ?>
                                  </td>
                                  <td>
                                      <button class="btn btn-sm btn-info view-user-btn" data-id="<?php echo $user['id']; ?>">View</button>
                                      <button class="btn btn-sm btn-primary edit-user-btn" data-id="<?php echo $user['id']; ?>">Edit</button>
                                      <button class="btn btn-sm btn-danger delete-user-btn" data-id="<?php echo $user['id']; ?>">Delete</button>
                                  </td>
                              </tr>
                              <?php endforeach; ?>
                          <?php else: ?>
                              <tr>
                                  <td colspan="8" class="text-center">No users found</td>
                              </tr>
                          <?php endif; ?>
                      </tbody>
                  </table>
              </div>
          </div>
      </div>
  </div>
  
  <!-- User Modal -->
  <div id="userModalBackdrop" class="modal-backdrop"></div>
  <div id="userModalContainer" class="modal-container">
      <div class="modal-header">
          <h2 id="userModalTitle">Add New User</h2>
          <button class="modal-close" id="closeUserModal">&times;</button>
      </div>
      <div class="modal-body">
          <form id="userForm" enctype="multipart/form-data">
              <input type="hidden" id="user_id" name="user_id">
              <input type="hidden" id="form_action" name="action" value="add">
              <input type="hidden" name="ajax" value="1">
              
              <div class="form-row">
                  <label for="full_name">Full Name <span class="required">*</span></label>
                  <input type="text" id="full_name" name="full_name" required>
              </div>
              
              <div class="form-row">
                  <label for="email">Email <span class="required">*</span></label>
                  <input type="email" id="email" name="email" required>
              </div>
              
              <div class="form-row">
                  <label for="phone">Phone <span class="required">*</span></label>
                  <input type="text" id="phone" name="phone" required>
              </div>
              
              <div class="form-row">
                  <label for="gender">Gender <span class="required">*</span></label>
                  <select id="gender" name="gender" required>
                      <option value="">Select Gender</option>
                      <option value="male">Male</option>
                      <option value="female">Female</option>
                  </select>
              </div>
              
              <div class="form-row">
                  <label for="role">Role <span class="required">*</span></label>
                  <select id="role" name="role" required>
                      <option value="">Select Role</option>
                      <option value="admin">Admin</option>
                      <option value="instructor">Instructor</option>
                      <option value="student">Student</option>
                  </select>
              </div>
              
              <div class="form-row">
                  <label for="status">Status <span class="required">*</span></label>
                  <select id="status" name="status" required>
                      <option value="active">Active</option>
                      <option value="inactive">Inactive</option>
                  </select>
              </div>
              
              <!-- Student-specific fields -->
              <div id="studentFields" class="hidden">
                  <h3 class="section-title">Student Information</h3>
                  <p class="form-instruction">Please provide the following information for student enrollment.</p>
                  
                  <div class="form-row">
                      <label for="department_id">Department <span class="required">*</span></label>
                      <select id="department_id" name="department_id">
                          <option value="">Select Department</option>
                          <?php foreach ($all_departments as $department): ?>
                              <option value="<?php echo $department['id']; ?>"><?php echo $department['name']; ?></option>
                          <?php endforeach; ?>
                      </select>
                  </div>

                  <div class="form-row">
                      <label for="program_id">Program <span class="required">*</span></label>
                      <select id="program_id" name="program_id" disabled>
                          <option value="">Select Program</option>
                          <!-- Will be populated based on selected department -->
                      </select>
                  </div>
                  
                  <div class="form-row">
                      <label for="batch_id">Batch <span class="required">*</span></label>
                      <select id="batch_id" name="batch_id" disabled>
                          <option value="">Select Batch</option>
                          <!-- Will be populated based on selected program -->
                      </select>
                  </div>
                  
                  <h3 class="section-title">Personal Information</h3>
                  
                  <div class="form-row">
                      <label for="mother_name">Mother's Name</label>
                      <input type="text" id="mother_name" name="mother_name">
                  </div>
                  
                  <div class="form-row">
                      <label for="date_of_birth">Date of Birth</label>
                      <input type="date" id="date_of_birth" name="date_of_birth">
                  </div>
                  
                  <div class="form-row">
                      <label for="place_of_birth">Place of Birth</label>
                      <input type="text" id="place_of_birth" name="place_of_birth">
                  </div>
                  
                  <div class="form-row">
                      <label for="nationality">Nationality</label>
                      <input type="text" id="nationality" name="nationality">
                  </div>
                  
                  <div class="form-row">
                        <label for="marital_status">Marital Status <span class="required">*</span></label>
                              <select id="marital_status" name="marital_status" required>
                                  <option value="">Select Status</option>
                                  <option value="Single" <?php echo (isset($_POST['marital_status']) && $_POST['marital_status'] == 'Single') ? 'selected' : ''; ?>>Single</option>
                                  <option value="Married" <?php echo (isset($_POST['marital_status']) && $_POST['marital_status'] == 'Married') ? 'selected' : ''; ?>>Married</option>
                              </select>
                  </div>
                  
                  <div class="form-row">
                      <label for="emergency_contact_name">Emergency Contact Name</label>
                      <input type="text" id="emergency_contact_name" name="emergency_contact_name">
                  </div>
                  
                  <h3 class="section-title">Academic Background</h3>
                  
                  <div class="form-row">
                      <label for="bachelor_institution">Bachelor Institution</label>
                      <input type="text" id="bachelor_institution" name="bachelor_institution">
                  </div>
                  
                  <div class="form-row">
                      <label for="bachelor_specialization">Bachelor Specialization</label>
                      <input type="text" id="bachelor_specialization" name="bachelor_specialization">
                  </div>
                  
                  <div class="form-row">
                      <label for="bachelor_location">Bachelor Location</label>
                      <input type="text" id="bachelor_location" name="bachelor_location">
                  </div>
                  
                  <div class="form-row">
                      <label for="bachelor_year">Bachelor Year</label>
                      <input type="text" id="bachelor_year" name="bachelor_year">
                  </div>
                  
                  <h3 class="section-title">Application Details</h3>
                  
                  <div class="form-row">
                   <label for="application_type">Application Type <span class="required">*</span></label>
                              <select id="application_type" name="application_type" required>
                                  <option value="">Select Type</option>
                                  <option value="First Year" <?php echo (isset($_POST['application_type']) && $_POST['application_type'] == 'First Year') ? 'selected' : ''; ?>>First Year</option>
                                  <option value="Transfer" <?php echo (isset($_POST['application_type']) && $_POST['application_type'] == 'Transfer') ? 'selected' : ''; ?>>Transfer</option>
                              </select>
                  </div>
                  
                  <div class="form-row">
                      <label for="language_of_instruction"> Language of instruction <span class="required">*</span></label>
                              <select id="language_of_instruction" name="language_of_instruction" required>
                                  <option value="">Select Language</option>
                                  <option value="English" <?php echo (isset($_POST['language_of_instruction']) && $_POST['language_of_instruction'] == 'English') ? 'selected' : ''; ?>>English</option>
                                  <option value="Arabic" <?php echo (isset($_POST['language_of_instruction']) && $_POST['language_of_instruction'] == 'Arabic') ? 'selected' : ''; ?>>Arabic</option>
                                  <option value="Other" <?php echo (isset($_POST['language_of_instruction']) && $_POST['language_of_instruction'] == 'Other') ? 'selected' : ''; ?>>Other</option>
                              </select>
                  </div>
                  
                  <div class="form-row">
                      <label for="parent_associated_with_uni">Parent Associated with University</label>
                      <div class="checkbox-wrapper">
                          <input type="checkbox" id="parent_associated_with_uni" name="parent_associated_with_uni">
                          <label for="parent_associated_with_uni" class="checkbox-label">Yes</label>
                      </div>
                  </div>
                  
                  <div class="form-row" id="parent_name_field" style="display: none;">
                      <label for="parent_name">Parent Name</label>
                      <input type="text" id="parent_name" name="parent_name">
                  </div>
                  
                  <div class="form-row">
                      <label for="documents">Degree Document (PDF, JPEG, PNG)</label>
                      <input type="file" id="documents" name="documents[]" accept=".pdf,.jpg,.jpeg,.png">
                      <small class="form-text">Upload student degree document (max 5MB)</small>
                  </div>
                  
                  <div id="documentsList" class="documents-list"></div>
              </div>
              
              <!-- Instructor-specific fields -->
              <div id="instructorFields" class="hidden">
                  <h3 class="section-title">Instructor Information</h3>
                  <p class="form-instruction">Please provide the following information for instructor profile.</p>
                  
                  <div class="form-row">
                      <label for="instructor_specialization">Specialization</label>
                      <input type="text" id="instructor_specialization" name="instructor_specialization" placeholder="e.g., Computer Science, Mathematics, Physics">
                      <small class="form-text">Enter the instructor's area of specialization or expertise</small>
                  </div>
              </div>
          </form>
      </div>
      <div class="modal-footer">
          <button class="btn btn-secondary" id="cancelUserBtn">Cancel</button>
          <button class="btn btn-primary" id="saveUserBtn">Save User</button>
      </div>
  </div>
  
  <!-- Delete Modal -->
  <div id="deleteModalBackdrop" class="modal-backdrop"></div>
  <div id="deleteModalContainer" class="modal-container">
      <div class="modal-header">
          <h2>Delete User</h2>
          <button class="modal-close" id="closeDeleteModal">&times;</button>
      </div>
      <div class="modal-body">
          <p>Are you sure you want to delete this user? This action cannot be undone.</p>
          <input type="hidden" id="delete_user_id">
      </div>
      <div class="modal-footer">
          <button class="btn btn-secondary" id="cancelDeleteBtn">Cancel</button>
          <button class="btn btn-danger" id="confirmDeleteBtn">Delete</button>
      </div>
  </div>
  
  <!-- View User Modal -->
  <div id="viewModalBackdrop" class="modal-backdrop"></div>
  <div id="viewModalContainer" class="modal-container">
      <div class="modal-header">
          <h2>User Details</h2>
          <button class="modal-close" id="closeViewModal">&times;</button>
      </div>
      <div class="modal-body">
          <div id="userDetails">
              <div class="user-detail-row">
                  <strong>Full Name:</strong>
                  <span id="view_full_name"></span>
              </div>
              <div class="user-detail-row">
                  <strong>Email:</strong>
                  <span id="view_email"></span>
              </div>
              <div class="user-detail-row">
                  <strong>Phone:</strong>
                  <span id="view_phone"></span>
              </div>
              <div class="user-detail-row">
                  <strong>Gender:</strong>
                  <span id="view_gender"></span>
              </div>
              <div class="user-detail-row">
                  <strong>Role:</strong>
                  <span id="view_role"></span>
              </div>
              <div class="user-detail-row">
                  <strong>Status:</strong>
                  <span id="view_status"></span>
              </div>
              <!-- Added instructor details section for view modal -->
              <div id="view_instructor_details" class="hidden">
                  <h3 class="section-title">Instructor Information</h3>
                  <div class="user-detail-row">
                      <strong>Specialization:</strong>
                      <span id="view_instructor_specialization"></span>
                  </div>
              </div>
              <div id="view_student_details" class="hidden">
                  <h3 class="section-title">Student Information</h3>
                  <div class="user-detail-row">
                      <strong>Program:</strong>
                      <span id="view_program"></span>
                  </div>
                  <div class="user-detail-row">
                      <strong>Department:</strong>
                      <span id="view_department"></span>
                  </div>
                  <div class="user-detail-row">
                      <strong>Batch:</strong>
                      <span id="view_batch"></span>
                  </div>
                  <div class="user-detail-row">
                      <strong>Student ID:</strong>
                      <span id="view_student_id"></span>
                  </div>
                  <div class="user-detail-row">
                      <strong>Mother's Name:</strong>
                      <span id="view_mother_name"></span>
                  </div>
                  <div class="user-detail-row">
                      <strong>Date of Birth:</strong>
                      <span id="view_date_of_birth"></span>
                  </div>
                  <div class="user-detail-row">
                      <strong>Place of Birth:</strong>
                      <span id="view_place_of_birth"></span>
                  </div>
                  <div class="user-detail-row">
                      <strong>Nationality:</strong>
                      <span id="view_nationality"></span>
                  </div>
                  <div class="user-detail-row">
                      <strong>Marital Status:</strong>
                      <span id="view_marital_status"></span>
                  </div>
                  <div class="user-detail-row">
                      <strong>Emergency Contact:</strong>
                      <span id="view_emergency_contact"></span>
                  </div>
                  <h3 class="section-title">Academic Background</h3>
                  <div class="user-detail-row">
                      <strong>Bachelor Institution:</strong>
                      <span id="view_bachelor_institution"></span>
                  </div>
                  <div class="user-detail-row">
                      <strong>Bachelor Specialization:</strong>
                      <span id="view_bachelor_specialization"></span>
                  </div>
                  <div class="user-detail-row">
                      <strong>Bachelor Location:</strong>
                      <span id="view_bachelor_location"></span>
                  </div>
                  <div class="user-detail-row">
                      <strong>Bachelor Year:</strong>
                      <span id="view_bachelor_year"></span>
                  </div>
                  <div class="user-detail-row">
                      <strong>Application Type:</strong>
                      <span id="view_application_type"></span>
                  </div>
                  <div class="user-detail-row">
                      <strong>Language of Instruction:</strong>
                      <span id="view_language_of_instruction"></span>
                  </div>
                  <div class="user-detail-row">
                      <strong>Parent Associated with University:</strong>
                      <span id="view_parent_associated"></span>
                  </div>
                  <div class="user-detail-row" id="parent_name_row" style="display: none;">
                      <strong>Parent Name:</strong>
                      <span id="view_parent_name"></span>
                  </div>
                  <div class="user-detail-row">
                      <strong>Registration Date:</strong>
                      <span id="view_registration_date"></span>
                  </div>
                  <div id="view_documents" class="hidden">
                      <h3 class="section-title">Documents</h3>
                      <div id="view_documents_list"></div>
                  </div>
              </div>
          </div>
      </div>
      <div class="modal-footer">
          <button class="btn btn-secondary" id="closeViewBtn">Close</button>
      </div>
  </div>
  
  <script src="../assets/js/theme.js"></script>
  <script>
  document.addEventListener('DOMContentLoaded', function() {
      // DOM Elements
      const alertContainer = document.getElementById('alertContainer');
      const userModalBackdrop = document.getElementById('userModalBackdrop');
      const userModalContainer = document.getElementById('userModalContainer');
      const deleteModalBackdrop = document.getElementById('deleteModalBackdrop');
      const deleteModalContainer = document.getElementById('deleteModalContainer');
      const userForm = document.getElementById('userForm');
      const userModalTitle = document.getElementById('userModalTitle');
      const saveUserBtn = document.getElementById('saveUserBtn');
      const roleSelect = document.getElementById('role');
      const studentFields = document.getElementById('studentFields');
      const instructorFields = document.getElementById('instructorFields');
      const departmentSelect = document.getElementById('department_id'); // Changed order
      const programSelect = document.getElementById('program_id'); // Changed order
      const batchSelect = document.getElementById('batch_id'); // Renamed for clarity
      const documentsList = document.getElementById('documentsList');
      const parentAssociatedCheckbox = document.getElementById('parent_associated_with_uni');
      const parentNameField = document.getElementById('parent_name_field');
      
      // Filter elements
      const roleFilter = document.getElementById('roleFilter');
      const statusFilter = document.getElementById('statusFilter');
      const searchInput = document.getElementById('searchInput');
      
      // Data from PHP
      const programsByDepartment = <?php echo json_encode($programs_by_department); ?>;
      const programToDepartmentMap = <?php echo json_encode($program_to_department_map); ?>; // Still useful
      
      // DOM Elements for View Modal
      const viewModalBackdrop = document.getElementById('viewModalBackdrop');
      const viewModalContainer = document.getElementById('viewModalContainer');
      
      // Show alert message
      function showAlert(message, type = 'success') {
          const alert = document.createElement('div');
          alert.className = `alert alert-${type}`;
          alert.textContent = message;
          
          alertContainer.appendChild(alert);
          
          // Auto-remove after 5 seconds
          setTimeout(() => {
              alert.remove();
          }, 5000);
      }
      
      // Open user modal
      function openUserModal() {
          userModalBackdrop.classList.add('show');
          userModalContainer.classList.add('show');
      }
      
      // Close user modal
      function closeUserModal() {
          userModalBackdrop.classList.remove('show');
          userModalContainer.classList.remove('show');
      }
      
      // Open delete modal
      function openDeleteModal() {
          deleteModalBackdrop.classList.add('show');
          deleteModalContainer.classList.add('show');
      }
      
      // Close delete modal
      function closeDeleteModal() {
          deleteModalBackdrop.classList.remove('show');
          deleteModalContainer.classList.remove('show');
      }
      
      // Open view modal
      function openViewModal() {
          viewModalBackdrop.classList.add('show');
          viewModalContainer.classList.add('show');
      }

      // Close view modal
      function closeViewModal() {
          viewModalBackdrop.classList.remove('show');
          viewModalContainer.classList.remove('show');
      }
      
      // Function to populate the program dropdown based on selected department
      function updateProgramDropdown(departmentId, selectedProgramId = '') {
          programSelect.innerHTML = '<option value="">Select Program</option>';
          programSelect.disabled = true; // Disable by default
          batchSelect.innerHTML = '<option value="">Select Batch</option>'; // Clear batches
          batchSelect.disabled = true; // Disable batches

          if (departmentId && programsByDepartment[departmentId]) {
              programsByDepartment[departmentId].forEach(program => {
                  const option = document.createElement('option');
                  option.value = program.id;
                  option.textContent = program.name;
                  
                  if (selectedProgramId && program.id == selectedProgramId) {
                      option.selected = true;
                  }
                  
                  programSelect.appendChild(option);
              });
              programSelect.disabled = false; // Enable if programs are found
          }
      }

      // Get batches based on program (and its associated department)
      function loadBatches(programId, selectedBatchId = '') {
          batchSelect.innerHTML = '<option value="">Select Batch</option>';
          batchSelect.disabled = true;

          if (!programId) {
              return;
          }

          const departmentId = programToDepartmentMap[programId];
          if (!departmentId) {
              console.error('Department ID not found for selected program:', programId);
              return;
          }
          
          fetch(`../api/get_batches.php?program_id=${programId}`) // Changed to program_id
              .then(response => response.json())
              .then(data => {
                  let options = '<option value="">Select Batch</option>';
                  if (data.success && data.data.length > 0) {
                      data.data.forEach(batch => {
                          const selected = selectedBatchId && batch.id == selectedBatchId ? 'selected' : '';
                          options += `<option value="${batch.id}" ${selected}>${batch.name} (${batch.year})</option>`;
                      });
                  }
                  batchSelect.innerHTML = options;
                  batchSelect.disabled = false; // Enable batches if loaded
              })
              .catch(error => {
                  console.error('Error loading batches:', error);
                  batchSelect.innerHTML = '<option value="">Error loading batches</option>';
              });
      }
      
      // Toggle student fields based on role selection
      roleSelect.addEventListener('change', function() {
          if (this.value === 'student') {
              studentFields.classList.add('active');
              studentFields.classList.remove('hidden');
              instructorFields.classList.remove('active');
              instructorFields.classList.add('hidden');
              
              // Make student fields required
              departmentSelect.setAttribute('required', 'required');
              programSelect.setAttribute('required', 'required');
              batchSelect.setAttribute('required', 'required');
          } else if (this.value === 'instructor') {
              instructorFields.classList.add('active');
              instructorFields.classList.remove('hidden');
              studentFields.classList.remove('active');
              studentFields.classList.add('hidden');
              
              // Remove required attribute from student fields
              departmentSelect.removeAttribute('required');
              programSelect.removeAttribute('required');
              batchSelect.removeAttribute('required');
          } else {
              studentFields.classList.remove('active');
              studentFields.classList.add('hidden');
              instructorFields.classList.remove('active');
              instructorFields.classList.add('hidden');
              
              // Remove required attribute from student fields
              departmentSelect.removeAttribute('required');
              programSelect.removeAttribute('required');
              batchSelect.removeAttribute('required');
          }
      });
      
      // Toggle parent name field based on checkbox
      parentAssociatedCheckbox.addEventListener('change', function() {
          if (this.checked) {
              parentNameField.style.display = 'block';
          } else {
              parentNameField.style.display = 'none';
          }
      });
      
      // Populate programs when department changes
      departmentSelect.addEventListener('change', function() {
          updateProgramDropdown(this.value);
      });

      // Load batches when program changes
      programSelect.addEventListener('change', function() {
          loadBatches(this.value);
      });
      
      // Add User button click
      document.getElementById('addUserBtn').addEventListener('click', function() {
          // Reset form
          userForm.reset();
          document.getElementById('user_id').value = '';
          document.getElementById('form_action').value = 'add';
          
          // Clear documents list
          documentsList.innerHTML = '';
          
          // Hide student fields initially
          studentFields.classList.add('hidden');
          studentFields.classList.remove('active');
          
          // Hide parent name field initially
          parentNameField.style.display = 'none';
          
          // Update modal title and button
          userModalTitle.textContent = 'Add New User';
          saveUserBtn.textContent = 'Create User';

          // Reset department, program, and batch dropdowns for new user
          departmentSelect.value = ''; // Clear department selection
          updateProgramDropdown(''); // Clear program and disable
          batchSelect.innerHTML = '<option value="">Select Batch</option>'; // Clear batches
          batchSelect.disabled = true; // Disable batches
          
          // Open modal
          openUserModal();
      });
      
      // Close user modal
      document.getElementById('closeUserModal').addEventListener('click', closeUserModal);
      document.getElementById('cancelUserBtn').addEventListener('click', closeUserModal);
      
      // Close user modal when clicking on backdrop
      userModalBackdrop.addEventListener('click', closeUserModal);
      
      // Close delete modal
      document.getElementById('closeDeleteModal').addEventListener('click', closeDeleteModal);
      document.getElementById('cancelDeleteBtn').addEventListener('click', closeDeleteModal);
      
      // Close delete modal when clicking on backdrop
      deleteModalBackdrop.addEventListener('click', closeDeleteModal);
      
      // Close view modal
      document.getElementById('closeViewModal').addEventListener('click', closeViewModal);
      document.getElementById('closeViewBtn').addEventListener('click', closeViewModal);

      // Close view modal when clicking on backdrop
      viewModalBackdrop.addEventListener('click', closeViewModal);
      
      // Edit user button click
      document.querySelectorAll('.edit-user-btn').forEach(button => {
          button.addEventListener('click', function() {
              const userId = this.getAttribute('data-id');
              
              // Set loading state
              button.disabled = true;
              button.innerHTML = 'Loading...';
              
              // Fetch user data
              const formData = new FormData();
              formData.append('ajax', 1);
              formData.append('action', 'get');
              formData.append('user_id', userId);
              
              fetch('users.php', {
                  method: 'POST',
                  body: formData
              })
              .then(response => response.json())
              .then(data => {
                  button.disabled = false;
                  button.innerHTML = 'Edit';
                  
                  if (data.success) {
                      const user = data.data;
                      
                      // Fill form with user data
                      document.getElementById('user_id').value = user.id;
                      document.getElementById('form_action').value = 'edit';
                      document.getElementById('full_name').value = user.full_name;
                      document.getElementById('email').value = user.email;
                      document.getElementById('phone').value = user.phone;
                      document.getElementById('gender').value = user.gender;
                      document.getElementById('role').value = user.role;
                      document.getElementById('status').value = user.status;
                      
                      if (user.role === 'instructor') {
                          instructorFields.classList.add('active');
                          instructorFields.classList.remove('hidden');
                          document.getElementById('instructor_specialization').value = user.instructor_specialization || '';
                          document.getElementById('instructor_specialization').setAttribute('required', 'required');
                      } else {
                          instructorFields.classList.remove('active');
                          instructorFields.classList.add('hidden');
                          document.getElementById('instructor_specialization').value = '';
                          document.getElementById('instructor_specialization').removeAttribute('required');
                      }
                      
                      // Populate student fields if role is student
                      if (user.role === 'student') {
                          studentFields.classList.add('active');
                          studentFields.classList.remove('hidden');
                          
                          // Make student fields required
                          departmentSelect.setAttribute('required', 'required');
                          programSelect.setAttribute('required', 'required');
                          batchSelect.setAttribute('required', 'required');
                          
                          // Set department and then populate program
                          departmentSelect.value = user.department_id || '';
                          updateProgramDropdown(user.department_id, user.program_id);
                          
                          // Load batches after program is set
                          loadBatches(user.program_id, user.batch_id);
                          
                          // Set additional student fields with proper fallbacks
                          document.getElementById('mother_name').value = user.mother_name || '';
                          document.getElementById('date_of_birth').value = user.date_of_birth || '';
                          document.getElementById('place_of_birth').value = user.place_of_birth || '';
                          document.getElementById('nationality').value = user.nationality || '';

                          // Set marital status dropdown with proper selection using setTimeout for timing
                          setTimeout(() => {
                              const maritalStatusSelect = document.getElementById('marital_status');
                              if (user.marital_status) {
                                  // Find and select the matching option
                                  const options = maritalStatusSelect.options;
                                  for (let i = 0; i < options.length; i++) {
                                      if (options[i].value === user.marital_status) {
                                          options[i].selected = true;
                                          maritalStatusSelect.value = user.marital_status;
                                          break;
                                      }
                                  }
                              } else {
                                  maritalStatusSelect.selectedIndex = 0; // Select first option (empty)
                              }
                          }, 100);

                          document.getElementById('bachelor_institution').value = user.bachelor_institution || '';
                          document.getElementById('bachelor_specialization').value = user.bachelor_specialization || '';
                          document.getElementById('bachelor_location').value = user.bachelor_location || '';
                          document.getElementById('bachelor_year').value = user.bachelor_year || '';

                          // Set application type dropdown with proper selection using setTimeout for timing
                          setTimeout(() => {
                              const applicationTypeSelect = document.getElementById('application_type');
                              if (user.application_type) {
                                  // Find and select the matching option
                                  const options = applicationTypeSelect.options;
                                  for (let i = 0; i < options.length; i++) {
                                      if (options[i].value === user.application_type) {
                                          options[i].selected = true;
                                          applicationTypeSelect.value = user.application_type;
                                          break;
                                      }
                                  }
                              } else {
                                  applicationTypeSelect.selectedIndex = 0; // Select first option (empty)
                              }
                          }, 100);

                          // Set language of instruction dropdown with proper selection using setTimeout for timing
                          setTimeout(() => {
                              const languageSelect = document.getElementById('language_of_instruction');
                              if (user.language_of_instruction) {
                                  // Find and select the matching option
                                  const options = languageSelect.options;
                                  for (let i = 0; i < options.length; i++) {
                                      if (options[i].value === user.language_of_instruction) {
                                          options[i].selected = true;
                                          languageSelect.value = user.language_of_instruction;
                                          break;
                                      }
                                  }
                              } else {
                                  languageSelect.selectedIndex = 0; // Select first option (empty)
                              }
                          }, 100);

                          document.getElementById('emergency_contact_name').value = user.emergency_contact_name || '';
                          
                          // Handle parent association
                          if (user.parent_associated_with_uni == 1) {
                              document.getElementById('parent_associated_with_uni').checked = true;
                              parentNameField.style.display = 'block';
                              document.getElementById('parent_name').value = user.parent_name || '';
                          } else {
                              document.getElementById('parent_associated_with_uni').checked = false;
                              parentNameField.style.display = 'none';
                              document.getElementById('parent_name').value = '';
                          }
                          
                          // Display document if any
                          documentsList.innerHTML = '';
                          if (user.degree_document) {
                              const docList = document.createElement('ul');
                              docList.className = 'documents-list';
                              
                              const listItem = document.createElement('li');
                              const link = document.createElement('a');
                              link.href = user.degree_document;
                              
                              // Extract filename from path
                              const fileName = user.degree_document.split('/').pop();
                              link.textContent = fileName;
                              link.target = '_blank';
                              
                              listItem.appendChild(link);
                              docList.appendChild(listItem);
                              
                              documentsList.appendChild(docList);
                          }
                      } else {
                          studentFields.classList.remove('active');
                          studentFields.classList.add('hidden');
                          
                          // Remove required attribute from student fields
                          departmentSelect.removeAttribute('required');
                          programSelect.removeAttribute('required');
                          batchSelect.removeAttribute('required');
                          
                          // Clear all student fields when role is not student
                          departmentSelect.value = '';
                          programSelect.value = '';
                          batchSelect.value = '';
                          departmentSelect.disabled = false; // Ensure department is enabled
                          programSelect.disabled = true; // Ensure program is disabled
                          batchSelect.disabled = true; // Ensure batch is disabled
                          document.getElementById('mother_name').value = '';
                          document.getElementById('date_of_birth').value = '';
                          document.getElementById('place_of_birth').value = '';
                          document.getElementById('nationality').value = '';

                          // Reset dropdown fields properly using setTimeout for timing
                          setTimeout(() => {
                              document.getElementById('marital_status').selectedIndex = 0;
                              document.getElementById('application_type').selectedIndex = 0;
                              document.getElementById('language_of_instruction').selectedIndex = 0;
                          }, 100);

                          document.getElementById('bachelor_institution').value = '';
                          document.getElementById('bachelor_specialization').value = '';
                          document.getElementById('bachelor_location').value = '';
                          document.getElementById('bachelor_year').value = '';
                          document.getElementById('emergency_contact_name').value = '';
                          document.getElementById('parent_associated_with_uni').checked = false;
                          document.getElementById('parent_name').value = '';
                          parentNameField.style.display = 'none';
                          documentsList.innerHTML = '';
                      }
                      
                      // Update modal title and button
                      userModalTitle.textContent = 'Edit User';
                      saveUserBtn.textContent = 'Update User';
                      
                      // Open modal
                      openUserModal();
                  } else {
                      showAlert(data.message, 'danger');
                  }
              })
              .catch(error => {
                  button.disabled = false;
                  button.innerHTML = 'Edit';
                  showAlert('An error occurred while fetching user data.', 'danger');
              });
          });
      });
      
      // View user button click
      document.querySelectorAll('.view-user-btn').forEach(button => {
          button.addEventListener('click', function() {
              const userId = this.getAttribute('data-id');
              
              // Set loading state
              button.disabled = true;
              button.innerHTML = 'Loading...';
              
              // Fetch user data
              const formData = new FormData();
              formData.append('ajax', 1);
              formData.append('action', 'get');
              formData.append('user_id', userId);
              
              fetch('users.php', {
                  method: 'POST',
                  body: formData
              })
              .then(response => response.json())
              .then(data => {
                  button.disabled = false;
                  button.innerHTML = 'View';
                  
                  if (data.success) {
                      const user = data.data;
                      
                      // Fill view modal with user data
                      document.getElementById('view_full_name').textContent = user.full_name;
                      document.getElementById('view_email').textContent = user.email;
                      document.getElementById('view_phone').textContent = user.phone;
                      document.getElementById('view_gender').textContent = user.gender.charAt(0).toUpperCase() + user.gender.slice(1);
                      
                      // Set role with badge
                      const roleBadge = document.createElement('span');
                      roleBadge.className = `role-badge ${user.role}`;
                      roleBadge.textContent = user.role.charAt(0).toUpperCase() + user.role.slice(1);
                      document.getElementById('view_role').innerHTML = '';
                      document.getElementById('view_role').appendChild(roleBadge);
                      
                      // Set status with badge
                      const statusBadge = document.createElement('span');
                      statusBadge.className = `status-badge ${user.status}`;
                      statusBadge.textContent = user.status.charAt(0).toUpperCase() + user.status.slice(1);
                      document.getElementById('view_status').innerHTML = '';
                      document.getElementById('view_status').appendChild(statusBadge);
                      
                      const instructorDetails = document.getElementById('view_instructor_details');
                      if (user.role === 'instructor') {
                          instructorDetails.classList.remove('hidden');
                          document.getElementById('view_instructor_specialization').textContent = user.instructor_specialization || 'Not specified';
                      } else {
                          instructorDetails.classList.add('hidden');
                      }
                      
                      // Handle student-specific fields
                      const studentDetails = document.getElementById('view_student_details');
                      if (user.role === 'student') {
                          studentDetails.classList.remove('hidden');
                          
                          // Get program and department names from the table
                          const userRow = document.querySelector(`tr [data-id="${userId}"]`).closest('tr');
                          const programDept = userRow.cells[5].textContent.trim();
                          const [program, department] = programDept.split(' / ');
                          
                          document.getElementById('view_program').textContent = program || 'Not assigned';
                          document.getElementById('view_department').textContent = department || 'Not assigned';
                          
                          // Get batch information directly from the server
                          let batchName = 'Not assigned';
                          if (user.batch_id) {
                              // Fetch batch information from the database
                              fetch(`../api/get_batch_info.php?batch_id=${user.batch_id}`)
                                  .then(response => response.json())
                                  .then(batchData => {
                                      if (batchData.success && batchData.data) {
                                          document.getElementById('view_batch').textContent = 
                                              `${batchData.data.name} (${batchData.data.year})`;
                                      }
                                  })
                                  .catch(error => {
                                      console.error('Error fetching batch info:', error);
                                  });
                          } else {
                              document.getElementById('view_batch').textContent = batchName;
                          }
                          
                          // Set student ID
                          document.getElementById('view_student_id').textContent = user.student_id || 'Not assigned';
                          
                          // Display document if any
                          const viewDocuments = document.getElementById('view_documents');
                          const viewDocumentsList = document.getElementById('view_documents_list');
                          viewDocumentsList.innerHTML = '';

                          if (user.degree_document) {
                              viewDocuments.classList.remove('hidden');
                              
                              const docList = document.createElement('ul');
                              docList.className = 'documents-list';
                              
                              const listItem = document.createElement('li');
                              const link = document.createElement('a');
                              link.href = user.degree_document;
                              
                              // Extract filename from path
                              const fileName = user.degree_document.split('/').pop();
                              link.textContent = fileName;
                              link.target = '_blank';
                              
                              listItem.appendChild(link);
                              docList.appendChild(listItem);
                              
                              viewDocumentsList.appendChild(docList);
                          } else {
                              viewDocuments.classList.add('hidden');
                          }
                          
                          // Fill additional student details with proper database values
                          document.getElementById('view_mother_name').textContent = user.mother_name || 'Not specified';
                          document.getElementById('view_date_of_birth').textContent = user.date_of_birth ? 
                              new Date(user.date_of_birth).toLocaleDateString() : 'Not specified';
                          document.getElementById('view_place_of_birth').textContent = user.place_of_birth || 'Not specified';
                          document.getElementById('view_nationality').textContent = user.nationality || 'Not specified';
                          document.getElementById('view_marital_status').textContent = user.marital_status || 'Not specified';
                          document.getElementById('view_emergency_contact').textContent = user.emergency_contact_name || 'Not specified';
                          document.getElementById('view_bachelor_institution').textContent = user.bachelor_institution || 'Not specified';
                          document.getElementById('view_bachelor_specialization').textContent = user.bachelor_specialization || 'Not specified';
                          document.getElementById('view_bachelor_location').textContent = user.bachelor_location || 'Not specified';
                          document.getElementById('view_bachelor_year').textContent = user.bachelor_year || 'Not specified';
                          document.getElementById('view_application_type').textContent = user.application_type || 'Not specified';
                          document.getElementById('view_language_of_instruction').textContent = user.language_of_instruction || 'Not specified';
                          document.getElementById('view_parent_associated').textContent = user.parent_associated_with_uni == 1 ? 'Yes' : 'No';

                          // Show parent name if associated
                          if (user.parent_associated_with_uni == 1 && user.parent_name) {
                              document.getElementById('view_parent_name').textContent = user.parent_name;
                              document.getElementById('parent_name_row').style.display = 'flex';
                          } else {
                              document.getElementById('parent_name_row').style.display = 'none';
                          }

                          document.getElementById('view_registration_date').textContent = user.registration_date ? 
                              new Date(user.registration_date).toLocaleDateString() : 
                              new Date(user.created_at).toLocaleDateString();
                      } else {
                          studentDetails.classList.add('hidden');
                      }
                      
                      // Open modal
                      openViewModal();
                  } else {
                      showAlert(data.message, 'danger');
                  }
              })
              .catch(error => {
                  button.disabled = false;
                  button.innerHTML = 'View';
                  showAlert('An error occurred while fetching user data.', 'danger');
              });
          });
      });
      
      // Delete user button click
      document.querySelectorAll('.delete-user-btn').forEach(button => {
          button.addEventListener('click', function() {
              const userId = this.getAttribute('data-id');
              document.getElementById('delete_user_id').value = userId;
              openDeleteModal();
          });
      });
      
      // Confirm delete button click
      document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
          const userId = document.getElementById('delete_user_id').value;
          
          // Set loading state
          this.disabled = true;
          this.innerHTML = 'Deleting...';
          
          // Delete user
          const formData = new FormData();
          formData.append('ajax', 1);
          formData.append('action', 'delete');
          formData.append('user_id', userId);
          
          fetch('users.php', {
              method: 'POST',
              body: formData
          })
          .then(response => response.json())
          .then(data => {
              this.disabled = false;
              this.innerHTML = 'Delete';
              
              if (data.success) {
                  showAlert(data.message, 'success');
                  closeDeleteModal();
                  
                  // Reload page to refresh the table
                  setTimeout(() => {
                      location.reload();
                  }, 1000);
              } else {
                  showAlert(data.message, 'danger');
              }
          })
          .catch(error => {
              this.disabled = false;
              this.innerHTML = 'Delete';
              showAlert('An error occurred while deleting user.', 'danger');
          });
      });
      
      // Save user button click
      saveUserBtn.addEventListener('click', function() {
          // Set loading state
          this.disabled = true;
          this.innerHTML = 'Saving...';
          
          // Submit form
          const formData = new FormData(userForm);
          
          fetch('users.php', {
              method: 'POST',
              body: formData
          })
          .then(response => response.json())
          .then(data => {
              this.disabled = false;
              this.innerHTML = document.getElementById('form_action').value === 'add' ? 'Create User' : 'Update User';
              
              if (data.success) {
                  showAlert(data.message, 'success');
                  closeUserModal();
                  
                  // Reload page to refresh the table
                  setTimeout(() => {
                      location.reload();
                  }, 1000);
              } else {
                  showAlert(data.message, 'danger');
              }
          })
          .catch(error => {
              this.disabled = false;
              this.innerHTML = document.getElementById('form_action').value === 'add' ? 'Create User' : 'Update User';
              showAlert('An error occurred while saving user.', 'danger');
          });
      });
      
      // Filter functionality
      function filterTable() {
          const roleFilterValue = roleFilter.value.toLowerCase();
          const statusFilterValue = statusFilter.value.toLowerCase();
          const searchValue = searchInput.value.toLowerCase();
          
          const rows = document.querySelectorAll('#usersTable tbody tr');
          
          rows.forEach(row => {
              const role = row.getAttribute('data-role');
              const status = row.getAttribute('data-status');
              const cells = row.querySelectorAll('td');
              
              // Get text content from all cells for search
              const rowText = Array.from(cells).map(cell => cell.textContent.toLowerCase()).join(' ');
              
              // Check filters
              const roleMatch = !roleFilterValue || role === roleFilterValue;
              const statusMatch = !statusFilterValue || status === statusFilterValue;
              const searchMatch = !searchValue || rowText.includes(searchValue);
              
              // Show/hide row
              if (roleMatch && statusMatch && searchMatch) {
                  row.style.display = '';
              } else {
                  row.style.display = 'none';
              }
          });
      }
      
      // Add event listeners for filters
      roleFilter.addEventListener('change', filterTable);
      statusFilter.addEventListener('change', filterTable);
      searchInput.addEventListener('input', filterTable);
  });
  </script>
</body>
</html>
