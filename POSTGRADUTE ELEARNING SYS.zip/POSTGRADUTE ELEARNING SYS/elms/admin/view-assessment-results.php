<?php
session_start();
include_once '../config/init.php';

// Set default timezone
date_default_timezone_set('Africa/Mogadishu');

// Check if user is logged in and is an admin
if (!is_logged_in() || !is_admin()) {
    header("Location: ../auth/login.php");
    exit();
}

$assessment_id = isset($_GET['assessment_id']) ? intval($_GET['assessment_id']) : 0;
$assessment = null;
$results = [];
$statistics = [];
$message = '';
$messageType = '';

if ($assessment_id <= 0) {
    header("Location: assessments");
    exit();
}

try {
    // Get assessment details
    $assessment_query = "SELECT a.*, c.name as course_name, c.code as course_code,
                                d.name as department_name, p.name as program_name,
                                u.full_name as creator_name
                         FROM assessments a
                         LEFT JOIN course c ON a.course_id = c.id
                         LEFT JOIN departments d ON a.department_id = d.id
                         LEFT JOIN programs p ON a.program_id = p.id
                         LEFT JOIN users u ON a.created_by = u.id
                         WHERE a.id = ?";
    $assessment_stmt = $conn->prepare($assessment_query);
    $assessment_stmt->execute([$assessment_id]);
    $assessment = $assessment_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$assessment) {
        header("Location: assessments");
        exit();
    }

    // Get assessment results with student information
    $results_query = "SELECT ar.*, u.full_name as student_name, e.student_id as enrollment_id,
                             b.name as batch_name, p.name as program_name, d.name as department_name
                     FROM assessment_results ar
                     JOIN users u ON ar.student_id = u.id
                     LEFT JOIN enrollment e ON u.id = e.user_id
                     LEFT JOIN batch b ON e.batch_id = b.id
                     LEFT JOIN programs p ON e.program_id = p.id
                     LEFT JOIN departments d ON e.department_id = d.id
                     WHERE ar.assessment_id = ?
                     ORDER BY ar.marks_obtained DESC, u.full_name ASC";
    $results_stmt = $conn->prepare($results_query);
    $results_stmt->execute([$assessment_id]);
    $results = $results_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Calculate statistics
    if (!empty($results)) {
        $marks = array_column($results, 'marks_obtained');
        $total_marks = $assessment['total_marks'];
        $pass_marks = $assessment['pass_marks'];
        
        // Calculate pass/fail counts
        $pass_count = 0;
        $fail_count = 0;
        foreach ($results as $result) {
            if ($result['marks_obtained'] >= $pass_marks) {
                $pass_count++;
            } else {
                $fail_count++;
            }
        }
        
        $statistics = [
            'total_submissions' => count($results),
            'highest_marks' => max($marks),
            'lowest_marks' => min($marks),
            'average_marks' => round(array_sum($marks) / count($marks), 2),
            'pass_count' => $pass_count,
            'fail_count' => $fail_count,
            'average_percentage' => round((array_sum($marks) / count($marks)) / $total_marks * 100, 2),
            'pass_percentage' => count($results) > 0 ? round(($pass_count / count($results)) * 100, 2) : 0
        ];
        
        // Grade distribution
        $grade_distribution = ['A' => 0, 'B' => 0, 'C' => 0, 'D' => 0, 'F' => 0];
        foreach ($results as $result) {
            $percentage = ($result['marks_obtained'] / $total_marks) * 100;
            if ($percentage >= 90) $grade_distribution['A']++;
            elseif ($percentage >= 80) $grade_distribution['B']++;
            elseif ($percentage >= 70) $grade_distribution['C']++;
            elseif ($percentage >= 60) $grade_distribution['D']++;
            else $grade_distribution['F']++;
        }
        $statistics['grade_distribution'] = $grade_distribution;
    }

} catch (PDOException $e) {
    error_log("Error fetching assessment results: " . $e->getMessage());
    $message = "Error loading assessment results.";
    $messageType = "danger";
}

// Function to calculate letter grade
function calculateLetterGrade($percentage) {
    if ($percentage >= 90) return 'A';
    elseif ($percentage >= 80) return 'B';
    elseif ($percentage >= 70) return 'C';
    elseif ($percentage >= 60) return 'D';
    else return 'F';
}

// Function to get grade color class
function getGradeColorClass($percentage) {
    if ($percentage >= 80) return 'excellent';
    elseif ($percentage >= 70) return 'good';
    elseif ($percentage >= 60) return 'average';
    else return 'poor';
}

// Function to get assessment scope display
function getAssessmentScope($assessment) {
    if ($assessment['program_id'] && $assessment['program_name']) {
        return $assessment['program_name'] . ' Program';
    } elseif ($assessment['department_id'] && $assessment['department_name']) {
        return $assessment['department_name'] . ' Department';
    } else {
        return 'System-wide';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assessment Results - <?php echo htmlspecialchars($assessment['title'] ?? ''); ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <?php echo FONT_AWESOME_CSS; ?>
    <style>
        .assessment-info {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
            border-left: 4px solid var(--primary-color);
        }

        .assessment-meta {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }

        .meta-item {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .meta-label {
            font-size: 0.85rem;
            color: var(--text-muted);
            font-weight: 500;
        }

        .meta-value {
            font-size: 1rem;
            color: var(--text-color);
            font-weight: 600;
        }

        .statistics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            text-align: center;
            border-top: 4px solid var(--primary-color);
            transition: transform 0.2s ease;
        }

        .stat-card:hover {
            transform: translateY(-2px);
        }

        .stat-icon {
            font-size: 2rem;
            color: var(--primary-color);
            margin-bottom: 10px;
        }

        .stat-value {
            font-size: 1.8rem;
            font-weight: bold;
            color: var(--text-color);
            margin-bottom: 5px;
        }

        .stat-label {
            font-size: 0.9rem;
            color: var(--text-muted);
        }

        .charts-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-bottom: 30px;
        }

        .chart-container {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            min-height: 350px;
            display: flex;
            flex-direction: column;
        }

        .chart-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--text-color);
            margin-bottom: 20px;
            text-align: center;
        }

        .chart-wrapper {
            flex: 1;
            position: relative;
            min-height: 250px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .chart-wrapper canvas {
            max-width: 100%;
            max-height: 100%;
        }

        .results-table-container {
            background: var(--card-bg);
            border-radius: 12px;
            box-shadow: var(--shadow);
            overflow: hidden;
        }

        .table-header {
            background: var(--bg-secondary);
            padding: 20px;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .results-table {
            width: 100%;
            border-collapse: collapse;
        }

        .results-table th {
            background: var(--bg-secondary);
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: var(--text-color);
            border-bottom: 1px solid var(--border-color);
        }

        .results-table td {
            padding: 12px 15px;
            border-bottom: 1px solid var(--border-light);
            color: var(--text-color);
        }

        .results-table tbody tr:hover {
            background: var(--hover-bg);
        }

        .student-name {
            font-weight: 600;
            color: var(--text-color);
        }

        .student-id {
            font-size: 0.85rem;
            color: var(--text-muted);
        }

        .batch-info {
            font-size: 0.85rem;
            color: var(--text-muted);
        }

        .score-display {
            font-weight: 600;
        }

        .percentage {
            font-size: 0.9rem;
            color: var(--text-muted);
        }

        .grade-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 12px;
            font-weight: bold;
            font-size: 0.8rem;
        }

        .grade-badge.excellent { background: #d1fae5; color: #059669; }
        .grade-badge.good { background: #dbeafe; color: #2563eb; }
        .grade-badge.average { background: #fef3c7; color: #d97706; }
        .grade-badge.poor { background: #fee2e2; color: #dc2626; }

        .status-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 500;
        }

        .status-badge.passed {
            background: #d1fae5;
            color: #047857;
        }

        .status-badge.failed {
            background: #fee2e2;
            color: #b91c1c;
        }

        .export-actions {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .btn-export {
            padding: 8px 16px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            background: var(--card-bg);
            color: var(--text-color);
            text-decoration: none;
            font-size: 0.9rem;
            transition: all 0.2s;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-export:hover {
            background: var(--hover-bg);
            text-decoration: none;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-muted);
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.3;
        }

        .admin-notice {
            background: #dbeafe;
            color: #1e40af;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #3b82f6;
        }

        .admin-notice i {
            margin-right: 8px;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .statistics-grid {
                grid-template-columns: repeat(3, 1fr);
            }
            
            .charts-section {
                grid-template-columns: 1fr;
                gap: 20px;
            }
        }

        @media (max-width: 768px) {
            .statistics-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 15px;
            }
            
            .assessment-meta {
                grid-template-columns: 1fr;
            }
            
            .results-table {
                font-size: 0.9rem;
            }
            
            .results-table th,
            .results-table td {
                padding: 8px;
            }
            
            .export-actions {
                flex-direction: column;
            }
            
            .chart-container {
                min-height: 300px;
            }
            
            .chart-wrapper {
                min-height: 200px;
            }
        }

        @media (max-width: 480px) {
            .statistics-grid {
                grid-template-columns: 1fr;
            }
            
            .stat-card {
                padding: 15px;
            }
            
            .stat-value {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>Assessment Results</h1>
                <a href="assessments.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Assessments
                </a>
            </div>
            
            <?php if (!empty($message)): ?>
                <div class="message <?php echo $messageType; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

             Admin Notice 
            <div class="admin-notice">
                <i class="fas fa-shield-alt"></i>
                <strong>Admin View:</strong> You can view results for all assessments across the system. This includes batch-specific data and comprehensive analytics.
            </div>

            <?php if ($assessment): ?>
                 Assessment Information 
                <div class="assessment-info">
                    <h2><?php echo htmlspecialchars($assessment['title']); ?></h2>
                    <div class="assessment-meta">
                        <div class="meta-item">
                            <span class="meta-label">Type</span>
                            <span class="meta-value"><?php echo ucfirst($assessment['type']); ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Scope</span>
                            <span class="meta-value"><?php echo getAssessmentScope($assessment); ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Created By</span>
                            <span class="meta-value"><?php echo htmlspecialchars($assessment['creator_name']); ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Total Marks</span>
                            <span class="meta-value"><?php echo $assessment['total_marks']; ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Pass Marks</span>
                            <span class="meta-value"><?php echo $assessment['pass_marks']; ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">End Time</span>
                            <span class="meta-value"><?php echo date('M j, Y g:i A', strtotime($assessment['end_time'])); ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Status</span>
                            <span class="meta-value"><?php echo ucfirst($assessment['status']); ?></span>
                        </div>
                    </div>
                </div>

                <?php if (!empty($results)): ?>
                     Statistics 
                    <div class="statistics-grid">
                        <div class="stat-card">
                            <div class="stat-icon"><i class="fas fa-users"></i></div>
                            <div class="stat-value"><?php echo $statistics['total_submissions']; ?></div>
                            <div class="stat-label">Total Students</div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                            <div class="stat-value"><?php echo $statistics['pass_count']; ?></div>
                            <div class="stat-label">Students Passed</div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon"><i class="fas fa-times-circle"></i></div>
                            <div class="stat-value"><?php echo $statistics['fail_count']; ?></div>
                            <div class="stat-label">Students Failed</div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon"><i class="fas fa-chart-line"></i></div>
                            <div class="stat-value"><?php echo $statistics['average_percentage']; ?>%</div>
                            <div class="stat-label">Average Score</div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon"><i class="fas fa-trophy"></i></div>
                            <div class="stat-value"><?php echo $statistics['highest_marks']; ?></div>
                            <div class="stat-label">Highest Score</div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon"><i class="fas fa-percentage"></i></div>
                            <div class="stat-value"><?php echo $statistics['pass_percentage']; ?>%</div>
                            <div class="stat-label">Pass Rate</div>
                        </div>
                    </div>

                     Charts 
                    <div class="charts-section">
                        <div class="chart-container">
                            <h3 class="chart-title">Grade Distribution</h3>
                            <div class="chart-wrapper">
                                <canvas id="gradeChart"></canvas>
                            </div>
                        </div>
                        
                        <div class="chart-container">
                            <h3 class="chart-title">Pass/Fail Distribution</h3>
                            <div class="chart-wrapper">
                                <canvas id="passFailChart"></canvas>
                            </div>
                        </div>
                    </div>

                     Export Actions 
                    <div class="export-actions">
                        <button onclick="printResults()" class="btn-export">
                            <i class="fas fa-print"></i> Print Results
                        </button>
                        <button onclick="exportToCSV()" class="btn-export">
                            <i class="fas fa-download"></i> Export CSV
                        </button>
                    </div>

                     Results Table 
                    <div class="results-table-container">
                        <div class="table-header">
                            <h3><i class="fas fa-table"></i> Detailed Results</h3>
                            <span><?php echo count($results); ?> submissions</span>
                        </div>
                        
                        <div style="overflow-x: auto;">
                            <table class="results-table" id="resultsTable">
                                <thead>
                                    <tr>
                                        <th>Rank</th>
                                        <th>Student</th>
                                        <th>Student ID</th>
                                        <th>Batch</th>
                                        <th>Program</th>
                                        <th>Score</th>
                                        <th>Percentage</th>
                                        <th>Grade</th>
                                        <th>Status</th>
                                        <th>Submitted At</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($results as $index => $result): ?>
                                        <?php 
                                        $percentage = ($result['marks_obtained'] / $assessment['total_marks']) * 100;
                                        $letter_grade = calculateLetterGrade($percentage);
                                        $status = $result['marks_obtained'] >= $assessment['pass_marks'] ? 'passed' : 'failed';
                                        ?>
                                        <tr>
                                            <td><?php echo $index + 1; ?></td>
                                            <td>
                                                <div class="student-name"><?php echo htmlspecialchars($result['student_name']); ?></div>
                                            </td>
                                            <td>
                                                <div class="student-id"><?php echo htmlspecialchars($result['enrollment_id'] ?? 'N/A'); ?></div>
                                            </td>
                                            <td>
                                                <div class="batch-info"><?php echo htmlspecialchars($result['batch_name'] ?? 'N/A'); ?></div>
                                            </td>
                                            <td>
                                                <div class="batch-info"><?php echo htmlspecialchars($result['program_name'] ?? 'N/A'); ?></div>
                                            </td>
                                            <td>
                                                <div class="score-display">
                                                    <?php echo $result['marks_obtained']; ?>/<?php echo $assessment['total_marks']; ?>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="percentage"><?php echo round($percentage, 1); ?>%</div>
                                            </td>
                                            <td>
                                                <span class="grade-badge <?php echo getGradeColorClass($percentage); ?>">
                                                    <?php echo $letter_grade; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="status-badge <?php echo $status; ?>">
                                                    <?php echo ucfirst($status); ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('M j, Y g:i A', strtotime($result['submitted_at'])); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-chart-bar"></i>
                        <h3>No Submissions Yet</h3>
                        <p>No students have submitted this assessment yet.</p>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
    <script>
        <?php if (!empty($results)): ?>
        // Grade Distribution Chart
        const gradeCtx = document.getElementById('gradeChart').getContext('2d');
        new Chart(gradeCtx, {
            type: 'doughnut',
            data: {
                labels: ['A', 'B', 'C', 'D', 'F'],
                datasets: [{
                    data: [
                        <?php echo $statistics['grade_distribution']['A']; ?>,
                        <?php echo $statistics['grade_distribution']['B']; ?>,
                        <?php echo $statistics['grade_distribution']['C']; ?>,
                        <?php echo $statistics['grade_distribution']['D']; ?>,
                        <?php echo $statistics['grade_distribution']['F']; ?>
                    ],
                    backgroundColor: [
                        '#10b981',
                        '#3b82f6',
                        '#f59e0b',
                        '#ef4444',
                        '#6b7280'
                    ],
                    borderWidth: 2,
                    borderColor: '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.parsed;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((value / total) * 100).toFixed(1);
                                return `${label}: ${value} students (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });

        // Pass/Fail Chart
        const passFailCtx = document.getElementById('passFailChart').getContext('2d');
        new Chart(passFailCtx, {
            type: 'pie',
            data: {
                labels: ['Passed', 'Failed'],
                datasets: [{
                    data: [
                        <?php echo $statistics['pass_count']; ?>,
                        <?php echo $statistics['fail_count']; ?>
                    ],
                    backgroundColor: [
                        '#10b981',
                        '#ef4444'
                    ],
                    borderWidth: 2,
                    borderColor: '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.parsed;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((value / total) * 100).toFixed(1);
                                return `${label}: ${value} students (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
        <?php endif; ?>

        // Print functionality
        function printResults() {
            const printContent = document.querySelector('.admin-content').innerHTML;
            const originalContent = document.body.innerHTML;
            
            document.body.innerHTML = `
                <div style="padding: 20px; font-family: Arial, sans-serif;">
                    <h1 style="text-align: center; margin-bottom: 30px;">Assessment Results Report</h1>
                    <div style="margin-bottom: 20px;">
                        <strong>Assessment:</strong> <?php echo htmlspecialchars($assessment['title']); ?><br>
                        <strong>Generated on:</strong> ${new Date().toLocaleDateString()}
                    </div>
                    ${printContent}
                </div>
            `;
            
            window.print();
            document.body.innerHTML = originalContent;
            location.reload();
        }

        // Export to CSV functionality
        function exportToCSV() {
            const results = <?php echo json_encode($results); ?>;
            const assessmentTitle = "<?php echo htmlspecialchars($assessment['title']); ?>";
            const totalMarks = <?php echo $assessment['total_marks']; ?>;
            const passMarks = <?php echo $assessment['pass_marks']; ?>;
            
            let csvContent = `Assessment Results Report\n`;
            csvContent += `Assessment: ${assessmentTitle}\n`;
            csvContent += `Generated on: ${new Date().toLocaleDateString()}\n\n`;
            csvContent += `Rank,Student Name,Student ID,Batch,Program,Marks Obtained,Total Marks,Percentage,Grade,Status,Submitted At\n`;
            
            results.forEach((result, index) => {
                const percentage = Math.round((result.marks_obtained / totalMarks) * 100 * 10) / 10;
                const grade = percentage >= 90 ? 'A' : percentage >= 80 ? 'B' : percentage >= 70 ? 'C' : percentage >= 60 ? 'D' : 'F';
                const status = result.marks_obtained >= passMarks ? 'Passed' : 'Failed';
                const submittedAt = new Date(result.submitted_at).toLocaleDateString();
                
                csvContent += `${index + 1},"${result.student_name}","${result.enrollment_id || 'N/A'}","${result.batch_name || 'N/A'}","${result.program_name || 'N/A'}",${result.marks_obtained},${totalMarks},${percentage}%,"${grade}","${status}","${submittedAt}"\n`;
            });
            
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement("a");
            const url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", `assessment_results_${assessmentTitle.replace(/\s/g, '_')}.csv`);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    </script>
</body>
</html>
