<?php
session_start();
include_once '../../config/init.php';

// Check if user is logged in and has appropriate role
if (!is_logged_in() || (!is_admin() && !is_instructor())) {
    header("Location: ../../auth/login.php");
    exit();
}

$user_role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];

// Get filter parameters (same as report page)
$program_filter = $_GET['program'] ?? '';
$supervisor_filter = $_GET['supervisor'] ?? '';
$department_filter = $_GET['department'] ?? '';
$status_filter = $_GET['status'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$export_format = $_GET['format'] ?? 'csv';

// Build query based on user role
$where_conditions = [];
$params = [];

if ($user_role === 'instructor') {
    $where_conditions[] = "t.supervisor_id = ?";
    $params[] = $user_id;
}

if ($program_filter) {
    $where_conditions[] = "t.program_id = ?";
    $params[] = $program_filter;
}

if ($supervisor_filter) {
    $where_conditions[] = "t.supervisor_id = ?";
    $params[] = $supervisor_filter;
}

if ($department_filter) {
    $where_conditions[] = "t.department_id = ?";
    $params[] = $department_filter;
}

if ($status_filter) {
    $where_conditions[] = "t.status = ?";
    $params[] = $status_filter;
}

if ($date_from) {
    $where_conditions[] = "t.submission_date >= ?";
    $params[] = $date_from;
}

if ($date_to) {
    $where_conditions[] = "t.submission_date <= ?";
    $params[] = $date_to;
}

$where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

try {
    $query = "SELECT t.title, t.keywords, t.abstract, t.submission_date, t.status,
              u.full_name as student_name, u.email as student_email,
              p.name as program_name, d.name as department_name,
              sup.full_name as supervisor_name,
              tr.status as review_status, tr.review_date, tr.overall_score,
              tr.content_score, tr.methodology_score, tr.presentation_score,
              tr.comments, tr.feedback
              FROM thesis t
              INNER JOIN users u ON t.student_id = u.id
              INNER JOIN programs p ON t.program_id = p.id
              INNER JOIN departments d ON t.department_id = d.id
              LEFT JOIN users sup ON t.supervisor_id = sup.id
              LEFT JOIN thesis_reviews tr ON t.id = tr.thesis_id
              $where_clause
              ORDER BY t.submission_date DESC";
    
    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $thesis_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($export_format === 'csv') {
        // Export as CSV
        $filename = 'thesis_report_' . date('Y-m-d_H-i-s') . '.csv';
        
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $output = fopen('php://output', 'w');
        
        // CSV Headers
        $headers = [
            'Student Name', 'Student Email', 'Thesis Title', 'Keywords', 
            'Program', 'Department', 'Supervisor', 'Submission Date', 
            'Status', 'Review Status', 'Review Date', 'Overall Score', 
            'Content Score', 'Methodology Score', 'Presentation Score', 
            'Comments', 'Feedback'
        ];
        
        fputcsv($output, $headers);
        
        // CSV Data
        foreach ($thesis_data as $row) {
            $csv_row = [
                $row['student_name'],
                $row['student_email'],
                $row['title'],
                $row['keywords'],
                $row['program_name'],
                $row['department_name'],
                $row['supervisor_name'] ?? 'Unassigned',
                $row['submission_date'],
                ucwords(str_replace('_', ' ', $row['status'])),
                $row['review_status'] ? ucwords(str_replace('_', ' ', $row['review_status'])) : 'Not Reviewed',
                $row['review_date'] ?? '',
                $row['overall_score'] ?? '',
                $row['content_score'] ?? '',
                $row['methodology_score'] ?? '',
                $row['presentation_score'] ?? '',
                $row['comments'] ?? '',
                $row['feedback'] ?? ''
            ];
            fputcsv($output, $csv_row);
        }
        
        fclose($output);
        exit();
        
    } else {
        // Export as HTML (for PDF printing)
        $filename = 'thesis_report_' . date('Y-m-d_H-i-s') . '.html';
        
        header('Content-Type: text/html');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        echo '<!DOCTYPE html>
        <html>
        <head>
            <title>Thesis Report - ' . date('Y-m-d') . '</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                .header { text-align: center; margin-bottom: 30px; }
                .summary { margin-bottom: 30px; }
                table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                th { background-color: #f2f2f2; font-weight: bold; }
                .status-approved { color: #28a745; }
                .status-rejected { color: #dc3545; }
                .status-pending { color: #ffc107; }
                .status-revision-required { color: #fd7e14; }
                @media print { body { margin: 0; } }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>Benadir University - Thesis Report</h1>
                <p>Generated on: ' . date('F j, Y g:i A') . '</p>
            </div>';
        
        if (!empty($thesis_data)) {
            echo '<table>
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Title</th>
                        <th>Program</th>
                        <th>Department</th>';
            
            if ($user_role === 'admin') {
                echo '<th>Supervisor</th>';
            }
            
            echo '<th>Submission Date</th>
                        <th>Status</th>
                        <th>Score</th>
                    </tr>
                </thead>
                <tbody>';
            
            foreach ($thesis_data as $thesis) {
                echo '<tr>
                    <td>' . htmlspecialchars($thesis['student_name']) . '</td>
                    <td>' . htmlspecialchars($thesis['title']) . '</td>
                    <td>' . htmlspecialchars($thesis['program_name']) . '</td>
                    <td>' . htmlspecialchars($thesis['department_name']) . '</td>';
                
                if ($user_role === 'admin') {
                    echo '<td>' . ($thesis['supervisor_name'] ? htmlspecialchars($thesis['supervisor_name']) : 'Unassigned') . '</td>';
                }
                
                echo '<td>' . date('M d, Y', strtotime($thesis['submission_date'])) . '</td>
                    <td class="status-' . $thesis['status'] . '">' . ucwords(str_replace('_', ' ', $thesis['status'])) . '</td>
                    <td>' . ($thesis['overall_score'] ? number_format($thesis['overall_score'], 1) . '/5' : '-') . '</td>
                </tr>';
            }
            
            echo '</tbody></table>';
        } else {
            echo '<p>No thesis data found for the selected criteria.</p>';
        }
        
        echo '</body></html>';
        exit();
    }

} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>
