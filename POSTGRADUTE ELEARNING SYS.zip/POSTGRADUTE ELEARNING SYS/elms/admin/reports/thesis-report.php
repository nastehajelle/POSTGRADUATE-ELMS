<?php
session_start();
include_once '../../config/init.php';

// Check if user is logged in and has appropriate role
if (!is_logged_in() || (!is_admin() && !is_instructor())) {
    header("Location: ../../auth/login.php");
    exit();
}

$user_role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];

// Get filter parameters
$program_filter = $_GET['program'] ?? '';
$supervisor_filter = $_GET['supervisor'] ?? '';
$department_filter = $_GET['department'] ?? '';
$status_filter = $_GET['status'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';

// Build query based on user role
$where_conditions = [];
$params = [];

if ($user_role === 'instructor') {
    $where_conditions[] = "t.supervisor_id = ?";
    $params[] = $user_id;
}

if ($program_filter) {
    $where_conditions[] = "t.program_id = ?";
    $params[] = $program_filter;
}

if ($supervisor_filter) {
    $where_conditions[] = "t.supervisor_id = ?";
    $params[] = $supervisor_filter;
}

if ($department_filter) {
    $where_conditions[] = "t.department_id = ?";
    $params[] = $department_filter;
}

if ($status_filter) {
    $where_conditions[] = "t.status = ?";
    $params[] = $status_filter;
}

if ($date_from) {
    $where_conditions[] = "t.submission_date >= ?";
    $params[] = $date_from;
}

if ($date_to) {
    $where_conditions[] = "t.submission_date <= ?";
    $params[] = $date_to;
}

$where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// Get thesis data
try {
    $query = "SELECT t.*, 
              u.full_name as student_name, u.email as student_email,
              p.name as program_name, d.name as department_name,
              sup.full_name as supervisor_name,
              tr.status as review_status, tr.review_date, tr.overall_score
              FROM thesis t
              INNER JOIN users u ON t.student_id = u.id
              INNER JOIN programs p ON t.program_id = p.id
              INNER JOIN departments d ON t.department_id = d.id
              LEFT JOIN users sup ON t.supervisor_id = sup.id
              LEFT JOIN thesis_reviews tr ON t.id = tr.thesis_id
              $where_clause
              ORDER BY t.submission_date DESC";
    
    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $thesis_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get summary statistics
    $stats_query = "SELECT 
                    COUNT(*) as total_thesis,
                    SUM(CASE WHEN t.status = 'pending' THEN 1 ELSE 0 END) as pending_count,
                    SUM(CASE WHEN t.status = 'approved' THEN 1 ELSE 0 END) as approved_count,
                    SUM(CASE WHEN t.status = 'rejected' THEN 1 ELSE 0 END) as rejected_count,
                    SUM(CASE WHEN t.status = 'revision_required' THEN 1 ELSE 0 END) as revision_count,
                    AVG(tr.overall_score) as avg_score
                    FROM thesis t
                    LEFT JOIN thesis_reviews tr ON t.id = tr.thesis_id
                    $where_clause";
    
    $stats_stmt = $conn->prepare($stats_query);
    $stats_stmt->execute($params);
    $stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);

    // Get filter options
    $programs_query = "SELECT id, name FROM programs ORDER BY name";
    $programs = $conn->query($programs_query)->fetchAll(PDO::FETCH_ASSOC);

    $departments_query = "SELECT id, name FROM departments ORDER BY name";
    $departments = $conn->query($departments_query)->fetchAll(PDO::FETCH_ASSOC);

    $supervisors_query = "SELECT DISTINCT u.id, u.full_name 
                         FROM users u 
                         INNER JOIN thesis t ON u.id = t.supervisor_id 
                         ORDER BY u.full_name";
    $supervisors = $conn->query($supervisors_query)->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thesis Report - Benadir University LMS</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="../../assets/css/admin.css">
    <link rel="stylesheet" href="../../assets/css/dashboard.css">
    <link rel="stylesheet" href="../../assets/css/thesis.css">
    <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
    <div class="admin-container">
        <?php 
        if ($user_role === 'admin') {
            include_once '../../includes/sidebar.php';
        } else {
            include_once '../../includes/instructor-sidebar.php';
        }
        ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <div class="admin-header-content">
                    <div class="header-title-section">
                        <h1><i class="fas fa-chart-bar"></i> Thesis Report</h1>
                        <p class="header-subtitle">Generate comprehensive thesis reports and analytics</p>
                    </div>
                    <div class="header-actions">
                        <button onclick="window.print()" class="btn btn-outline-primary">
                            <i class="fas fa-print"></i> Print Report
                        </button>
                        <a href="../thesis-export.php<?php echo $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : ''; ?>" 
                           class="btn btn-outline-secondary">
                            <i class="fas fa-download"></i> Export Data
                        </a>
                    </div>
                </div>
            </div>

            <!-- Report Filters -->
            <div class="report-filters">
                <form method="GET" class="filter-form">
                    <div class="filter-grid">
                        <div class="form-group">
                            <label for="program">Program</label>
                            <select name="program" id="program">
                                <option value="">All Programs</option>
                                <?php foreach ($programs as $program): ?>
                                <option value="<?php echo $program['id']; ?>" 
                                        <?php echo $program_filter == $program['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($program['name']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="department">Department</label>
                            <select name="department" id="department">
                                <option value="">All Departments</option>
                                <?php foreach ($departments as $department): ?>
                                <option value="<?php echo $department['id']; ?>" 
                                        <?php echo $department_filter == $department['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($department['name']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <?php if ($user_role === 'admin'): ?>
                        <div class="form-group">
                            <label for="supervisor">Supervisor</label>
                            <select name="supervisor" id="supervisor">
                                <option value="">All Supervisors</option>
                                <?php foreach ($supervisors as $supervisor): ?>
                                <option value="<?php echo $supervisor['id']; ?>" 
                                        <?php echo $supervisor_filter == $supervisor['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($supervisor['full_name']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <?php endif; ?>

                        <div class="form-group">
                            <label for="status">Status</label>
                            <select name="status" id="status">
                                <option value="">All Statuses</option>
                                <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="approved" <?php echo $status_filter == 'approved' ? 'selected' : ''; ?>>Approved</option>
                                <option value="rejected" <?php echo $status_filter == 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                                <option value="revision_required" <?php echo $status_filter == 'revision_required' ? 'selected' : ''; ?>>Revision Required</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="date_from">Date From</label>
                            <input type="date" name="date_from" id="date_from" value="<?php echo $date_from; ?>">
                        </div>

                        <div class="form-group">
                            <label for="date_to">Date To</label>
                            <input type="date" name="date_to" id="date_to" value="<?php echo $date_to; ?>">
                        </div>
                    </div>
                    
                    <div class="filter-actions">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-filter"></i> Apply Filters
                        </button>
                        <a href="?" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Clear Filters
                        </a>
                    </div>
                </form>
            </div>

            <!-- Report Summary -->
            <div class="report-summary">
                <div class="summary-cards">
                    <div class="summary-card">
                        <div class="card-icon">
                            <i class="fas fa-file-alt"></i>
                        </div>
                        <div class="card-content">
                            <div class="card-number"><?php echo $stats['total_thesis']; ?></div>
                            <div class="card-label">Total Thesis</div>
                        </div>
                    </div>
                    
                    <div class="summary-card pending">
                        <div class="card-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div class="card-content">
                            <div class="card-number"><?php echo $stats['pending_count']; ?></div>
                            <div class="card-label">Pending</div>
                        </div>
                    </div>
                    
                    <div class="summary-card approved">
                        <div class="card-icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div class="card-content">
                            <div class="card-number"><?php echo $stats['approved_count']; ?></div>
                            <div class="card-label">Approved</div>
                        </div>
                    </div>
                    
                    <div class="summary-card rejected">
                        <div class="card-icon">
                            <i class="fas fa-times-circle"></i>
                        </div>
                        <div class="card-content">
                            <div class="card-number"><?php echo $stats['rejected_count']; ?></div>
                            <div class="card-label">Rejected</div>
                        </div>
                    </div>
                    
                    <div class="summary-card revision">
                        <div class="card-icon">
                            <i class="fas fa-edit"></i>
                        </div>
                        <div class="card-content">
                            <div class="card-number"><?php echo $stats['revision_count']; ?></div>
                            <div class="card-label">Needs Revision</div>
                        </div>
                    </div>
                    
                    <div class="summary-card score">
                        <div class="card-icon">
                            <i class="fas fa-star"></i>
                        </div>
                        <div class="card-content">
                            <div class="card-number"><?php echo number_format($stats['avg_score'], 1); ?></div>
                            <div class="card-label">Avg Score</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Report Data Table -->
            <div class="report-table-container">
                <div class="table-header">
                    <h3>Thesis Details</h3>
                    <p class="table-description">Detailed breakdown of thesis submissions</p>
                </div>
                
                <div class="table-content">
                    <?php if (!empty($thesis_data)): ?>
                        <table class="data-table report-table">
                            <thead>
                                <tr>
                                    <th>Student</th>
                                    <th>Title</th>
                                    <th>Program</th>
                                    <th>Department</th>
                                    <?php if ($user_role === 'admin'): ?>
                                    <th>Supervisor</th>
                                    <?php endif; ?>
                                    <th>Submission Date</th>
                                    <th>Status</th>
                                    <th>Score</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($thesis_data as $thesis): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($thesis['student_name']); ?></td>
                                    <td class="thesis-title-cell">
                                        <?php echo htmlspecialchars($thesis['title']); ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($thesis['program_name']); ?></td>
                                    <td><?php echo htmlspecialchars($thesis['department_name']); ?></td>
                                    <?php if ($user_role === 'admin'): ?>
                                    <td><?php echo $thesis['supervisor_name'] ? htmlspecialchars($thesis['supervisor_name']) : 'Unassigned'; ?></td>
                                    <?php endif; ?>
                                    <td><?php echo date('M d, Y', strtotime($thesis['submission_date'])); ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo $thesis['status']; ?>">
                                            <?php echo ucwords(str_replace('_', ' ', $thesis['status'])); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($thesis['overall_score']): ?>
                                            <span class="score-badge"><?php echo number_format($thesis['overall_score'], 1); ?>/5</span>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="no-data">
                            <i class="fas fa-chart-bar"></i>
                            <h3>No Data Found</h3>
                            <p>No thesis data matches the selected criteria.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="../../assets/js/theme.js"></script>
</body>
</html>
