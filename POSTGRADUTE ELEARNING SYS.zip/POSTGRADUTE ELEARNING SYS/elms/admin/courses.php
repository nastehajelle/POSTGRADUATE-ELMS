<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is admin
if (!is_logged_in() || !is_admin()) {
    header("Location: ../auth/login.php");
    exit();
}

// First, check if the course table has the required columns
try {
    // Check if batch_id and instructor_id columns exist in course table
    $columns = $conn->query("DESCRIBE course");
    $column_names = [];
    while ($column = $columns->fetch(PDO::FETCH_ASSOC)) {
        $column_names[] = $column['Field'];
    }
    
    // If batch_id or instructor_id columns don't exist, add them
    if (!in_array('batch_id', $column_names) || !in_array('instructor_id', $column_names)) {
        $alter_queries = [];
        
        if (!in_array('batch_id', $column_names)) {
            $alter_queries[] = "ALTER TABLE course ADD COLUMN batch_id INT NULL";
            $alter_queries[] = "ALTER TABLE course ADD CONSTRAINT fk_course_batch FOREIGN KEY (batch_id) REFERENCES batch(id) ON DELETE SET NULL";
        }
        
        if (!in_array('instructor_id', $column_names)) {
            $alter_queries[] = "ALTER TABLE course ADD COLUMN instructor_id INT NULL";
            $alter_queries[] = "ALTER TABLE course ADD CONSTRAINT fk_course_instructor FOREIGN KEY (instructor_id) REFERENCES users(id) ON DELETE SET NULL";
        }
        
        foreach ($alter_queries as $query) {
            $conn->exec($query);
        }
        
        // Log the changes
        error_log("Added missing columns to course table: " . implode(", ", $alter_queries));
    }
    
    // Now check if enrollment table has course_id column
    $check_enrollment = $conn->query("SHOW TABLES LIKE 'enrollment'");
    if ($check_enrollment->rowCount() > 0) {
        $enrollment_columns = $conn->query("DESCRIBE enrollment");
        $enrollment_column_names = [];
        while ($column = $enrollment_columns->fetch(PDO::FETCH_ASSOC)) {
            $enrollment_column_names[] = $column['Field'];
        }
        
        // If course_id column doesn't exist in enrollment table, add it
        if (!in_array('course_id', $enrollment_column_names)) {
            // First add the column
            $conn->exec("ALTER TABLE enrollment ADD COLUMN course_id INT NULL");
            
            // Then try to add the foreign key constraint with proper error handling
            try {
                $conn->exec("ALTER TABLE enrollment ADD CONSTRAINT fk_enrollment_course FOREIGN KEY (course_id) REFERENCES course(id) ON DELETE SET NULL");
                error_log("Added course_id column and foreign key constraint to enrollment table");
            } catch (PDOException $fkError) {
                // Log the error but continue - the column is still usable even without the constraint
                error_log("Added course_id column but failed to add foreign key: " . $fkError->getMessage());
            }
        }
    }
} catch (PDOException $e) {
    error_log("Error checking or altering tables: " . $e->getMessage());
}

// Check the enrollment table structure
try {
    // Check if enrollment table exists
    $check_table = $conn->query("SHOW TABLES LIKE 'enrollment'");
    $enrollment_exists = $check_table->rowCount() > 0;
    
    // Default column name for course reference in enrollment table
    $enrollment_course_column = 'course_id'; // Now we use course_id as the standard
    
    if ($enrollment_exists) {
        // Get the column names from enrollment table
        $columns = $conn->query("DESCRIBE enrollment");
        $column_names = [];
        while ($column = $columns->fetch(PDO::FETCH_ASSOC)) {
            $column_names[] = $column['Field'];
        }
        
        // Verify that course_id exists in the enrollment table
        if (!in_array('course_id', $column_names)) {
            // Log this situation for debugging
            error_log("course_id column not found in enrollment table. Available columns: " . implode(", ", $column_names));
            
            // Disable enrollment checks to prevent errors
            $enrollment_exists = false;
        }
    }
} catch (PDOException $e) {
    // If there's an error, disable enrollment checks
    $enrollment_exists = false;
    error_log("Error checking enrollment table: " . $e->getMessage());
}

// Process AJAX requests
if (isset($_POST['ajax']) && $_POST['ajax'] == 1) {
    header('Content-Type: application/json');
    
    try {
        if ($_POST['action'] == 'add' || $_POST['action'] == 'edit') {
            // Sanitize input
            $course_code = sanitize_input($_POST['course_code']);
            $course_name = sanitize_input($_POST['course_name']);
            $credit_hours = (int)$_POST['credit_hours'];
            $description = sanitize_input($_POST['description']);
            $department_id = !empty($_POST['department_id']) ? (int)$_POST['department_id'] : null;
            $program_id = !empty($_POST['program_id']) ? (int)$_POST['program_id'] : null;
            $semester_id = !empty($_POST['semester_id']) ? (int)$_POST['semester_id'] : null;
            $batch_id = !empty($_POST['batch_id']) ? (int)$_POST['batch_id'] : null;
            $instructor_id = !empty($_POST['instructor_id']) ? (int)$_POST['instructor_id'] : null;
            
            // Validate input
            if (empty($course_code) || empty($course_name) || empty($credit_hours) || empty($department_id) || empty($program_id) || empty($batch_id) || empty($instructor_id)) {
                throw new Exception("Please fill in all required fields. Course code, name, credit hours, department, program, batch, and instructor are required.");
            }
            
            // Begin transaction
            $conn->beginTransaction();
            
            if ($_POST['action'] == 'edit' && !empty($_POST['id'])) {
                // Update existing course
                $course_id = sanitize_input($_POST['id']);
                
                // Check if code already exists (excluding current course)
                $check_query = "SELECT COUNT(*) as count FROM course WHERE code = ? AND id != ?";
                $check_stmt = $conn->prepare($check_query);
                $check_stmt->execute([$course_code, $course_id]);
                $count = $check_stmt->fetch(PDO::FETCH_ASSOC)['count'];
                
                if ($count > 0) {
                    throw new Exception("Course code already exists");
                }
                
                $query = "UPDATE course SET code = ?, name = ?, credit_hours = ?, description = ?, 
                          department_id = ?, program_id = ?, semester_id = ?, batch_id = ?, instructor_id = ?, 
                          updated_at = NOW() WHERE id = ?";
                $stmt = $conn->prepare($query);
                $stmt->execute([$course_code, $course_name, $credit_hours, $description, 
                               $department_id, $program_id, $semester_id, $batch_id, $instructor_id, 
                               $course_id]);
                $message = "Course updated successfully";
            } else {
                // Check if code already exists
                $check_query = "SELECT COUNT(*) as count FROM course WHERE code = ?";
                $check_stmt = $conn->prepare($check_query);
                $check_stmt->execute([$course_code]);
                $count = $check_stmt->fetch(PDO::FETCH_ASSOC)['count'];
                
                if ($count > 0) {
                    throw new Exception("Course code already exists");
                }
                
                // Create new course
                $query = "INSERT INTO course (code, name, credit_hours, description, department_id, program_id, 
                          semester_id, batch_id, instructor_id, created_at, status) 
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), 'active')";
                $stmt = $conn->prepare($query);
                $stmt->execute([$course_code, $course_name, $credit_hours, $description, 
                               $department_id, $program_id, $semester_id, $batch_id, $instructor_id]);
                $message = "Course created successfully";
            }
            
            // Commit transaction
            $conn->commit();
            
            echo json_encode(['success' => true, 'message' => $message]);
        } 
        elseif ($_POST['action'] == 'delete' && !empty($_POST['id'])) {
            $course_id = sanitize_input($_POST['id']);
            
            // Check if enrollment table exists and if course is being used
            if ($enrollment_exists) {
                try {
                    $check_query = "SELECT COUNT(*) as count FROM enrollment WHERE course_id = ?";
                    $check_stmt = $conn->prepare($check_query);
                    $check_stmt->execute([$course_id]);
                    $count = $check_stmt->fetch(PDO::FETCH_ASSOC)['count'];
                    
                    if ($count > 0) {
                        throw new Exception("Cannot delete course because it is associated with student enrollments");
                    }
                } catch (PDOException $e) {
                    // If there's an error with the enrollment check, log it and proceed with deletion
                    error_log("Error checking course enrollments: " . $e->getMessage());
                    // Continue with deletion anyway since we can't verify enrollments
                }
            }
            
            // Delete course
            $query = "DELETE FROM course WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->execute([$course_id]);
            echo json_encode(['success' => true, 'message' => "Course deleted successfully"]);
        }
        elseif ($_POST['action'] == 'get' && !empty($_POST['id'])) {
            $course_id = sanitize_input($_POST['id']);
            
            $query = "SELECT c.*, d.name as department_name, p.name as program_name, s.name as semester_name,
                     b.name as batch_name, CONCAT(u.full_name, ' (', u.email, ')') as instructor_name
                     FROM course c
                     LEFT JOIN departments d ON c.department_id = d.id
                     LEFT JOIN programs p ON c.program_id = p.id
                     LEFT JOIN semester s ON c.semester_id = s.id
                     LEFT JOIN batch b ON c.batch_id = b.id
                     LEFT JOIN users u ON c.instructor_id = u.id
                     WHERE c.id = ?";
            $stmt = $conn->prepare($query);
            $stmt->execute([$course_id]);
            
            if ($stmt->rowCount() > 0) {
                $course = $stmt->fetch(PDO::FETCH_ASSOC);
                
                echo json_encode(['success' => true, 'data' => $course]);
            } else {
                throw new Exception("Course not found");
            }
        }
        else {
            throw new Exception("Invalid action");
        }
    } catch(Exception $e) {
        // Rollback transaction if necessary
        if ($conn->inTransaction()) {
            $conn->rollBack();
        }
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit();
}

// Get all courses for listing
$courses_query = "SELECT c.*, d.name as department_name, p.name as program_name, s.name as semester_name,
                 b.name as batch_name, CONCAT(u.full_name, ' (', u.email, ')') as instructor_name";

$courses_query .= " FROM course c
                 LEFT JOIN departments d ON c.department_id = d.id
                 LEFT JOIN programs p ON c.program_id = p.id
                 LEFT JOIN semester s ON c.semester_id = s.id
                 LEFT JOIN batch b ON c.batch_id = b.id
                 LEFT JOIN users u ON c.instructor_id = u.id
                 ORDER BY c.code";

$courses_stmt = $conn->prepare($courses_query);
$courses_stmt->execute();
$courses = $courses_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all departments for dropdown
$departments_query = "SELECT id, name FROM departments WHERE status = 'active' ORDER BY name";
$departments_stmt = $conn->prepare($departments_query);
$departments_stmt->execute();
$departments = $departments_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all semesters for dropdown
$semesters_query = "SELECT id, name FROM semester ORDER BY name";
$semesters_stmt = $conn->prepare($semesters_query);
$semesters_stmt->execute();
$semesters = $semesters_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all instructors for dropdown
$instructors_query = "SELECT u.id, u.full_name, u.email 
                     FROM users u 
                     LEFT JOIN instructors i ON u.id = i.user_id
                     WHERE u.role = 'instructor' 
                     ORDER BY u.full_name";
$instructors_stmt = $conn->prepare($instructors_query);
$instructors_stmt->execute();
$instructors = $instructors_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get course statistics
$stats_query = "SELECT 
                COUNT(*) as total_courses, 
                COALESCE(SUM(credit_hours), 0) as total_credit_hours,
                COUNT(DISTINCT department_id) as departments_count,
                COUNT(DISTINCT program_id) as programs_count,
                COUNT(DISTINCT batch_id) as batches_count,
                COUNT(DISTINCT instructor_id) as instructors_count
                FROM course";
$stats_stmt = $conn->prepare($stats_query);
$stats_stmt->execute();
$stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Courses - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/modal.css">
    <link rel="stylesheet" href="../assets/css/icons.css">
    <link rel="stylesheet" href="../assets/css/courses.css">
    <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>Manage Courses</h1>
                
                <div class="admin-header-right">
                    <button class="btn btn-primary" id="addCourseBtn">Add New Course</button>
                </div>
            </div>
            
            <div id="alertContainer"></div>
            
            <!-- Stats Cards -->
            <div class="stats-cards">
                <div class="stat-card">
                    <div class="stat-card-icon">
                        <i class="icon-book"></i>
                    </div>
                    <div class="stat-card-info">
                        <h3>Total Courses</h3>
                        <p><?php echo $stats['total_courses']; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-card-icon">
                        <i class="icon-clock"></i>
                    </div>
                    <div class="stat-card-info">
                        <h3>Credit Hours</h3>
                        <p><?php echo $stats['total_credit_hours']; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-card-icon">
                        <i class="icon-building"></i>
                    </div>
                    <div class="stat-card-info">
                        <h3>Departments</h3>
                        <p><?php echo $stats['departments_count']; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-card-icon">
                        <i class="icon-graduation-cap"></i>
                    </div>
                    <div class="stat-card-info">
                        <h3>Batches</h3>
                        <p><?php echo $stats['batches_count']; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-card-icon">
                        <i class="icon-user"></i>
                    </div>
                    <div class="stat-card-info">
                        <h3>Instructors</h3>
                        <p><?php echo $stats['instructors_count']; ?></p>
                    </div>
                </div>
            </div>
            
            <!-- Filter Controls -->
            <div class="filter-controls">
                <div class="filter-item">
                    <label for="departmentFilter">Department:</label>
                    <select id="departmentFilter">
                        <option value="">All Departments</option>
                        <?php foreach ($departments as $department): ?>
                            <option value="<?php echo $department['name']; ?>"><?php echo $department['name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="filter-item">
                    <label for="batchFilter">Batch:</label>
                    <select id="batchFilter">
                        <option value="">All Batches</option>
                        <?php foreach ($batches as $batch): ?>
                            <option value="<?php echo $batch['name']; ?>"><?php echo $batch['name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="filter-item">
                    <label for="instructorFilter">Instructor:</label>
                    <select id="instructorFilter">
                        <option value="">All Instructors</option>
                        <?php foreach ($instructors as $instructor): ?>
                            <option value="<?php echo $instructor['full_name']; ?>"><?php echo $instructor['full_name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="filter-item">
                    <label for="searchInput">Search:</label>
                    <input type="text" id="searchInput" placeholder="Course code, name...">
                </div>
            </div>
            
            <!-- Courses List -->
            <div class="card">
                <div class="card-body">
                    <table class="data-table" id="coursesTable">
                        <thead>
                            <tr>
                                <th>Code</th>
                                <th>Course Name</th>
                                <!-- Removed Credit Hours, Batch, Department, Semester columns to simplify the list view -->
                                <th>Instructor</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($courses) > 0): ?>
                                <?php foreach ($courses as $course): ?>
                                <tr>
                                    <td><?php echo $course['code']; ?></td>
                                    <td><?php echo $course['name']; ?></td>
                                    <!-- Removed credit hours, batch, department, semester columns from table rows -->
                                    <td><?php echo $course['instructor_name'] ?? 'Not Assigned'; ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo strtolower($course['status'] ?? 'inactive'); ?>">
                                            <?php echo ucfirst($course['status'] ?? 'Inactive'); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-info view-course-btn" data-id="<?php echo $course['id']; ?>">View</button>
                                        <button class="btn btn-sm btn-primary edit-course-btn" data-id="<?php echo $course['id']; ?>">Edit</button>
                                        <button class="btn btn-sm btn-danger delete-course-btn" data-id="<?php echo $course['id']; ?>">Delete</button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <!-- Updated colspan from 9 to 5 to match the reduced number of columns -->
                                    <td colspan="5" class="text-center">No courses found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Course Modal -->
    <div id="courseModalBackdrop" class="modal-backdrop"></div>
    <div id="courseModalContainer" class="modal-container">
        <div class="modal-header">
            <h2 id="courseModalTitle">Add New Course</h2>
            <button class="modal-close" id="closeCourseModal">&times;</button>
        </div>
        <div class="modal-body">
            <form id="courseForm">
                <input type="hidden" id="id" name="id">
                <input type="hidden" id="form_action" name="action" value="add">
                <input type="hidden" name="ajax" value="1">
                
                <div class="form-row">
                    <label for="course_code">Course Code <span class="required">*</span></label>
                    <input type="text" id="course_code" name="course_code" required>
                    <small>A unique code for the course (e.g., CS101, MATH201)</small>
                </div>
                
                <div class="form-row">
                    <label for="course_name">Course Name <span class="required">*</span></label>
                    <input type="text" id="course_name" name="course_name" required>
                </div>
                
                <div class="form-row">
                    <label for="credit_hours">Credit Hours <span class="required">*</span></label>
                    <input type="number" id="credit_hours" name="credit_hours" min="1" max="6" required>
                </div>
                
                <!-- Implement dependent dropdowns: Department → Programs → Batches -->
                <div class="form-row">
                    <label for="department_id">Department <span class="required">*</span></label>
                    <select id="department_id" name="department_id" required>
                        <option value="">Select Department</option>
                        <?php foreach ($departments as $department): ?>
                            <option value="<?php echo $department['id']; ?>"><?php echo $department['name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-row">
                    <label for="program_id">Program <span class="required">*</span></label>
                    <select id="program_id" name="program_id" required disabled>
                        <option value="">Select Department First</option>
                    </select>
                    <small id="program_duration" class="text-muted"></small>
                </div>
                
                <div class="form-row">
                    <label for="batch_id">Batch <span class="required">*</span></label>
                    <select id="batch_id" name="batch_id" required disabled>
                        <option value="">Select Program First</option>
                    </select>
                </div>
                
                <div class="form-row">
                    <label for="instructor_id">Instructor <span class="required">*</span></label>
                    <select id="instructor_id" name="instructor_id" required>
                        <option value="">Select Instructor</option>
                        <?php foreach ($instructors as $instructor): ?>
                            <option value="<?php echo $instructor['id']; ?>"><?php echo $instructor['full_name'] . ' (' . $instructor['email'] . ')'; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-row">
                    <label for="semester_id">Semester</label>
                    <select id="semester_id" name="semester_id">
                        <option value="">Select Semester</option>
                        <?php foreach ($semesters as $semester): ?>
                            <option value="<?php echo $semester['id']; ?>"><?php echo $semester['name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-row">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="4"></textarea>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" id="cancelCourseBtn">Cancel</button>
            <button class="btn btn-primary" id="saveCourseBtn">Save Course</button>
        </div>
    </div>
    
    <!-- View Course Modal -->
    <div id="viewModalBackdrop" class="modal-backdrop"></div>
    <div id="viewModalContainer" class="modal-container">
        <div class="modal-header">
            <h2>Course Details</h2>
            <button class="modal-close" id="closeViewModal">&times;</button>
        </div>
        <div class="modal-body">
            <div id="courseDetails">
                <div class="detail-row">
                    <strong>Course Code:</strong>
                    <span id="view_course_code"></span>
                </div>
                <div class="detail-row">
                    <strong>Course Name:</strong>
                    <span id="view_course_name"></span>
                </div>
                <div class="detail-row">
                    <strong>Credit Hours:</strong>
                    <span id="view_credit_hours"></span>
                </div>
                <div class="detail-row">
                    <strong>Batch:</strong>
                    <span id="view_batch"></span>
                </div>
                <div class="detail-row">
                    <strong>Instructor:</strong>
                    <span id="view_instructor"></span>
                </div>
                <div class="detail-row">
                    <strong>Department:</strong>
                    <span id="view_department"></span>
                </div>
                <div class="detail-row">
                    <strong>Program:</strong>
                    <span id="view_program"></span>
                </div>
                <div class="detail-row">
                    <strong>Semester:</strong>
                    <span id="view_semester"></span>
                </div>
                <div class="detail-row">
                    <strong>Description:</strong>
                    <div id="view_description" class="description-text"></div>
                </div>
                <!-- Removed Student Enrollments field from view modal -->
                <div class="detail-row">
                    <strong>Status:</strong>
                    <span id="view_status"></span>
                </div>
                <div class="detail-row">
                    <strong>Created:</strong>
                    <span id="view_created_at"></span>
                </div>
                <div class="detail-row">
                    <strong>Last Updated:</strong>
                    <span id="view_updated_at"></span>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" id="closeViewBtn">Close</button>
        </div>
    </div>
    
    <!-- Delete Modal -->
    <div id="deleteModalBackdrop" class="modal-backdrop"></div>
    <div id="deleteModalContainer" class="modal-container">
        <div class="modal-header">
            <h2>Delete Course</h2>
            <button class="modal-close" id="closeDeleteModal">&times;</button>
        </div>
        <div class="modal-body">
            <p>Are you sure you want to delete this course? This action cannot be undone.</p>
            <p class="text-danger"><strong>Note:</strong> Courses with student enrollments cannot be deleted.</p>
            <input type="hidden" id="delete_course_id">
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" id="cancelDeleteBtn">Cancel</button>
            <button class="btn btn-danger" id="confirmDeleteBtn">Delete</button>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // DOM Elements
        const alertContainer = document.getElementById('alertContainer');
        const courseModalBackdrop = document.getElementById('courseModalBackdrop');
        const courseModalContainer = document.getElementById('courseModalContainer');
        const deleteModalBackdrop = document.getElementById('deleteModalBackdrop');
        const deleteModalContainer = document.getElementById('deleteModalContainer');
        const viewModalBackdrop = document.getElementById('viewModalBackdrop');
        const viewModalContainer = document.getElementById('viewModalContainer');
        const courseForm = document.getElementById('courseForm');
        const courseModalTitle = document.getElementById('courseModalTitle');
        const saveCourseBtn = document.getElementById('saveCourseBtn');
        
        const departmentSelect = document.getElementById('department_id');
        const programSelect = document.getElementById('program_id');
        const batchSelect = document.getElementById('batch_id');
        const programDurationText = document.getElementById('program_duration');
        
        // Filter elements
        const departmentFilter = document.getElementById('departmentFilter');
        const batchFilter = document.getElementById('batchFilter');
        const instructorFilter = document.getElementById('instructorFilter');
        const searchInput = document.getElementById('searchInput');
        
        // Department change handler
        departmentSelect.addEventListener('change', function() {
            const departmentId = this.value;
            
            // Reset dependent dropdowns
            programSelect.innerHTML = '<option value="">Loading programs...</option>';
            programSelect.disabled = true;
            batchSelect.innerHTML = '<option value="">Select Program First</option>';
            batchSelect.disabled = true;
            programDurationText.textContent = '';
            
            if (departmentId) {
                // Fetch programs for selected department
                fetch(`../api/get_programs.php?department_id=${departmentId}`)
                    .then(response => response.json())
                    .then(programs => {
                        programSelect.innerHTML = '<option value="">Select Program</option>';
                        
                        if (programs && programs.length > 0) {
                            programs.forEach(program => {
                                const option = document.createElement('option');
                                option.value = program.id;
                                option.textContent = program.name;
                                option.dataset.duration = program.duration || '';
                                programSelect.appendChild(option);
                            });
                            programSelect.disabled = false;
                        } else {
                            programSelect.innerHTML = '<option value="">No programs available</option>';
                        }
                    })
                    .catch(error => {
                        console.error('Error fetching programs:', error);
                        programSelect.innerHTML = '<option value="">Error loading programs</option>';
                        showAlert('Error loading programs. Please try again.', 'danger');
                    });
            } else {
                programSelect.innerHTML = '<option value="">Select Department First</option>';
                programSelect.disabled = true;
            }
        });
        
        // Program change handler
        programSelect.addEventListener('change', function() {
            const programId = this.value;
            const selectedOption = this.options[this.selectedIndex];
            
            // Reset batch dropdown
            batchSelect.innerHTML = '<option value="">Loading batches...</option>';
            batchSelect.disabled = true;
            
            // Show program duration
            if (selectedOption && selectedOption.dataset.duration) {
                programDurationText.textContent = `Duration: ${selectedOption.dataset.duration}`;
            } else {
                programDurationText.textContent = '';
            }
            
            if (programId) {
                // Fetch batches for selected program
                fetch(`../api/get_batches.php?program_id=${programId}`)
                    .then(response => response.json())
                    .then(data => {
                        batchSelect.innerHTML = '<option value="">Select Batch</option>';
                        
                        if (data.success && data.data && data.data.length > 0) {
                            data.data.forEach(batch => {
                                const option = document.createElement('option');
                                option.value = batch.id;
                                option.textContent = `${batch.name} (${batch.year})`;
                                batchSelect.appendChild(option);
                            });
                            batchSelect.disabled = false;
                        } else {
                            batchSelect.innerHTML = '<option value="">No batches available</option>';
                        }
                    })
                    .catch(error => {
                        console.error('Error fetching batches:', error);
                        batchSelect.innerHTML = '<option value="">Error loading batches</option>';
                        showAlert('Error loading batches. Please try again.', 'danger');
                    });
            } else {
                batchSelect.innerHTML = '<option value="">Select Program First</option>';
                batchSelect.disabled = true;
                programDurationText.textContent = '';
            }
        });
        
        // Show alert message
        function showAlert(message, type = 'success') {
            const alert = document.createElement('div');
            alert.className = `alert alert-${type}`;
            alert.textContent = message;
            
            alertContainer.appendChild(alert);
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                alert.remove();
            }, 5000);
        }
        
        // Open course modal
        function openCourseModal() {
            courseModalBackdrop.classList.add('show');
            courseModalContainer.classList.add('show');
        }
        
        // Close course modal
        function closeCourseModal() {
            courseModalBackdrop.classList.remove('show');
            courseModalContainer.classList.remove('show');
        }
        
        // Open delete modal
        function openDeleteModal() {
            deleteModalBackdrop.classList.add('show');
            deleteModalContainer.classList.add('show');
        }
        
        // Close delete modal
        function closeDeleteModal() {
            deleteModalBackdrop.classList.remove('show');
            deleteModalContainer.classList.remove('show');
        }
        
        // Open view modal
        function openViewModal() {
            viewModalBackdrop.classList.add('show');
            viewModalContainer.classList.add('show');
        }
        
        // Close view modal
        function closeViewModal() {
            viewModalBackdrop.classList.remove('show');
            viewModalContainer.classList.remove('show');
        }
        
        // Add Course button click
        document.getElementById('addCourseBtn').addEventListener('click', function() {
            // Reset form
            courseForm.reset();
            document.getElementById('id').value = '';
            document.getElementById('form_action').value = 'add';
            
            // Update modal title and button
            courseModalTitle.textContent = 'Add New Course';
            saveCourseBtn.textContent = 'Create Course';
            
            // Open modal
            openCourseModal();
        });
        
        // Close course modal
        document.getElementById('closeCourseModal').addEventListener('click', closeCourseModal);
        document.getElementById('cancelCourseBtn').addEventListener('click', closeCourseModal);
        
        // Close course modal when clicking on backdrop
        courseModalBackdrop.addEventListener('click', closeCourseModal);
        
        // Close view modal
        document.getElementById('closeViewModal').addEventListener('click', closeViewModal);
        document.getElementById('closeViewBtn').addEventListener('click', closeViewModal);
        courseModalBackdrop.addEventListener('click', closeCourseModal);
        
        // Close view modal
        document.getElementById('closeViewModal').addEventListener('click', closeViewModal);
        document.getElementById('closeViewBtn').addEventListener('click', closeViewModal);
        
        // Close view modal when clicking on backdrop
        viewModalBackdrop.addEventListener('click', closeViewModal);
        
        // Edit course button click
        document.querySelectorAll('.edit-course-btn').forEach(button => {
            button.addEventListener('click', function() {
                const courseId = this.getAttribute('data-id');
                
                // Set loading state
                button.disabled = true;
                button.innerHTML = 'Loading...';
                
                // Fetch course data
                const formData = new FormData();
                formData.append('ajax', 1);
                formData.append('action', 'get');
                formData.append('id', courseId);
                
                fetch('courses.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    button.disabled = false;
                    button.innerHTML = 'Edit';
                    
                    if (data.success) {
                        const course = data.data;
                        
                        // Fill form with course data
                        document.getElementById('id').value = course.id;
                        document.getElementById('form_action').value = 'edit';
                        document.getElementById('course_code').value = course.code;
                        document.getElementById('course_name').value = course.name;
                        document.getElementById('credit_hours').value = course.credit_hours;
                        document.getElementById('instructor_id').value = course.instructor_id || '';
                        document.getElementById('semester_id').value = course.semester_id || '';
                        document.getElementById('description').value = course.description || '';
                        
                        // Handle dependent dropdowns for editing
                        if (course.department_id) {
                            document.getElementById('department_id').value = course.department_id;
                            
                            // Trigger department change to load programs
                            departmentSelect.dispatchEvent(new Event('change'));
                            
                            // Wait for programs to load, then set program
                            setTimeout(() => {
                                if (course.program_id) {
                                    document.getElementById('program_id').value = course.program_id;
                                    
                                    // Trigger program change to load batches
                                    programSelect.dispatchEvent(new Event('change'));
                                    
                                    // Wait for batches to load, then set batch
                                    setTimeout(() => {
                                        if (course.batch_id) {
                                            document.getElementById('batch_id').value = course.batch_id;
                                        }
                                    }, 500);
                                }
                            }, 500);
                        }
                        
                        // Update modal title and button
                        courseModalTitle.textContent = 'Edit Course';
                        saveCourseBtn.textContent = 'Update Course';
                        
                        // Open modal
                        openCourseModal();
                    } else {
                        showAlert(data.message, 'danger');
                    }
                })
                .catch(error => {
                    button.disabled = false;
                    button.innerHTML = 'Edit';
                    showAlert('An error occurred while fetching course data.', 'danger');
                });
            });
        });
        
        // View course button click
        document.querySelectorAll('.view-course-btn').forEach(button => {
            button.addEventListener('click', function() {
                const courseId = this.getAttribute('data-id');
                
                // Set loading state
                button.disabled = true;
                button.innerHTML = 'Loading...';
                
                // Fetch course data
                const formData = new FormData();
                formData.append('ajax', 1);
                formData.append('action', 'get');
                formData.append('id', courseId);
                
                fetch('courses.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    button.disabled = false;
                    button.innerHTML = 'View';
                    
                    if (data.success) {
                        const course = data.data;
                        
                        // Fill view modal with course data
                        document.getElementById('view_course_code').textContent = course.code;
                        document.getElementById('view_course_name').textContent = course.name;
                        document.getElementById('view_credit_hours').textContent = course.credit_hours;
                        document.getElementById('view_batch').textContent = course.batch_name || 'Not Assigned';
                        document.getElementById('view_instructor').textContent = course.instructor_name || 'Not Assigned';
                        document.getElementById('view_department').textContent = course.department_name || 'Not Assigned';
                        document.getElementById('view_program').textContent = course.program_name || 'Not Assigned';
                        document.getElementById('view_semester').textContent = course.semester_name || 'Not Assigned';
                        document.getElementById('view_description').textContent = course.description || 'No description available';
                        document.getElementById('view_status').textContent = course.status ? course.status.charAt(0).toUpperCase() + course.status.slice(1) : 'Inactive';
                        document.getElementById('view_created_at').textContent = course.created_at || 'N/A';
                        document.getElementById('view_updated_at').textContent = course.updated_at || 'N/A';
                        
                        // Open modal
                        openViewModal();
                    } else {
                        showAlert(data.message, 'danger');
                    }
                })
                .catch(error => {
                    button.disabled = false;
                    button.innerHTML = 'View';
                    showAlert('An error occurred while fetching course data.', 'danger');
                });
            });
        });
        
        // Delete course button click
        document.querySelectorAll('.delete-course-btn').forEach(button => {
            button.addEventListener('click', function() {
                const courseId = this.getAttribute('data-id');
                document.getElementById('delete_course_id').value = courseId;
                
                // Open delete modal
                openDeleteModal();
            });
        });
        
        // Save course form
        saveCourseBtn.addEventListener('click', function() {
            // Check form validity
            if (!courseForm.checkValidity()) {
                courseForm.reportValidity();
                return;
            }
            
            // Disable button and show loading
            saveCourseBtn.disabled = true;
            saveCourseBtn.textContent = 'Saving...';
            
            // Prepare form data
            const formData = new FormData(courseForm);
            
            // Send AJAX request
            fetch('courses.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                saveCourseBtn.disabled = false;
                saveCourseBtn.textContent = document.getElementById('form_action').value === 'add' ? 'Create Course' : 'Update Course';
                
                if (data.success) {
                    // Close modal and show success message
                    closeCourseModal();
                    showAlert(data.message, 'success');
                    
                    // Reload page after a short delay
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);
                } else {
                    // Show error
                    showAlert(data.message, 'danger');
                }
            })
            .catch(error => {
                saveCourseBtn.disabled = false;
                saveCourseBtn.textContent = document.getElementById('form_action').value === 'add' ? 'Create Course' : 'Update Course';
                showAlert('An error occurred while submitting the form.', 'danger');
            });
        });
        
        // Confirm delete course
        document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
            const courseId = document.getElementById('delete_course_id').value;
            const button = this;
            
            // Disable button and show loading
            button.disabled = true;
            button.textContent = 'Deleting...';
            
            const formData = new FormData();
            formData.append('ajax', 1);
            formData.append('action', 'delete');
            formData.append('id', courseId);
            
            fetch('courses.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                button.disabled = false;
                button.textContent = 'Delete';
                
                if (data.success) {
                    // Close modal and show success message
                    closeDeleteModal();
                    showAlert(data.message, 'success');
                    
                    // Reload page after a short delay
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);
                } else {
                    // Show error
                    showAlert(data.message, 'danger');
                }
            })
            .catch(error => {
                button.disabled = false;
                button.textContent = 'Delete';
                showAlert('An error occurred while deleting the course.', 'danger');
            });
        });
        
        // Filter functionality
        function applyFilters() {
            const departmentValue = departmentFilter.value.toLowerCase();
            const batchValue = batchFilter.value.toLowerCase();
            const instructorValue = instructorFilter.value.toLowerCase();
            const searchValue = searchInput.value.toLowerCase();
            
            const rows = document.querySelectorAll('#coursesTable tbody tr');
            
            rows.forEach(row => {
                const code = row.cells[0].textContent.toLowerCase();
                const name = row.cells[1].textContent.toLowerCase();
                const batch = row.cells[3].textContent.toLowerCase();
                const instructor = row.cells[4].textContent.toLowerCase();
                const department = row.cells[5].textContent.toLowerCase();
                
                const departmentMatch = !departmentValue || department.includes(departmentValue);
                const batchMatch = !batchValue || batch.includes(batchValue);
                const instructorMatch = !instructorValue || instructor.includes(instructorValue);
                const searchMatch = !searchValue || 
                                   code.includes(searchValue) || 
                                   name.includes(searchValue);
                
                if (departmentMatch && batchMatch && instructorMatch && searchMatch) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }
        
        // Add event listeners for filters
        departmentFilter.addEventListener('change', applyFilters);
        batchFilter.addEventListener('change', applyFilters);
        instructorFilter.addEventListener('change', applyFilters);
        searchInput.addEventListener('input', applyFilters);
    });
    </script>
</body>
</html>
