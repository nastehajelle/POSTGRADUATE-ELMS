<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in
if (!is_logged_in()) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Get program fee for enrollment
if (isset($_GET['program_id'])) {
    $program_id = sanitize_input($_GET['program_id']);
    
    try {
        $query = "SELECT monthly_fee, name FROM programs WHERE id = ? AND status = 'active'";
        $stmt = $conn->prepare($query);
        $stmt->execute([$program_id]);
        
        if ($stmt->rowCount() > 0) {
            $program = $stmt->fetch(PDO::FETCH_ASSOC);
            echo json_encode([
                'success' => true, 
                'monthly_fee' => $program['monthly_fee'],
                'program_name' => $program['name'],
                'formatted_fee' => $program['monthly_fee'] ? '$' . number_format($program['monthly_fee'], 2) : 'Not set'
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Program not found']);
        }
    } catch(Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Program ID required']);
}
?>
