<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is an admin
if (!is_logged_in() || !is_admin()) {
    header("Location: ../auth/login.php");
    exit();
}

$message = '';
$messageType = '';

// Auto-update assessment statuses
try {
    $conn->query("UPDATE assessments SET status = 'inactive' WHERE end_time < NOW() AND status = 'active'");
} catch (PDOException $e) {
    error_log("Error updating assessment statuses: " . $e->getMessage());
}

// Get departments, programs, and batches for dropdowns
$departments = [];
$programs = [];
$batches = [];

try {
    $departments_query = "SELECT id, name, code FROM departments WHERE status = 'active' ORDER BY name";
    $departments_stmt = $conn->prepare($departments_query);
    $departments_stmt->execute();
    $departments = $departments_stmt->fetchAll(PDO::FETCH_ASSOC);

    $programs_query = "SELECT id, name, code, department_id FROM programs WHERE status = 'active' ORDER BY name";
    $programs_stmt = $conn->prepare($programs_query);
    $programs_stmt->execute();
    $programs = $programs_stmt->fetchAll(PDO::FETCH_ASSOC);

    $batches_query = "SELECT id, name, program_id FROM batch WHERE status = 'active' ORDER BY name";
    $batches_stmt = $conn->prepare($batches_query);
    $batches_stmt->execute();
    $batches = $batches_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching dropdown data: " . $e->getMessage());
}

// Handle assessment creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_assessment'])) {
    $type = sanitize_input($_POST['type']);
    $title = sanitize_input($_POST['title']);
    $description = sanitize_input($_POST['description']);
    $scope = sanitize_input($_POST['scope']);
    $department_id = ($scope === 'department' && !empty($_POST['department_id'])) ? intval($_POST['department_id']) : null;
    $program_id = ($scope === 'program' && !empty($_POST['program_id'])) ? intval($_POST['program_id']) : null;
    $total_marks = intval($_POST['total_marks']);
    $pass_marks = intval($_POST['pass_marks']);
    $start_time = sanitize_input($_POST['start_time']);
    $end_time = sanitize_input($_POST['end_time']);
    $duration_minutes = intval($_POST['duration_minutes']);
    $instructions = sanitize_input($_POST['instructions']);
    $randomize_questions = isset($_POST['randomize_questions']) ? 1 : 0;
    $attempts_allowed = intval($_POST['attempts_allowed']);

    if (!empty($title) && !empty($type) && $total_marks > 0 && $pass_marks >= 0) {
        try {
            $insert_query = "INSERT INTO assessments (course_id, program_id, department_id, type, title, description, 
                            total_marks, pass_marks, duration_minutes, start_time, end_time, instructions, 
                            randomize_questions, attempts_allowed, created_by, status) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')";
            $insert_stmt = $conn->prepare($insert_query);
            $insert_stmt->execute([
                null, // course_id is null for admin-created assessments
                $program_id, $department_id, $type, $title, $description, $total_marks, $pass_marks,
                $duration_minutes, $start_time, $end_time, $instructions, $randomize_questions,
                $attempts_allowed, $_SESSION['user_id']
            ]);

            $message = ucfirst($type) . " created successfully!";
            $messageType = "success";
        } catch (PDOException $e) {
            error_log("Error creating assessment: " . $e->getMessage());
            $message = "Error creating assessment. Please try again.";
            $messageType = "danger";
        }
    } else {
        $message = "Please fill in all required fields correctly.";
        $messageType = "danger";
    }
}

// Get assessments based on view (upcoming or past)
$view = isset($_GET['view']) ? $_GET['view'] : 'upcoming';
$assessments = [];

try {
    if ($view === 'upcoming') {
        $assessments_query = "SELECT a.*, 
                                     d.name as department_name, d.code as department_code,
                                     p.name as program_name, p.code as program_code,
                                     c.name as course_name, c.code as course_code,
                                     u.full_name as creator_name,
                                     (SELECT COUNT(DISTINCT aq.batch_id) FROM assessment_questions aq WHERE aq.assessment_id = a.id) as batch_count,
                                     (SELECT COUNT(*) FROM assessment_questions aq WHERE aq.assessment_id = a.id) as question_count,
                                     (SELECT COUNT(*) FROM assessment_results ar WHERE ar.assessment_id = a.id) as submission_count
                              FROM assessments a
                              LEFT JOIN departments d ON a.department_id = d.id
                              LEFT JOIN programs p ON a.program_id = p.id
                              LEFT JOIN course c ON a.course_id = c.id
                              LEFT JOIN users u ON a.created_by = u.id
                              WHERE a.start_time > NOW()
                              ORDER BY a.start_time ASC";
    } else {
        $assessments_query = "SELECT a.*, 
                                     d.name as department_name, d.code as department_code,
                                     p.name as program_name, p.code as program_code,
                                     c.name as course_name, c.code as course_code,
                                     u.full_name as creator_name,
                                     (SELECT COUNT(DISTINCT aq.batch_id) FROM assessment_questions aq WHERE aq.assessment_id = a.id) as batch_count,
                                     (SELECT COUNT(*) FROM assessment_questions aq WHERE aq.assessment_id = a.id) as question_count,
                                     (SELECT COUNT(*) FROM assessment_results ar WHERE ar.assessment_id = a.id) as submission_count
                              FROM assessments a
                              LEFT JOIN departments d ON a.department_id = d.id
                              LEFT JOIN programs p ON a.program_id = p.id
                              LEFT JOIN course c ON a.course_id = c.id
                              LEFT JOIN users u ON a.created_by = u.id
                              WHERE a.end_time <= NOW()
                              ORDER BY a.end_time DESC";
    }
    
    $assessments_stmt = $conn->prepare($assessments_query);
    $assessments_stmt->execute();
    $assessments = $assessments_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching assessments: " . $e->getMessage());
    $message = "Error loading assessments.";
    $messageType = "danger";
}

// Function to get assessment scope display
function getAssessmentScope($assessment) {
    if ($assessment['department_id'] && $assessment['program_id']) {
        return $assessment['program_name'] . ' (' . $assessment['department_name'] . ')';
    } elseif ($assessment['department_id']) {
        return $assessment['department_name'] . ' Department';
    } else {
        return 'System-wide';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Assessments - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <?php echo FONT_AWESOME_CSS; ?>
    <style>
        .view-tabs {
            display: flex;
            background: var(--card-bg);
            border-radius: 8px;
            padding: 4px;
            margin-bottom: 20px;
            box-shadow: var(--shadow);
        }

        .view-tab {
            flex: 1;
            padding: 12px 20px;
            text-align: center;
            border-radius: 6px;
            text-decoration: none;
            transition: all 0.2s;
            font-weight: 500;
            color: var(--text-muted);
        }

        .view-tab.active {
            background: var(--primary-color);
            color: white;
        }

        .view-tab:hover {
            text-decoration: none;
            background: var(--hover-bg);
        }

        .view-tab.active:hover {
            background: var(--primary-dark);
        }

        .assessments-grid {
            display: grid;
            gap: 20px;
            margin-top: 20px;
        }

        .assessment-card {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 20px;
            box-shadow: var(--shadow);
            border-left: 4px solid;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .assessment-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }

        .assessment-card.quiz { border-left-color: #3b82f6; }
        .assessment-card.assignment { border-left-color: #10b981; }
        .assessment-card.project { border-left-color: #f59e0b; }
        .assessment-card.exam { border-left-color: #ef4444; }

        .assessment-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }

        .assessment-title {
            font-size: 1.3rem;
            font-weight: 600;
            color: var(--text-color);
            margin: 0 0 8px 0;
        }

        .assessment-type {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
            text-transform: uppercase;
        }

        .assessment-type.quiz { background: #dbeafe; color: #1d4ed8; }
        .assessment-type.assignment { background: #d1fae5; color: #047857; }
        .assessment-type.project { background: #fef3c7; color: #b45309; }
        .assessment-type.exam { background: #fee2e2; color: #b91c1c; }

        .assessment-scope {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
            background: #e0e7ff;
            color: #4338ca;
            margin-left: 8px;
        }

        .assessment-meta {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin: 15px 0;
            padding: 15px;
            background: var(--bg-light);
            border-radius: 8px;
        }

        .meta-item {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }

        .meta-label {
            font-size: 0.8rem;
            color: var(--text-muted);
            font-weight: 500;
        }

        .meta-value {
            font-size: 0.9rem;
            color: var(--text-color);
            font-weight: 600;
        }

        .assessment-stats {
            display: flex;
            gap: 20px;
            margin: 15px 0;
        }

        .stat-item {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            background: var(--bg-secondary);
            border-radius: 6px;
            font-size: 0.9rem;
        }

        .stat-icon {
            color: var(--primary-color);
        }

        .batch-indicator {
            background: #f3e8ff;
            color: #7c3aed;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 500;
            margin-left: 8px;
        }

        .assessment-actions {
            display: flex;
            gap: 10px;
            margin-top: 20px;
            flex-wrap: wrap;
        }

        .btn-action {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-primary {
            background: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            color: white;
            text-decoration: none;
        }

        .btn-secondary {
            background: var(--bg-secondary);
            color: var(--text-color);
            border: 1px solid var(--border-color);
        }

        .btn-secondary:hover {
            background: var(--hover-bg);
            text-decoration: none;
        }

        .btn-success {
            background: #10b981;
            color: white;
        }

        .btn-success:hover {
            background: #059669;
            color: white;
            text-decoration: none;
        }

        .btn-warning {
            background: #f59e0b;
            color: white;
        }

        .btn-warning:hover {
            background: #d97706;
            color: white;
            text-decoration: none;
        }

        .btn-danger {
            background: #ef4444;
            color: white;
        }

        .btn-danger:hover {
            background: #dc2626;
            color: white;
            text-decoration: none;
        }

        .status-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 500;
        }

        .status-badge.active {
            background: #d1fae5;
            color: #047857;
        }

        .status-badge.inactive {
            background: #fee2e2;
            color: #b91c1c;
        }

        .create-assessment-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: var(--primary-color);
            color: white;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            transition: all 0.2s;
            z-index: 1000;
        }

        .create-assessment-btn:hover {
            background: var(--primary-dark);
            transform: scale(1.1);
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }

        .modal-content {
            background-color: var(--card-bg);
            margin: 3% auto;
            padding: 30px;
            border-radius: 12px;
            width: 90%;
            max-width: 700px;
            max-height: 85vh;
            overflow-y: auto;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border-color);
        }

        .close {
            color: var(--text-muted);
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.2s;
        }

        .close:hover {
            color: var(--text-color);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--text-color);
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            font-size: 0.9rem;
            background: var(--input-bg);
            color: var(--text-color);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-top: 10px;
        }

        .checkbox-group input[type="checkbox"] {
            width: auto;
        }

        .scope-options {
            display: none;
            margin-top: 15px;
            padding: 15px;
            background: var(--bg-light);
            border-radius: 6px;
        }

        .scope-options.active {
            display: block;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-muted);
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.3;
        }

        .admin-notice {
            background: #dbeafe;
            color: #1e40af;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #3b82f6;
        }

        .admin-notice i {
            margin-right: 8px;
        }

        .batch-notice {
            background: #f3e8ff;
            color: #7c3aed;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #8b5cf6;
        }

        .batch-notice i {
            margin-right: 8px;
        }

        @media (max-width: 768px) {
            .assessment-meta {
                grid-template-columns: 1fr;
            }
            
            .assessment-stats {
                flex-direction: column;
                gap: 10px;
            }
            
            .assessment-actions {
                flex-direction: column;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>Manage Assessments</h1>
                <div class="admin-header-right">
                    <span class="assessments-count"><?php echo count($assessments); ?> assessments</span>
                </div>
            </div>
            
            <?php if (!empty($message)): ?>
                <div class="message <?php echo $messageType; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

             Admin Notice 
            <div class="admin-notice">
                <i class="fas fa-info-circle"></i>
                <strong>Admin Privileges:</strong> You can create all types of assessments including exams. Assessments can be system-wide, department-specific, or program-specific.
            </div>

             Batch Notice 
            <div class="batch-notice">
                <i class="fas fa-layer-group"></i>
                <strong>Batch-Based Questions:</strong> All questions are batch-specific. Instructors will create separate question sets for each batch, ensuring students only see questions for their own batch.
            </div>

             View Tabs 
            <div class="view-tabs">
                <a href="?view=upcoming" class="view-tab <?php echo $view === 'upcoming' ? 'active' : ''; ?>">
                    <i class="fas fa-clock"></i> Upcoming Assessments
                </a>
                <a href="?view=past" class="view-tab <?php echo $view === 'past' ? 'active' : ''; ?>">
                    <i class="fas fa-history"></i> Past Assessments
                </a>
            </div>

             Assessments Grid 
            <div class="assessments-grid">
                <?php if (!empty($assessments)): ?>
                    <?php foreach ($assessments as $assessment): ?>
                        <div class="assessment-card <?php echo $assessment['type']; ?>">
                            <div class="assessment-header">
                                <div>
                                    <h3 class="assessment-title"><?php echo htmlspecialchars($assessment['title']); ?></h3>
                                    <span class="assessment-type <?php echo $assessment['type']; ?>">
                                        <?php echo ucfirst($assessment['type']); ?>
                                    </span>
                                    <span class="assessment-scope">
                                        <?php echo getAssessmentScope($assessment); ?>
                                    </span>
                                    <span class="batch-indicator">
                                        <?php echo $assessment['batch_count']; ?> Batch<?php echo $assessment['batch_count'] != 1 ? 'es' : ''; ?>
                                    </span>
                                    <span class="status-badge <?php echo $assessment['status']; ?>">
                                        <?php echo ucfirst($assessment['status']); ?>
                                    </span>
                                </div>
                            </div>
                            
                            <?php if (!empty($assessment['description'])): ?>
                                <p style="color: var(--text-muted); margin: 10px 0;">
                                    <?php echo nl2br(htmlspecialchars($assessment['description'])); ?>
                                </p>
                            <?php endif; ?>
                            
                            <div class="assessment-meta">
                                <div class="meta-item">
                                    <span class="meta-label">Created By</span>
                                    <span class="meta-value"><?php echo htmlspecialchars($assessment['creator_name']); ?></span>
                                </div>
                                <div class="meta-item">
                                    <span class="meta-label">Total Marks</span>
                                    <span class="meta-value"><?php echo $assessment['total_marks']; ?></span>
                                </div>
                                <div class="meta-item">
                                    <span class="meta-label">Pass Marks</span>
                                    <span class="meta-value"><?php echo $assessment['pass_marks']; ?></span>
                                </div>
                                <?php if ($assessment['duration_minutes'] > 0): ?>
                                <div class="meta-item">
                                    <span class="meta-label">Duration</span>
                                    <span class="meta-value"><?php echo $assessment['duration_minutes']; ?> min</span>
                                </div>
                                <?php endif; ?>
                                <div class="meta-item">
                                    <span class="meta-label">Start Time</span>
                                    <span class="meta-value"><?php echo date('M j, Y g:i A', strtotime($assessment['start_time'])); ?></span>
                                </div>
                                <div class="meta-item">
                                    <span class="meta-label">End Time</span>
                                    <span class="meta-value"><?php echo date('M j, Y g:i A', strtotime($assessment['end_time'])); ?></span>
                                </div>
                            </div>
                            
                            <div class="assessment-stats">
                                <div class="stat-item">
                                    <i class="fas fa-question-circle stat-icon"></i>
                                    <span><?php echo $assessment['question_count']; ?> Questions</span>
                                </div>
                                <div class="stat-item">
                                    <i class="fas fa-layer-group stat-icon"></i>
                                    <span><?php echo $assessment['batch_count']; ?> Batches</span>
                                </div>
                                <div class="stat-item">
                                    <i class="fas fa-users stat-icon"></i>
                                    <span><?php echo $assessment['submission_count']; ?> Submissions</span>
                                </div>
                            </div>
                            
                            <div class="assessment-actions">
                                <?php if ($view === 'past'): ?>
                                    <a href="view-assessment-results.php?assessment_id=<?php echo $assessment['id']; ?>" class="btn-action btn-success">
                                        <i class="fas fa-chart-bar"></i> View Results
                                    </a>
                                <?php endif; ?>
                                
                                <a href="edit-assessment.php?id=<?php echo $assessment['id']; ?>" class="btn-action btn-secondary">
                                    <i class="fas fa-cog"></i> Edit Settings
                                </a>
                                
                                <a href="preview-assessment.php?id=<?php echo $assessment['id']; ?>" class="btn-action btn-warning">
                                    <i class="fas fa-eye"></i> Preview
                                </a>
                                
                                <a href="manage-assessment-batches.php?assessment_id=<?php echo $assessment['id']; ?>" class="btn-action btn-primary">
                                    <i class="fas fa-layer-group"></i> Manage Batches
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-clipboard-list"></i>
                        <h3>No <?php echo $view === 'upcoming' ? 'Upcoming' : 'Past'; ?> Assessments</h3>
                        <p>
                            <?php if ($view === 'upcoming'): ?>
                                No upcoming assessments found. Create a new assessment to get started.
                            <?php else: ?>
                                No past assessments found yet.
                            <?php endif; ?>
                        </p>
                    </div>
                <?php endif; ?>
            </div>

             Create Assessment Button (only for upcoming view) 
            <?php if ($view === 'upcoming'): ?>
            <button class="create-assessment-btn" onclick="openModal('createAssessmentModal')" title="Create New Assessment">
                <i class="fas fa-plus"></i>
            </button>
            <?php endif; ?>
        </div>
    </div>

     Create Assessment Modal 
    <div id="createAssessmentModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Create New Assessment</h2>
                <span class="close" onclick="closeModal('createAssessmentModal')">&times;</span>
            </div>
            
            <form method="POST">
                <div class="form-group">
                    <label for="type">Assessment Type *</label>
                    <select name="type" id="type" required>
                        <option value="">Select Type</option>
                        <option value="exam">Exam</option>
                        
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="title">Title *</label>
                    <input type="text" name="title" id="title" required placeholder="Enter assessment title">
                </div>
                
                <div class="form-group">
                    <label for="scope">Assessment Scope *</label>
                    <select name="scope" id="scope" required onchange="toggleScopeOptions()">
                        <option value="">Select Scope</option>
                        <option value="general">System-wide (All Students)</option>
                        <option value="department">Department-specific</option>
                        <option value="program">Program-specific</option>
                    </select>
                </div>

                 Department Scope Options 
                <div id="departmentScope" class="scope-options">
                    <div class="form-group">
                        <label for="department_id">Select Department *</label>
                        <select name="department_id" id="department_id">
                            <option value="">Choose Department</option>
                            <?php foreach ($departments as $dept): ?>
                                <option value="<?php echo $dept['id']; ?>">
                                    <?php echo htmlspecialchars($dept['name'] . ' (' . $dept['code'] . ')'); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                 Program Scope Options 
                <div id="programScope" class="scope-options">
                    <div class="form-group">
                        <label for="program_department_id">Department *</label>
                        <select name="program_department_id" id="program_department_id" onchange="filterPrograms()">
                            <option value="">Choose Department First</option>
                            <?php foreach ($departments as $dept): ?>
                                <option value="<?php echo $dept['id']; ?>">
                                    <?php echo htmlspecialchars($dept['name'] . ' (' . $dept['code'] . ')'); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="program_id">Select Program *</label>
                        <select name="program_id" id="program_id">
                            <option value="">Choose Department First</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea name="description" id="description" placeholder="Enter assessment description"></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="total_marks">Total Marks *</label>
                        <input type="number" name="total_marks" id="total_marks" required min="1" placeholder="100">
                    </div>
                    <div class="form-group">
                        <label for="pass_marks">Pass Marks *</label>
                        <input type="number" name="pass_marks" id="pass_marks" required min="0" placeholder="60">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="start_time">Start Time *</label>
                        <input type="datetime-local" name="start_time" id="start_time" required>
                    </div>
                    <div class="form-group">
                        <label for="end_time">End Time *</label>
                        <input type="datetime-local" name="end_time" id="end_time" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="duration_minutes">Duration (Minutes)</label>
                        <input type="number" name="duration_minutes" id="duration_minutes" min="0" placeholder="60">
                        <small style="color: var(--text-muted);">Leave 0 for no time limit</small>
                    </div>
                    <div class="form-group">
                        <label for="attempts_allowed">Attempts Allowed</label>
                        <input type="number" name="attempts_allowed" id="attempts_allowed" min="1" value="1" placeholder="1">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="instructions">Instructions</label>
                    <textarea name="instructions" id="instructions" placeholder="Enter instructions for students"></textarea>
                </div>
                
                <div class="checkbox-group">
                    <input type="checkbox" name="randomize_questions" id="randomize_questions">
                    <label for="randomize_questions">Randomize question order</label>
                </div>
                
                <div class="form-group" style="margin-top: 30px;">
                    <button type="submit" name="create_assessment" class="btn btn-primary" style="width: 100%; padding: 12px;">
                        <i class="fas fa-plus"></i> Create Assessment
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
    <script>
        // Store programs and batches data for filtering
        const programsData = <?php echo json_encode($programs); ?>;
        const batchesData = <?php echo json_encode($batches); ?>;
        
        // Modal functionality
        function openModal(modalId) {
            document.getElementById(modalId).style.display = 'block';
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
        
        // Toggle scope options
        function toggleScopeOptions() {
            const scope = document.getElementById('scope').value;
            const departmentScope = document.getElementById('departmentScope');
            const programScope = document.getElementById('programScope');
            
            // Hide all scope options
            departmentScope.classList.remove('active');
            programScope.classList.remove('active');
            
            // Show relevant scope options
            if (scope === 'department') {
                departmentScope.classList.add('active');
                document.getElementById('department_id').required = true;
                document.getElementById('program_department_id').required = false;
                document.getElementById('program_id').required = false;
            } else if (scope === 'program') {
                programScope.classList.add('active');
                document.getElementById('department_id').required = false;
                document.getElementById('program_department_id').required = true;
                document.getElementById('program_id').required = true;
            } else {
                document.getElementById('department_id').required = false;
                document.getElementById('program_department_id').required = false;
                document.getElementById('program_id').required = false;
            }
        }
        
        // Filter programs based on selected department
        function filterPrograms() {
            const departmentId = document.getElementById('program_department_id').value;
            const programSelect = document.getElementById('program_id');
            
            // Clear existing options
            programSelect.innerHTML = '<option value="">Choose Program</option>';
            
            if (departmentId) {
                // Filter programs for selected department
                const filteredPrograms = programsData.filter(program => 
                    program.department_id == departmentId
                );
                
                // Add filtered programs to select
                filteredPrograms.forEach(program => {
                    const option = document.createElement('option');
                    option.value = program.id;
                    option.textContent = program.name + ' (' + program.code + ')';
                    programSelect.appendChild(option);
                });
            }
        }
        
        // Set default start time to current time + 1 hour
        document.addEventListener('DOMContentLoaded', function() {
            const now = new Date();
            now.setHours(now.getHours() + 1);
            const startTime = now.toISOString().slice(0, 16);
            document.getElementById('start_time').value = startTime;
            
            // Set default end time to start time + 2 hours
            now.setHours(now.getHours() + 2);
            const endTime = now.toISOString().slice(0, 16);
            document.getElementById('end_time').value = endTime;
        });
        
        // Update pass marks when total marks change
        document.getElementById('total_marks').addEventListener('input', function() {
            const totalMarks = parseInt(this.value);
            if (totalMarks > 0) {
                const passMarks = Math.floor(totalMarks * 0.6); // 60% pass rate
                document.getElementById('pass_marks').value = passMarks;
            }
        });
        
        // Validate end time is after start time
        document.getElementById('end_time').addEventListener('change', function() {
            const startTime = new Date(document.getElementById('start_time').value);
            const endTime = new Date(this.value);
            
            if (endTime <= startTime) {
                alert('End time must be after start time');
                this.value = '';
            }
        });
    </script>
</body>
</html>
