<?php
session_start();
include_once '../config/init.php';

$pdo = $conn;

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Get current report type
$active_report = $_GET['report'] ?? 'users';

if ($active_report === 'student_profile') {
    $active_report = 'users';
}

// Get filter parameters
$search = $_GET['search'] ?? '';
$department_filter = $_GET['department'] ?? '';
$role_filter = $_GET['role'] ?? '';
$status_filter = $_GET['status'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$sort_by = $_GET['sort_by'] ?? '';
$sort_order = $_GET['sort_order'] ?? 'DESC';
$mode = $_GET['mode'] ?? '';
$batch_filter = $_GET['batch'] ?? '';
$program_filter = $_GET['program'] ?? '';
$instructor_filter = $_GET['instructor'] ?? '';
$attendance_filter = $_GET['attendance_filter'] ?? '';

$order = $_GET['order'] ?? 'DESC';

$student_id_filter = $_GET['student_id'] ?? '';

// Validate sort_by parameter - only allow valid column names
$valid_sort_columns = [
    'users' => ['full_name', 'email', 'role', 'status', 'created_at'],
    'attendance_summary' => ['student_name', 'attendance_percentage', 'program_name'],
    'assessments' => ['student_name', 'assessment_title', 'marks_obtained', 'submitted_at', 'batch_name', 'total_students', 'passed', 'failed'],
    'thesis' => ['student_name', 'thesis_title', 'status', 'submission_date', 'supervisor_name']
];

// Get the active report type
$active_report = $_GET['report'] ?? 'users';

// Validate sort_by parameter
if (!empty($sort_by)) {
    $allowed_sorts = $valid_sort_columns[$active_report] ?? $valid_sort_columns['users'];
    if (!in_array($sort_by, $allowed_sorts)) {
        $sort_by = $allowed_sorts[0]; // Default to first valid option
    }
}

// Validate order parameter - only allow ASC or DESC
if (!in_array(strtoupper($order), ['ASC', 'DESC'])) {
    $order = 'DESC'; // Default to DESC
}

// Validate sort_order parameter as well
if (!in_array(strtoupper($sort_order), ['ASC', 'DESC'])) {
    $sort_order = 'DESC'; // Default to DESC
}

// Handle exports
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['export_action'])) {
    $export_type = $_POST['export_type'];
    $export_report = $_POST['export_report'];
    
    // Generate filename
    $filename = $export_report . '_report_' . date('Y-m-d_H-i-s');
    
    if ($export_type === 'csv') {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
        $output = fopen('php://output', 'w');
        
        // Export logic based on report type
        switch ($export_report) {
            case 'users':
                fputcsv($output, ['ID', 'Full Name', 'Email', 'Role', 'Status', 'Created Date']);
                $stmt = $pdo->prepare("
                    SELECT u.id, u.full_name, u.email, u.role, u.status, u.created_at
                    FROM users u 
                    ORDER BY u.created_at DESC
                ");
                break;
                
            case 'instructors':
                fputcsv($output, ['Instructor Name', 'Email', 'Total Batches', 'Total Students', 'Total Courses', 'Status']);
                $stmt = $pdo->prepare("
                    SELECT 
                        u.full_name,
                        u.email,
                        COUNT(DISTINCT cb.batch_id) as total_batches,
                        COUNT(DISTINCT e.user_id) as total_students,
                        COUNT(DISTINCT cb.course_id) as total_courses,
                        u.status
                    FROM users u
                    LEFT JOIN course_batch cb ON u.id = cb.instructor_id
                    LEFT JOIN enrollment e ON cb.batch_id = e.batch_id
                    WHERE u.role = 'instructor'
                    GROUP BY u.id
                    ORDER BY u.full_name
                ");
                break;
                
            case 'thesis':
                fputcsv($output, ['Student Name', 'Student ID', 'Thesis Title', 'Status', 'Supervisor', 'Submission Date', 'Department', 'Program']);
                $stmt = $pdo->prepare("
                    SELECT 
                        u.full_name,
                        e.student_id,
                        t.title,
                        t.status,
                        sup.full_name as supervisor_name,
                        t.submission_date,
                        d.name as department_name,
                        p.name as program_name
                    FROM thesis t
                    JOIN users u ON t.student_id = u.id
                    JOIN enrollment e ON u.id = e.user_id
                    JOIN departments d ON t.department_id = d.id
                    JOIN programs p ON t.program_id = p.id
                    LEFT JOIN users sup ON t.supervisor_id = sup.id
                    ORDER BY t.submission_date DESC
                ");
                break;
                
            case 'courses':
                fputcsv($output, ['ID', 'Course Name', 'Department', 'Created Date']);
                $stmt = $pdo->prepare("
                    SELECT c.id, c.name, d.name as department_name, c.created_at
                    FROM course c 
                    LEFT JOIN departments d ON c.department_id = d.id
                    ORDER BY c.created_at DESC
                ");
                break;
                
            case 'attendance_summary':
                fputcsv($output, ['Student Name', 'Student ID', 'Course', 'Batch', 'Total Sessions', 'Attended', 'Absent', 'Attendance %']);
                $filters = [
                    'batch' => $batch_filter,
                    'date_from' => $date_from,
                    'date_to' => $date_to
                ];
                $query = buildReportQuery($pdo, 'attendance_summary', $search, $filters, 'student_name', 'ASC');
                $stmt = $pdo->prepare($query['sql']);
                $stmt->execute($query['params']);
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    fputcsv($output, [
                        $row['student_name'],
                        $row['student_id'],
                        $row['course_name'],
                        $row['batch_name'],
                        $row['total_sessions'],
                        $row['attended_sessions'],
                        $row['absent_sessions'],
                        $row['attendance_percentage'] . '%'
                    ]);
                }
                break;

            case 'assessments':
                if ($mode === 'by_batch') {
                    fputcsv($output, ['Batch', 'Assessment', 'Type', 'Total Students', 'Passed', 'Failed', 'Average Marks', 'Total Marks']);
                } else {
                    fputcsv($output, ['Student Name', 'Student ID', 'Department', 'Program', 'Batch', 'Course', 'Assessment', 'Marks', 'Total', 'Result']);
                }
                $filters = [
                    'mode' => $mode,
                    'batch' => $batch_filter,
                    'department' => $department_filter,
                    'program' => $program_filter
                ];
                $query = buildReportQuery($pdo, 'assessments', $search, $filters, 'student_name', 'ASC');
                $stmt = $pdo->prepare($query['sql']);
                $stmt->execute($query['params']);
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    if ($mode === 'by_batch') {
                        fputcsv($output, [
                            $row['batch_name'],
                            $row['assessment_title'],
                            $row['assessment_type'],
                            $row['total_students'],
                            $row['passed'],
                            $row['failed'],
                            $row['average_marks'],
                            $row['total_marks']
                        ]);
                    } else {
                        fputcsv($output, [
                            $row['student_name'],
                            $row['student_id'],
                            $row['department_name'],
                            $row['program_name'],
                            $row['batch_name'],
                            $row['course_name'],
                            $row['assessment_title'],
                            $row['marks_obtained'],
                            $row['total_marks'],
                            $row['result']
                        ]);
                    }
                }
                break;
        }
        
        $stmt->execute();
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($output, $row);
        }
        
        fclose($output);
        exit();
    } elseif ($export_type === 'pdf') {
        echo "<script>alert('PDF export is currently unavailable. Please use CSV export instead.'); window.history.back();</script>";
        exit();
    }
    
    // Redirect after POST
    header("Location: reports.php?report=" . $export_report);
    exit();
}

// Get filter options
try {
    // Get departments
    $departments = $pdo->query("SELECT id, name FROM departments ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
    
    // Get batches if table exists
    $batches = [];
    $batch_check = $pdo->query("SHOW TABLES LIKE 'batch'")->fetch();
    if ($batch_check) {
        $batches = $pdo->query("SELECT id, name FROM batch ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Get programs if table exists
    $programs = [];
    $program_check = $pdo->query("SHOW TABLES LIKE 'programs'")->fetch();
    if ($program_check) {
        $programs = $pdo->query("SELECT id, name FROM programs ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    $departments = [];
    $batches = [];
    $programs = [];
}

function getBatches($pdo) {
    try {
        $stmt = $pdo->query("SELECT id, name FROM batch ORDER BY name");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        return [];
    }
}

// Get departments for filter dropdown
function getDepartments($pdo) {
    try {
        $stmt = $pdo->query("SELECT id, name FROM departments ORDER BY name");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        return [];
    }
}

function buildReportQuery($pdo, $report_type, $search, $filters, $sort_by, $sort_order) {
    $where_conditions = [];
    $params = [];
    $base_query = "";
    
    $student_id_filter = $filters['student_id'] ?? '';
    
    // Handle batch filter for assessments and attendance_summary
    if (!empty($filters['batch']) && in_array($report_type, ['assessments', 'attendance_summary'])) {
        $where_conditions[] = "e.batch_id = ?";
        $params[] = $filters['batch'];
    }

    if (!empty($filters['attendance_filter']) && $report_type === 'attendance_summary') {
        // This will be handled in HAVING clause, not WHERE
    }

    switch ($report_type) {
        
        case 'users':
            $base_query = "
                SELECT 
                    u.id,
                    u.full_name,
                    u.email,
                    u.role,
                    u.status,
                    u.created_at
                FROM users u
                WHERE 1=1
            ";
            
            if ($search) {
                $where_conditions[] = "(u.full_name LIKE ? OR u.email LIKE ?)";
                $params[] = "%$search%";
                $params[] = "%$search%";
            }
            
            if (!empty($filters['status'])) {
                $where_conditions[] = "u.status = ?";
                $params[] = $filters['status'];
            }
            
            $group_by = "";
            $allowed_sorts = ['full_name', 'email', 'role', 'status', 'created_at'];
            $sort_column = in_array($sort_by, $allowed_sorts) ? $sort_by : "u.full_name";
            break;

        
        case 'instructors':
            $base_query = "
                SELECT 
                    u.id,
                    u.full_name as instructor_name,
                    u.email,
                    u.phone,
                    COUNT(DISTINCT cb.batch_id) as total_batches,
                    COUNT(DISTINCT e.user_id) as total_students,
                    COUNT(DISTINCT cb.course_id) as total_courses,
                    u.status,
                    u.created_at,
                    GROUP_CONCAT(DISTINCT CONCAT(c.name, ' (', b.name, ')') SEPARATOR ', ') as courses_batches
                FROM users u
                LEFT JOIN course_batch cb ON u.id = cb.instructor_id
                LEFT JOIN course c ON cb.course_id = c.id
                LEFT JOIN batch b ON cb.batch_id = b.id
                LEFT JOIN enrollment e ON cb.batch_id = e.batch_id
                WHERE u.role = 'instructor'
            ";
            
            if ($search) {
                $where_conditions[] = "(u.full_name LIKE ? OR u.email LIKE ?)";
                $params[] = "%$search%";
                $params[] = "%$search%";
            }
            
            if (!empty($filters['status'])) {
                $where_conditions[] = "u.status = ?";
                $params[] = $filters['status'];
            }
            
            if (!empty($filters['department'])) {
                $where_conditions[] = "c.department_id = ?";
                $params[] = $filters['department'];
            }
            
            $group_by = " GROUP BY u.id, u.full_name, u.email, u.phone, u.status, u.created_at";
            $allowed_sorts = ['instructor_name', 'total_batches', 'total_students', 'total_courses'];
            $sort_column = in_array($sort_by, $allowed_sorts) ? $sort_by : "u.full_name";
            break;

        case 'thesis':
            $base_query = "
                SELECT 
                    t.id,
                    u.full_name as student_name,
                    e.student_id,
                    t.title as thesis_title,
                    t.status,
                    sup.full_name as supervisor_name,
                    t.submission_date,
                    d.name as department_name,
                    p.name as program_name,
                    b.name as batch_name,
                    t.file_type,
                    t.file_size,
                    CASE 
                        WHEN t.submission_date <= CURDATE() THEN 'On Time'
                        ELSE 'Late'
                    END as submission_status,
                    DATEDIFF(CURDATE(), t.submission_date) as days_since_submission
                FROM thesis t
                JOIN users u ON t.student_id = u.id
                JOIN enrollment e ON u.id = e.user_id
                JOIN departments d ON t.department_id = d.id
                JOIN programs p ON t.program_id = p.id
                JOIN batch b ON e.batch_id = b.id
                LEFT JOIN users sup ON t.supervisor_id = sup.id
                WHERE 1=1
            ";
            
            if ($search) {
                $where_conditions[] = "(u.full_name LIKE ? OR t.title LIKE ? OR e.student_id LIKE ?)";
                $params[] = "%$search%";
                $params[] = "%$search%";
                $params[] = "%$search%";
            }
            
            if (!empty($filters['status'])) {
                $where_conditions[] = "t.status = ?";
                $params[] = $filters['status'];
            }
            
            if (!empty($filters['department'])) {
                $where_conditions[] = "t.department_id = ?";
                $params[] = $filters['department'];
            }
            
            if (!empty($filters['program'])) {
                $where_conditions[] = "t.program_id = ?";
                $params[] = $filters['program'];
            }
            
            if (!empty($filters['supervisor'])) {
                $where_conditions[] = "t.supervisor_id = ?";
                $params[] = $filters['supervisor'];
            }
            
            if (!empty($filters['date_from'])) {
                $where_conditions[] = "t.submission_date >= ?";
                $params[] = $filters['date_from'];
            }
            
            if (!empty($filters['date_to'])) {
                $where_conditions[] = "t.submission_date <= ?";
                $params[] = $filters['date_to'];
            }
            
            $allowed_sorts = ['student_name', 'thesis_title', 'status', 'submission_date', 'supervisor_name'];
            $sort_column = in_array($sort_by, $allowed_sorts) ? $sort_by : "t.submission_date";
            break;

        case 'batches':
            $base_query = "
                SELECT 
                    b.id,
                    b.name as batch_name,
                    p.name as program_name,
                    d.name as department_name,
                    b.year,
                    b.start_date,
                    b.end_date,
                    b.status,
                    COUNT(DISTINCT e.user_id) as total_students,
                    COUNT(DISTINCT cb.course_id) as total_courses,
                    COUNT(DISTINCT cb.instructor_id) as total_instructors,
                    ROUND(AVG(
                        CASE WHEN att.status IN ('present', 'late') THEN 100.0 ELSE 0.0 END
                    ), 2) as avg_attendance_percentage,
                    COUNT(DISTINCT t.id) as thesis_submissions
                FROM batch b
                LEFT JOIN programs p ON b.program_id = p.id
                LEFT JOIN departments d ON p.department_id = d.id
                LEFT JOIN enrollment e ON b.id = e.batch_id
                LEFT JOIN course_batch cb ON b.id = cb.batch_id
                LEFT JOIN attendance att ON e.user_id = att.student_id
                LEFT JOIN thesis t ON e.user_id = t.student_id
                WHERE 1=1
            ";
            
            if ($search) {
                $where_conditions[] = "(b.name LIKE ? OR p.name LIKE ?)";
                $params[] = "%$search%";
                $params[] = "%$search%";
            }
            
            if (!empty($filters['department'])) {
                $where_conditions[] = "d.id = ?";
                $params[] = $filters['department'];
            }
            
            if (!empty($filters['program'])) {
                $where_conditions[] = "p.id = ?";
                $params[] = $filters['program'];
            }
            
            if (!empty($filters['status'])) {
                $where_conditions[] = "b.status = ?";
                $params[] = $filters['status'];
            }
            
            $group_by = " GROUP BY b.id, b.name, p.name, d.name, b.year, b.start_date, b.end_date, b.status";
            $allowed_sorts = ['batch_name', 'program_name', 'total_students', 'total_courses', 'avg_attendance_percentage'];
            $sort_column = in_array($sort_by, $allowed_sorts) ? $sort_by : "b.name";
            break;

        case 'courses':
            $base_query = "
                SELECT 
                    c.id,
                    c.name,
                    c.code,
                    c.description,
                    c.credit_hours,
                    c.status,
                    d.name as department_name,
                    p.name as program_name,
                    COUNT(DISTINCT e.user_id) as enrollment_count
                FROM course c
                LEFT JOIN departments d ON c.department_id = d.id
                LEFT JOIN programs p ON c.program_id = p.id
                LEFT JOIN enrollment e ON c.id = e.course_id
                WHERE 1=1
            ";
            
            if ($search) {
                $where_conditions[] = "(c.name LIKE ? OR c.code LIKE ?)";
                $params[] = "%$search%";
                $params[] = "%$search%";
            }
            
            if (!empty($filters['department'])) {
                $where_conditions[] = "c.department_id = ?";
                $params[] = $filters['department'];
            }
            
            if (!empty($filters['course'])) {
                $where_conditions[] = "c.id = ?";
                $params[] = $filters['course'];
            }
            
            $group_by = " GROUP BY c.id, c.name, c.code, c.description, c.credit_hours, c.status, d.name, p.name";
            $allowed_sorts = ['id', 'name', 'code', 'credit_hours', 'status'];
            $sort_column = in_array($sort_by, $allowed_sorts) ? "c.$sort_by" : "c.id";
            break;

        case 'departments':
            $base_query = "
                SELECT 
                    d.id,
                    d.name,
                    d.description,
                    d.status,
                    COUNT(DISTINCT c.id) as course_count,
                    COUNT(DISTINCT e.user_id) as user_count,
                    d.created_at
                FROM departments d
                LEFT JOIN course c ON d.id = c.department_id
                LEFT JOIN enrollment e ON d.id = e.department_id
                WHERE 1=1
            ";
            
            if ($search) {
                $where_conditions[] = "d.name LIKE ?";
                $params[] = "%$search%";
            }
            
            $group_by = " GROUP BY d.id, d.name, d.description, d.status, d.created_at";
            $allowed_sorts = ['id', 'name', 'status', 'course_count', 'user_count'];
            $sort_column = in_array($sort_by, $allowed_sorts) ? "d.$sort_by" : "d.id";
            break;

        case 'assessments':
            if (isset($filters['mode']) && $filters['mode'] === 'by_batch') {
                // Pass/fail summary by batch
                $base_query = "
                    SELECT 
                        b.name as batch_name,
                        a.title as assessment_title,
                        a.type as assessment_type,
                        COUNT(ar.id) as total_students,
                        SUM(CASE WHEN ar.marks_obtained >= a.pass_marks THEN 1 ELSE 0 END) as passed,
                        SUM(CASE WHEN ar.marks_obtained < a.pass_marks THEN 1 ELSE 0 END) as failed,
                        ROUND(AVG(ar.marks_obtained), 2) as average_marks,
                        a.total_marks,
                        a.pass_marks
                    FROM assessments a
                    JOIN assessment_results ar ON a.id = ar.assessment_id
                    JOIN enrollment e ON ar.student_id = e.user_id
                    JOIN batch b ON e.batch_id = b.id
                    WHERE 1=1
                ";
                
                if ($search) {
                    $where_conditions[] = "(a.title LIKE ? OR b.name LIKE ?)";
                    $params[] = "%$search%";
                    $params[] = "%$search%";
                }
                
                if (!empty($filters['department'])) {
                    $where_conditions[] = "e.department_id = ?";
                    $params[] = $filters['department'];
                }
                
                if (!empty($filters['program'])) {
                    $where_conditions[] = "e.program_id = ?";
                    $params[] = $filters['program'];
                }
                
                $group_by = " GROUP BY b.id, a.id, b.name, a.title, a.type, a.total_marks, a.pass_marks";
                $allowed_sorts = ['batch_name', 'assessment_title', 'total_students', 'passed', 'failed'];
                $sort_column = in_array($sort_by, $allowed_sorts) ? $sort_by : "b.name";
            } else {
                // Individual student assessments with pass/fail counts
                $base_query = "
                    SELECT 
                        u.full_name as student_name,
                        e.student_id,
                        a.title as assessment_title,
                        a.type as assessment_type,
                        ar.marks_obtained,
                        a.total_marks,
                        a.pass_marks,
                        CASE WHEN ar.marks_obtained >= a.pass_marks THEN 'Pass' ELSE 'Fail' END as result,
                        c.name as course_name,
                        b.name as batch_name,
                        d.name as department_name,
                        p.name as program_name,
                        ar.submitted_at,
                        (SELECT COUNT(*) FROM assessment_results ar2 
                         JOIN assessments a2 ON ar2.assessment_id = a2.id 
                         WHERE ar2.student_id = u.id AND ar2.marks_obtained >= a2.pass_marks) as total_passed,
                        (SELECT COUNT(*) FROM assessment_results ar3 
                         JOIN assessments a3 ON ar3.assessment_id = a3.id 
                         WHERE ar3.student_id = u.id AND ar3.marks_obtained < a3.pass_marks) as total_failed
                    FROM assessment_results ar
                    JOIN assessments a ON ar.assessment_id = a.id
                    JOIN users u ON ar.student_id = u.id
                    JOIN enrollment e ON u.id = e.user_id
                    LEFT JOIN course c ON a.course_id = c.id
                    JOIN batch b ON e.batch_id = b.id
                    JOIN departments d ON e.department_id = d.id
                    JOIN programs p ON e.program_id = p.id
                    WHERE 1=1
                ";
                
                if ($search) {
                    $where_conditions[] = "(u.full_name LIKE ? OR u.email LIKE ? OR a.title LIKE ? OR e.student_id LIKE ?)";
                    $params[] = "%$search%";
                    $params[] = "%$search%";
                    $params[] = "%$search%";
                    $params[] = "%$search%";
                }
                
                if (!empty($filters['department'])) {
                    $where_conditions[] = "e.department_id = ?";
                    $params[] = $filters['department'];
                }
                
                if (!empty($filters['program'])) {
                    $where_conditions[] = "e.program_id = ?";
                    $params[] = $filters['program'];
                }
                
                $allowed_sorts = ['student_name', 'assessment_title', 'marks_obtained', 'submitted_at'];
                $sort_column = in_array($sort_by, $allowed_sorts) ? $sort_by : "u.full_name";
            }
            break;

        case 'batches':
            $base_query = "
                SELECT 
                    b.id,
                    b.name as batch_name,
                    p.name as program_name,
                    d.name as department_name,
                    b.year,
                    b.start_date,
                    b.end_date,
                    b.status,
                    COUNT(DISTINCT e.user_id) as total_students,
                    COUNT(DISTINCT cb.course_id) as total_courses,
                    COUNT(DISTINCT cb.instructor_id) as total_instructors,
                    ROUND(AVG(
                        CASE WHEN att.status IN ('present', 'late') THEN 100.0 ELSE 0.0 END
                    ), 2) as avg_attendance_percentage,
                    COUNT(DISTINCT t.id) as thesis_submissions
                FROM batch b
                LEFT JOIN programs p ON b.program_id = p.id
                LEFT JOIN departments d ON p.department_id = d.id
                LEFT JOIN enrollment e ON b.id = e.batch_id
                LEFT JOIN course_batch cb ON b.id = cb.batch_id
                LEFT JOIN attendance att ON e.user_id = att.student_id
                LEFT JOIN thesis t ON e.user_id = t.student_id
                WHERE 1=1
            ";
            
            if ($search) {
                $where_conditions[] = "(b.name LIKE ? OR p.name LIKE ?)";
                $params[] = "%$search%";
                $params[] = "%$search%";
            }
            
            if (!empty($filters['department'])) {
                $where_conditions[] = "d.id = ?";
                $params[] = $filters['department'];
            }
            
            if (!empty($filters['program'])) {
                $where_conditions[] = "p.id = ?";
                $params[] = $filters['program'];
            }
            
            if (!empty($filters['status'])) {
                $where_conditions[] = "b.status = ?";
                $params[] = $filters['status'];
            }
            
            $group_by = " GROUP BY b.id, b.name, p.name, d.name, b.year, b.start_date, b.end_date, b.status";
            $allowed_sorts = ['batch_name', 'program_name', 'total_students', 'total_courses', 'avg_attendance_percentage'];
            $sort_column = in_array($sort_by, $allowed_sorts) ? $sort_by : "b.name";
            break;

        case 'attendance_summary':
            $base_query = "
                SELECT 
                    u.full_name AS student_name,
                    p.name as program_name,
                    COALESCE(SUM(CASE WHEN att.status IN ('present', 'late') THEN 1 ELSE 0 END), 0) AS attended_sessions,
                    COALESCE(COUNT(att.id), 0) AS total_sessions,
                    CASE 
                        WHEN COUNT(att.id) > 0 THEN ROUND(SUM(CASE WHEN att.status IN ('present', 'late') THEN 1 ELSE 0 END) * 100.0 / COUNT(att.id), 2)
                        ELSE 0 
                    END AS attendance_percentage
                FROM users u
                JOIN enrollment e ON u.id = e.user_id
                JOIN batch b ON e.batch_id = b.id
                JOIN departments d ON e.department_id = d.id
                JOIN programs p ON e.program_id = p.id
                LEFT JOIN attendance att ON u.id = att.student_id
                WHERE u.role = 'student'
            ";
            
            if ($search) {
                $where_conditions[] = "(u.full_name LIKE ?)";
                $params[] = "%$search%";
            }
            
            if (!empty($filters['batch'])) {
                $where_conditions[] = "e.batch_id = ?";
                $params[] = $filters['batch'];
            }
            
            if (!empty($filters['program'])) {
                $where_conditions[] = "e.program_id = ?";
                $params[] = $filters['program'];
            }
            
            if (!empty($filters['date_from'])) {
                $where_conditions[] = "(att.date >= ? OR att.date IS NULL)";
                $params[] = $filters['date_from'];
            }
            
            if (!empty($filters['date_to'])) {
                $where_conditions[] = "(att.date <= ? OR att.date IS NULL)";
                $params[] = $filters['date_to'];
            }

            $group_by = " GROUP BY u.id, u.full_name, p.name";
            
            $having_conditions = [];
            if (!empty($filters['attendance_filter'])) {
                $having_conditions[] = "attendance_percentage >= ?";
                $params[] = $filters['attendance_filter'];
            }
            $having_clause = !empty($having_conditions) ? " HAVING " . implode(" AND ", $having_conditions) : "";
            
            $allowed_sorts = ['student_name', 'attendance_percentage', 'program_name'];
            $sort_column = in_array($sort_by, $allowed_sorts) ? $sort_by : "u.full_name";
            break;

        case 'student_profile':
            if (!empty($student_id_filter)) {
                // Get student basic info
                $student_query = "
                    SELECT 
                        u.id as user_id,
                        u.full_name,
                        u.email,
                        u.phone,
                        e.student_id,
                        p.name as program_name,
                        d.name as department_name,
                        b.name as batch_name,
                        u.status,
                        e.created_at as enrollment_date
                    FROM users u
                    LEFT JOIN enrollment e ON u.id = e.user_id
                    LEFT JOIN programs p ON e.program_id = p.id
                    LEFT JOIN departments d ON e.department_id = d.id
                    LEFT JOIN batch b ON e.batch_id = b.id
                    WHERE e.student_id = ? AND u.role = 'student'
                ";
                $stmt = $pdo->prepare($student_query);
                $stmt->execute([$student_id_filter]);
                $student_data = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($student_data) {
                    $user_id = $student_data['user_id'];
                    
                    // Get attendance data
                    $attendance_query = "
                        SELECT 
                            COUNT(CASE WHEN a.status = 'present' THEN 1 END) as present_count,
                            COUNT(*) as total_sessions,
                            ROUND((COUNT(CASE WHEN a.status = 'present' THEN 1 END) / COUNT(*)) * 100, 2) as attendance_percentage
                        FROM attendance a
                        WHERE a.student_id = ?
                    ";
                    $stmt = $pdo->prepare($attendance_query);
                    $stmt->execute([$user_id]);
                    $attendance = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    // Get assessment data
                    $assessment_query = "
                        SELECT 
                            a.title,
                            ar.marks_obtained,
                            a.total_marks,
                            ar.submitted_at,
                            CASE 
                                WHEN ar.marks_obtained >= a.pass_marks THEN 'Passed'
                                ELSE 'Failed'
                            END as result
                        FROM assessment_results ar
                        JOIN assessments a ON ar.assessment_id = a.id
                        WHERE ar.student_id = ?
                        ORDER BY ar.submitted_at DESC
                    ";
                    $stmt = $pdo->prepare($assessment_query);
                    $stmt->execute([$user_id]);
                    $assessments = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    // Get thesis data
                    $thesis_query = "
                        SELECT 
                            t.title,
                            t.status,
                            t.submission_date,
                            u.full_name as supervisor_name
                        FROM thesis t
                        LEFT JOIN users u ON t.supervisor_id = u.id
                        WHERE t.student_id = ?
                    ";
                    $stmt = $pdo->prepare($thesis_query);
                    $stmt->execute([$user_id]);
                    $thesis = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    // Get live classes data - simplified since live_class_attendance table may not exist
                    $classes_query = "
                        SELECT 
                            lc.title,
                            lc.scheduled_date,
                            lc.duration,
                            'N/A' as attendance_status
                        FROM live_classes lc
                        JOIN enrollment e ON lc.course_id = e.course_id
                        WHERE e.user_id = ?
                        ORDER BY lc.scheduled_date DESC
                        LIMIT 10
                    ";
                    $stmt = $pdo->prepare($classes_query);
                    $stmt->execute([$user_id]);
                    $classes = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
            }
            $base_query = "SELECT 1 as dummy WHERE 0"; // Returns no results but is valid
            $allowed_sorts = ['dummy'];
            $sort_column = 'dummy';
            break;

        case 'exams':
            $base_query = "
                SELECT 
                    a.id,
                    a.title,
                    c.name as course_name,
                    a.start_time as date,
                    a.total_marks,
                    a.pass_marks,
                    d.name as department_name,
                    a.created_at
                FROM assessments a
                LEFT JOIN course c ON a.course_id = c.id
                LEFT JOIN departments d ON a.department_id = d.id
                WHERE a.type = 'exam'
            ";
            
            if ($search) {
                $where_conditions[] = "(a.title LIKE ? OR c.name LIKE ?)";
                $params[] = "%$search%";
            }
            
            if (!empty($filters['department'])) {
                $where_conditions[] = "a.department_id = ?";
                $params[] = $filters['department'];
            }
            
            $allowed_sorts = ['start_time', 'title', 'course_name'];
            $sort_column = in_array($sort_by, $allowed_sorts) ? ($sort_by === 'date' ? 'a.start_time' : "a.$sort_by") : "a.start_time";
            break;
            
        default:
            $base_query = "SELECT 1 as dummy WHERE 0"; // Returns no results but is valid
            $allowed_sorts = ['dummy'];
            $sort_column = 'dummy';
            break;
    }
    
    // Build final query
    $final_query = $base_query;
    
    if (!empty($where_conditions)) {
        $final_query .= " AND " . implode(" AND ", $where_conditions);
    }
    
    if (isset($group_by)) {
        $final_query .= $group_by;
    }
    
    if (isset($having_clause)) {
        $final_query .= $having_clause;
    }
    
    if (isset($sort_column)) {
        $final_query .= " ORDER BY " . $sort_column . " " . ($sort_order === 'ASC' ? 'ASC' : 'DESC');
    }
    
    return [
        'sql' => $final_query,
        'params' => $params
    ];
}

// Get report data
$filters = [
    'status' => $status_filter,
    'department' => $department_filter,
    'batch' => $batch_filter,
    'student_id' => $student_id_filter,
    'program' => $program_filter,
    'supervisor' => $instructor_filter,
    'attendance_filter' => $attendance_filter // Fixed filter key name
];

try {
    $query_result = buildReportQuery($pdo, $active_report, $search, $filters, $sort_by, $sort_order);
    $query = $query_result['sql'];
    $params = $query_result['params'];

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $report_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $report_data = [];
    $error_message = "Error generating report: " . $e->getMessage();
}

// Handle session messages
$success_message = $_SESSION['success_message'] ?? '';
$error_message = $_SESSION['error_message'] ?? ($error_message ?? '');
unset($_SESSION['success_message'], $_SESSION['error_message']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Benadir LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/reports.css">
    <?php echo FONT_AWESOME_CSS; ?>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="admin-layout">
        <!-- Sidebar -->
        <?php include '../includes/sidebar.php'; ?>
        
        <!-- Main Content -->
        <main class="main-content">
            <!-- Header -->
            <header class="page-header">
                <div class="header-content">
                    <div class="header-left">
                        <h1 class="page-title">
                            <i class="fas fa-chart-bar"></i>
                            System Reports
                        </h1>
                        <p class="page-subtitle">Generate and export detailed system reports</p>
                    </div>
                    <div class="header-actions">
                        <button class="btn btn-secondary" onclick="window.print()">
                            <i class="fas fa-print"></i>
                            Print Report
                        </button>
                        <button class="btn btn-primary" onclick="showExportModal()">
                            <i class="fas fa-download"></i>
                            Export Report
                        </button>
                    </div>
                </div>
            </header>

            <!-- Content Area -->
            <div class="content-area">
                <!-- Alerts -->
                <?php if ($success_message): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i>
                        <span><?php echo htmlspecialchars($success_message); ?></span>
                    </div>
                <?php endif; ?>

                <?php if ($error_message): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <span><?php echo htmlspecialchars($error_message); ?></span>
                    </div>
                <?php endif; ?>

                <!-- Report Navigation -->
                
                <div class="report-tabs">
                    <a href="?report=users" class="tab-link <?php echo $active_report === 'users' ? 'active' : ''; ?>">
                        <i class="fas fa-users"></i>
                        User Reports
                    </a>
                    <a href="?report=attendance_summary" class="tab-link <?php echo $active_report === 'attendance_summary' ? 'active' : ''; ?>">
                        <i class="fas fa-calendar-check"></i>
                        Attendance Reports
                    </a>
                    <a href="?report=assessments" class="tab-link <?php echo $active_report === 'assessments' ? 'active' : ''; ?>">
                        <i class="fas fa-clipboard-list"></i>
                        Assessment Reports
                    </a>
                    <a href="?report=thesis" class="tab-link <?php echo $active_report === 'thesis' ? 'active' : ''; ?>">
                        <i class="fas fa-graduation-cap"></i>
                        Thesis Reports
                    </a>
                </div>

                <!-- Filters Section -->
                <div class="filters-section">
                    <form method="GET" class="filters-form" id="filter-form">
                        <input type="hidden" name="report" value="<?php echo htmlspecialchars($active_report); ?>">
                        
                        <div class="filters-grid">
                            <!-- Search -->
                            <div class="filter-group">
                                <label for="search">Search</label>
                                <input type="text" id="search" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search...">
                            </div>

                            <!-- Added filters for thesis reports -->
                            <?php if ($active_report === 'thesis'): ?>
                            <div class="filter-group">
                                <label for="status">Thesis Status</label>
                                <select id="status" name="status">
                                    <option value="">All Status</option>
                                    <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="under_review" <?php echo $status_filter === 'under_review' ? 'selected' : ''; ?>>Under Review</option>
                                    <option value="approved" <?php echo $status_filter === 'approved' ? 'selected' : ''; ?>>Approved</option>
                                    <option value="rejected" <?php echo $status_filter === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                                    <option value="revision_required" <?php echo $status_filter === 'revision_required' ? 'selected' : ''; ?>>Revision Required</option>
                                </select>
                            </div>
                            
                            <div class="filter-group">
                                <label for="supervisor">Supervisor</label>
                                <select id="supervisor" name="supervisor">
                                    <option value="">All Supervisors</option>
                                    <?php
                                    $supervisors = $pdo->query("SELECT DISTINCT u.id, u.full_name FROM users u JOIN thesis t ON u.id = t.supervisor_id WHERE u.role = 'instructor' ORDER BY u.full_name")->fetchAll();
                                    foreach ($supervisors as $supervisor): ?>
                                        <option value="<?php echo $supervisor['id']; ?>" <?php echo $instructor_filter == $supervisor['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($supervisor['full_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php endif; ?>

                            <!-- Added mode filter for assessments report -->
                            <?php if ($active_report === 'assessments'): ?>
                            <div class="filter-group">
                                <label for="mode">View Mode</label>
                                <select id="mode" name="mode">
                                    <option value="" <?php echo $mode === '' ? 'selected' : ''; ?>>Individual Students</option>
                                    <option value="by_batch" <?php echo $mode === 'by_batch' ? 'selected' : ''; ?>>By Batch Summary</option>
                                </select>
                            </div>
                            <?php endif; ?>

                            <?php if (in_array($active_report, ['assessments', 'attendance_summary', 'courses'])): ?>
                            <div class="filter-group">
                                <label for="batch">Batch</label>
                                <select id="batch" name="batch">
                                    <option value="">All Batches</option>
                                    <?php foreach ($batches as $batch): ?>
                                        <option value="<?php echo $batch['id']; ?>" <?php echo $batch_filter == $batch['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($batch['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php endif; ?>
                            
                            <!-- Added program filter for relevant reports -->
                            <?php if (in_array($active_report, ['assessments', 'attendance_summary'])): ?>
                            <div class="filter-group">
                                <label for="program">Program</label>
                                <select id="program" name="program">
                                    <option value="">All Programs</option>
                                    <?php foreach ($programs as $program): ?>
                                        <option value="<?php echo $program['id']; ?>" <?php echo $program_filter == $program['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($program['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php endif; ?>

                            <?php if ($active_report === 'courses' || $active_report === 'exams'): ?>
                            <!-- Department Filter -->
                            <div class="filter-group">
                                <label for="department">Department</label>
                                <select id="department" name="department">
                                    <option value="">All Departments</option>
                                    <?php foreach ($departments as $dept): ?>
                                        <option value="<?php echo $dept['id']; ?>" <?php echo $department_filter == $dept['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($dept['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php endif; ?>

                            <?php if ($active_report === 'users'): ?>
                            <!-- Role Filter -->
                            <div class="filter-group">
                                <label for="role">Role</label>
                                <select id="role" name="role">
                                    <option value="">All Roles</option>
                                    <option value="admin" <?php echo $role_filter === 'admin' ? 'selected' : ''; ?>>Admin</option>
                                    <option value="instructor" <?php echo $role_filter === 'instructor' ? 'selected' : ''; ?>>Instructor</option>
                                    <option value="student" <?php echo $role_filter === 'student' ? 'selected' : ''; ?>>Student</option>
                                </select>
                            </div>

                            <!-- Status Filter -->
                            <div class="filter-group">
                                <label for="status">Status</label>
                                <select id="status" name="status">
                                    <option value="">All Status</option>
                                    <option value="active" <?php echo $status_filter === 'active' ? 'selected' : ''; ?>>Active</option>
                                    <option value="inactive" <?php echo $status_filter === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                    <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                </select>
                            </div>
                            <?php endif; ?>

                            <!-- Enhanced date filters for thesis and attendance reports -->
                            <?php if (in_array($active_report, ['attendance_summary', 'thesis'])): ?>
                            <div class="filter-group">
                                <label for="date_from">From Date</label>
                                <input type="date" id="date_from" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>">
                            </div>
                            
                            <div class="filter-group">
                                <label for="date_to">To Date</label>
                                <input type="date" id="date_to" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>">
                            </div>
                            <?php endif; ?>

                            
                            <?php if ($active_report === 'attendance_summary'): ?>
                            <div class="filter-group">
                                <label for="batch">Batch</label>
                                <select id="batch" name="batch">
                                    <option value="">All Batches</option>
                                    <?php foreach ($batches as $batch): ?>
                                        <option value="<?php echo $batch['id']; ?>" <?php echo $batch_filter == $batch['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($batch['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="filter-group">
                                <label for="program">Program</label>
                                <select id="program" name="program">
                                    <option value="">All Programs</option>
                                    <?php foreach ($programs as $program): ?>
                                        <option value="<?php echo $program['id']; ?>" <?php echo $program_filter == $program['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($program['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="filter-group">
                                <label for="attendance_filter">Attendance Percentage</label>
                                <select id="attendance_filter" name="attendance_filter">
                                    <option value="">All Students</option>
                                    <option value="50" <?php echo $attendance_filter === '50' ? 'selected' : ''; ?>>≥ 50%</option>
                                    <option value="75" <?php echo $attendance_filter === '75' ? 'selected' : ''; ?>>≥ 75%</option>
                                    <option value="100" <?php echo $attendance_filter === '100' ? 'selected' : ''; ?>>100%</option>
                                </select>
                            </div>
                            
                            <div class="filter-group">
                                <label for="sort_by">Sort By</label>
                                <select id="sort_by" name="sort_by">
                                    <option value="student_name" <?php echo $sort_by === 'student_name' ? 'selected' : ''; ?>>Student Name</option>
                                    <option value="attendance_percentage" <?php echo $sort_by === 'attendance_percentage' ? 'selected' : ''; ?>>Attendance %</option>
                                    <option value="program_name" <?php echo $sort_by === 'program_name' ? 'selected' : ''; ?>>Program</option>
                                </select>
                            </div>
                            
                            <div class="filter-group">
                                <label for="order">Order</label>
                                <select id="order" name="order">
                                    <option value="ASC" <?php echo $order === 'ASC' ? 'selected' : ''; ?>>Ascending</option>
                                    <option value="DESC" <?php echo $order === 'DESC' ? 'selected' : ''; ?>>Descending</option>
                                </select>
                            </div>
                            <?php endif; ?>

                            <!-- Sort Options -->
                            <div class="filter-group">
                                <label for="sort_by">Sort By</label>
                                <select id="sort_by" name="sort_by">
                                    <?php if ($active_report === 'users'): ?>
                                        <option value="created_at" <?php echo $sort_by === 'created_at' ? 'selected' : ''; ?>>Created Date</option>
                                        <option value="full_name" <?php echo $sort_by === 'full_name' ? 'selected' : ''; ?>>Name</option>
                                        <option value="email" <?php echo $sort_by === 'email' ? 'selected' : ''; ?>>Email</option>
                                        <option value="role" <?php echo $sort_by === 'role' ? 'selected' : ''; ?>>Role</option>
                                    <?php elseif ($active_report === 'courses'): ?>
                                        <option value="created_at" <?php echo $sort_by === 'created_at' ? 'selected' : ''; ?>>Created Date</option>
                                        <option value="name" <?php echo $sort_by === 'name' ? 'selected' : ''; ?>>Course Name</option>
                                        <option value="enrollment_count" <?php echo $sort_by === 'enrollment_count' ? 'selected' : ''; ?>>Enrollments</option>
                                    <?php elseif ($active_report === 'departments'): ?>
                                        <option value="created_at" <?php echo $sort_by === 'created_at' ? 'selected' : ''; ?>>Created Date</option>
                                        <option value="name" <?php echo $sort_by === 'name' ? 'selected' : ''; ?>>Department Name</option>
                                        <option value="course_count" <?php echo $sort_by === 'course_count' ? 'selected' : ''; ?>>Courses</option>
                                    <!-- Removed attendance report sort options -->
                                    <!-- Added sort options for new reports -->
                                    <?php elseif ($active_report === 'assessments'): ?>
                                        <?php if ($mode === 'by_batch'): ?>
                                            <option value="batch_name" <?php echo $sort_by === 'batch_name' ? 'selected' : ''; ?>>Batch Name</option>
                                            <option value="assessment_title" <?php echo $sort_by === 'assessment_title' ? 'selected' : ''; ?>>Assessment</option>
                                            <option value="total_students" <?php echo $sort_by === 'total_students' ? 'selected' : ''; ?>>Total Students</option>
                                            <option value="passed" <?php echo $sort_by === 'passed' ? 'selected' : ''; ?>>Passed</option>
                                        <?php else: ?>
                                            <option value="student_name" <?php echo $sort_by === 'student_name' ? 'selected' : ''; ?>>Student Name</option>
                                            <option value="assessment_title" <?php echo $sort_by === 'assessment_title' ? 'selected' : ''; ?>>Assessment</option>
                                            <option value="marks_obtained" <?php echo $sort_by === 'marks_obtained' ? 'selected' : ''; ?>>Marks</option>
                                            <option value="result" <?php echo $sort_by === 'result' ? 'selected' : ''; ?>>Result</option>
                                        <?php endif; ?>
                                    <?php elseif ($active_report === 'attendance_summary'): ?>
                                        <option value="student_name" <?php echo $sort_by === 'student_name' ? 'selected' : ''; ?>>Student Name</option>
                                        <option value="attendance_percentage" <?php echo $sort_by === 'attendance_percentage' ? 'selected' : ''; ?>>Attendance %</option>

                                    <?php elseif ($active_report === 'exams'): ?>
                                        <option value="date" <?php echo $sort_by === 'date' ? 'selected' : ''; ?>>Date</option>
                                        <option value="title" <?php echo $sort_by === 'title' ? 'selected' : ''; ?>>Title</option>
                                        <option value="course_name" <?php echo $sort_by === 'course_name' ? 'selected' : ''; ?>>Course</option>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <div class="filter-group">
                                <label for="sort_order">Order</label>
                                <select id="sort_order" name="sort_order">
                                    <option value="DESC" <?php echo $sort_order === 'DESC' ? 'selected' : ''; ?>>Descending</option>
                                    <option value="ASC" <?php echo $sort_order === 'ASC' ? 'selected' : ''; ?>>Ascending</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="filters-actions">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-filter"></i>
                                Apply Filters
                            </button>
                            <a href="?report=<?php echo htmlspecialchars($active_report); ?>" class="btn btn-secondary">
                                <i class="fas fa-times"></i>
                                Clear Filters
                            </a>
                        </div>
                    </form>
                </div>

                <!-- Report Table -->
                <div class="report-table-section">
                    <div class="table-header">
                        <h3 class="table-title">
                            <?php 
                            $titles = [
                                'users' => 'Users Report',
                                'instructors' => 'Instructor Reports',
                                'courses' => 'Courses Report', 
                                'batches' => 'Batch Reports',
                                'departments' => 'Departments Report',
                                'attendance_summary' => 'Attendance Summary Report',
                                'assessments' => 'Assessments Report',
                                'thesis' => 'Thesis Reports',
                                'student_profile' => 'Student Profile Report',
                                'exams' => 'Exams Report'
                            ];
                            echo $titles[$active_report] ?? 'Report';
                            ?>
                        </h3>
                        <div class="table-meta">
                            <span class="record-count"><?php echo count($report_data); ?> records found</span>
                            <span class="generated-time">Generated: <?php echo date('M j, Y g:i A'); ?></span>
                        </div>
                    </div>

                    <div class="table-container">
                        <!-- Added responsive wrapper for all tables -->
                        <div class="table-responsive" style="overflow-x: auto;">
                            <table class="table table-striped">
                                <?php if ($active_report === 'attendance_summary'): ?>
                                <!-- Simplified attendance table headers -->
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Student Name</th>
                                        <th>Program</th>
                                        <th>Attendance %</th>
                                    </tr>
                                </thead>
                                <?php elseif ($active_report === 'thesis'): ?>
                                    <!-- Simplified thesis table columns with View Details button -->
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Student Name</th>
                                            <th>Thesis Title</th>
                                            <th>Status</th>
                                            <th>Supervisor</th>
                                            <th>Submission Date</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                <?php elseif ($active_report === 'users'): ?>
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Full Name</th>
                                            <th>Email</th>
                                            <th>Role</th>
                                            <th>Status</th>
                                            <th>Created Date</th>
                                        </tr>
                                    </thead>
                                <!-- Added instructor reports table rows -->
                                <?php elseif ($active_report === 'instructors'): ?>
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Instructor Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Total Batches</th>
                                            <th>Total Students</th>
                                            <th>Total Courses</th>
                                            <th>Courses & Batches</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                <?php elseif ($active_report === 'courses'): ?>
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Course Name</th>
                                            <th>Department</th>
                                            <th>Enrollments</th>
                                            <th>Created Date</th>
                                        </tr>
                                    </thead>
                                <!-- Added batch reports table headers -->
                                <?php elseif ($active_report === 'batches'): ?>
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Batch Name</th>
                                            <th>Program</th>
                                            <th>Department</th>
                                            <th>Year</th>
                                            <th>Students</th>
                                            <th>Courses</th>
                                            <th>Instructors</th>
                                            <th>Avg Attendance</th>
                                            <th>Thesis Submissions</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                <?php elseif ($active_report === 'departments'): ?>
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Department Name</th>
                                            <th>Courses</th>
                                            <th>Users</th>
                                            <th>Created Date</th>
                                        </tr>
                                    </thead>
                                <?php elseif ($active_report === 'assessments'): ?>
                                    <thead>
                                        <tr>
                                            <?php if ($mode === 'by_batch'): ?>
                                                <th>Batch</th>
                                                <th>Assessment</th>
                                                <th>Type</th>
                                                <th>Total Students</th>
                                                <th>Passed</th>
                                                <th>Failed</th>
                                                <th>Average Marks</th>
                                                <th>Total Marks</th>
                                                <th>Pass Marks</th>
                                            <?php else: ?>
                                                <th>Student Name</th>
                                                <th>Assessment Name</th>
                                                <th>Marks/Grades</th>
                                                <th>Status</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                <?php elseif ($active_report === 'exams'): ?>
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Exam Title</th>
                                            <th>Course</th>
                                            <th>Department</th>
                                            <th>Date</th>
                                            <th>Total Marks</th>
                                            <th>Pass Marks</th>
                                        </tr>
                                    </thead>
                                <?php endif; ?>
                                <tbody>
                                    <?php foreach ($report_data as $row): ?>
                                        <tr>
                                            <?php if ($active_report === 'users'): ?>
                                                <td><?php echo htmlspecialchars($row['id']); ?></td>
                                                <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                                <td><span class="badge badge-<?php echo $row['role']; ?>"><?php echo ucfirst($row['role']); ?></span></td>
                                                <td><span class="badge badge-<?php echo $row['status']; ?>"><?php echo ucfirst($row['status']); ?></span></td>
                                                <td><?php echo date('M j, Y', strtotime($row['created_at'])); ?></td>
                                            <!-- Added instructor reports table rows -->
                                            <?php elseif ($active_report === 'instructors'): ?>
                                                <td><?php echo htmlspecialchars($row['id']); ?></td>
                                                <td><?php echo htmlspecialchars($row['instructor_name']); ?></td>
                                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                                <td><?php echo htmlspecialchars($row['phone'] ?? 'N/A'); ?></td>
                                                <td><span class="badge badge-info"><?php echo $row['total_batches']; ?></span></td>
                                                <td><span class="badge badge-success"><?php echo $row['total_students']; ?></span></td>
                                                <td><span class="badge badge-primary"><?php echo $row['total_courses']; ?></span></td>
                                                <td class="text-sm"><?php echo htmlspecialchars($row['courses_batches'] ?? 'No assignments'); ?></td>
                                                <td><span class="badge badge-<?php echo $row['status']; ?>"><?php echo ucfirst($row['status']); ?></span></td>
                                            <?php elseif ($active_report === 'courses'): ?>
                                                <td><?php echo htmlspecialchars($row['id']); ?></td>
                                                <td><?php echo htmlspecialchars($row['name']); ?></td>
                                                <td><?php echo htmlspecialchars($row['department_name'] ?? 'N/A'); ?></td>
                                                <td><span class="badge badge-info"><?php echo $row['enrollment_count']; ?></span></td>
                                                <td><?php echo date('M j, Y', strtotime($row['created_at'] ?? 'now')); ?></td>
                                            <!-- Added batch reports table rows -->
                                            <?php elseif ($active_report === 'batches'): ?>
                                                <td><?php echo htmlspecialchars($row['id']); ?></td>
                                                <td><?php echo htmlspecialchars($row['batch_name']); ?></td>
                                                <td><?php echo htmlspecialchars($row['program_name'] ?? 'N/A'); ?></td>
                                                <td><?php echo htmlspecialchars($row['department_name'] ?? 'N/A'); ?></td>
                                                <td><?php echo htmlspecialchars($row['year']); ?></td>
                                                <td><span class="badge badge-success"><?php echo $row['total_students']; ?></span></td>
                                                <td><span class="badge badge-primary"><?php echo $row['total_courses']; ?></span></td>
                                                <td><span class="badge badge-info"><?php echo $row['total_instructors']; ?></span></td>
                                                <td>
                                                    <?php 
                                                    $attendance = $row['avg_attendance_percentage'] ?? 0;
                                                    $badge_class = $attendance >= 80 ? 'success' : ($attendance >= 60 ? 'warning' : 'danger');
                                                    ?>
                                                    <span class="badge badge-<?php echo $badge_class; ?>"><?php echo number_format($attendance, 1); ?>%</span>
                                                </td>
                                                <td><span class="badge badge-secondary"><?php echo $row['thesis_submissions']; ?></span></td>
                                                <td><span class="badge badge-<?php echo $row['status']; ?>"><?php echo ucfirst($row['status']); ?></span></td>
                                            <?php elseif ($active_report === 'departments'): ?>
                                                <td><?php echo htmlspecialchars($row['id']); ?></td>
                                                <td><?php echo htmlspecialchars($row['name']); ?></td>
                                                <td><span class="badge badge-info"><?php echo $row['course_count']; ?></span></td>
                                                <td><span class="badge badge-success"><?php echo $row['user_count']; ?></span></td>
                                                <td><?php echo date('M j, Y', strtotime($row['created_at'])); ?></td>
                                            <?php elseif ($active_report === 'assessments'): ?>
                                                <?php if ($mode === 'by_batch'): ?>
                                                    <td><?php echo htmlspecialchars($row['batch_name']); ?></td>
                                                    <td><?php echo htmlspecialchars($row['assessment_title']); ?></td>
                                                    <td><span class="badge badge-secondary"><?php echo ucfirst($row['assessment_type']); ?></span></td>
                                                    <td><span class="badge badge-info"><?php echo $row['total_students']; ?></span></td>
                                                    <td><span class="badge badge-success"><?php echo $row['passed']; ?></span></td>
                                                    <td><span class="badge badge-danger"><?php echo $row['failed']; ?></span></td>
                                                    <td><?php echo $row['average_marks']; ?></td>
                                                    <td><?php echo $row['total_marks']; ?></td>
                                                    <td><?php echo $row['pass_marks']; ?></td>
                                                <?php else: ?>
                                                    <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                                                    <td><?php echo htmlspecialchars($row['assessment_title']); ?></td>
                                                    <td><?php echo $row['marks_obtained'] . '/' . $row['total_marks']; ?></td>
                                                    <td><span class="badge badge-<?php echo $row['result'] === 'Pass' ? 'success' : 'danger'; ?>"><?php echo $row['result']; ?></span></td>
                                                <?php endif; ?>
                                            <?php elseif ($active_report === 'attendance_summary'): ?>
                                                <!-- Updated attendance table data display -->
                                                <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                                                <td><?php echo htmlspecialchars($row['program_name']); ?></td>
                                                <td>
                                                    <?php 
                                                    $percentage = $row['attendance_percentage'];
                                                    $badge_class = $percentage >= 75 ? 'success' : ($percentage >= 50 ? 'warning' : 'danger');
                                                    ?>
                                                    <span class="badge badge-<?php echo $badge_class; ?>"><?php echo $percentage; ?>%</span>
                                                </td>
                                            <?php elseif ($active_report === 'thesis'): ?>
                                                <!-- Updated thesis table with View Details button -->
                                                <td><?php echo htmlspecialchars($row['id']); ?></td>
                                                <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                                                <td class="text-sm"><?php echo htmlspecialchars($row['thesis_title']); ?></td>
                                                <td>
                                                    <?php 
                                                    $status_colors = [
                                                        'pending' => 'warning',
                                                        'under_review' => 'info',
                                                        'approved' => 'success',
                                                        'rejected' => 'danger',
                                                        'revision_required' => 'secondary'
                                                    ];
                                                    $color = $status_colors[$row['status']] ?? 'secondary';
                                                    ?>
                                                    <span class="badge badge-<?php echo $color; ?>"><?php echo ucwords(str_replace('_', ' ', $row['status'])); ?></span>
                                                </td>
                                                <td><?php echo htmlspecialchars($row['supervisor_name'] ?? 'Not Assigned'); ?></td>
                                                <td><?php echo date('M j, Y', strtotime($row['submission_date'])); ?></td>
                                                <td>
                                                    <button class="btn btn-sm btn-info" onclick="viewThesisDetails(<?php echo htmlspecialchars(json_encode($row)); ?>)">
                                                        View Details
                                                    </button>
                                                </td>
                                            <?php elseif ($active_report === 'exams'): ?>
                                                <td><?php echo htmlspecialchars($row['id']); ?></td>
                                                <td><?php echo htmlspecialchars($row['title']); ?></td>
                                                <td><?php echo htmlspecialchars($row['course_name']); ?></td>
                                                <td><?php echo htmlspecialchars($row['department_name'] ?? 'N/A'); ?></td>
                                                <td><?php echo date('M j, Y', strtotime($row['date'])); ?></td>
                                                <td><?php echo htmlspecialchars($row['total_marks']); ?></td>
                                                <td><?php echo htmlspecialchars($row['pass_marks']); ?></td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

</div>

<!-- Added thesis details modal -->
<div class="modal fade" id="thesisDetailsModal" tabindex="-1" role="dialog" aria-labelledby="thesisDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="thesisDetailsModalLabel">Thesis Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Student ID:</strong> <span id="modal-student-id"></span></p>
                        <p><strong>Department:</strong> <span id="modal-department"></span></p>
                        <p><strong>Program:</strong> <span id="modal-program"></span></p>
                        <p><strong>Batch:</strong> <span id="modal-batch"></span></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>File Type:</strong> <span id="modal-file-type"></span></p>
                        <p><strong>File Size:</strong> <span id="modal-file-size"></span> KB</p>
                        <p><strong>Days Since Submission:</strong> <span id="modal-days-since"></span></p>
                        <p><strong>Submission Status:</strong> <span id="modal-submission-status"></span></p>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
function viewThesisDetails(thesis) {
    document.getElementById('modal-student-id').textContent = thesis.student_id || '';
    document.getElementById('modal-department').textContent = thesis.department_name || '';
    document.getElementById('modal-program').textContent = thesis.program_name || '';
    document.getElementById('modal-batch').textContent = thesis.batch_name || '';
    document.getElementById('modal-file-type').textContent = thesis.file_type ? thesis.file_type.toUpperCase() : '';
    document.getElementById('modal-file-size').textContent = thesis.file_size ? (thesis.file_size / 1024).toFixed(1) : '';
    document.getElementById('modal-days-since').textContent = thesis.days_since_submission || '';
    document.getElementById('modal-submission-status').textContent = thesis.submission_status || '';
    
    $('#thesisDetailsModal').modal('show');
}

document.addEventListener('DOMContentLoaded', function() {
    const filterForm = document.getElementById('filter-form');
    if (filterForm) {
        filterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const params = new URLSearchParams();
            
            for (let [key, value] of formData.entries()) {
                if (value) {
                    params.append(key, value);
                }
            }
            
            window.location.href = '?' + params.toString();
        });
    }
});
</script>

    <!-- Export Modal -->
    <div class="modal" id="exportModal">
        <div class="modal-content">
            <span class="close-button" onclick="closeExportModal()">&times;</span>
            <h2>Export Report</h2>
            <p>Choose the format to export the current report:</p>
            <form method="POST">
                <input type="hidden" name="export_report" value="<?php echo htmlspecialchars($active_report); ?>">
                <div class="form-group">
                    <label for="export_type">Export Type:</label>
                    <select id="export_type" name="export_type">
                        <option value="csv">CSV (Comma Separated Values)</option>
                        <option value="pdf">PDF (Portable Document Format)</option>
                    </select>
                </div>
                <button type="submit" name="export_action" class="btn btn-primary">Export</button>
            </form>
        </div>
    </div>

    <script>
        function showExportModal() {
            document.getElementById('exportModal').style.display = 'block';
        }

        function closeExportModal() {
            document.getElementById('exportModal').style.display = 'none';
        }

        // Close modal if clicked outside the modal
        window.onclick = function(event) {
            var modal = document.getElementById('exportModal');
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>

    <!-- Fix print functionality to include all data -->
    <!-- Restored original CSS styles and improved print functionality -->
    <style>
        .report-container {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .report-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            text-align: center;
        }
        
        .report-tabs {
            display: flex;
            background: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
        }
        
        .tab-btn {
            flex: 1;
            padding: 15px 20px;
            border: none;
            background: transparent;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        
        .tab-btn.active {
            background: #007bff;
            color: white;
        }
        
        .tab-btn:hover:not(.active) {
            background: #e9ecef;
        }
        
        .filters-section {
            padding: 20px;
            background: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
        }
        
        .filter-row {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
            flex-wrap: wrap;
        }
        
        .filter-group {
            flex: 1;
            min-width: 200px;
        }
        
        .filter-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: #495057;
        }
        
        .form-control {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            font-size: 14px;
        }
        
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: #007bff;
            color: white;
        }
        
        .btn-primary:hover {
            background: #0056b3;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #545b62;
        }
        
        .btn-success {
            background: #28a745;
            color: white;
        }
        
        .btn-success:hover {
            background: #1e7e34;
        }
        
        .report-content {
            padding: 20px;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .table th,
        .table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #dee2e6;
        }
        
        .table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #495057;
        }
        
        .table tbody tr:hover {
            background: #f8f9fa;
        }
        
        .badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .badge-admin {
            background: #dc3545;
            color: white;
        }
        
        .badge-instructor {
            background: #007bff;
            color: white;
        }
        
        .badge-student {
            background: #28a745;
            color: white;
        }
        
        .status-badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-active {
            background: #d4edda;
            color: #155724;
        }
        
        .status-inactive {
            background: #f8d7da;
            color: #721c24;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }
        
        .pagination a {
            padding: 8px 12px;
            margin: 0 4px;
            text-decoration: none;
            border: 1px solid #dee2e6;
            color: #007bff;
            border-radius: 4px;
        }
        
        .pagination a:hover {
            background: #e9ecef;
        }
        
        .pagination .current {
            background: #007bff;
            color: white;
            border-color: #007bff;
        }
        
        @media print {
            .no-print { 
                display: none !important; 
            }
            
            .print-only { 
                display: block !important; 
            }
            
            body { 
                font-size: 12px;
                margin: 0;
                padding: 0;
            }
            
            .report-container {
                box-shadow: none;
                border-radius: 0;
            }
            
            .table { 
                width: 100%; 
                border-collapse: collapse;
                page-break-inside: auto;
            }
            
            .table th, 
            .table td { 
                border: 1px solid #000; 
                padding: 6px; 
                text-align: left;
                font-size: 11px;
                page-break-inside: avoid;
            }
            
            .table th {
                background: #f0f0f0 !important;
                font-weight: bold;
            }
            
            .header-actions, 
            .filters-section, 
            .pagination,
            .report-tabs { 
                display: none !important; 
            }
            
            .report-content { 
                margin: 0; 
                padding: 10px;
            }
            
            .report-header {
                background: none !important;
                color: #000 !important;
                padding: 10px;
                border-bottom: 2px solid #000;
            }
            
            @page {
                margin: 0.5in;
                size: A4;
            }
        }

/* Added styles for the new student profile design */
.student-profile-container {
    background: #fff;
    border-radius: 8px;
    padding: 20px;
}

.student-profile-header {
    display: flex;
    justify-content: between;
    align-items: center;
    border-bottom: 2px solid #e9ecef;
    padding-bottom: 15px;
}

.profile-section {
    border: 1px solid #e9ecef;
    border-radius: 6px;
    overflow: hidden;
}

.section-header {
    background: #f8f9fa;
    padding: 15px 20px;
    cursor: pointer;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #e9ecef;
}

.section-header:hover {
    background: #e9ecef;
}

.section-content {
    padding: 20px;
}

.section-content.collapsed {
    display: none;
}

.toggle-icon {
    transition: transform 0.3s ease;
}

.toggle-icon.rotated {
    transform: rotate(180deg);
}

.info-item {
    margin-bottom: 10px;
    padding: 8px 0;
    border-bottom: 1px solid #f8f9fa;
}

.info-item:last-child {
    border-bottom: none;
}

.stat-card {
    text-align: center;
    padding: 20px;
    background: #f8f9fa;
    border-radius: 6px;
    margin-bottom: 15px;
}

.stat-value {
    font-size: 2rem;
    font-weight: bold;
    margin-bottom: 5px;
}

.stat-label {
    color: #6c757d;
    font-size: 0.9rem;
}

.search-prompt, .no-results {
    background: #f8f9fa;
    border-radius: 8px;
    margin: 20px 0;
}

@media (max-width: 768px) {
    .student-profile-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
    }
    
    .stat-card {
        margin-bottom: 10px;
    }
}
</style>

<script>
function toggleSection(sectionId) {
    const content = document.getElementById(sectionId);
    const icon = content.previousElementSibling.querySelector('.toggle-icon');
    
    if (content.classList.contains('collapsed')) {
        content.classList.remove('collapsed');
        icon.classList.remove('rotated');
    } else {
        content.classList.add('collapsed');
        icon.classList.add('rotated');
        icon.classList.add('rotated');
    }
}

function exportStudentProfile() {
    // Simple export functionality - could be enhanced with actual PDF generation
    window.print();
}

// Initialize all sections as expanded
document.addEventListener('DOMContentLoaded', function() {
    const sections = document.querySelectorAll('.section-content');
    sections.forEach(section => {
        section.classList.remove('collapsed');
    });
});
</script>

    <!-- Removed custom dark mode styles and reverted to original styling -->
    <script src="../assets/js/theme.js"></script>
    <script src="../assets/js/reports.js"></script>
    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
