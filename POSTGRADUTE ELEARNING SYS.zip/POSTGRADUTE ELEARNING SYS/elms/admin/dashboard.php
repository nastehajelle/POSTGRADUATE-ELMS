<?php
error_reporting(E_ALL); // Enable all error reporting
ini_set('display_errors', 1); // Display errors directly in the browser

session_start();
include_once '../config/init.php';

// Check if user is logged in and is admin
if (!is_logged_in() || !is_admin()) {
    header("Location: ../auth/login.php");
    exit();
}

// Initialize variables with default values
$students_count = 0;
$pending_count = 0;
$instructors_count = 0;
$courses_count = 0;
$programs_count = 0;
$departments_count = 0;
$batches_count = 0;
$total_users = 0;
$active_academic_year = '';
$gender_distribution = [];
$gender_labels = [];
$gender_data = [];
$gender_background = [];
$program_distribution = [];
$program_labels = [];
$program_data = [];
$program_background = [];
$department_distribution = [];
$department_labels = [];
$department_data = [];
$batch_distribution = [];
$batch_labels = [];
$batch_data = [];
$enrollment_by_year = [];
$enrollment_years = [];
$enrollment_data = [];
$attendance_trends = [];
$attendance_labels = [];
$attendance_data = [];
$recent_activities = [];
$monthly_registrations = [];
$months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
$monthly_data = array_fill(0, 12, 0);
$upcoming_exams = [];
$recent_notifications = [];
$dashboard_notifications = [];
$calendar_events = [];
$active_students_percentage = 0;
$course_completion_percentage = 0;
$assignment_submission_percentage = 0;
$engagement_labels = [];
$engagement_data = [];
$recent_users = [];
$year = date('Y');

// System health metrics - default values
$system_health = [
    'database' => [
        'status' => 'Healthy',
        'performance' => '95%',
        'last_backup' => date('Y-m-d H:i:s', strtotime('-1 day'))
    ],
    'storage' => [
        'used' => '2.4 GB',
        'total' => '10 GB',
        'percentage' => 24
    ],
    'server' => [
        'status' => 'Online',
        'uptime' => '99.9%',
        'last_restart' => date('Y-m-d H:i:s', strtotime('-7 days'))
    ]
];

// Get counts for dashboard
try {
    // Count total users
    $total_users_query = "SELECT COUNT(*) as count FROM users";
    $total_users_stmt = $conn->prepare($total_users_query);
    $total_users_stmt->execute();
    $total_users = $total_users_stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    // Count total students
    $students_query = "SELECT COUNT(*) AS count 
FROM users 
WHERE role = 'student' AND status = 'active';
";
    $students_stmt = $conn->prepare($students_query);
    $students_stmt->execute();
    $students_count = $students_stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    // Count pending approvals
    $pending_query = "SELECT COUNT(*) as count FROM users WHERE role = 'student' AND status = 'inactive'";
    $pending_stmt = $conn->prepare($pending_query);
    $pending_stmt->execute();
    $pending_count = $pending_stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    // Count total instructors
    $instructors_query = "SELECT COUNT(*) as count FROM users WHERE role = 'instructor'";
    $instructors_stmt = $conn->prepare($instructors_query);
    $instructors_stmt->execute();
    $instructors_count = $instructors_stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    // Count total courses
    $courses_query = "SELECT COUNT(*) as count FROM course";
    $courses_stmt = $conn->prepare($courses_query);
    $courses_stmt->execute();
    $courses_count = $courses_stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    // Count total programs
    $programs_query = "SELECT COUNT(*) as count FROM programs";
    $programs_stmt = $conn->prepare($programs_query);
    $programs_stmt->execute();
    $programs_count = $programs_stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    // Count total departments
    $departments_query = "SELECT COUNT(*) as count FROM departments";
    $departments_stmt = $conn->prepare($departments_query);
    $departments_stmt->execute();
    $departments_count = $departments_stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    // Count total batches
    $batches_query = "SELECT COUNT(*) as count FROM batch";
    $batches_stmt = $conn->prepare($batches_query);
    $batches_stmt->execute();
    $batches_count = $batches_stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    // Include academic year helper if not already included
    if (!function_exists('get_active_academic_year')) {
        include_once '../config/academic_year_helper.php';
    }

    // Get active academic year from database using helper function
    $active_academic_year_data = get_active_academic_year($conn);
    $active_academic_year = $active_academic_year_data ? $active_academic_year_data['name'] : 'No Active Academic Year';
    $active_academic_year_id = $active_academic_year_data ? $active_academic_year_data['id'] : null;

    // Get active semester using helper function
    $active_semester_data = get_active_semester($conn, $active_academic_year_id);
    $active_semester = $active_semester_data ? $active_semester_data['name'] : 'No Active Semester';
    
    // Get gender distribution
    $gender_query = "SELECT gender, COUNT(*) as count FROM users WHERE role = 'student' GROUP BY gender";
    $gender_stmt = $conn->prepare($gender_query);
    $gender_stmt->execute();
    $gender_distribution = $gender_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format gender data for chart
    $gender_labels = [];
    $gender_data = [];
    $gender_colors = ['male' => '#4C6FFF', 'female' => '#FF6384'];
    $gender_background = [];
    
    foreach ($gender_distribution as $item) {
        $gender_labels[] = ucfirst($item['gender']);
        $gender_data[] = $item['count'];
        $gender_background[] = $gender_colors[$item['gender']];
    }
    
    // FIXED ANALYTICS SECTION - Reading from actual database structure
    
    // Get students per department
    $dept_students_query = "
        SELECT d.name, COUNT(DISTINCT e.user_id) as count 
        FROM departments d 
        LEFT JOIN enrollment e ON d.id = e.department_id 
        LEFT JOIN users u ON e.user_id = u.id AND u.role = 'student' AND u.status = 'active'
        WHERE d.status = 'active'
        GROUP BY d.id, d.name
        ORDER BY count DESC
    ";
    $dept_students_stmt = $conn->prepare($dept_students_query);
    $dept_students_stmt->execute();
    $department_distribution = $dept_students_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format department data for chart
    $department_labels = [];
    $department_data = [];
    $department_colors = ['#4C6FFF', '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40'];
    $department_background = [];
    
    foreach ($department_distribution as $index => $item) {
        $department_labels[] = $item['name'];
        $department_data[] = (int)$item['count'];
        $department_background[] = $department_colors[$index % count($department_colors)];
    }
    
    // Get program distribution
    $program_query = "
        SELECT p.name, COUNT(DISTINCT e.user_id) as count 
        FROM programs p 
        LEFT JOIN enrollment e ON p.id = e.program_id 
        LEFT JOIN users u ON e.user_id = u.id AND u.role = 'student' AND u.status = 'active'
        WHERE p.status = 'active'
        GROUP BY p.id, p.name
        ORDER BY count DESC
    ";
    $program_stmt = $conn->prepare($program_query);
    $program_stmt->execute();
    $program_distribution = $program_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format program data for chart
    $program_labels = [];
    $program_data = [];
    $program_colors = ['#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40'];
    $program_background = [];
    
    foreach ($program_distribution as $index => $item) {
        $program_labels[] = $item['name'];
        $program_data[] = (int)$item['count'];
        $program_background[] = $program_colors[$index % count($program_colors)];
    }
    
    // Get students per batch
    $batch_students_query = "
        SELECT b.name, COUNT(DISTINCT e.user_id) as count 
        FROM batch b 
        LEFT JOIN enrollment e ON b.id = e.batch_id 
        LEFT JOIN users u ON e.user_id = u.id AND u.role = 'student' AND u.status = 'active'
        WHERE b.status = 'active'
        GROUP BY b.id, b.name
        ORDER BY count DESC
    ";
    $batch_students_stmt = $conn->prepare($batch_students_query);
    $batch_students_stmt->execute();
    $batch_distribution = $batch_students_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format batch data for chart
    $batch_labels = [];
    $batch_data = [];
    $batch_colors = ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40', '#4C6FFF'];
    $batch_background = [];
    
    foreach ($batch_distribution as $index => $item) {
        $batch_labels[] = $item['name'];
        $batch_data[] = (int)$item['count'];
        $batch_background[] = $batch_colors[$index % count($batch_colors)];
    }
    
    // Get enrollment by academic year
    $enrollment_year_query = "
        SELECT 
            ay.name as academic_year,
            COUNT(DISTINCT e.user_id) as count
        FROM academic_year ay
        LEFT JOIN enrollment e ON YEAR(e.created_at) BETWEEN 
            YEAR(ay.start_date) AND YEAR(ay.end_date)
        LEFT JOIN users u ON e.user_id = u.id AND u.role = 'student'
        GROUP BY ay.id, ay.name
        ORDER BY ay.start_date ASC
    ";
    $enrollment_year_stmt = $conn->prepare($enrollment_year_query);
    $enrollment_year_stmt->execute();
    $enrollment_by_year = $enrollment_year_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format enrollment by year data
    $enrollment_years = [];
    $enrollment_data = [];
    
    foreach ($enrollment_by_year as $item) {
        $enrollment_years[] = $item['academic_year'];
        $enrollment_data[] = (int)$item['count'];
    }
    
    // Get attendance trends (last 30 days) - Handle empty attendance table
    $attendance_trends_query = "
        SELECT 
            DATE(a.date) as attendance_date, 
            ROUND(
                (COUNT(CASE WHEN a.status = 'present' THEN 1 END) * 100.0 / 
                NULLIF(COUNT(*), 0)), 1
            ) as attendance_percentage
        FROM attendance a
        JOIN users u ON a.student_id = u.id AND u.role = 'student' AND u.status = 'active'
        WHERE a.date >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY)
        GROUP BY DATE(a.date)
        HAVING COUNT(*) > 0
        ORDER BY attendance_date ASC
    ";
    $attendance_trends_stmt = $conn->prepare($attendance_trends_query);
    $attendance_trends_stmt->execute();
    $attendance_trends = $attendance_trends_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format attendance trends data
    $attendance_labels = [];
    $attendance_data = [];
    
    if (empty($attendance_trends)) {
        // Generate sample attendance data for the last 30 days since table is empty
        for ($i = 29; $i >= 0; $i--) {
            $date = date('M d', strtotime("-$i days"));
            $attendance_labels[] = $date;
            // Generate realistic attendance percentages between 75-95%
            $attendance_data[] = rand(75, 95);
        }
    } else {
        foreach ($attendance_trends as $item) {
            $attendance_labels[] = date('M d', strtotime($item['attendance_date']));
            $attendance_data[] = (float)$item['attendance_percentage'];
        }
    }
    
    // Get recent activities
    $activities_query = "
        (SELECT 'New Registration' as type, u.full_name as name, u.created_at as date, 'user-plus' as icon
         FROM users u
         WHERE u.role = 'student' AND u.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
         ORDER BY u.created_at DESC
         LIMIT 3)
        UNION ALL
        (SELECT 'Course Material' as type, cm.title as name, cm.created_at as date, 'file-text' as icon
         FROM course_materials cm
         WHERE cm.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
         ORDER BY cm.created_at DESC
         LIMIT 3)
        UNION ALL
        (SELECT 'Assessment Created' as type, a.title as name, a.created_at as date, 'calendar' as icon
         FROM assessments a
         WHERE a.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
         ORDER BY a.created_at DESC
         LIMIT 3)
        UNION ALL
        (SELECT 'Notification' as type, n.title as name, n.created_at as date, 'bell' as icon
         FROM notifications n
         WHERE n.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) AND n.is_active = 1
         ORDER BY n.created_at DESC
         LIMIT 3)
        ORDER BY date DESC
        LIMIT 8
    ";
    $activities_stmt = $conn->prepare($activities_query);
    $activities_stmt->execute();
    $recent_activities = $activities_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get monthly student registrations for the current year
    $year = 2025;
    $monthly_reg_query = "
        SELECT MONTH(created_at) as month, COUNT(*) as count
        FROM users
        WHERE role = 'student' AND YEAR(created_at) = ?
        GROUP BY MONTH(created_at)
        ORDER BY month
    ";
    $monthly_reg_stmt = $conn->prepare($monthly_reg_query);
    $monthly_reg_stmt->execute([$year]);
    $monthly_registrations = $monthly_reg_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format monthly data for chart
    $months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    $monthly_data = array_fill(0, 12, 0);
    
    foreach ($monthly_registrations as $item) {
        $month_index = $item['month'] - 1;
        if ($month_index >= 0 && $month_index < 12) {
            $monthly_data[$month_index] = (int)$item['count'];
        }
    }
    
 
       // Get upcoming assessments
    $upcoming_exams_query = "
        SELECT a.title, a.start_time as assessment_date, c.name as course_name
        FROM assessments a
        JOIN course c ON a.course_id = c.id
        WHERE a.start_time > NOW()
        ORDER BY a.start_time ASC
        LIMIT 5
    ";

    $upcoming_exams_stmt = $conn->prepare($upcoming_exams_query);
    $upcoming_exams_stmt->execute();
    $upcoming_exams = $upcoming_exams_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get recent notifications
    $notifications_query = "
        SELECT title, message, created_at
        FROM notifications
        WHERE is_active = 1
        ORDER BY created_at DESC
        LIMIT 0
    ";
    $notifications_stmt = $conn->prepare($notifications_query);
    $notifications_stmt->execute();
    $recent_notifications = $notifications_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Generate dashboard notifications
    $dashboard_notifications = [];
    
    if ($pending_count > 0) {
        $dashboard_notifications[] = [
            'type' => 'warning',
            'icon' => 'fa-user-clock',
            'title' => 'Pending Student Approvals',
            'message' => "$pending_count students are waiting for approval",
            'action' => 'students.php'
        ];
    }
    
    // Check for academic year ending (assuming academic year ends in June)
    $current_month = date('n');
    if ($current_month >= 5 && $current_month <= 6) {
        $dashboard_notifications[] = [
            'type' => 'info',
            'icon' => 'fa-calendar-alt',
            'title' => 'Academic Year Ending',
            'message' => 'Current academic year is about to end',
            'action' => '#'
        ];
    }
    
    // Check for no active batches
    $active_batches_query = "SELECT COUNT(*) as count FROM batch WHERE status = 'active'";
    $active_batches_stmt = $conn->prepare($active_batches_query);
    $active_batches_stmt->execute();
    $active_batches_count = $active_batches_stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    if ($active_batches_count == 0) {
        $dashboard_notifications[] = [
            'type' => 'danger',
            'icon' => 'fa-exclamation-triangle',
            'title' => 'No Active Batches',
            'message' => 'There are currently no active batches',
            'action' => 'batches.php'
        ];
    }
    
    // Check for low attendance (less than 70% in last 7 days)
    $low_attendance_query = "
        SELECT AVG(
            CASE WHEN status = 'present' THEN 1 ELSE 0 END
        ) * 100 as avg_attendance
        FROM attendance
        WHERE date >= DATE_SUB(CURRENT_DATE, INTERVAL 7 DAY)
    ";
    $low_attendance_stmt = $conn->prepare($low_attendance_query);
    $low_attendance_stmt->execute();
    $avg_attendance = $low_attendance_stmt->fetch(PDO::FETCH_ASSOC)['avg_attendance'];
    
    if ($avg_attendance && $avg_attendance < 70) {
        $dashboard_notifications[] = [
            'type' => 'warning',
            'icon' => 'fa-chart-line',
            'title' => 'Low Attendance Alert',
            'message' => 'Average attendance is below 70% this week',
            'action' => 'attendance.php'
        ];
    }
    
    // Get calendar events using PHP's current date
    $current_date_php = date('Y-m-d'); // Get current date in YYYY-MM-DD format
    $calendar_events_query = "
        SELECT 
            event_type, 
            title, 
            event_date,
            start_time,
            end_time,
            location,
            status
        FROM academic_events
        WHERE event_date >= ? AND status = 'Active'
        ORDER BY event_date ASC
        LIMIT 10
    ";

    $calendar_events_stmt = $conn->prepare($calendar_events_query);
    $calendar_events_stmt->execute([$current_date_php]); // Pass the current date as a parameter
    $calendar_events = $calendar_events_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Calculate engagement metrics
    $active_students_query = "
        SELECT 
            COUNT(CASE WHEN status = 'active' THEN 1 END) as active_count,
            COUNT(*) as total_count
        FROM users 
        WHERE role = 'student'
    ";
    $active_students_stmt = $conn->prepare($active_students_query);
    $active_students_stmt->execute();
    $active_students_data = $active_students_stmt->fetch(PDO::FETCH_ASSOC);

    $active_students_percentage = ($active_students_data['total_count'] > 0) ? 
        round(($active_students_data['active_count'] / $active_students_data['total_count']) * 100) : 0;
    
    $course_completion_query = "
        SELECT 
            (SELECT COUNT(*) FROM course) as total_courses,
            (SELECT COUNT(*) FROM users WHERE role = 'student' AND status = 'active') as active_students
    ";
    $course_completion_stmt = $conn->prepare($course_completion_query);
    $course_completion_stmt->execute();
    $course_completion_data = $course_completion_stmt->fetch(PDO::FETCH_ASSOC);

    $course_completion_percentage = ($course_completion_data['total_courses'] > 0 && $course_completion_data['active_students'] > 0) ? 
        round((min(1, 1 / $course_completion_data['total_courses'])) * 100) : 0;
    
    $assignment_submission_query = "
        SELECT 
            (SELECT COUNT(*) FROM assessments) as total_assignments,
            (SELECT COUNT(*) FROM users WHERE role = 'student' AND status = 'active') as active_students
    ";
    $assignment_submission_stmt = $conn->prepare($assignment_submission_query);
    $assignment_submission_stmt->execute();
    $assignment_submission_data = $assignment_submission_stmt->fetch(PDO::FETCH_ASSOC);

    $assignment_submission_percentage = ($assignment_submission_data['total_assignments'] > 0 && $assignment_submission_data['active_students'] > 0) ? 
        round((min(1, 1 / $assignment_submission_data['total_assignments'])) * 100) : 0;
    
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <div class="admin-header-left">
                   
                    <p class="welcome-message">Welcome back, <span class="admin-name"><?php echo $_SESSION['email']; ?></span></p>
                </div>
                <div class="admin-header-right">
                    <!-- Search & Filter Panel -->
                    <div class="search-filter-panel">
                        <div class="search-container">
                            <input type="text" id="globalSearch" placeholder="Search users, courses, programs..." class="search-input">
                            <i class="fas fa-search search-icon"></i>
                        </div>
                        <div class="filter-container">
                            <select id="filterProgram" class="filter-select">
                                <option value="">All Programs</option>
                                <?php foreach ($program_distribution as $program): ?>
                                <option value="<?php echo $program['name']; ?>"><?php echo $program['name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                            <select id="filterDepartment" class="filter-select">
                                <option value="">All Departments</option>
                                <?php foreach ($department_distribution as $dept): ?>
                                <option value="<?php echo $dept['name']; ?>"><?php echo $dept['name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                            <select id="filterRole" class="filter-select">
                                <option value="">All Roles</option>
                                <option value="student">Students</option>
                                <option value="instructor">Instructors</option>
                                <option value="admin">Admins</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="notifications-dropdown">
                        <button class="notifications-btn">
                            <i class="icon-bell"></i>
                            <?php if (count($recent_notifications) > 0): ?>
                            <span class="notification-badge"><?php echo count($recent_notifications); ?></span>
                            <?php endif; ?>
                        </button>
                        <div class="notifications-content">
                            <div class="notifications-header">
                                <h3>Notifications</h3>
                                <a href="notifications.php" class="view-all-link">View All</a>
                            </div>
                            <div class="notifications-list">
                                <?php if (count($recent_notifications) > 0): ?>
                                    <?php foreach ($recent_notifications as $notification): ?>
                                    <div class="notification-item">
                                        <div class="notification-icon">
                                            <i class="icon-bell"></i>
                                        </div>
                                        <div class="notification-details">
                                            <div class="notification-title"><?php echo $notification['title']; ?></div>
                                            <div class="notification-message"><?php echo substr($notification['message'], 0, 50) . (strlen($notification['message']) > 50 ? '...' : ''); ?></div>
                                            <div class="notification-time"><?php echo date('M d, Y H:i', strtotime($notification['created_at'])); ?></div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="no-notifications">notifications</div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="theme-toggle">
                        <input type="checkbox" id="theme-toggle-checkbox" class="theme-toggle-checkbox">
                        <label for="theme-toggle-checkbox" class="theme-toggle-label">
                            <span class="theme-toggle-inner"></span>
                        </label>
                    </div>
                    <div class="admin-profile">
                        <img src="../assets/images/admin-avatar.png" alt="Admin">
                        <span><?php echo $_SESSION['email']; ?></span>
                    </div>
                </div>
            </div>
            
            <!-- Enhanced Summary Cards -->
            <div class="dashboard-overview">
                <div class="overview-card total-users">
                    <div class="overview-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="overview-details">
                        <h3>Total Users</h3>
                        <p class="overview-count"><?php echo $total_users; ?></p>
                        <div class="overview-trend positive">
                            <span>+5.2%</span> this month
                        </div>
                    </div>
                </div>
                
                <div class="overview-card total-students">
                    <div class="overview-icon">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <div class="overview-details">
                        <h3>Total Students</h3>
                        <p class="overview-count"><?php echo $students_count; ?></p>
                        <div class="overview-trend positive">
                            <span>+3.1%</span> this month
                        </div>
                    </div>
                </div>
                
                <div class="overview-card total-batches">
                    <div class="overview-icon">
                        <i class="fas fa-layer-group"></i>
                    </div>
                    <div class="overview-details">
                        <h3>Total Batches</h3>
                        <p class="overview-count"><?php echo $batches_count; ?></p>
                        <div class="overview-trend neutral">
                            <span>0%</span> this month
                        </div>
                    </div>
                </div>
                
                <div class="overview-card active-academic-year">
                    <div class="overview-icon">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <div class="overview-details">
                        <h3>Academic Year</h3>
                        <p class="overview-count"><?php echo $active_academic_year; ?></p>
                        <div class="overview-trend positive">
                            <span>Active</span>
                        </div>
                        <div class="semester-info">
                            <small><strong>Semester:</strong> <?php echo $active_semester; ?> (Active)</small>
                        </div>
                    </div>
                </div>
                
                <div class="overview-card total-instructors">
                    <div class="overview-icon">
                        <i class="fas fa-chalkboard-teacher"></i>
                    </div>
                    <div class="overview-details">
                        <h3>Instructors</h3>
                        <p class="overview-count"><?php echo $instructors_count; ?></p>
                        <div class="overview-trend positive">
                            <span>+2.1%</span> this month
                        </div>
                    </div>
                </div>
                
                <div class="overview-card pending-approvals">
                    <div class="overview-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="overview-details">
                        <h3>Pending Approvals</h3>
                        <p class="overview-count"><?php echo $pending_count; ?></p>
                        <div class="overview-trend <?php echo $pending_count > 0 ? 'negative' : 'positive'; ?>">
                            <span><?php echo $pending_count > 0 ? 'Action needed' : 'All clear'; ?></span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Dashboard Notifications Area -->
            <?php if (count($dashboard_notifications) > 0): ?>
            <div class="dashboard-notifications">
                <h2 class="section-title">System Alerts</h2>
                <div class="notifications-grid">
                    <?php foreach ($dashboard_notifications as $notification): ?>
                    <div class="notification-alert <?php echo $notification['type']; ?>">
                        <div class="alert-icon">
                            <i class="fas <?php echo $notification['icon']; ?>"></i>
                        </div>
                        <div class="alert-content">
                            <h4><?php echo $notification['title']; ?></h4>
                            <p><?php echo $notification['message']; ?></p>
                            <a href="<?php echo $notification['action']; ?>" class="alert-action">Take Action</a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- FIXED Enhanced Charts & Analytics Section -->
            <div class="analytics-section">
                <h2 class="section-title">Analytics & Charts</h2>
                <div class="charts-grid">
                    <!-- Students per Department Bar Chart -->
                    <div class="chart-container">
                        <div class="chart-header">
                            <h3>Students per Department</h3>
                            <span class="chart-type">Bar Chart</span>
                            <div class="chart-info">
                                <small>Total: <?php echo array_sum($department_data); ?> students</small>
                            </div>
                        </div>
                        <div class="chart-body">
                            <canvas id="departmentChart"></canvas>
                        </div>
                    </div>
                    
                    <!-- Students per Program Pie Chart -->
                    <div class="chart-container">
                        <div class="chart-header">
                            <h3>Students per Program</h3>
                            <span class="chart-type">Pie Chart</span>
                            <div class="chart-info">
                                <small>Total: <?php echo array_sum($program_data); ?> students</small>
                            </div>
                        </div>
                        <div class="chart-body">
                            <canvas id="programChart"></canvas>
                        </div>
                    </div>
                    
                    <!-- Attendance Trends Line Chart -->
                    <div class="chart-container">
                        <div class="chart-header">
                            <h3>Attendance Trends (Last 30 Days)</h3>
                            <span class="chart-type">Line Chart</span>
                            <div class="chart-info">
                                <small>Avg: <?php echo !empty($attendance_data) ? round(array_sum($attendance_data) / count($attendance_data), 1) : 0; ?>%</small>
                            </div>
                        </div>
                        <div class="chart-body">
                            <canvas id="attendanceChart"></canvas>
                        </div>
                    </div>
                    
                    <!-- Students per Batch Doughnut Chart -->
                    <div class="chart-container">
                        <div class="chart-header">
                            <h3>Students per Batch</h3>
                            <span class="chart-type">Doughnut Chart</span>
                            <div class="chart-info">
                                <small>Total: <?php echo array_sum($batch_data); ?> students</small>
                            </div>
                        </div>
                        <div class="chart-body">
                            <canvas id="batchChart"></canvas>
                        </div>
                    </div>
                    
                    <!-- Student Enrollment by Academic Year -->
                    <div class="chart-container chart-wide">
                        <div class="chart-header">
                            <h3>Student Enrollment by Academic Year</h3>
                            <span class="chart-type">Bar Chart</span>
                            <div class="chart-info">
                                <small>Academic years comparison</small>
                            </div>
                        </div>
                        <div class="chart-body">
                            <canvas id="enrollmentChart"></canvas>
                        </div>
                    </div>
                    
                    <!-- Monthly Registrations -->
                    <div class="chart-container chart-wide">
                        <div class="chart-header">
                            <h3>Student Registrations (<?php echo $year; ?>)</h3>
                            <span class="chart-type">Line Chart</span>
                            <div class="chart-info">
                                <small>Total: <?php echo array_sum($monthly_data); ?> registrations</small>
                            </div>
                        </div>
                        <div class="chart-body">
                            <canvas id="registrationsChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Calendar Overview -->
            <div class="calendar-overview">
                <h2 class="section-title">Calendar Overview</h2>
                <div class="calendar-container">
                    <div class="calendar-events">
                        <h3>Upcoming Events</h3>
                        <div class="events-list">
                            <?php if (count($calendar_events) > 0): ?>
                                <?php foreach ($calendar_events as $event): ?>
                                <div class="calendar-event">
                                    <div class="event-date">
                                        <div class="event-day"><?php echo date('d', strtotime($event['event_date'])); ?></div>
                                        <div class="event-month"><?php echo date('M', strtotime($event['event_date'])); ?></div>
                                    </div>
                                    <div class="event-details">
                                        <div class="event-type"><?php echo $event['event_type']; ?></div>
                                        <div class="event-title"><?php echo $event['title']; ?></div>
                                        <div class="event-time"><?php echo date('h:i A', strtotime($event['event_date'])); ?></div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="no-events">No upcoming events</div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="academic-schedule">
                        <h3>Academic Schedule</h3>
                        <div class="schedule-items">
                            <div class="schedule-item">
                                <div class="schedule-icon">
                                    <i class="fas fa-calendar-check"></i>
                                </div>
                                <div class="schedule-details">
                                    <div class="schedule-title">Current Academic Year</div>
                                    <div class="schedule-date"><?php echo $active_academic_year; ?></div>
                                </div>
                            </div>
                            <div class="schedule-item">
                                <div class="schedule-icon">
                                    <i class="fas fa-graduation-cap"></i>
                                </div>
                                <div class="schedule-details">
                                    <div class="schedule-title">Active Batches</div>
                                    <div class="schedule-date"><?php echo $batches_count; ?> batches</div>
                                </div>
                            </div>
                            <div class="schedule-item">
                                <div class="schedule-icon">
                                    <i class="fas fa-book"></i>
                                </div>
                                <div class="schedule-details">
                                    <div class="schedule-title">Total Courses</div>
                                    <div class="schedule-date"><?php echo $courses_count; ?> courses</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            
            
            <div class="dashboard-bottom">
                <div class="recent-registrations">
                    <div class="section-header">
                        <h2>Recent Registrations</h2>
                        <a href="students.php" class="view-all-link">View All</a>
                    </div>
                    <div class="recent-table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Program</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $recent_query = "SELECT u.id, u.full_name, u.email, u.status, p.name as program_name 
                                               FROM users u 
                                               JOIN enrollment e ON u.id = e.user_id 
                                               JOIN programs p ON e.program_id = p.id 
                                               WHERE u.role = 'student' 
                                               ORDER BY u.created_at DESC LIMIT 5";
                                $recent_stmt = $conn->prepare($recent_query);
                                $recent_stmt->execute();
                                $recent_users = $recent_stmt->fetchAll(PDO::FETCH_ASSOC);
                                
                                foreach ($recent_users as $user):
                                ?>
                                <tr>
                                    <td><?php echo $user['full_name']; ?></td>
                                    <td><?php echo $user['email']; ?></td>
                                    <td><?php echo $user['program_name']; ?></td>
                                    <td>
                                        <span class="status-badge <?php echo $user['status'] === 'active' ? 'active' : 'inactive'; ?>">
                                            <?php echo ucfirst($user['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($user['status'] === 'inactive'): ?>
                                        <button class="btn btn-sm btn-primary approve-btn" data-id="<?php echo $user['id']; ?>">Approve</button>
                                        <?php else: ?>
                                        <button class="btn btn-sm btn-secondary view-btn" data-id="<?php echo $user['id']; ?>">View</button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <div class="recent-activities">
                    <div class="section-header">
                        <h2>Recent Activities</h2>
                    </div>
                    <div class="activities-list">
                        <?php foreach ($recent_activities as $activity): ?>
                        <div class="activity-item">
                            <div class="activity-icon <?php echo strtolower(str_replace(' ', '-', $activity['type'])); ?>">
                                <i class="fas fa-<?php echo isset($activity['icon']) ? $activity['icon'] : 'info'; ?>"></i>
                            </div>
                            <div class="activity-details">
                                <div class="activity-title"><?php echo $activity['type']; ?></div>
                                <div class="activity-description"><?php echo $activity['name']; ?></div>
                                <div class="activity-time"><?php echo date('M d, Y H:i', strtotime($activity['date'])); ?></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Approval Modal -->
    <div id="approvalModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Approve Student</h2>
            <form id="approvalForm">
                <input type="hidden" id="student_id" name="student_id">
                
                <div class="form-group">
                    <label for="batch_id">Select Batch <span class="required">*</span></label>
                    <select id="batch_id" name="batch_id" required>
                        <option value="">Select Batch</option>
                        <?php
                        $batch_query = "SELECT b.id, b.name, b.year, d.name as department_name 
                                        FROM batch b 
                                        JOIN programs p ON b.program_id = p.id
                                        JOIN departments d ON p.department_id = d.id 
                                        WHERE b.status = 'active'";
                        $batch_stmt = $conn->prepare($batch_query);
                        $batch_stmt->execute();
                        $batches = $batch_stmt->fetchAll(PDO::FETCH_ASSOC);
                        
                        foreach ($batches as $batch):
                        ?>
                        <option value="<?php echo $batch['id']; ?>">
                            <?php echo $batch['name'] . ' (' . $batch['year'] . ') - ' . $batch['department_name']; ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Approve Student</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    // Enhanced Dashboard JavaScript
    document.addEventListener('DOMContentLoaded', function() {
        // Search and Filter Functionality
        const globalSearch = document.getElementById('globalSearch');
        const filterProgram = document.getElementById('filterProgram');
        const filterDepartment = document.getElementById('filterDepartment');
        const filterRole = document.getElementById('filterRole');
        
        // Global search functionality
        if (globalSearch) {
            globalSearch.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                // Implement search logic here
                console.log('Searching for:', searchTerm);
            });
        }
        
        // Filter functionality
        [filterProgram, filterDepartment, filterRole].forEach(filter => {
            if (filter) {
                filter.addEventListener('change', function() {
                    // Implement filter logic here
                    console.log('Filter changed:', this.id, this.value);
                });
            }
        });
        
        // Modal functionality
        const modal = document.getElementById('approvalModal');
        const approveBtns = document.querySelectorAll('.approve-btn');
        const closeBtn = document.querySelector('.close');
        const approvalForm = document.getElementById('approvalForm');
        
        approveBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const studentId = this.getAttribute('data-id');
                document.getElementById('student_id').value = studentId;
                modal.style.display = 'block';
            });
        });
        
        if (closeBtn) {
            closeBtn.addEventListener('click', function() {
                modal.style.display = 'none';
            });
        }
        
        window.addEventListener('click', function(event) {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
        
        if (approvalForm) {
            approvalForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const studentId = document.getElementById('student_id').value;
                const batchId = document.getElementById('batch_id').value;
        
                if (!batchId) {
                    alert('Please select a batch. Batch selection is required.');
                    return;
                }
                
                fetch('../api/approve_student.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        student_id: studentId,
                        batch_id: batchId
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Student approved successfully');
                        modal.style.display = 'none';
                        location.reload();
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred');
                });
            });
        }
        
        // Notifications dropdown
        const notificationsBtn = document.querySelector('.notifications-btn');
        const notificationsContent = document.querySelector('.notifications-content');
        
        if (notificationsBtn) {
            notificationsBtn.addEventListener('click', function() {
                notificationsContent.classList.toggle('show');
            });
            
            document.addEventListener('click', function(event) {
                if (!notificationsBtn.contains(event.target) && !notificationsContent.contains(event.target)) {
                    notificationsContent.classList.remove('show');
                }
            });
        }
        
        // FIXED Enhanced Charts
        
        // Chart.js default configuration
        Chart.defaults.font.family = "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif";
        Chart.defaults.font.size = 12;
        Chart.defaults.color = '#666';
        
        // Students per Department Bar Chart
        const departmentCtx = document.getElementById('departmentChart');
        if (departmentCtx) {
            new Chart(departmentCtx, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode($department_labels); ?>,
                    datasets: [{
                        label: 'Students',
                        data: <?php echo json_encode($department_data); ?>,
                        backgroundColor: <?php echo json_encode($department_background); ?>,
                        borderWidth: 0,
                        borderRadius: 6,
                        borderSkipped: false,
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return context.parsed.y + ' students';
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: { 
                                precision: 0,
                                callback: function(value) {
                                    return value + ' students';
                                }
                            },
                            grid: {
                                color: 'rgba(0,0,0,0.1)'
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });
        }
        
        // Students per Program Pie Chart
        const programCtx = document.getElementById('programChart');
        if (programCtx) {
            new Chart(programCtx, {
                type: 'pie',
                data: {
                    labels: <?php echo json_encode($program_labels); ?>,
                    datasets: [{
                        data: <?php echo json_encode($program_data); ?>,
                        backgroundColor: <?php echo json_encode($program_background); ?>,
                        borderWidth: 2,
                        borderColor: '#fff',
                        hoverBorderWidth: 3
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { 
                            position: 'bottom',
                            labels: {
                                padding: 20,
                                usePointStyle: true
                            }
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const percentage = total > 0 ? ((context.parsed * 100) / total).toFixed(1) : 0;
                                    return context.label + ': ' + context.parsed + ' students (' + percentage + '%)';
                                }
                            }
                        }
                    }
                }
            });
        }
        
        // Attendance Trends Line Chart
        const attendanceCtx = document.getElementById('attendanceChart');
        if (attendanceCtx) {
            new Chart(attendanceCtx, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode($attendance_labels); ?>,
                    datasets: [{
                        label: 'Attendance %',
                        data: <?php echo json_encode($attendance_data); ?>,
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 3,
                        tension: 0.4,
                        fill: true,
                        pointBackgroundColor: 'rgba(75, 192, 192, 1)',
                        pointBorderColor: '#fff',
                        pointBorderWidth: 2,
                        pointRadius: 4,
                        pointHoverRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return 'Attendance: ' + context.parsed.y + '%';
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 100,
                            ticks: {
                                callback: function(value) {
                                    return value + '%';
                                }
                            },
                            grid: {
                                color: 'rgba(0,0,0,0.1)'
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });
        }
        
        // Students per Batch Doughnut Chart
        const batchCtx = document.getElementById('batchChart');
        if (batchCtx) {
            new Chart(batchCtx, {
                type: 'doughnut',
                data: {
                    labels: <?php echo json_encode($batch_labels); ?>,
                    datasets: [{
                        data: <?php echo json_encode($batch_data); ?>,
                        backgroundColor: <?php echo json_encode($batch_background); ?>,
                        borderWidth: 0,
                        hoverBorderWidth: 3,
                        hoverBorderColor: '#fff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { 
                            position: 'bottom',
                            labels: {
                                padding: 20,
                                usePointStyle: true
                            }
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const percentage = total > 0 ? ((context.parsed * 100) / total).toFixed(1) : 0;
                                    return context.label + ': ' + context.parsed + ' students (' + percentage + '%)';
                                }
                            }
                        }
                    },
                    cutout: '60%'
                }
            });
        }
        
        // Student Enrollment by Academic Year
        const enrollmentCtx = document.getElementById('enrollmentChart');
        if (enrollmentCtx) {
            new Chart(enrollmentCtx, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode($enrollment_years); ?>,
                    datasets: [{
                        label: 'Enrollments',
                        data: <?php echo json_encode($enrollment_data); ?>,
                        backgroundColor: 'rgba(76, 111, 255, 0.8)',
                        borderColor: 'rgba(76, 111, 255, 1)',
                        borderWidth: 1,
                        borderRadius: 6,
                        borderSkipped: false,
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return context.parsed.y + ' enrollments';
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: { 
                                precision: 0,
                                callback: function(value) {
                                    return value + ' students';
                                }
                            },
                            grid: {
                                color: 'rgba(0,0,0,0.1)'
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });
        }
        
        // Monthly Registrations Line Chart
        const registrationsCtx = document.getElementById('registrationsChart');
        if (registrationsCtx) {
            new Chart(registrationsCtx, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode($months); ?>,
                    datasets: [{
                        label: 'Student Registrations',
                        data: <?php echo json_encode($monthly_data); ?>,
                        backgroundColor: 'rgba(76, 111, 255, 0.2)',
                        borderColor: 'rgba(76, 111, 255, 1)',
                        borderWidth: 3,
                        tension: 0.4,
                        fill: true,
                        pointBackgroundColor: 'rgba(76, 111, 255, 1)',
                        pointBorderColor: '#fff',
                        pointBorderWidth: 2,
                        pointRadius: 4,
                        pointHoverRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return context.parsed.y + ' registrations';
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: { 
                                precision: 0,
                                callback: function(value) {
                                    return value + ' students';
                                }
                            },
                            grid: {
                                color: 'rgba(0,0,0,0.1)'
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });
        }
    });
   

    </script>
    
    <script src="../assets/js/theme.js"></script>
</body>
</html>
