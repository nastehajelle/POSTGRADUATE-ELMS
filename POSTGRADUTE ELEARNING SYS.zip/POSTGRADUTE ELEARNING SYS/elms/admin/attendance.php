<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is admin
if (!is_logged_in() || !is_admin()) {
    header("Location: ../auth/login.php");
    exit();
}

// Check if the attendance table exists, if not create it
try {
    $check_table = $conn->query("SHOW TABLES LIKE 'attendance'");
    if ($check_table->rowCount() == 0) {
        // Create attendance table
        $create_table = "CREATE TABLE attendance (
            id INT AUTO_INCREMENT PRIMARY KEY,
            course_id INT NOT NULL,
            student_id INT NOT NULL,
            date DATE NOT NULL,
            status ENUM('present', 'absent', 'late', 'excused') NOT NULL DEFAULT 'absent',
            remarks TEXT,
            created_by INT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (course_id) REFERENCES course(id) ON DELETE CASCADE,
            FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
            UNIQUE KEY unique_attendance (course_id, student_id, date)
        )";
        $conn->exec($create_table);
        error_log("Created attendance table");
    }
} catch (PDOException $e) {
    error_log("Error creating attendance table: " . $e->getMessage());
}

// Process AJAX requests
if (isset($_POST['ajax']) && $_POST['ajax'] == 1) {
    header('Content-Type: application/json');
    
    try {
        if ($_POST['action'] == 'save_attendance') {
            // Sanitize input
            $course_id = sanitize_input($_POST['course_id']);
            $date = sanitize_input($_POST['date']);
            $attendance_data = $_POST['attendance_data'];
            
            // Validate input
            if (empty($course_id) || empty($date) || empty($attendance_data)) {
                throw new Exception("Please provide all required data");
            }
            
            // Begin transaction
            $conn->beginTransaction();
            
            foreach ($attendance_data as $student_id => $status) {
                $student_id = sanitize_input($student_id);
                $status = sanitize_input($status);
                $remarks = isset($_POST['remarks'][$student_id]) ? sanitize_input($_POST['remarks'][$student_id]) : '';
                
                // Check if record already exists
                $check_query = "SELECT id FROM attendance WHERE course_id = ? AND student_id = ? AND date = ?";
                $check_stmt = $conn->prepare($check_query);
                $check_stmt->execute([$course_id, $student_id, $date]);
                
                if ($check_stmt->rowCount() > 0) {
                    // Update existing record
                    $attendance_id = $check_stmt->fetch(PDO::FETCH_ASSOC)['id'];
                    $update_query = "UPDATE attendance SET status = ?, remarks = ?, updated_at = NOW() WHERE id = ?";
                    $update_stmt = $conn->prepare($update_query);
                    $update_stmt->execute([$status, $remarks, $attendance_id]);
                } else {
                    // Insert new record
                    $insert_query = "INSERT INTO attendance (course_id, student_id, date, status, remarks, created_by) 
                                    VALUES (?, ?, ?, ?, ?, ?)";
                    $insert_stmt = $conn->prepare($insert_query);
                    $insert_stmt->execute([$course_id, $student_id, $date, $status, $remarks, $_SESSION['user_id']]);
                }
            }
            
            // Commit transaction
            $conn->commit();
            
            echo json_encode(['success' => true, 'message' => "Attendance saved successfully"]);
        }
        elseif ($_POST['action'] == 'get_attendance') {
            $course_id = sanitize_input($_POST['course_id']);
            $date = sanitize_input($_POST['date']);
            
            // Get all students enrolled in the course
            $students_query = "SELECT u.id, u.full_name, e.student_id as enrollment_id
                              FROM users u
                              JOIN enrollment e ON u.id = e.user_id
                              WHERE e.course_id = ? OR e.batch_id = (SELECT batch_id FROM course WHERE id = ?)
                              ORDER BY u.full_name";
            $students_stmt = $conn->prepare($students_query);
            $students_stmt->execute([$course_id, $course_id]);
            $students = $students_stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Get attendance records for the selected date
            $attendance_query = "SELECT student_id, status, remarks FROM attendance WHERE course_id = ? AND date = ?";
            $attendance_stmt = $conn->prepare($attendance_query);
            $attendance_stmt->execute([$course_id, $date]);
            $attendance_records = [];
            
            while ($record = $attendance_stmt->fetch(PDO::FETCH_ASSOC)) {
                $attendance_records[$record['student_id']] = [
                    'status' => $record['status'],
                    'remarks' => $record['remarks']
                ];
            }
            
            // Combine student data with attendance records
            foreach ($students as &$student) {
                if (isset($attendance_records[$student['id']])) {
                    $student['attendance'] = $attendance_records[$student['id']];
                } else {
                    $student['attendance'] = [
                        'status' => 'absent',
                        'remarks' => ''
                    ];
                }
            }
            
            echo json_encode(['success' => true, 'data' => $students]);
        }
        elseif ($_POST['action'] == 'get_attendance_report') {
            $course_id = sanitize_input($_POST['course_id']);
            $start_date = sanitize_input($_POST['start_date']);
            $end_date = sanitize_input($_POST['end_date']);
            
            // Validate dates
            if (empty($start_date) || empty($end_date)) {
                throw new Exception("Please provide start and end dates");
            }
            
            // Get all students enrolled in the course
            $students_query = "SELECT u.id, u.full_name, e.student_id as enrollment_id
                              FROM users u
                              JOIN enrollment e ON u.id = e.user_id
                              WHERE e.course_id = ? OR e.batch_id = (SELECT batch_id FROM course WHERE id = ?)
                              ORDER BY u.full_name";
            $students_stmt = $conn->prepare($students_query);
            $students_stmt->execute([$course_id, $course_id]);
            $students = $students_stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Get all dates between start and end date
            $period = new DatePeriod(
                new DateTime($start_date),
                new DateInterval('P1D'),
                new DateTime($end_date . ' +1 day')
            );
            
            $dates = [];
            foreach ($period as $date) {
                $dates[] = $date->format('Y-m-d');
            }
            
            // Get attendance records for all students in the date range
            $attendance_query = "SELECT student_id, date, status FROM attendance 
                                WHERE course_id = ? AND date BETWEEN ? AND ?";
            $attendance_stmt = $conn->prepare($attendance_query);
            $attendance_stmt->execute([$course_id, $start_date, $end_date]);
            $attendance_records = [];
            
            while ($record = $attendance_stmt->fetch(PDO::FETCH_ASSOC)) {
                if (!isset($attendance_records[$record['student_id']])) {
                    $attendance_records[$record['student_id']] = [];
                }
                $attendance_records[$record['student_id']][$record['date']] = $record['status'];
            }
            
            // Prepare report data
            $report_data = [
                'students' => $students,
                'dates' => $dates,
                'attendance' => $attendance_records
            ];
            
            echo json_encode(['success' => true, 'data' => $report_data]);
        }
        else {
            throw new Exception("Invalid action");
        }
    } catch(Exception $e) {
        // Rollback transaction if necessary
        if ($conn->inTransaction()) {
            $conn->rollBack();
        }
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit();
}

// Get all courses for dropdown
$courses_query = "SELECT c.id, c.code, c.name, b.name as batch_name, d.name as department_name
                 FROM course c
                 LEFT JOIN batch b ON c.batch_id = b.id
                 LEFT JOIN departments d ON c.department_id = d.id
                 WHERE c.status = 'active'
                 ORDER BY c.code";
$courses_stmt = $conn->prepare($courses_query);
$courses_stmt->execute();
$courses = $courses_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get attendance statistics
$stats_query = "SELECT 
               COUNT(DISTINCT course_id) as courses_count,
               COUNT(DISTINCT student_id) as students_count,
               COUNT(DISTINCT date) as days_count,
               COUNT(*) as total_records,
               SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present_count,
               SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) as absent_count,
               SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) as late_count,
               SUM(CASE WHEN status = 'excused' THEN 1 ELSE 0 END) as excused_count
               FROM attendance";
$stats_stmt = $conn->prepare($stats_query);
$stats_stmt->execute();
$stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);

// If no attendance records yet, initialize stats
if (!$stats['total_records']) {
    $stats = [
        'courses_count' => 0,
        'students_count' => 0,
        'days_count' => 0,
        'total_records' => 0,
        'present_count' => 0,
        'absent_count' => 0,
        'late_count' => 0,
        'excused_count' => 0
    ];
}

// Calculate attendance percentage if there are records
$attendance_percentage = 0;
if ($stats['total_records'] > 0) {
    // Only count present against actual recorded attendance (not including not-recorded days)
    $recorded_attendance = $stats['present_count'] + $stats['absent_count'] + $stats['late_count'] + $stats['excused_count'];
    if ($recorded_attendance > 0) {
        $attendance_percentage = round(($stats['present_count'] / $recorded_attendance) * 100);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Attendance - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/modal.css">
    <link rel="stylesheet" href="../assets/css/icons.css">
    <?php echo FONT_AWESOME_CSS; ?>
    <style>
        /* Attendance specific styles */
        .attendance-container {
            margin-top: 20px;
        }
        
        .attendance-form {
            margin-top: 20px;
            display: none;
        }
        
        .attendance-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .attendance-table th, .attendance-table td {
            padding: 10px;
            border: 1px solid var(--border-color);
            text-align: left;
        }
        
        .attendance-table th {
            background-color: var(--secondary-bg);
            font-weight: 600;
        }
        
        .attendance-status {
            display: flex;
            gap: 10px;
        }
        
        .status-radio {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .status-radio input[type="radio"] {
            margin: 0;
        }
        
        .status-badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.8rem;
            font-weight: 500;
            text-align: center;
            display: inline-block;
            min-width: 80px;
        }
        
        .status-present {
            background-color: #d1fae5;
            color: #065f46;
        }
        
        .status-absent {
            background-color: #fee2e2;
            color: #b91c1c;
        }
        
        .status-late {
            background-color: #fef3c7;
            color: #92400e;
        }
        
        .status-excused {
            background-color: #e0e7ff;
            color: #3730a3;
        }
        
        .status-not-recorded {
            background-color: #f3f4f6;
            color: #6b7280;
        }
        
        .attendance-report {
            margin-top: 30px;
            display: none;
        }
        
        .report-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            font-size: 0.9rem;
        }
        
        .report-table th, .report-table td {
            padding: 8px;
            border: 1px solid var(--border-color);
            text-align: center;
        }
        
        .report-table th {
            background-color: var(--secondary-bg);
            font-weight: 600;
        }
        
        .report-table .student-name {
            text-align: left;
            font-weight: 500;
        }
        
        .report-summary {
            margin-top: 20px;
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }
        
        .summary-item {
            background-color: var(--card-bg);
            padding: 15px;
            border-radius: 8px;
            box-shadow: var(--shadow);
            flex: 1;
            min-width: 200px;
        }
        
        .summary-item h3 {
            margin: 0 0 10px 0;
            font-size: 1rem;
            color: var(--text-muted);
        }
        
        .summary-item p {
            margin: 0;
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .tab-container {
            margin-top: 20px;
        }
        
        .tab-buttons {
            display: flex;
            border-bottom: 1px solid var(--border-color);
        }
        
        .tab-button {
            padding: 10px 20px;
            background: none;
            border: none;
            border-bottom: 3px solid transparent;
            cursor: pointer;
            font-weight: 500;
            color: var(--text-muted);
            transition: all 0.3s ease;
        }
        
        .tab-button.active {
            border-bottom-color: var(--primary-color);
            color: var(--primary-color);
        }
        
        .tab-content {
            padding: 20px 0;
        }
        
        .tab-panel {
            display: none;
        }
        
        .tab-panel.active {
            display: block;
        }
        
        .stats-cards {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background-color: var(--card-bg);
            border-radius: 8px;
            box-shadow: var(--shadow);
            padding: 20px;
            flex: 1;
            min-width: 200px;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .stat-card-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: rgba(var(--primary-rgb), 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-color);
            font-size: 1.5rem;
        }
        
        .stat-card-info h3 {
            margin: 0;
            font-size: 0.9rem;
            color: var(--text-muted);
            font-weight: 500;
        }
        
        .stat-card-info p {
            margin: 5px 0 0 0;
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-color);
        }
        
        .form-actions {
            margin-top: 20px;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
        
        @media (max-width: 768px) {
            .attendance-status {
                flex-direction: column;
                gap: 5px;
            }
            
            .report-table {
                font-size: 0.8rem;
            }
            
            .report-table th, .report-table td {
                padding: 5px;
            }
            
            .stat-card {
                min-width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>Manage Attendance</h1>
            </div>
            
            <div id="alertContainer"></div>
            
            <!-- Stats Cards -->
            <div class="stats-cards">
                <div class="stat-card">
                    <div class="stat-card-icon">
                        <i class="icon-users"></i>
                    </div>
                    <div class="stat-card-info">
                        <h3>Students Tracked</h3>
                        <p><?php echo $stats['students_count']; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-card-icon">
                        <i class="icon-book"></i>
                    </div>
                    <div class="stat-card-info">
                        <h3>Courses</h3>
                        <p><?php echo $stats['courses_count']; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-card-icon">
                        <i class="icon-calendar"></i>
                    </div>
                    <div class="stat-card-info">
                        <h3>Days Recorded</h3>
                        <p><?php echo $stats['days_count']; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-card-icon">
                        <i class="icon-chart-bar"></i>
                    </div>
                    <div class="stat-card-info">
                        <h3>Attendance Rate</h3>
                        <p><?php echo $attendance_percentage; ?>%</p>
                    </div>
                </div>
            </div>
            
            <div class="tab-container">
                <div class="tab-buttons">
                    <button class="tab-button active" data-tab="take-attendance">Take Attendance</button>
                    <button class="tab-button" data-tab="attendance-report">Attendance Report</button>
                </div>
                
                <div class="tab-content">
                    <!-- Take Attendance Tab -->
                    <div class="tab-panel active" id="take-attendance-panel">
                        <div class="card">
                            <div class="card-body">
                                <h2 class="card-title">Take Attendance</h2>
                                
                                <div class="form-row">
                                    <label for="course_id">Select Course:</label>
                                    <select id="course_id" required>
                                        <option value="">Select Course</option>
                                        <?php foreach ($courses as $course): ?>
                                            <option value="<?php echo $course['id']; ?>">
                                                <?php echo $course['code'] . ' - ' . $course['name'] . ' (' . $course['batch_name'] . ')'; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="form-row">
                                    <label for="attendance_date">Date:</label>
                                    <input type="date" id="attendance_date" required value="<?php echo date('Y-m-d'); ?>">
                                </div>
                                
                                <div class="form-actions">
                                    <button class="btn btn-primary" id="loadAttendanceBtn">Load Students</button>
                                </div>
                                
                                <div id="attendanceForm" class="attendance-form">
                                    <div id="studentsList"></div>
                                    
                                    <div class="form-actions">
                                        <button class="btn btn-secondary" id="cancelAttendanceBtn">Cancel</button>
                                        <button class="btn btn-primary" id="saveAttendanceBtn">Save Attendance</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Attendance Report Tab -->
                    <div class="tab-panel" id="attendance-report-panel">
                        <div class="card">
                            <div class="card-body">
                                <h2 class="card-title">Attendance Report</h2>
                                
                                <div class="form-row">
                                    <label for="report_course_id">Select Course:</label>
                                    <select id="report_course_id" required>
                                        <option value="">Select Course</option>
                                        <?php foreach ($courses as $course): ?>
                                            <option value="<?php echo $course['id']; ?>">
                                                <?php echo $course['code'] . ' - ' . $course['name'] . ' (' . $course['batch_name'] . ')'; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="form-row">
                                    <label for="start_date">Start Date:</label>
                                    <input type="date" id="start_date" required>
                                </div>
                                
                                <div class="form-row">
                                    <label for="end_date">End Date:</label>
                                    <input type="date" id="end_date" required>
                                </div>
                                
                                <div class="form-actions">
                                    <button class="btn btn-primary" id="generateReportBtn">Generate Report</button>
                                </div>
                                
                                <div id="attendanceReport" class="attendance-report">
                                    <div id="reportContent"></div>
                                    
                                    <div class="report-summary" id="reportSummary"></div>
                                    
                                    <div class="form-actions">
                                        <button class="btn btn-secondary" id="printReportBtn">Print Report</button>
                                        <button class="btn btn-primary" id="exportReportBtn">Export to CSV</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // DOM Elements
        const alertContainer = document.getElementById('alertContainer');
        const courseSelect = document.getElementById('course_id');
        const attendanceDate = document.getElementById('attendance_date');
        const loadAttendanceBtn = document.getElementById('loadAttendanceBtn');
        const attendanceForm = document.getElementById('attendanceForm');
        const studentsList = document.getElementById('studentsList');
        const saveAttendanceBtn = document.getElementById('saveAttendanceBtn');
        const cancelAttendanceBtn = document.getElementById('cancelAttendanceBtn');
        
        // Report Elements
        const reportCourseSelect = document.getElementById('report_course_id');
        const startDate = document.getElementById('start_date');
        const endDate = document.getElementById('end_date');
        const generateReportBtn = document.getElementById('generateReportBtn');
        const attendanceReport = document.getElementById('attendanceReport');
        const reportContent = document.getElementById('reportContent');
        const reportSummary = document.getElementById('reportSummary');
        const printReportBtn = document.getElementById('printReportBtn');
        const exportReportBtn = document.getElementById('exportReportBtn');
        
        // Tab Elements
        const tabButtons = document.querySelectorAll('.tab-button');
        const tabPanels = document.querySelectorAll('.tab-panel');
        
        // Show alert message
        function showAlert(message, type = 'success') {
            const alert = document.createElement('div');
            alert.className = `alert alert-${type}`;
            alert.textContent = message;
            
            alertContainer.appendChild(alert);
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                alert.remove();
            }, 5000);
        }
        
        // Tab functionality
        tabButtons.forEach(button => {
            button.addEventListener('click', function() {
                const tabId = this.getAttribute('data-tab');
                
                // Remove active class from all buttons and panels
                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabPanels.forEach(panel => panel.classList.remove('active'));
                
                // Add active class to clicked button and corresponding panel
                this.classList.add('active');
                document.getElementById(`${tabId}-panel`).classList.add('active');
            });
        });
        
        // Load students for attendance
        loadAttendanceBtn.addEventListener('click', function() {
            const courseId = courseSelect.value;
            const date = attendanceDate.value;
            
            if (!courseId) {
                showAlert('Please select a course', 'danger');
                return;
            }
            
            if (!date) {
                showAlert('Please select a date', 'danger');
                return;
            }
            
            // Disable button and show loading
            loadAttendanceBtn.disabled = true;
            loadAttendanceBtn.textContent = 'Loading...';
            
            // Prepare form data
            const formData = new FormData();
            formData.append('ajax', 1);
            formData.append('action', 'get_attendance');
            formData.append('course_id', courseId);
            formData.append('date', date);
            
            // Send AJAX request
            fetch('attendance.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                loadAttendanceBtn.disabled = false;
                loadAttendanceBtn.textContent = 'Load Students';
                
                if (data.success) {
                    const students = data.data;
                    
                    if (students.length === 0) {
                        showAlert('No students found for this course', 'warning');
                        return;
                    }
                    
                    // Create attendance table
                    let tableHtml = `
                        <table class="attendance-table">
                            <thead>
                                <tr>
                                    <th>Student ID</th>
                                    <th>Name</th>
                                    <th>Status</th>
                                    <th>Remarks</th>
                                </tr>
                            </thead>
                            <tbody>
                    `;
                    
                    students.forEach(student => {
                        const studentId = student.id;
                        const status = student.attendance.status;
                        const remarks = student.attendance.remarks || '';
                        
                        tableHtml += `
                            <tr>
                                <td>${student.enrollment_id || 'N/A'}</td>
                                <td>${student.full_name}</td>
                                <td>
                                    <div class="attendance-status">
                                        <div class="status-radio">
                                            <input type="radio" name="status_${studentId}" value="present" id="present_${studentId}" ${status === 'present' ? 'checked' : ''}>
                                            <label for="present_${studentId}">Present</label>
                                        </div>
                                        <div class="status-radio">
                                            <input type="radio" name="status_${studentId}" value="absent" id="absent_${studentId}" ${status === 'absent' ? 'checked' : ''}>
                                            <label for="absent_${studentId}">Absent</label>
                                        </div>
                                        <div class="status-radio">
                                            <input type="radio" name="status_${studentId}" value="late" id="late_${studentId}" ${status === 'late' ? 'checked' : ''}>
                                            <label for="late_${studentId}">Late</label>
                                        </div>
                                        <div class="status-radio">
                                            <input type="radio" name="status_${studentId}" value="excused" id="excused_${studentId}" ${status === 'excused' ? 'checked' : ''}>
                                            <label for="excused_${studentId}">Excused</label>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <input type="text" class="form-control" name="remarks_${studentId}" value="${remarks}" placeholder="Optional remarks">
                                </td>
                            </tr>
                        `;
                    });
                    
                    tableHtml += `
                            </tbody>
                        </table>
                    `;
                    
                    // Display the table
                    studentsList.innerHTML = tableHtml;
                    attendanceForm.style.display = 'block';
                } else {
                    showAlert(data.message, 'danger');
                }
            })
            .catch(error => {
                loadAttendanceBtn.disabled = false;
                loadAttendanceBtn.textContent = 'Load Students';
                showAlert('An error occurred while loading students', 'danger');
                console.error(error);
            });
        });
        
        // Cancel attendance form
        cancelAttendanceBtn.addEventListener('click', function() {
            attendanceForm.style.display = 'none';
            studentsList.innerHTML = '';
        });
        
        // Save attendance
        saveAttendanceBtn.addEventListener('click', function() {
            const courseId = courseSelect.value;
            const date = attendanceDate.value;
            
            if (!courseId || !date) {
                showAlert('Please select a course and date', 'danger');
                return;
            }
            
            // Collect attendance data
            const attendanceData = {};
            const remarks = {};
            
            // Find all status radio buttons that are checked
            const statusInputs = document.querySelectorAll('input[type="radio"]:checked');
            statusInputs.forEach(input => {
                const name = input.getAttribute('name');
                const studentId = name.replace('status_', '');
                attendanceData[studentId] = input.value;
            });
            
            // Find all remarks inputs
            const remarksInputs = document.querySelectorAll('input[name^="remarks_"]');
            remarksInputs.forEach(input => {
                const name = input.getAttribute('name');
                const studentId = name.replace('remarks_', '');
                remarks[studentId] = input.value;
            });
            
            if (Object.keys(attendanceData).length === 0) {
                showAlert('No attendance data to save', 'danger');
                return;
            }
            
            // Disable button and show loading
            saveAttendanceBtn.disabled = true;
            saveAttendanceBtn.textContent = 'Saving...';
            
            // Prepare form data
            const formData = new FormData();
            formData.append('ajax', 1);
            formData.append('action', 'save_attendance');
            formData.append('course_id', courseId);
            formData.append('date', date);
            formData.append('attendance_data', JSON.stringify(attendanceData));
            formData.append('remarks', JSON.stringify(remarks));
            
            // Send AJAX request
            fetch('attendance.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                saveAttendanceBtn.disabled = false;
                saveAttendanceBtn.textContent = 'Save Attendance';
                
                if (data.success) {
                    showAlert(data.message, 'success');
                    
                    // Reset form
                    attendanceForm.style.display = 'none';
                    studentsList.innerHTML = '';
                    
                    // Reload the page after a short delay to update stats
                    setTimeout(() => {
                        window.location.reload();
                    }, 1500);
                } else {
                    showAlert(data.message, 'danger');
                }
            })
            .catch(error => {
                saveAttendanceBtn.disabled = false;
                saveAttendanceBtn.textContent = 'Save Attendance';
                showAlert('An error occurred while saving attendance', 'danger');
                console.error(error);
            });
        });
        
        // Generate attendance report
        generateReportBtn.addEventListener('click', function() {
            const courseId = reportCourseSelect.value;
            const startDateValue = startDate.value;
            const endDateValue = endDate.value;
            
            if (!courseId) {
                showAlert('Please select a course', 'danger');
                return;
            }
            
            if (!startDateValue || !endDateValue) {
                showAlert('Please select start and end dates', 'danger');
                return;
            }
            
            // Validate date range
            const start = new Date(startDateValue);
            const end = new Date(endDateValue);
            
            if (start > end) {
                showAlert('Start date cannot be after end date', 'danger');
                return;
            }
            
            // Disable button and show loading
            generateReportBtn.disabled = true;
            generateReportBtn.textContent = 'Generating...';
            
            // Prepare form data
            const formData = new FormData();
            formData.append('ajax', 1);
            formData.append('action', 'get_attendance_report');
            formData.append('course_id', courseId);
            formData.append('start_date', startDateValue);
            formData.append('end_date', endDateValue);
            
            // Send AJAX request
            fetch('attendance.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                generateReportBtn.disabled = false;
                generateReportBtn.textContent = 'Generate Report';
                
                if (data.success) {
                    const reportData = data.data;
                    const students = reportData.students;
                    const dates = reportData.dates;
                    const attendance = reportData.attendance;
                    
                    if (students.length === 0) {
                        showAlert('No students found for this course', 'warning');
                        return;
                    }
                    
                    // Create report table
                    let tableHtml = `
                        <table class="report-table" id="reportTable">
                            <thead>
                                <tr>
                                    <th>Student ID</th>
                                    <th>Name</th>
                    `;
                    
                    // Add date columns
                    dates.forEach(date => {
                        const formattedDate = new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
                        tableHtml += `<th>${formattedDate}</th>`;
                    });
                    
                    tableHtml += `
                                    <th>Present</th>
                                    <th>Absent</th>
                                    <th>Late</th>
                                    <th>Excused</th>
                                    <th>Attendance %</th>
                                </tr>
                            </thead>
                            <tbody>
                    `;
                    
                    // Add student rows
                    let totalPresent = 0;
                    let totalAbsent = 0;
                    let totalLate = 0;
                    let totalExcused = 0;
                    let totalDays = dates.length * students.length;
                    
                    students.forEach(student => {
                        const studentId = student.id;
                        let presentCount = 0;
                        let absentCount = 0;
                        let lateCount = 0;
                        let excusedCount = 0;
                        
                        tableHtml += `
                            <tr>
                                <td>${student.enrollment_id || 'N/A'}</td>
                                <td class="student-name">${student.full_name}</td>
                        `;

                        // Add status for each date
                        dates.forEach(date => {
                            // Only count as absent if there's an actual record with 'absent' status
                            // Otherwise, mark as 'not recorded' (N/R)
                            let status = 'not-recorded';
                            let displayText = 'N/R';
                            
                            if (attendance[studentId] && attendance[studentId][date]) {
                                status = attendance[studentId][date];
                                displayText = status.charAt(0).toUpperCase();
                                
                                // Count statuses for actual records
                                if (status === 'present') presentCount++;
                                else if (status === 'absent') absentCount++;
                                else if (status === 'late') lateCount++;
                                else if (status === 'excused') excusedCount++;
                            }
                            
                            // Add status cell with appropriate class
                            tableHtml += `<td><span class="status-badge status-${status}">${displayText}</span></td>`;
                        });
                        
                        // Calculate attendance percentage
                        const totalClasses = dates.length;
                        const attendancePercentage = totalClasses > 0 ? Math.round((presentCount / totalClasses) * 100) : 0;
                        
                        // Add summary columns
                        tableHtml += `
                                <td>${presentCount}</td>
                                <td>${absentCount}</td>
                                <td>${lateCount}</td>
                                <td>${excusedCount}</td>
                                <td>${attendancePercentage}%</td>
                            </tr>
                        `;
                        
                        // Add to totals
                        totalPresent += presentCount;
                        totalAbsent += absentCount;
                        totalLate += lateCount;
                        totalExcused += excusedCount;
                    });
                    
                    tableHtml += `
                            </tbody>
                        </table>
                    `;
                    
                    // Display the report
                    reportContent.innerHTML = tableHtml;
                    
                    // Calculate overall attendance percentage
                    const overallAttendance = totalDays > 0 ? Math.round((totalPresent / totalDays) * 100) : 0;
                    
                    // Create summary
                    const summaryHtml = `
                        <div class="summary-item">
                            <h3>Present</h3>
                            <p>${totalPresent}</p>
                        </div>
                        <div class="summary-item">
                            <h3>Absent</h3>
                            <p>${totalAbsent}</p>
                        </div>
                        <div class="summary-item">
                            <h3>Late</h3>
                            <p>${totalLate}</p>
                        </div>
                        <div class="summary-item">
                            <h3>Excused</h3>
                            <p>${totalExcused}</p>
                        </div>
                        <div class="summary-item">
                            <h3>Overall Attendance</h3>
                            <p>${overallAttendance}%</p>
                        </div>
                    `;
                    
                    reportSummary.innerHTML = summaryHtml;
                    attendanceReport.style.display = 'block';
                } else {
                    showAlert(data.message, 'danger');
                }
            })
            .catch(error => {
                generateReportBtn.disabled = false;
                generateReportBtn.textContent = 'Generate Report';
                showAlert('An error occurred while generating the report', 'danger');
                console.error(error);
            });
        });
        
        // Print report
        printReportBtn.addEventListener('click', function() {
            const courseText = reportCourseSelect.options[reportCourseSelect.selectedIndex].text;
            const startDateText = new Date(startDate.value).toLocaleDateString();
            const endDateText = new Date(endDate.value).toLocaleDateString();
            
            // Create a new window for printing
            const printWindow = window.open('', '_blank');
            
            // Write the print content
            printWindow.document.write(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Attendance Report</title>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            margin: 20px;
                        }
                        h1 {
                            text-align: center;
                            margin-bottom: 10px;
                        }
                        .report-info {
                            text-align: center;
                            margin-bottom: 20px;
                        }
                        table {
                            width: 100%;
                            border-collapse: collapse;
                            margin-bottom: 20px;
                        }
                        th, td {
                            border: 1px solid #ddd;
                            padding: 8px;
                            text-align: center;
                        }
                        th {
                            background-color: #f2f2f2;
                        }
                        .student-name {
                            text-align: left;
                        }
                        .status-badge {
                            padding: 2px 5px;
                            border-radius: 3px;
                            font-size: 12px;
                        }
                        .status-present {
                            background-color: #d1fae5;
                        }
                        .status-absent {
                            background-color: #fee2e2;
                        }
                        .status-late {
                            background-color: #fef3c7;
                        }
                        .status-excused {
                            background-color: #e0e7ff;
                        }
                        .summary {
                            display: flex;
                            justify-content: space-around;
                            margin-top: 20px;
                        }
                        .summary-item {
                            text-align: center;
                        }
                        .summary-item h3 {
                            margin: 0;
                            font-size: 14px;
                        }
                        .summary-item p {
                            margin: 5px 0 0 0;
                            font-size: 18px;
                            font-weight: bold;
                        }
                        @media print {
                            .no-print {
                                display: none;
                            }
                        }
                    </style>
                </head>
                <body>
                    <h1>Attendance Report</h1>
                    <div class="report-info">
                        <p><strong>Course:</strong> ${courseText}</p>
                        <p><strong>Period:</strong> ${startDateText} to ${endDateText}</p>
                    </div>
                    
                    ${reportContent.innerHTML}
                    
                    <div class="summary">
                        ${reportSummary.innerHTML}
                    </div>
                    
                    <div class="no-print" style="text-align: center; margin-top: 20px;">
                        <button onclick="window.print()">Print</button>
                        <button onclick="window.close()">Close</button>
                    </div>
                </body>
                </html>
            `);
            
            // Close the document
            printWindow.document.close();
        });
        
        // Export report to CSV
        exportReportBtn.addEventListener('click', function() {
            const table = document.getElementById('reportTable');
            if (!table) {
                showAlert('No report data to export', 'danger');
                return;
            }
            
            // Get course name
            const courseText = reportCourseSelect.options[reportCourseSelect.selectedIndex].text;
            
            // Create CSV content
            let csv = [];
            
            // Add title row
            csv.push(['Attendance Report - ' + courseText]);
            csv.push(['Period: ' + startDate.value + ' to ' + endDate.value]);
            csv.push([]);  // Empty row
            
            // Add header row
            let header = [];
            for (let i = 0; i < table.rows[0].cells.length; i++) {
                header.push(table.rows[0].cells[i].textContent);
            }
            csv.push(header);
            
            // Add data rows
            for (let i = 1; i < table.rows.length; i++) {
                let row = [];
                for (let j = 0; j < table.rows[i].cells.length; j++) {
                    // Get text content, removing any HTML
                    let cellContent = table.rows[i].cells[j].textContent.trim();
                    row.push(cellContent);
                }
                csv.push(row);
            }
            
            // Convert to CSV string
            const csvContent = csv.map(row => row.join(',')).join('\n');
            
            // Create download link
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.setAttribute('href', url);
            link.setAttribute('download', 'attendance_report.csv');
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        });
        
        // Set default dates for report
        const today = new Date();
        const oneMonthAgo = new Date();
        oneMonthAgo.setMonth(today.getMonth() - 1);
        
        startDate.value = oneMonthAgo.toISOString().split('T')[0];
        endDate.value = today.toISOString().split('T')[0];
    });
    </script>
</body>
</html>
