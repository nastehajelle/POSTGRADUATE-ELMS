<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is admin
if (!is_logged_in() || !is_admin()) {
    header("Location: ../auth/login.php");
    exit();
}

// Process AJAX requests for student status management
if (isset($_POST['ajax']) && $_POST['ajax'] == 1) {
    header('Content-Type: application/json');
    
    try {
        if ($_POST['action'] == 'change_student_status' && !empty($_POST['user_id']) && !empty($_POST['new_status'])) {
            $user_id = sanitize_input($_POST['user_id']);
            $new_status = sanitize_input($_POST['new_status']);
            $new_batch_id = isset($_POST['new_batch_id']) ? sanitize_input($_POST['new_batch_id']) : null;
            
            // Get current student status
            $status_query = "SELECT s.status, s.previous_batch_id FROM students s WHERE s.user_id = ?";
            $status_stmt = $conn->prepare($status_query);
            $status_stmt->execute([$user_id]);
            $current_data = $status_stmt->fetch(PDO::FETCH_ASSOC);
            $current_status = $current_data['status'];
            
            // Validate status change using access control function
            include_once '../config/access_control.php';
            if (!can_change_student_status($current_status, $new_status)) {
                throw new Exception("Cannot change status from {$current_status} to {$new_status}");
            }
            
            // Validate required fields for transfer
            if ($new_status === 'transfer' && empty($new_batch_id)) {
                throw new Exception("Batch selection is required for transfer status");
            }
            
            $conn->beginTransaction();
            
            // Handle transfer logic
            if ($new_status === 'transfer' && $new_batch_id) {
                // Get current batch from enrollment
                $current_batch_query = "SELECT batch_id FROM enrollment WHERE user_id = ?";
                $current_batch_stmt = $conn->prepare($current_batch_query);
                $current_batch_stmt->execute([$user_id]);
                $current_batch_id = $current_batch_stmt->fetch(PDO::FETCH_ASSOC)['batch_id'];
                
                // Update enrollment to new batch
                $update_enrollment_query = "UPDATE enrollment SET batch_id = ? WHERE user_id = ?";
                $update_enrollment_stmt = $conn->prepare($update_enrollment_query);
                $update_enrollment_stmt->execute([$new_batch_id, $user_id]);
                
                // Update student record with transfer info
                $update_query = "UPDATE students SET 
                                status = ?, 
                                previous_batch_id = ?, 
                                transfer_date = NOW(), 
                                status_changed_at = NOW(), 
                                status_changed_by = ?, 
                                updated_at = NOW() 
                                WHERE user_id = ?";
                $update_stmt = $conn->prepare($update_query);
                $update_stmt->execute([$new_status, $current_batch_id, $_SESSION['user_id'], $user_id]);
            } else {
                // Regular status update
                $update_query = "UPDATE students SET 
                                status = ?, 
                                status_changed_at = NOW(), 
                                status_changed_by = ?, 
                                updated_at = NOW() 
                                WHERE user_id = ?";
                $update_stmt = $conn->prepare($update_query);
                $update_stmt->execute([$new_status, $_SESSION['user_id'], $user_id]);
            }
            
            $conn->commit();
            
            echo json_encode([
                'success' => true, 
                'message' => "Student status updated to " . ucfirst($new_status),
                'new_status' => $new_status
            ]);
        } else {
            throw new Exception("Invalid action or missing parameters");
        }
    } catch(Exception $e) {
        if ($conn->inTransaction()) {
            $conn->rollBack();
        }
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit();
}

// Initialize filter variables
$filter_batch_id = isset($_GET['batch_id']) ? sanitize_input($_GET['batch_id']) : '';

// Get batch information for display
$batch_info = null;
if (!empty($filter_batch_id)) {
    $batch_query = "SELECT b.name, b.year, p.name as program_name, d.name as department_name 
                    FROM batch b 
                    LEFT JOIN programs p ON b.program_id = p.id 
                    LEFT JOIN departments d ON p.department_id = d.id 
                    WHERE b.id = ?";
    $batch_stmt = $conn->prepare($batch_query);
    $batch_stmt->execute([$filter_batch_id]);
    $batch_info = $batch_stmt->fetch(PDO::FETCH_ASSOC);
}

$students_query = "SELECT u.id as user_id, u.full_name, e.student_id, s.status as student_status,
                          s.status_changed_at, s.transfer_date, s.previous_batch_id,
                          pb.name as previous_batch_name
                   FROM users u 
                   JOIN enrollment e ON u.id = e.user_id 
                   JOIN students s ON u.id = s.user_id
                   LEFT JOIN batch pb ON s.previous_batch_id = pb.id
                   WHERE u.role = 'student'";

$query_params = [];

if (!empty($filter_batch_id)) {
    $students_query .= " AND e.batch_id = ?";
    $query_params[] = $filter_batch_id;
} else {
    // If no batch_id is provided, show error message
    $students_query .= " AND 1 = 0";
}

$students_query .= " ORDER BY e.student_id ASC";

$students_stmt = $conn->prepare($students_query);
$students_stmt->execute($query_params);
$students = $students_stmt->fetchAll(PDO::FETCH_ASSOC);

$batches_query = "SELECT id, name, year FROM batch WHERE status = 'active' ORDER BY year DESC, name";
$batches_stmt = $conn->prepare($batches_query);
$batches_stmt->execute();
$available_batches = $batches_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students in Batch - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/modal.css">
    <link rel="stylesheet" href="../assets/css/users.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>Students in Batch</h1>
                <?php if ($batch_info): ?>
                     Enhanced batch information display 
                    <div class="batch-info">
                        <h3><?php echo htmlspecialchars($batch_info['name']); ?> (<?php echo $batch_info['year']; ?>)</h3>
                        <p><strong>Program:</strong> <?php echo htmlspecialchars($batch_info['program_name']); ?></p>
                        <p><strong>Department:</strong> <?php echo htmlspecialchars($batch_info['department_name']); ?></p>
                    </div>
                <?php elseif (!empty($filter_batch_id)): ?>
                    <p>Batch not found.</p>
                <?php else: ?>
                    <p class="text-danger">No batch ID provided. Please select a batch from the <a href="batches.php">Batch Management</a> page.</p>
                <?php endif; ?>
                
                <div class="admin-header-right">
                    <a href="batches.php" class="btn btn-secondary">Back to Batches</a>
                </div>
            </div>
            
            <div id="alertContainer"></div>
            
             Students List 
            <div class="card">
                <div class="card-body">
                    <table class="data-table" id="studentsTable">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Full Name</th>
                                <th>Status</th>
                                 Added status info and transfer history columns 
                                <th>Status Info</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($students) > 0): ?>
                                <?php foreach ($students as $student): ?>
                                <tr>
                                    <td><?php echo $student['student_id'] ? $student['student_id'] : 'N/A'; ?></td>
                                    <td><?php echo htmlspecialchars($student['full_name']); ?></td>
                                     Updated status display with new status options 
                                    <td>
                                        <span class="status-badge <?php echo $student['student_status']; ?>">
                                            <?php echo ucfirst($student['student_status']); ?>
                                        </span>
                                    </td>
                                     Added status information column 
                                    <td class="status-info">
                                        <?php if ($student['student_status'] === 'transfer' && $student['previous_batch_name']): ?>
                                            <small>From: <?php echo htmlspecialchars($student['previous_batch_name']); ?></small><br>
                                            <small>Date: <?php echo date('M d, Y', strtotime($student['transfer_date'])); ?></small>
                                        <?php elseif ($student['status_changed_at']): ?>
                                            <small>Changed: <?php echo date('M d, Y', strtotime($student['status_changed_at'])); ?></small>
                                        <?php else: ?>
                                            <small>-</small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                         Updated actions to include status change dropdown 
                                        <div class="action-buttons">
                                            <button class="btn btn-xs btn-outline change-status-btn" 
                                                    data-id="<?php echo $student['user_id']; ?>" 
                                                    data-status="<?php echo $student['student_status']; ?>"
                                                    data-name="<?php echo htmlspecialchars($student['full_name']); ?>"
                                                    title="Change Student Status">
                                                <i class="fas fa-edit"></i> Status
                                            </button>
                                            <a href="users.php?action=edit&id=<?php echo $student['user_id']; ?>" 
                                               class="btn btn-sm btn-primary">Edit</a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center">
                                        <?php if (empty($filter_batch_id)): ?>
                                            No batch selected.
                                        <?php else: ?>
                                            No students found for this batch.
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
     Added status change modal 
    <div id="statusModalBackdrop" class="modal-backdrop"></div>
    <div id="statusModalContainer" class="modal-container">
        <div class="modal-header">
            <h2>Change Student Status</h2>
            <button class="modal-close" id="closeStatusModal">&times;</button>
        </div>
        <div class="modal-body">
            <form id="statusChangeForm">
                <input type="hidden" id="student_user_id" name="user_id">
                
                <div class="form-group">
                    <label>Student:</label>
                    <span id="student_name_display"></span>
                </div>
                
                <div class="form-group">
                    <label>Current Status:</label>
                    <span id="current_status_display"></span>
                </div>
                
                <div class="form-group">
                    <label for="new_status">New Status:</label>
                    <select id="new_status" name="new_status" required>
                        <option value="">Select Status</option>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                        <option value="graduated">Graduated</option>
                        <option value="dead">Dead</option>
                        <option value="transfer">Transfer</option>
                    </select>
                </div>
                
                <div class="form-group" id="batch_selection_group" style="display: none;">
                    <label for="new_batch_id">Transfer to Batch:</label>
                    <select id="new_batch_id" name="new_batch_id">
                        <option value="">Select Batch</option>
                        <?php foreach ($available_batches as $batch): ?>
                            <option value="<?php echo $batch['id']; ?>">
                                <?php echo htmlspecialchars($batch['name']) . ' (' . $batch['year'] . ')'; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="status-change-warnings">
                    <div id="graduated_warning" class="alert alert-warning" style="display: none;">
                        <i class="fas fa-exclamation-triangle"></i>
                        <strong>Warning:</strong> Graduated students lose access to all academic features and cannot be reactivated or transferred.
                    </div>
                    <div id="dead_warning" class="alert alert-danger" style="display: none;">
                        <i class="fas fa-exclamation-circle"></i>
                        <strong>Warning:</strong> Dead status permanently locks the account. This action cannot be undone.
                    </div>
                    <div id="transfer_info" class="alert alert-info" style="display: none;">
                        <i class="fas fa-info-circle"></i>
                        <strong>Note:</strong> Transfer will move the student to a new batch and update their course access.
                    </div>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" id="cancelStatusChange">Cancel</button>
            <button class="btn btn-primary" id="confirmStatusChange">Update Status</button>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // DOM Elements
        const alertContainer = document.getElementById('alertContainer');
        const statusModalBackdrop = document.getElementById('statusModalBackdrop');
        const statusModalContainer = document.getElementById('statusModalContainer');
        const newStatusSelect = document.getElementById('new_status');
        const batchSelectionGroup = document.getElementById('batch_selection_group');
        
        // Show alert message
        function showAlert(message, type = 'success') {
            const alert = document.createElement('div');
            alert.className = `alert alert-${type}`;
            alert.textContent = message;
            
            alertContainer.appendChild(alert);
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                alert.remove();
            }, 5000);
        }
        
        // Open status modal
        function openStatusModal() {
            statusModalBackdrop.classList.add('show');
            statusModalContainer.classList.add('show');
        }

        // Close status modal
        function closeStatusModal() {
            statusModalBackdrop.classList.remove('show');
            statusModalContainer.classList.remove('show');
            document.getElementById('statusChangeForm').reset();
            batchSelectionGroup.style.display = 'none';
            hideAllWarnings();
        }
        
        // Hide all warning messages
        function hideAllWarnings() {
            document.getElementById('graduated_warning').style.display = 'none';
            document.getElementById('dead_warning').style.display = 'none';
            document.getElementById('transfer_info').style.display = 'none';
        }
        
        // Show/hide batch selection and warnings based on status
        newStatusSelect.addEventListener('change', function() {
            const selectedStatus = this.value;
            hideAllWarnings();
            
            if (selectedStatus === 'transfer') {
                batchSelectionGroup.style.display = 'block';
                document.getElementById('transfer_info').style.display = 'block';
                document.getElementById('new_batch_id').required = true;
            } else {
                batchSelectionGroup.style.display = 'none';
                document.getElementById('new_batch_id').required = false;
            }
            
            if (selectedStatus === 'graduated') {
                document.getElementById('graduated_warning').style.display = 'block';
            } else if (selectedStatus === 'dead') {
                document.getElementById('dead_warning').style.display = 'block';
            }
        });
        
        // Close modal events
        document.getElementById('closeStatusModal').addEventListener('click', closeStatusModal);
        document.getElementById('cancelStatusChange').addEventListener('click', closeStatusModal);
        statusModalBackdrop.addEventListener('click', closeStatusModal);
        
        // Change status button click
        document.querySelectorAll('.change-status-btn').forEach(button => {
            button.addEventListener('click', function() {
                const userId = this.getAttribute('data-id');
                const currentStatus = this.getAttribute('data-status');
                const studentName = this.getAttribute('data-name');
                
                // Fill modal with student data
                document.getElementById('student_user_id').value = userId;
                document.getElementById('student_name_display').textContent = studentName;
                document.getElementById('current_status_display').innerHTML = 
                    `<span class="status-badge ${currentStatus}">${currentStatus.charAt(0).toUpperCase() + currentStatus.slice(1)}</span>`;
                
                // Filter status options based on current status
                const statusOptions = newStatusSelect.querySelectorAll('option');
                statusOptions.forEach(option => {
                    if (option.value === '') return; // Keep the default option
                    
                    // Disable invalid transitions
                    if ((currentStatus === 'graduated' && ['active', 'inactive', 'transfer'].includes(option.value)) ||
                        (currentStatus === 'dead' && option.value !== 'dead')) {
                        option.disabled = true;
                        option.style.display = 'none';
                    } else {
                        option.disabled = false;
                        option.style.display = 'block';
                    }
                });
                
                openStatusModal();
            });
        });
        
        // Confirm status change
        document.getElementById('confirmStatusChange').addEventListener('click', function() {
            const formData = new FormData(document.getElementById('statusChangeForm'));
            formData.append('ajax', 1);
            formData.append('action', 'change_student_status');
            
            // Validate required fields
            if (!formData.get('new_status')) {
                showAlert('Please select a new status', 'danger');
                return;
            }
            
            if (formData.get('new_status') === 'transfer' && !formData.get('new_batch_id')) {
                showAlert('Please select a batch for transfer', 'danger');
                return;
            }
            
            // Set loading state
            this.disabled = true;
            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Updating...';
            
            fetch('view_students.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showAlert(data.message, 'success');
                    closeStatusModal();
                    // Reload page to reflect changes
                    setTimeout(() => {
                        location.reload();
                    }, 1000);
                } else {
                    showAlert(data.message, 'danger');
                }
                
                this.disabled = false;
                this.innerHTML = 'Update Status';
            })
            .catch(error => {
                this.disabled = false;
                this.innerHTML = 'Update Status';
                showAlert('An error occurred while updating student status.', 'danger');
            });
        });
    });
    </script>
</body>
</html>
