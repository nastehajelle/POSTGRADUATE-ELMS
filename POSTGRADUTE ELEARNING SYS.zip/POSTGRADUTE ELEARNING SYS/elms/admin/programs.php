<?php
session_start();
include_once '../config/init.php';

// Check if user is logged in and is admin
if (!is_logged_in() || !is_admin()) {
    header("Location: ../auth/login.php");
    exit();
}

// Process AJAX requests
if (isset($_POST['ajax']) && $_POST['ajax'] == 1) {
    header('Content-Type: application/json');
    
    try {
        if ($_POST['action'] == 'add' || $_POST['action'] == 'edit') {
            // Sanitize input
            $program_name = sanitize_input($_POST['program_name']);
            $program_code = sanitize_input($_POST['program_code']);
            $description  = sanitize_input($_POST['description']);
            $duration     = sanitize_input($_POST['duration']);
            $monthly_fee  = !empty($_POST['monthly_fee']) ? floatval($_POST['monthly_fee']) : null;
            $status       = sanitize_input($_POST['status']);
            
            // Validate input
            if (empty($program_name) || empty($program_code)) {
                throw new Exception("Please fill in all required fields");
            }
            
            if ($monthly_fee !== null && $monthly_fee < 0) {
                throw new Exception("Monthly fee cannot be negative");
            }
            
            // Begin transaction
            $conn->beginTransaction();
            
            if ($_POST['action'] == 'edit' && !empty($_POST['program_id'])) {
                // Update existing program
                $program_id = sanitize_input($_POST['program_id']);
                
                $current_fee_query = "SELECT monthly_fee FROM programs WHERE id = ?";
                $current_fee_stmt  = $conn->prepare($current_fee_query);
                $current_fee_stmt->execute([$program_id]);
                $current_fee = $current_fee_stmt->fetch(PDO::FETCH_ASSOC)['monthly_fee'];
                
                // Check if code already exists (excluding current program)
                $check_query = "SELECT COUNT(*) as count FROM programs WHERE code = ? AND id != ?";
                $check_stmt  = $conn->prepare($check_query);
                $check_stmt->execute([$program_code, $program_id]);
                $count = $check_stmt->fetch(PDO::FETCH_ASSOC)['count'];
                
                if ($count > 0) {
                    throw new Exception("Program code already exists");
                }
                
                $query = "UPDATE programs 
                          SET name = ?, code = ?, description = ?, duration = ?, monthly_fee = ?, status = ?, updated_at = NOW() 
                          WHERE id = ?";
                $stmt = $conn->prepare($query);
                $stmt->execute([$program_name, $program_code, $description, $duration, $monthly_fee, $status, $program_id]);
                
                if ($current_fee != $monthly_fee) {
                    $history_query = "INSERT INTO program_fee_history (program_id, old_fee, new_fee, changed_by, reason) 
                                      VALUES (?, ?, ?, ?, ?)";
                    $history_stmt = $conn->prepare($history_query);
                    $history_stmt->execute([$program_id, $current_fee, $monthly_fee, $_SESSION['user_id'], 'Fee updated via admin panel']);
                }
                
                $message = "Program updated successfully";
            } else {
                // Check if code already exists
                $check_query = "SELECT COUNT(*) as count FROM programs WHERE code = ?";
                $check_stmt  = $conn->prepare($check_query);
                $check_stmt->execute([$program_code]);
                $count = $check_stmt->fetch(PDO::FETCH_ASSOC)['count'];
                
                if ($count > 0) {
                    throw new Exception("Program code already exists");
                }
                
                $query = "INSERT INTO programs (name, code, description, duration, monthly_fee, status, created_at) 
                          VALUES (?, ?, ?, ?, ?, ?, NOW())";
                $stmt = $conn->prepare($query);
                $stmt->execute([$program_name, $program_code, $description, $duration, $monthly_fee, $status]);
                
                if ($monthly_fee !== null) {
                    $new_program_id = $conn->lastInsertId();
                    $history_query = "INSERT INTO program_fee_history (program_id, old_fee, new_fee, changed_by, reason) 
                                      VALUES (?, ?, ?, ?, ?)";
                    $history_stmt = $conn->prepare($history_query);
                    $history_stmt->execute([$new_program_id, null, $monthly_fee, $_SESSION['user_id'], 'Initial fee set during program creation']);
                }
                
                $message = "Program created successfully";
            }
            
            // Commit transaction
            $conn->commit();
            
            echo json_encode(['success' => true, 'message' => $message]);
        } 
        elseif ($_POST['action'] == 'delete' && !empty($_POST['program_id'])) {
            $program_id = sanitize_input($_POST['program_id']);
            
            // Check if program is being used in batches
            $check_query = "SELECT COUNT(*) as count FROM batch WHERE program_id = ?";
            $check_stmt  = $conn->prepare($check_query);
            $check_stmt->execute([$program_id]);
            $count = $check_stmt->fetch(PDO::FETCH_ASSOC)['count'];
            
            if ($count > 0) {
                throw new Exception("Cannot delete program because it is associated with batches");
            }
            
            // Check if program is being used in enrollments
            $check_query = "SELECT COUNT(*) as count FROM enrollment WHERE program_id = ?";
            $check_stmt  = $conn->prepare($check_query);
            $check_stmt->execute([$program_id]);
            $count = $check_stmt->fetch(PDO::FETCH_ASSOC)['count'];
            
            if ($count > 0) {
                throw new Exception("Cannot delete program because it is associated with student enrollments");
            }
            
            // Check if program is being used in courses
            $check_query = "SELECT COUNT(*) as count FROM course WHERE program_id = ?";
            $check_stmt  = $conn->prepare($check_query);
            $check_stmt->execute([$program_id]);
            $count = $check_stmt->fetch(PDO::FETCH_ASSOC)['count'];
            
            if ($count > 0) {
                throw new Exception("Cannot delete program because it is associated with courses");
            }
            
            // Delete program
            $query = "DELETE FROM programs WHERE id = ?";
            $stmt  = $conn->prepare($query);
            $stmt->execute([$program_id]);
            echo json_encode(['success' => true, 'message' => "Program deleted successfully"]);
        }
        elseif ($_POST['action'] == 'get' && !empty($_POST['program_id'])) {
            $program_id = sanitize_input($_POST['program_id']);
            $query = "SELECT * FROM programs WHERE id = ?";
            $stmt  = $conn->prepare($query);
            $stmt->execute([$program_id]);
            
            if ($stmt->rowCount() > 0) {
                $program = $stmt->fetch(PDO::FETCH_ASSOC);
                echo json_encode(['success' => true, 'data' => $program]);
            } else {
                throw new Exception("Program not found");
            }
        }
        else {
            throw new Exception("Invalid action");
        }
    } catch(Exception $e) {
        // Rollback transaction if necessary
        if ($conn->inTransaction()) {
            $conn->rollBack();
        }
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit();
}


// Get all programs for dropdown
$programs_query = "SELECT id, name FROM departments WHERE status = 'active' ORDER BY name ASC";
$programs_stmt = $conn->prepare($programs_query);
$programs_stmt->execute();
$programs = $programs_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all departments for listing
$departments_query = "SELECT p.*, d.name as department_name 
                     FROM programs p 
                     JOIN departments d  ON p.department_id = d.id 
                     ORDER BY d.name ASC, p.name ASC";
$departments_stmt = $conn->prepare($departments_query);
$departments_stmt->execute();
$departments = $departments_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get statistics for each department
$department_stats = [];
foreach ($departments as $department) {
    // Count batches
    $batch_query = "SELECT COUNT(*) as batch_count FROM batch WHERE program_id = ?";
    $batch_stmt = $conn->prepare($batch_query);
    $batch_stmt->execute([$department['id']]);
    $batch_count = $batch_stmt->fetch(PDO::FETCH_ASSOC)['batch_count'];
    
    // Count students
    $student_query = "SELECT COUNT(*) as student_count FROM enrollment WHERE program_id = ?";
    $student_stmt = $conn->prepare($student_query);
    $student_stmt->execute([$department['id']]);
    $student_count = $student_stmt->fetch(PDO::FETCH_ASSOC)['student_count'];
    
    // Count courses
    $course_query = "SELECT COUNT(*) as course_count FROM course WHERE program_id = ?";
    $course_stmt = $conn->prepare($course_query);
    $course_stmt->execute([$department['id']]);
    $course_count = $course_stmt->fetch(PDO::FETCH_ASSOC)['course_count'];
    
    $department_stats[$department['id']] = [
        'batches' => $batch_count,
        'students' => $student_count,
        'courses' => $course_count
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage programs - Benadir University LMS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/modal.css">
    <?php echo FONT_AWESOME_CSS; ?>
</head>
<body>
    <div class="admin-container">
        <?php include_once '../includes/sidebar.php'; ?>
        
        <div class="admin-content">
            <div class="admin-header">
                <h1>Manage Programs</h1>
                
                <div class="admin-header-right">
                    <button class="btn btn-primary" id="addDepartmentBtn">Add New Program</button>
                </div>
            </div>
            
            <div id="alertContainer"></div>
            
            <!-- Filter Controls -->
            <div class="filter-controls">
                <div class="filter-item">
                    <label for="programFilter">Filter by Department:</label>
                    <select id="programFilter">
                        <option value="">All departments</option>
                        <?php foreach ($programs as $program): ?>
                            <option value="<?php echo $program['name']; ?>"><?php echo $program['name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="filter-item">
                    <label for="statusFilter">Filter by Status:</label>
                    <select id="statusFilter">
                        <option value="">All Status</option>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
                <div class="filter-item">
                    <label for="searchInput">Search:</label>
                    <input type="text" id="searchInput" placeholder="Department name or code...">
                </div>
            </div>
            
            <!-- Departments List -->
            <div class="card">
                <div class="card-body">
                    <table class="data-table" id="departmentsTable">
                        <thead>
                            <tr>
                                <th>program Name</th>
                                <th>Code</th>
                                <th>departments</th>
                                <th>Duration</th>
                                <th>Monthly Fee</th>
                                <th>Batches</th>
                                <th>Students</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($departments) > 0): ?>
                                <?php foreach ($departments as $department): ?>
                                <tr data-program="<?php echo $department['department_name']; ?>" data-status="<?php echo $department['status']; ?>">
                                    <td><?php echo $department['name']; ?></td>
                                    <td><?php echo $department['code']; ?></td>
                                    <td><?php echo $department['department_name']; ?></td>
                                    <td><?php echo $department['duration'] ? $department['duration'] : 'Not specified'; ?></td>
                                    <td><?php echo $department['monthly_fee'] ? '$' . number_format($department['monthly_fee'], 2) : 'Not set'; ?></td>
                                    <td><?php echo $department_stats[$department['id']]['batches']; ?></td>
                                    <td><?php echo $department_stats[$department['id']]['students']; ?></td>
                                    <td>
                                        <span class="status-badge <?php echo $department['status']; ?>">
                                            <?php echo ucfirst($department['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-primary edit-department-btn" data-id="<?php echo $department['id']; ?>">Edit</button>
                                        <button class="btn btn-sm btn-danger delete-department-btn" data-id="<?php echo $department['id']; ?>">Delete</button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="9" class="text-center">No program found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Department Modal -->
    <div id="departmentModalBackdrop" class="modal-backdrop"></div>
    <div id="departmentModalContainer" class="modal-container">
        <div class="modal-header">
            <h2 id="departmentModalTitle">Add New program</h2>
            <button class="modal-close" id="closeDepartmentModal">&times;</button>
        </div>
        <div class="modal-body">
            <form id="departmentForm">
                <input type="hidden" id="program_id" name="program_id">
                <input type="hidden" id="form_action" name="action" value="add">
                <input type="hidden" name="ajax" value="1">
                
                <div class="form-row">
                    <label for="department_id">department <span class="required">*</span></label>
                    <select id="department_id" name="department_id" required>
                        <option value="">Select department</option>
                        <?php foreach ($programs as $program): ?>
                            <option value="<?php echo $program['id']; ?>"><?php echo $program['name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-row">
                    <label for="program_name">program Name <span class="required">*</span></label>
                    <input type="text" id="program_name" name="program_name" required>
                </div>
                
                <div class="form-row">
                    <label for="program_code">program Code <span class="required">*</span></label>
                    <input type="text" id="program_code" name="program_code" required>
                    <small>A unique code for the program (e.g., SE, NS)</small>
                </div>
                
                <div class="form-row">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="4"></textarea>
                </div>
                
                <div class="form-row">
                    <label for="duration">Duration</label>
                    <input type="text" id="duration" name="duration" placeholder="e.g., 4 Years, 2 Semesters, 18 Months">
                    <small>Specify the duration of the program (e.g., 4 Years, 2 Semesters, 18 Months)</small>
                </div>
                
                <!-- Added Monthly Fee input field -->
                <div class="form-row">
                    <label for="monthly_fee">Monthly Fee</label>
                    <input type="number" id="monthly_fee" name="monthly_fee" step="0.01" min="0" placeholder="e.g., 500.00">
                    <small>Enter the monthly fee amount for this program (leave empty if not applicable)</small>
                </div>
                
                <div class="form-row">
                    <label for="status">Status</label>
                    <select id="status" name="status" required>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" id="cancelDepartmentBtn">Cancel</button>
            <button class="btn btn-primary" id="saveDepartmentBtn">Save program</button>
        </div>
    </div>
    
    <!-- Delete Modal -->
    <div id="deleteModalBackdrop" class="modal-backdrop"></div>
    <div id="deleteModalContainer" class="modal-container">
        <div class="modal-header">
            <h2>Delete program</h2>
            <button class="modal-close" id="closeDeleteModal">&times;</button>
        </div>
        <div class="modal-body">
            <p>Are you sure you want to delete this program? This action cannot be undone.</p>
            <p class="text-danger"><strong>Note:</strong> program with associated batches, courses, or student enrollments cannot be deleted.</p>
            <input type="hidden" id="delete_department_id">
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" id="cancelDeleteBtn">Cancel</button>
            <button class="btn btn-danger" id="confirmDeleteBtn">Delete</button>
        </div>
    </div>
    
    <script src="../assets/js/theme.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // DOM Elements
        const alertContainer = document.getElementById('alertContainer');
        const departmentModalBackdrop = document.getElementById('departmentModalBackdrop');
        const departmentModalContainer = document.getElementById('departmentModalContainer');
        const deleteModalBackdrop = document.getElementById('deleteModalBackdrop');
        const deleteModalContainer = document.getElementById('deleteModalContainer');
        const departmentForm = document.getElementById('departmentForm');
        const departmentModalTitle = document.getElementById('departmentModalTitle');
        const saveDepartmentBtn = document.getElementById('saveDepartmentBtn');
        
        // Filter elements
        const programFilter = document.getElementById('programFilter');
        const statusFilter = document.getElementById('statusFilter');
        const searchInput = document.getElementById('searchInput');
        
        // Show alert message
        function showAlert(message, type = 'success') {
            const alert = document.createElement('div');
            alert.className = `alert alert-${type}`;
            alert.textContent = message;
            
            alertContainer.appendChild(alert);
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                alert.remove();
            }, 5000);
        }
        
        // Open department modal
        function openDepartmentModal() {
            departmentModalBackdrop.classList.add('show');
            departmentModalContainer.classList.add('show');
        }
        
        // Close department modal
        function closeDepartmentModal() {
            departmentModalBackdrop.classList.remove('show');
            departmentModalContainer.classList.remove('show');
        }
        
        // Open delete modal
        function openDeleteModal() {
            deleteModalBackdrop.classList.add('show');
            deleteModalContainer.classList.add('show');
        }
        
        // Close delete modal
        function closeDeleteModal() {
            deleteModalBackdrop.classList.remove('show');
            deleteModalContainer.classList.remove('show');
        }
        
        // Close department modal when clicking on backdrop
        departmentModalBackdrop.addEventListener('click', closeDepartmentModal);
        
        // Close delete modal when clicking on backdrop
        deleteModalBackdrop.addEventListener('click', closeDeleteModal);
        
        // Add Department button click
        document.getElementById('addDepartmentBtn').addEventListener('click', function() {
            // Reset form
            departmentForm.reset();
            document.getElementById('department_id').value = '';
            document.getElementById('form_action').value = 'add';
            
            // Update modal title and button
            departmentModalTitle.textContent = 'Add New program';
            saveDepartmentBtn.textContent = 'Create program';
            
            // Open modal
            openDepartmentModal();
        });
        
        // Close department modal
        document.getElementById('closeDepartmentModal').addEventListener('click', closeDepartmentModal);
        document.getElementById('cancelDepartmentBtn').addEventListener('click', closeDepartmentModal);
        
        // Edit department button click
        document.querySelectorAll('.edit-department-btn').forEach(button => {
            button.addEventListener('click', function() {
                const departmentId = this.getAttribute('data-id');
                
                // Set loading state
                button.disabled = true;
                button.innerHTML = 'Loading...';
                
                // Fetch department data
                const formData = new FormData();
                formData.append('ajax', 1);
                formData.append('action', 'get');
                formData.append('program_id', departmentId);
                
                fetch('programs.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    button.disabled = false;
                    button.innerHTML = 'Edit';
                    
                    if (data.success) {
                        const department = data.data;
                        
                        // Fill form with department data
                        document.getElementById('program_id').value = department.id;
                        document.getElementById('form_action').value = 'edit';
                        document.getElementById('department_id').value = department.department_id;
                        document.getElementById('program_name').value = department.name;
                        document.getElementById('program_code').value = department.code;
                        document.getElementById('description').value = department.description;
                        document.getElementById('duration').value = department.duration || '';
                        document.getElementById('monthly_fee').value = department.monthly_fee || '';
                        document.getElementById('status').value = department.status;
                        
                        // Update modal title and button
                        departmentModalTitle.textContent = 'Edit program';
                        saveDepartmentBtn.textContent = 'Update program';
                        
                        // Open modal
                        openDepartmentModal();
                    } else {
                        showAlert(data.message, 'danger');
                    }
                })
                .catch(error => {
                    button.disabled = false;
                    button.innerHTML = 'Edit';
                    showAlert('An error occurred while fetching program data.', 'danger');
                });
            });
        });
        
        // Delete department button click
        document.querySelectorAll('.delete-department-btn').forEach(button => {
            button.addEventListener('click', function() {
                const departmentId = this.getAttribute('data-id');
                document.getElementById('delete_department_id').value = departmentId;
                
                // Open delete modal
                openDeleteModal();
            });
        });
        
        // Save department form
        saveDepartmentBtn.addEventListener('click', function() {
            // Check form validity
            if (!departmentForm.checkValidity()) {
                departmentForm.reportValidity();
                return;
            }
            
            // Disable button and show loading
            saveDepartmentBtn.disabled = true;
            saveDepartmentBtn.textContent = 'Saving...';
            
            // Prepare form data
            const formData = new FormData(departmentForm);
            
            // Send AJAX request
            fetch('programs.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                saveDepartmentBtn.disabled = false;
                saveDepartmentBtn.textContent = document.getElementById('form_action').value === 'add' ? 'Create Department' : 'Update Department';
                
                if (data.success) {
                    // Close modal and show success message
                    closeDepartmentModal();
                    showAlert(data.message, 'success');
                    
                    // Reload page after a short delay
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);
                } else {
                    // Show error
                    showAlert(data.message, 'danger');
                }
            })
            .catch(error => {
                saveDepartmentBtn.disabled = false;
                saveDepartmentBtn.textContent = document.getElementById('form_action').value === 'add' ? 'Create Department' : 'Update Department';
                showAlert('An error occurred while submitting the form.', 'danger');
            });
        });
        
        // Confirm delete department
        document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
            const departmentId = document.getElementById('delete_department_id').value;
            const button = this;
            
            // Disable button and show loading
            button.disabled = true;
            button.textContent = 'Deleting...';
            
            const formData = new FormData();
            formData.append('ajax', 1);
            formData.append('action', 'delete');
            formData.append('program_id', departmentId);
            
            fetch('programs.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                button.disabled = false;
                button.textContent = 'Delete';
                
                if (data.success) {
                    // Close modal and show success message
                    closeDeleteModal();
                    showAlert(data.message, 'success');
                    
                    // Reload page after a short delay
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);
                } else {
                    // Show error
                    showAlert(data.message, 'danger');
                }
            })
            .catch(error => {
                button.disabled = false;
                button.textContent = 'Delete';
                showAlert('An error occurred while deleting the program.', 'danger');
            });
        });
        
        // Filter functionality
        function applyFilters() {
            const programValue = programFilter.value;
            const statusValue = statusFilter.value;
            const searchValue = searchInput.value.toLowerCase();
            
            const rows = document.querySelectorAll('#departmentsTable tbody tr');
            
            rows.forEach(row => {
                const program = row.getAttribute('data-program');
                const status = row.getAttribute('data-status');
                const name = row.cells[0].textContent.toLowerCase();
                const code = row.cells[1].textContent.toLowerCase();
                
                const programMatch = !programValue || program === programValue;
                const statusMatch = !statusValue || status === statusValue;
                const searchMatch = !searchValue || 
                                   name.includes(searchValue) || 
                                   code.includes(searchValue);
                
                if (programMatch && statusMatch && searchMatch) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }
        
        // Add event listeners for filters
        programFilter.addEventListener('change', applyFilters);
        statusFilter.addEventListener('change', applyFilters);
        searchInput.addEventListener('input', applyFilters);
    });
    </script>
</body>
</html>
