<?php
// Thesis Notification Cleanup Script
// Run this script periodically (e.g., via cron job) to clean up old notifications

include_once '../config/init.php';
include_once '../includes/thesis-notifications.php';

echo "Starting thesis notification cleanup...\n";

try {
    // Clean up notifications older than 6 months
    $result = cleanupOldThesisNotifications($conn);
    
    if ($result) {
        echo "Successfully cleaned up old thesis notifications.\n";
        
        // Get count of remaining notifications
        $count_query = "SELECT COUNT(*) as count FROM thesis_notifications";
        $count_stmt = $conn->prepare($count_query);
        $count_stmt->execute();
        $count = $count_stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        echo "Remaining notifications: {$count}\n";
    } else {
        echo "Failed to clean up old notifications.\n";
    }
    
} catch (Exception $e) {
    echo "Error during cleanup: " . $e->getMessage() . "\n";
}

echo "Cleanup completed.\n";
?>
